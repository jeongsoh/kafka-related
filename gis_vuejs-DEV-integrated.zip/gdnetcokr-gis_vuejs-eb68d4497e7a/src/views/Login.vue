<template lang="pug">
.main-login
  .bg-frame.dfr.jcc
    video.video-login(id="login-video-container" autoplay loop muted="muted")
      source(:src="require('@/assets/img/login/intro_motion.ogg')" type="video/mp4")
    .login-frame.dfr.jcfe
      form.input-frame.dfc.jcfe#signin(action='javascript:;')
        h1 LOGIN
        p {{area}} 도로조명 관제 시스템
        hr
        .input_container
          i.fas.fa-envelope
          input.input_field#inputAccount(type="text" placeholder="ID" required='')
        .input_container
          i.fas.fa-lock
          input.input_field#inputAccountPW(type="password" placeholder="PW" required='')
        p.Forward Forward by. Guardian E&G
        input.btn.btn--submit.primary(type='submit' value='Login')
</template>

<script>
import Vue from "vue";
import area from "@/assets/json/area.json";

export default {
  data() {
    return {
      CACHE_VAL_ID: "__ID__",
      CACHE_TTL_KEY: "__TTL__",
      CACHE_API_KEY: "__APIKEY__",
      CACHE_VAL_JSON_PREFIX: "_JSON_:",
      CACHE_AREA_NAME: "__AREANAME__",
      code: ""
    };
  },
  computed: {
    area() {
      // NOTE :: 로그인 이후로는 vuex의 데이터에 따라 관제명이 바뀜
      if (this.$store.getters.config_area == "guardian") {
        return "가디언";
      } else {
        return this.code[this.$store.getters.config_area];
      }
    }
  },
  methods: {},
  updated() {
    // NOTE :: 로그인 화면 자동 영상
    var video = document.getElementById("login-video-container");
    var playPromise = video.play();

    if (playPromise !== null) {
      playPromise.catch(() => {
        video.play();
      });
    }
  },
  mounted() {
    this.code = JSON.parse(JSON.stringify(area));
    this.$store.commit("reset");
    var vm = this;
    import("@/assets/js/sha1.js").then(sha => {
      if (this.$_API_GET_CACHE(vm.CACHE_API_KEY) != undefined) {
        this.$_API_POST("login").then(function(res) {
          vm.$router.push({
            name: "Maps"
          });
          window.loginCheck = true;
        });
      }
      var user_id = this.$_API_GET_CACHE(vm.CACHE_VAL_ID);

      if (user_id != undefined) {
        $("#inputAccount").val(user_id);
      }

      $("#signin").submit(function(event) {
        // TODO :: 스피너는 기존꺼 넣다보니 기존말고 vue용 스피너를 넣는게 좋아보임. 당장 중요한것아니니 추후 작업 진행
        var hash = sha1.create();
        var day = new Date();
        // day.setHours(0);
        day.setMinutes(0);
        day.setSeconds(0);
        day.setMilliseconds(0);
        day /= 1000;
        hash.update(day + $("#inputAccountPW").val());
        $("#inputAccountPW").val("");
        var nextDay = new Date();
        nextDay.setHours(0);
        nextDay.setMinutes(0);
        nextDay.setSeconds(0);
        nextDay.setMilliseconds(0);
        nextDay.setDate(nextDay.getDate() + 1);
        var remainTime = Math.floor(nextDay.getTime() - Date.now());
        console.log("id", $("#inputAccount").val());
        console.log("pw", hash.hex());
        vm.$_API_POST("signin", {
          id: $("#inputAccount").val(),
          pw: hash.hex()
        })
          .then(function(res) {
            console.log("login data", res);
            vm.$_API_SET_CACHE(
              vm.CACHE_API_KEY,
              res.data.access_key,
              remainTime
            );
            // NOTE :: BE 설정 저장
            vm.$_API_SET_CACHE(vm.CACHE_VAL_ID, $("#inputAccount").val());
            vm.$_API_SET_CACHE(vm.CACHE_AREA_NAME, res.data.AREA_NAME);
            if (res.data.filter_1 != undefined) {
              vm.$store.commit("filter1", res.data.filter_1);
            }
            if (res.data.filter_2 != undefined) {
              vm.$store.commit("filter2", res.data.filter_2);
            }
            if (res.data.AREA_NAME != undefined) {
              vm.$store.commit("config_area", res.data.AREA_NAME);
            }
            if (res.data.S3_PATH != undefined) {
              vm.$store.commit("config_s3_path", res.data.S3_PATH);
            }
            if (res.data.START_LNG != undefined) {
              vm.$store.commit("config_s3_base", res.data.S3_BASE);
            }
            if (res.data.START_LAT != undefined) {
              vm.$store.commit("config_lat", res.data.START_LAT);
            }
            if (res.data.START_LNG != undefined) {
              vm.$store.commit("config_lng", res.data.START_LNG);
            }
            if (res.data.DEFAULT_ON_DEVIATION != undefined) {
              vm.$store.commit("config_on_deviation", res.data.DEFAULT_ON_DEVIATION);
            }
            if (res.data.DEFAULT_OFF_DEVIATION != undefined) {
              vm.$store.commit("config_off_deviation", res.data.DEFAULT_OFF_DEVIATION);
            }
            // SetBasicCoordinate(res.data.START_LAT, res.data.START_LNG);
            vm.$router.push({
              name: "Maps"
            });
          })
          .finally(function(res) {});
      });
    });
  }
};
</script>

<style>
body {
  /* background: #092943 url("../assets/img/_pc/images/bg_pattern.png") 0 0 repeat; */
  color: #606468;
  margin: 0;
  min-height: 100%;
}
</style>

<style scoped>
a {
  color: #eee;
  outline: 0;
  text-decoration: none;
}
a:focus,
a:hover {
  text-decoration: underline;
}

input {
  border: 0;
  color: inherit;
  font: inherit;
  margin: 0;
  outline: 0;
  padding: 0;
  -webkit-transition: background-color 0.2s;
  transition: background-color 0.2s;
}

.site_container {
  padding: 3rem 0;
  border: 1px solid #0b2c45;
  background: #09263c;
  background-color: rgba(9, 38, 60, 0.8);

  width: 100%;
  position: absolute;
  top: 50%;
  margin-top: -230px;
}

.logo_wrap img {
  display: block;
  margin: 0 auto;
}
.logo_wrap .p {
  background: #071c2c;
  margin-top: 10px;
  margin-bottom: 20px;
  padding: 2px;
  text-align: center;
  color: #e1e1e1;
}

.form input[type="password"],
.form input[type="text"] {
  width: 83%;
  margin-left: 16%;
  color: #2c3539;
}
.form input[type="submit"] {
  width: 100%;
}
.form-login {
  color: #c4c4c4;
}
.form-login label {
  position: absolute;
  width: 52px;
  height: 51px;
}
.form-login label,
.form-login input[type="text"],
.form-login input[type="password"],
.form-login input[type="submit"] {
  border-radius: 0.25rem;
  padding: 1rem;
}
.form-login label {
  background-color: #555;
  border-bottom-right-radius: 0;
  border-top-right-radius: 0;
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.form-login input[type="text"],
.form-login input[type="password"] {
  background-color: #e1e1e1;
  border-bottom-left-radius: 0;
  border-top-left-radius: 0;
}
.form-login input[type="text"]:focus,
.form-login input[type="text"]:hover,
.form-login input[type="password"]:focus,
.form-login input[type="password"]:hover {
  background-color: #fff;
}
.form-login input[type="submit"] {
  background-color: #496d0b;
  color: #fff;
  font-weight: bold;
  text-transform: uppercase;
}
.form-login input[type="submit"]:focus,
.form--login input[type="submit"]:hover {
  background-color: #ffb401;
}
.form_login {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  margin-bottom: 1rem;
}
.form_input {
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
}

.align {
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
  -webkit-flex-direction: row;
  -ms-flex-direction: row;
  flex-direction: row;
}

.hidden {
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

.text-center {
  text-align: center;
}

.grid_container {
  margin: 0 auto;
  max-width: 20rem;
  width: 90%;
}
.logo_size {
  width: 300px;
  margin-bottom: 30px;
}
</style>

<style>
html,
body,
.main-login,
.main-login > * {
  width: 100%;
  height: 100%;
  font-family: "Noto Sans KR", sans-serif !important;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow: hidden;
}
.main-login .dfc {
  display: flex;
  flex-direction: column;
}
.main-login .dfr {
  display: flex;
  flex-direction: row;
}
.main-login .jcc {
  justify-content: center;
}
.main-login .jcfe {
  justify-content: flex-end;
}

.main-login .bg-frame {
  position: relative;
  height: 100vh;
  background-image: url("../assets/img/login/background.jpg");
  background-size: 100%;
  justify-content: space-around;
  align-items: center;
  display: flex;
}

/*로그인 폼 영역*/

.main-login .login-frame {
  width: 1010px;
  height: 600px;
  margin: auto 0;
  padding: 50px;
  /* background-color: var(--form_bg); */
  /* background-image: url("../assets/img/login/intro_motion.gif"); */
  /* background-size: 100%;
  background-repeat: no-repeat; */
  border-radius: 10px;
  text-align: right;
  z-index: 1;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.main-login .video-login {
  width: 1010px;
  height: 600px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 14px;
  border: 0px;
  background: url("../assets/img/login/login_background.png") top no-repeat;
  background-size: 1010px 600px;
}
.main-login .input-frame {
  width: 300px;
  align-items: flex-end;
}

.main-login .input-frame .btn--submit {
  width: 130px;
}

.main-login .input_container {
  background-color: var(--input_bg);
  display: flex;
  align-items: center;
  height: 50px;
  border-radius: 10px;
  width: 100%;
  padding-left: 20px;
  padding-right: 50px;
  margin-bottom: 10px;
  background-color: #fff;
  border: solid 1px #c9c9c9;
}

.main-login .input_field {
  color: var(--icon_color);
  background-color: inherit;
  width: 90%;
  border: none;
  font-size: 18px;
  font-weight: 400;
  padding-left: 30px;
  color: #000;
}

.main-login .input_field:hover,
.main-login .input_field:focus {
  outline: none;
}

.main-login .btn--submit:hover {
  background-color: #00a0ea;
  /* simple color transition on hover */
  transition: background-color, 1s;
  cursor: pointer;
}

.main-login h1,
.main-login span {
  text-align: right;
}

.main-login h1 {
  font-size: 38px;
  font-weight: bold;
  margin-bottom: 0px;
  color: #000;
}

.main-login p {
  font-size: 18px;
  margin-bottom: 50px;
  font-weight: 600;
  color: #000;
}

.main-login .Forward {
  font-size: 12px;
  font-weight: 100;
  color: #ddd;
  margin-bottom: 0px;
}

.main-login hr {
  border: solid 1px #016aae;
  margin-top: -35px;
  margin-bottom: 25px;
  width: 80%;
  margin-right: 0px;
}

.main-login a:hover {
  color: var(--submit_hover);
}

.main-login i {
  color: #868787;
}

.main-login .btn {
  height: 60px;
  font-size: 20px;
  padding: 15px 20px 20px 20px;
  border-radius: 10px;
  text-align: center;
  cursor: pointer;
  font-weight: bold;
  margin-top: 30px;
  border: 0px;
}

.main-login .primary {
  background-color: #016aae;
  color: white;
}

/* input box color */
.main-login input#inputAccount:-webkit-autofill,
.main-login input#inputAccount:-webkit-autofill:hover,
.main-login input#inputAccount:-webkit-autofill:focus,
.main-login input#inputAccount:-webkit-autofill:active,
.main-login input#inputAccountPW:-webkit-autofill,
.main-login input#inputAccountPW:-webkit-autofill:hover,
.main-login input#inputAccountPW:-webkit-autofill:focus,
.main-login input#inputAccountPW:-webkit-autofill:active {
  transition: background-color 5000s ease-in-out 0s;
}
</style>
