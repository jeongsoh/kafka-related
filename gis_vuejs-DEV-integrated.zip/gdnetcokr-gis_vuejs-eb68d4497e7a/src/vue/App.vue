<template lang="pug">
#app
  router-view
</template>

<script>
export default {
  mounted() {
    this.$store.commit("status", "");
    $("#modal_area").removeClass("hidden");
    window.vm = this;
  }
};
</script>

<style>
.lds-spinner {
  color: official;
  display: inline-block;
  position: relative;
  width: 64px;
  height: 64px;
}
.lds-spinner div {
  transform-origin: 32px 32px;
  animation: lds-spinner 1.2s linear infinite;
}
.lds-spinner div:after {
  content: " ";
  display: block;
  position: absolute;
  top: 3px;
  left: 29px;
  width: 5px;
  height: 14px;
  border-radius: 20%;
  background: #cef;
}
.lds-spinner div:nth-child(1) {
  transform: rotate(0deg);
  animation-delay: -1.1s;
}
.lds-spinner div:nth-child(2) {
  transform: rotate(30deg);
  animation-delay: -1s;
}
.lds-spinner div:nth-child(3) {
  transform: rotate(60deg);
  animation-delay: -0.9s;
}
.lds-spinner div:nth-child(4) {
  transform: rotate(90deg);
  animation-delay: -0.8s;
}
.lds-spinner div:nth-child(5) {
  transform: rotate(120deg);
  animation-delay: -0.7s;
}
.lds-spinner div:nth-child(6) {
  transform: rotate(150deg);
  animation-delay: -0.6s;
}
.lds-spinner div:nth-child(7) {
  transform: rotate(180deg);
  animation-delay: -0.5s;
}
.lds-spinner div:nth-child(8) {
  transform: rotate(210deg);
  animation-delay: -0.4s;
}
.lds-spinner div:nth-child(9) {
  transform: rotate(240deg);
  animation-delay: -0.3s;
}
.lds-spinner div:nth-child(10) {
  transform: rotate(270deg);
  animation-delay: -0.2s;
}
.lds-spinner div:nth-child(11) {
  transform: rotate(300deg);
  animation-delay: -0.1s;
}
.lds-spinner div:nth-child(12) {
  transform: rotate(330deg);
  animation-delay: 0s;
}
@keyframes lds-spinner {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}

.modal-alert-background {
  z-index: 10000;
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: rgb(0, 0, 0, 0.4);
  left: 0px;
  top: 0px;
  pointer-events: auto;
  border-radius: 0px 0px 10px 10px;
}
#modal_area .modal-alert-background.vm-alert {
  background: rgba(255, 255, 255, 0.95);
}
#modal_area .modal-alert-background.vm-alert .modal-content {
  border: 0px;
  box-shadow: none;
  background: rgba(255, 255, 255, 0);
}
.modal-alert {
  position: absolute;
  display: table;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
}

::-webkit-scrollbar {
  width: 0px; /* 세로축 스크롤바 길이 */
  height: 0px; /* 가로축 스크롤바 길이 */
}
::-webkit-scrollbar-track {
  background-color: rgba(0, 0, 0, 0);
}
::-webkit-scrollbar-track-piece {
  background-color: #434343;
}
::-webkit-scrollbar-thumb {
  border-radius: 8px;
  background-color: #313131;
}
::-webkit-scrollbar-button {
  background-color: rgba(0, 0, 0, 0);
  width: 100%;
  height: 0px;
}
::-webkit-scrollbar-button:start {
  background-color: rgba(0, 0, 0, 0); /* Top, Left 방향의 이동버튼 */
}
::-webkit-scrollbar-button:end {
  background-color: rgba(0, 0, 0, 0); /* Bottom, Right 방향의 이동버튼 */
}
::-webkit-scrollbar-corner {
  background-color: rgba(0, 0, 0, 0); /* 우측 하단의 코너 부분 */
}
::-webkit-resizer {
  background-color: rgba(0, 0, 0, 0);
}

@-webkit-keyframes load3 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes load3 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

.fa-calendar {
  margin-left: 4px;
}

input[type="number"]::-webkit-outer-spin-button,
input[type="number"]::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

input,
div {
  outline-color: #00a0ea;
}

@page {
  size: A4 landscape;
}

@media print {
  @page {
    size: A4 landscape;
  }
  body {
    position: unset !important;
  }
  .content-wrapper,
  .main-footer,
  #right-sidebar {
    display: none;
  }
  canvas {
    left: 0px;
    height: 210mm;
    width: 297mm;
  }
  #map_wrap > *,
  #main > * {
    display: none;
  }
}
@media print and (-ms-high-contrast: active), (-ms-high-contrast: none) {
  canvas {
    left: 0px;
    height: 170mm;
    width: 267mm;
  }
}

.monthselect,
.yearselect {
  border: 0px;
}
</style>
