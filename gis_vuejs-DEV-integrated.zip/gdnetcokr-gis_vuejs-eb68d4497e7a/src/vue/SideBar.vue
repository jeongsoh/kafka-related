<template lang="pug">
.side-bar
  #header
    img(:src="logoImage()" @click="refreshAll()")
  div
    ul#menu
      li(@click="ep('showPanel', 'VPDashboard', 'VPDashboard')" :class="menuClickClass(['VPDashboard'])")
        img(src="@/assets/img/res/img/menu_status.png")
        span 현황판
      li(v-if="sidebarArea == 'geoje'" @click="ep('modalOpen','complainRegister','VMComplainRegister')")
        img(src="@/assets/img/res/img/menu_report.png")
        span 고장 신고
      li.device-menu(@click="ep('showPanel', 'VPDeviceSearch', 'VPDeviceSearch')" :class="menuClickClass(['VPDeviceSearch','VPDeviceTrouble'])")
        img(src="@/assets/img/res/img/menu_device.png")
        span 시설물
      li(@click="ep('showPanel', 'VPComplaintList', 'VPComplaintList')" :class="menuClickClass(['VPComplaintList'])")
        img(src="@/assets/img/res/img/menu_complain.png")
        span 민원
      li(v-if="sidebarArea != 'geoje'" @click="ep('modalOpen','complainRegister','VMComplainRegister')")
        img(src="@/assets/img/res/img/menu_report.png")
        span 고장 신고
      li(@click="ep('showPanel', 'VPJajeList', 'VPJajeList')" :class="menuClickClass(['VPJajeList','VPJajeIO'])")
        img(src="@/assets/img/res/img/menu_materials.png")
        span 자재
      li(v-if="sidebarArea == 'yeonggwang'" @click="ep('showPanel', 'VPReportTrouble', 'VPReportTrouble')" :class="menuClickClass(['VPReportTrouble','VPReportInspection','VPReportJaje'])")
        img(src="@/assets/img/res/img/menu_report.png")
        span 레포트
  #footer
    .logout(@click="signout" @mouseover="logout_image = logout_hover" @mouseleave="mouseLeave")
      img(:src="logout_image")
      span 로그아웃
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
export default {
  data() {
    return {
      logout_image: require("@/assets/img/res/img/logout.png"),
      logout: require("@/assets/img/res/img/logout.png"),
      logout_hover: require("@/assets/img/res/img/logout_hover.png"),
      dashboard: {
        total: {
          light_count: "",
          light_complain: "",
          light_error: "",
          security_count: "",
          security_complain: "",
          security_error: "",
          etc_count: "",
          etc_complain: "",
          etc_error: "",
          total_count: "",
          total_complain: "",
          total_error: ""
        },
        iot: {
          light_count: "",
          light_complain: "",
          light_error: "",
          security_count: "",
          security_complain: "",
          security_error: "",
          etc_count: "",
          etc_complain: "",
          etc_error: "",
          total_count: "",
          total_complain: "",
          total_error: ""
        },
        time: {
          OFF_Hour: 0,
          OFF_Min: 0,
          ON_Hour: 0,
          ON_Min: 0
        }
      },
      searchType: "sb_name",
      searchData: "",
      dashboardRepeat: "",
      dashboardBtn: false,
      dashboardType: "전체"
    };
  },
  computed: {
    sidebarArea() {
      return this.$store.getters.config_area;      
    },
    searchTypeText() {
      if (this.searchType == "sb_name") {
        return "시설";
      } else if (this.searchType == "sb_addr") {
        return "주소";
      } else {
        return "";
      }
    },
    streetProgress() {
      return (
        ((this.dashboard.street_distribution_count -
          this.dashboard.street_distribution_notice_count) /
          this.dashboard.street_distribution_count) *
        100
      );
    },
    securityProgress() {
      return (
        ((this.dashboard.security_repeater_count -
          this.dashboard.security_repeater_notice_count) /
          this.dashboard.security_repeater_count) *
        100
      );
    },
    etcProgress() {
      return (
        ((this.dashboard.etc_count - this.dashboard.etc_notice_count) /
          this.dashboard.etc_count) *
        100
      );
    },
    lightProgress() {
      return (
        ((this.dashboard.light_count - this.dashboard.light_error_count) /
          this.dashboard.light_count) *
        100
      );
    }
  },
  methods: {
    signout() {
      window.signout();
    },
    mouseLeave() {
      this.logout_image = this.logout;
    },
    refreshAll() {
      window.location.reload();
    },
    getPcFacilityCountAPI() {
      var vm = this;
      this.$_API_GET("pc/facility/count", { SL_SLNAME: this.searchData }).then(
        function(res) {
          if (res.length == 0) {
            vm.$emit(
              "onAlert",
              "black",
              null,
              "검색된 결과가 없습니다",
              null,
              null,
              true,
              false
            );
          } else if (res.length == 1) {
            var point = window.setCoordsFromPoint(
              res[0].SL_MAP_X,
              res[0].SL_MAP_Y,
              vm.$store.getters.panel_location_name
            );
            window.SetPositionLevel(point.getLng(), point.getLat(), 1);
          } else {
            vm.searchLight();
          }
        }
      );
    },
    onClickSearch() {
      if (this.searchType == "sb_name") {
        this.getPcFacilityCountAPI();
      } else if (this.searchType == "sb_addr") {
        window.getValue(this.searchData);
      }
    },
    searchEnter(e) {
      if (e.key == "Enter") {
        this.onClickSearch();
      }
    },
    mainShowAlert() {
      this.$emit(
        "onAlert",
        "black",
        null,
        "현재 준비 중인 기능입니다",
        null,
        null,
        true,
        false
      );
    },
    ep(name, data, type) {
      if (window.installFlag) {
        this.$emit(
          "onAlert",
          "black",
          null,
          "시설물 설치 중 입니다",
          null,
          null,
          true,
          false
        );
        return;
      }
      if (window.tooltipDataObj.isMoving) {
        this.$emit(
          "onAlert",
          "black",
          null,
          "시설물 이동 중 입니다",
          null,
          null,
          true,
          false
        );
        return;
      }
      if (name == "modalOpen") {
        EventBus.$emit(name, data, type);
      } else {
        if (this.$store.getters.sidebar_content == type) {
          this.$store.commit("sidebar_content", "");
          this.$store.commit("sidebar_onHeader", "");
        } else {
          this.$store.commit("sidebar_content", type);
          if (type == "VPDashboard") {
            this.$store.commit("sidebar_onHeader", "현황판");
          } else if (type == "VPDeviceSearch") {
            this.$store.commit("sidebar_onHeader", "상세 검색");
          } else if (type == "VPComplaintList") {
            this.$store.commit("sidebar_onHeader", "민원 목록");
          } else if (type == "VPJajeList") {
            this.$store.commit("sidebar_onHeader", "자재 현황");
          } else if (type == "VPReportTrouble") {
            this.$store.commit("sidebar_onHeader", "시설물 장애이력");
          }
        }
      }
    },
    searchLight() {
      // NOTE :: 검색 DB와 일치 작업할 때 같이 작업 필요
      this.$store.commit("sidebar_content", "VPDeviceSearch");
      this.$store.commit("sidebar_onHeader", "상세 검색");

      var vm = this;
      Vue.nextTick(function() {
        EventBus.$emit("getPcfacilityAPI", vm.searchData, vm.searchType);
      });
    },
    pad(n, width) {
      n = n + "";
      return n.length >= width
        ? n
        : new Array(width - n.length + 1).join("0") + n;
    },
    getMidnightDashboard() {
      var vm = this;
      setTimeout(() => {
        console.log(vm.datepickerFormatter(new Date()));
        console.log(
          vm.datepickerFormatter(new Date().setDate(new Date().getDate() + 1))
        );
        vm.getMidnightDashboard();
      }, 1000);
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD  HH:mm:ss");
    },
    getDashboard() {
      var vm = this;
      this.$_API_GET("pcdashboard").then(function(res) {
        console.log(res);
        vm.dashboard = res;
      });
    },
    onClickChangeDashboard() {
      console.log(this.dashboardBtn);
      if (!this.dashboardBtn) {
        this.dashboardType = "IoT";
      } else {
        this.dashboardType = "전체";
      }
    },
    menuClickClass(data) {
      // NOTE :: 메뉴 클릭된 css Class 기능
      if (data.includes(this.$store.getters.sidebar_content)) {
        return "li-clicked";
      } else {
        return "";
      }
    },
    logoImage() {
      if (this.$store.getters.config_area == undefined) {
        return require("@/assets/img/logo/guardian-logo.png");
      } else {
        return require("@/assets/img/logo/" +
          this.$store.getters.config_area +
          "-logo.png");
      }
    }
  },
  mounted() {
    $("#menu > li").hover(
      function() {
        $(this)
          .children("ul")
          .css("display", "block");
      },
      function() {
        $(this)
          .children("ul")
          .css("display", "none");
      }
    );

    var vm = this;
    window.modalAlert = function(
      alertType,
      headerTitle,
      firstText,
      secondText,
      inputPlaceHolder,
      okBtn,
      cancelBtn
    ) {
      vm.$emit(
        "onAlert",
        alertType,
        headerTitle,
        firstText,
        secondText,
        inputPlaceHolder,
        okBtn,
        cancelBtn
      );
    };
  },
  beforeDestroy() {
    clearInterval(this.dashboardRepeat);
  }
};
</script>

<style scoped>
.logout span {
  margin-right: 10px;
}
.logout {
  color: #757575;
  font-size: 10px;
  display: flex;
  cursor: pointer;
}
.logout:hover {
  color: #fff;
}
#footer .logout img {
  margin-left: 13px;
  width: 20%;
}
#header {
  width: 100%;
  height: 100px;
  background-color: #424242;
}
#header img {
  margin-top: 19px;
  margin-bottom: 77px;
  width: 58px;
  height: 70px;
  margin-left: auto;
  margin-right: auto;
  display: block;
  cursor: pointer;
}
#summary {
  overflow: hidden;
  padding: 0px 10px;
  margin-top: 10px;
}
#summary .column {
  padding: 1px 0px;
}
#summary ul {
  overflow: hidden;
  margin-top: 15px;
  margin-bottom: 8px;
}
#summary li {
  font-size: 12px;
}
#summary li:first-child {
  font-weight: bold;
}
#summary .graph-info {
  float: right;
  margin-top: -17px;
}
#summary .column .progress {
  height: 20px;
  border-radius: 15px;
}

#search {
  margin-top: 25px;
  padding: 0px 10px;
}
#search * {
  color: black;
  font-size: 14px;
  border-radius: 15px;
  background: white;
}
/* #search .dropdown-menu {
  width: 50px;
} */
#search input {
  margin-left: 7px;
  padding-right: 27px;
  z-index: 0;
}
#search #seatch-btn {
  background: transparent;
  position: absolute;
  right: 4px;
  box-shadow: none;
  z-index: 10;
}

#menu li ul.sub-menu {
  position: absolute;
  left: 220px;
  z-index: 100;
  background-color: #424242;
  display: none;
}

ul.sub-menu.sub-01 {
  top: 0;
}
ul.sub-menu.sub-02 {
  top: 41px;
}
ul.sub-menu.sub-03 {
  top: 82px;
}
ul.sub-menu.sub-04 {
  top: 123px;
}

#menu li ul.sub-menu li {
  width: 150px;
  height: 41px;
  padding: 8px 20px;
}

#menu li ul.sub-menu li:hover {
  background-color: #50505f;
}

#footer {
  position: absolute;
  width: inherit;
  bottom: 20px;
}
#footer img {
  height: 100%;
  margin-left: auto;
  margin-right: auto;
  display: block;
}
.cursor-pointer {
  cursor: pointer;
}
.pointer-events-none {
  pointer-events: none;
}
.sidebar-time {
  margin-top: 30px;
  display: flex;
}
.main-title {
  text-align: center;
  margin-top: 10px;
}
.main-title > * {
  padding-bottom: 13px;
  padding-left: 30px;
  padding-right: 30px;
  border-bottom: 0.6px solid rgba(195, 195, 195, 0.3);
}
.on_hour,
.off_hour,
.on_min,
.off_min {
  background: url("../assets/img/res/img/on_off_time_bg.png") no-repeat;
  background-size: 45px;
  width: 45px;
  height: 45px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.off_time,
.on_time {
  display: flex;
}
.time-font {
  font-size: 18px;
}
.off_time_area {
  margin-left: 10px;
}
.on_time_area {
  margin-left: 15px;
}
.time_title {
  margin-left: 8px;
  font-size: 11pt;
}

.sidebar-search-btn {
  background: url("../assets/img/res/img/sidebar-search-arrow.png") no-repeat
    right #fff !important;
  background-size: 23px !important;
}
#summary td {
  padding: 5px 0px 5px 0px;
  text-align: center;
}
#summary tr:last-child {
  border: 0px;
}
.dashboard-type {
  text-align: left !important;
  padding-left: 10px !important;
}
#trouble {
  margin-top: 13px;
  text-align: right;
}
.trouble_btn {
  font-size: 13px;
  padding-bottom: 3px;
  margin-right: 12px;
  border-bottom: 0.8px solid rgb(0, 173, 239);
  cursor: pointer;
}
</style>

<style>
.side-bar {
  pointer-events: auto;
  background-color: #424242;
  z-index: 100;
  width: 85px;
}
</style>

<style lang="scss">
.side-bar {
  & #menu {
    font-size: 15px;
    position: relative;
    margin-top: 35px;
    cursor: pointer;
    & li {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 15px 0px 15px 0px;
      & span {
        font-size: 13px;
        padding-top: 15px;
        color: #757575;
      }
      & img {
        width: 28px;
        height: 30px;
      }
      &:hover {
        background-color: #3b3b3b;
        & span {
          color: #fff;
        }
      }
      &.li-clicked {
        background-color: #3b3b3b;
        & span {
          color: #fff;
        }
        &:before {
          content: "";
          display: inline-block;
          width: 3px;
          height: 94.3px;
          position: absolute;
          left: 0;
          background-color: #337ab7;
        }
      }
    }
  }
}
</style>
