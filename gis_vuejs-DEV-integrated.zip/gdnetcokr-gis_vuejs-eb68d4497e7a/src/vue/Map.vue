<template lang="pug">
#map
  #map_canvas
    .main-wrap
      .map_option
        #mapMessage(style='display:none')
  #rvUI
    .change-main-roadview(v-show="this.$store.getters.roadviewMap == 'roadview'" @click="changeRoadviewMap('map')" style="display:none;")
    .exit-rv(v-show="this.$store.getters.roadviewMap == 'roadview'" @click="exitRV" style="display:none;")
    transition(name='modal' v-if="modalAlert")
      .modal-background
        .modal-position
          .loader
          br
          | {{alertText}}
</template>

<script>
import Vue from "vue";
import VueDaumMap from "vue-daum-map";
import { EventBus } from "@/main";

export default {
  components: {
    VueDaumMap
  },
  data() {
    return {
      alertText: "",
      modalAlert: false,
      appKey: "6353f7b8ce76cc0661c9b68ad071a226", // 테스트용 appkey
      center: { lat: 34.880584, lng: 128.621222 }, // 지도의 중심 좌표
      level: 3, // 지도의 레벨(확대, 축소 정도)
      mapTypeId: VueDaumMap.MapTypeId.NORMAL, // 맵 타입
      libraries: [], // 추가로 불러올 라이브러리
      map: null, // 지도 객체. 지도가 로드되면 할당됨.
      content: {
        basicMap: true,
        weesung: false,
        roadView: false,
        Ruler: false
      },
      datenow: ""
    };
  },
  methods: {
    maptime() {
      var self = this;
      this.datenow = this.moment(new Date()).format(
        "YYYY년 MM월 DD일 hh시 mm분"
      );
    },
    print() {
      window.print();
    },
    zoomIn() {
      window.map.setLevel(window.map.getLevel() - 1);
    },
    zoomOut() {
      window.map.setLevel(window.map.getLevel() + 1);
    },
    mapBtnClass(data) {
      if (data == "basicMap" && this.content.basicMap) {
        return "on";
      } else if (data == "weesung" && this.content.weesung) {
        return "on";
      } else {
        return "";
      }
    },
    RvClass() {
      if (this.content.roadView) {
        return "on";
      }
    },
    RulerClass() {
      if (this.content.Ruler) {
        return "on";
      }
    },
    setRulerMode(e) {
      window.setRulerModeAtSide(e.target);
      if (this.content.Ruler) {
        this.content.Ruler = false;
      } else {
        this.content.Ruler = true;
      }
    },
    setRvMode(e) {
      window.setRvModeAtSide(e.target);
      if (this.content.roadView) {
        this.content.roadView = false;
      } else {
        Vue.nextTick(function() {
          $("#rvWrapper .ui-resizable-handle.ui-resizable-nw").css(
            "display",
            "block"
          );
        });
        this.content.roadView = true;
      }
    },
    makeAlert() {
      alert("현재 준비중인 기능입니다.");
    },
    areaAction(slcode) {
      let panel_level = this.$store.getters.panel_location_name;
      if (window.tooltipDataObj.isOn) {
        window.closeToolTip();
      }
      this.$_API_GET("facility/tooltilp", {
        SL_SLCODE: slcode
      }).then(function(res) {
        res.SL_SLCODE = slcode;
        window.makeToolTip(res, panel_level);
      });
    },
    facilityDetail() {
      let slcode = window.tooltipDataObj.data.SL_SLCODE;
      EventBus.$emit("modalOpen", slcode, "VMLight");
      Vue.nextTick(function() {
        setTimeout(function() {
          window.closeToolTip();
        }, 3000);
        EventBus.$emit("modalOpenParam" + slcode, slcode, "VMLightAdd", {
          choiceTab: "상세"
        });
      });
    },
    showFacilityDetail(slcode) {
      EventBus.$emit("modalOpen", slcode, "VMLight");
      Vue.nextTick(function() {
        setTimeout(function() {
          window.closeToolTip();
        }, 3000);
        EventBus.$emit("modalOpenParam" + slcode, slcode, "VMLightAdd", {
          choiceTab: "상세"
        });
      });
    },
    facilityConfig() {
      let slcode = window.tooltipDataObj.data.SL_SLCODE;
      EventBus.$emit("modalOpen", slcode, "VMLight");
      Vue.nextTick(function() {
        setTimeout(function() {
          window.closeToolTip();
        }, 3000);
        EventBus.$emit("modalOpenParam" + slcode, slcode, "VMLightConfig", {
          choiceTab: "제어"
        });
      });
    },
    ep(name, data, type) {
      var vm = this;
      if (window.tooltipDataObj.isMoving) {
        this.$emit(
          "onAlert",
          "black",
          null,
          "시설물 이동 중 입니다",
          null,
          null,
          true,
          false
        );
        return;
      }
      if (name == "modalOpen") {
        EventBus.$emit(name, data, type);
      } else {
        this.$emit(name, data, type);
      }
    },
    facilityComplain(data, name) {
      console.log("facilityComplain", data, name);
      this.ep("modalOpen", data + "deviceRegister", "VMComplainRegister");
      var vm = this;
      Vue.nextTick(function() {
        setTimeout(function() {
          window.closeToolTip();
        }, 3000);
        EventBus.$emit("setComplainAddr" + data + "deviceRegister", name, data);
      });
    },
    getPanelLevel() {
      return this.$store.getters.panel_location_name;
    },
    saveCrossHead(data) {
      this.$store.commit("crossHairPostion", window.CrossHeadPosition);
      console.log("saveCross", window.CrossHeadPosition);
    },
    checkCrossHeadWhenRefresh() {
      if (
        window.CrossHeadPosition !== undefined &&
        this.$store.getters.crossHairPostion !== ""
      ) {
        console.log("checkCrossHeadWhenRefresh");
        // alert(this.$store.getters.crossHairPostion);
        window.SetPositionLevel(
          this.$store.getters.crossHairPostion.getLng(),
          this.$store.getters.crossHairPostion.getLat(),
          1
        );
        this.$store.commit("crossHairPostion", "");
      }
    },
    changeRoadviewMap(data) {
      $("#rvWrapper .ui-resizable-handle.ui-resizable-nw").css(
        "display",
        "block"
      );
      $("#map_wrap .ui-resizable-handle.ui-resizable-nw").css(
        "display",
        "none"
      );
      $("#map_add_btn").css("display","block");
      var add_btn_right = parseInt($("#map_wrap").css("width")) + 10;
      $("#map_add_btn").css("right",add_btn_right + "px");
      this.$store.commit("roadviewMap", data);
      Vue.nextTick(function() {
        window.map.relayout();
        window.rv.relayout();
        var rvPosition = window.rv.getPosition();
        var panel_level = getPanelLevel();
        var point = window.setCoordsFromPoint(
          rvPosition.getLng(),
          rvPosition.getLat(),
          panel_level
        );
        window.map.setCenter(point);
      });
    },
    exitRV() {
      this.changeRoadviewMap("map");
      $("#roadview-btn").click();
    }
  },
  created() {},
  mounted() {
    if (window.loginCheck) {
      window.location.reload();
    }
    var vm = this;
    // NOTE :: js import 처리
    import("@/assets/js/gd.js").then(gd => {
      import("@/assets/js/postcode.js").then(postcode => {
        import("@/assets/js/light.js").then(light => {
          import("@/assets/js/map.js").then(map => {
            console.log("map");
            window.init();
            window.panelPosition = vm.$store.getters.panel_location_name;
            $("#map_canvas")
              .children()
              .eq(2)
              .insertAfter(".daum_copyright");
            // $("#map_canvas")
            //   .children()
            //   .eq(2)
            //   .css("left", "230px")
            //   .insertAfter(".daum_copyright");
            vm.checkCrossHeadWhenRefresh();
          });
        });
      });
    });
    window.saveCrossHead = this.saveCrossHead;
    window.getPanelLevel = this.getPanelLevel;
    window.areaAction = this.areaAction;
    window.facilityDetail = this.facilityDetail;
    window.showFacilityDetail = this.showFacilityDetail;
    window.facilityConfig = this.facilityConfig;
    window.facilityComplain = this.facilityComplain;
  }
};
</script>

<style>
#map_wrap .is-zoomMax {
  visibility: collapse;
}
#map_wrap .is-move-bg {
  background: #40d3fd;
}
#map_wrap .is-move {
  opacity: 0.35;
}

#map_wrap .tab_menu .btn-outline-primary {
  border-color: #424242;
}
#map_wrap .map-overlaybox .box-table .box-head {
  color: #fff;
  font-weight: bold;
  background-color: #484848;
  padding: 3px 0px 3px 7px;
}
#map_wrap .map-overlaybox .box-table .box-td {
  padding: 0px 0px 0px 7px;
}
#map_wrap .map-overlaybox .box-table table {
  margin: 15px;
  -moz-border-radius: 6px;
  -webkit-border-radius: 6px;
  border-radius: 6px;
  margin-top: 0;
  margin-bottom: 0px;
}
#map_wrap .map-overlaybox .box-title {
  padding-top: 12px;
  padding-bottom: 0;
  margin-left: 11px;
  padding-left: 5px;
}
#map_wrap .map-overlaybox .box-title {
  margin-left: 11px;
  display: flex;
  align-items: center;
}
#map_wrap .map-overlaybox .box-title .close {
  margin-left: 72%;
}
#map_wrap .map-overlaybox .box-close {
  margin-left: 19px;
  margin-right: 20px;
  padding: 1px 1px 1px 1px;
  font-size: 25px;
  cursor: pointer;
}
#map_wrap .map-overlaybox .tooltipclose {
  font-size: 25px;
  position: absolute;
  top: 5px;
  right: 23px;
  cursor: pointer;
}

#map_wrap .map-overlaybox .tab_menu {
  float: right;
  width: 100%;
  margin-right: 15px;
}
#map_wrap .map-overlaybox .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
}
#map_wrap .map-overlaybox .tab_menu button:hover {
  background: #016aae;
}

/* 툴팁 CSS */
#map_wrap .map-overlaybox {
  position: relative;
  width: 360px;
  height: 230px;
  padding: 0px;
  background: #ffffff;
  -webkit-border-radius: 10px;
  -moz-border-radius: 10px;
  border-radius: 10px;
  border: #7f7f7f solid 1px;
  z-index: 5;
}
#map_wrap .map-overlaybox table tr th {
  border-bottom: 1px solid rgba(91, 91, 91, 0.3);
}
#map_wrap .map-overlaybox table tr td {
  border-bottom: 1px solid #eeeeee;
}
#map_wrap .map-overlaybox table .last-clear-bottom {
  border-bottom: 0px;
}

#map_wrap .map-overlaybox:after {
  content: "";
  position: absolute;
  border-style: solid;
  border-width: 15px 25px 15px 0;
  border-color: transparent #ffffff;
  display: block;
  width: 0;
  z-index: 1;
  left: -25px;
  top: 53px;
}

#map_wrap .map-overlaybox:before {
  content: "";
  position: absolute;
  border-style: solid;
  border-width: 15px 25px 15px 0;
  border-color: transparent rgb(125, 125, 125);
  display: block;
  width: 0;
  z-index: 0;
  left: -26px;
  top: 53px;
}
#map_wrap #light_etc {
  vertical-align: middle;
}

#_map,
#map_canvas {
  width: 100%;
  height: 100%;
}

#daum_link {
  margin: 0px !important;
  pointer-events: auto;
}
.top #daum_link,
.right #daum_link {
  margin: 0px !important;
}
.left #daum_link {
  margin-bottom: 0px !important;
}
.bottom #daum_link {
  margin-left: 0px !important;
}

#center_mark {
  position: absolute;
  width: 64px;
  height: 64px;
  margin: -32px;
  z-index: 1;
  opacity: 0.5;
  pointer-events: none;
}
.hidden + #map #center_mark {
  margin: -32px !important;
}

.left #center_mark,
.top #center_mark {
  left: 50%;
  top: 50%;
}
.right #center_mark,
.bottom #center_mark {
  right: 50%;
  bottom: 50%;
}
.left #center_mark {
  margin-top: -32px !important;
}
.bottom #center_mark {
  margin-right: -32px !important;
}
.right #center_mark {
  margin-bottom: -32px !important;
  margin-left: 0px !important;
}
.top #center_mark {
  margin-bottom: 0px !important;
  margin-left: -32px !important;
}

#row_line {
  position: absolute;
  top: 50%;
  margin-top: -2px;
  width: 100%;
  height: 4px;
  background: tomato;
}
#col_line {
  position: absolute;
  left: 50%;
  margin-left: -2px;
  width: 4px;
  height: 100%;
  background: tomato;
}

/* label1 = 마커 이름 */
.label1 * {
  display: inline-block;
  vertical-align: top;
}
.label1 .center b {
  /* cursor: default; */
  -webkit-user-select: none;
  -moz-user-select: none;
  -khtml-user-select: none;
  -ms-user-select: none;
}
.label1 .left {
  background: url("../assets/img/res/img/tip_l.png") 1px 0 no-repeat;
  display: inline-block;
  height: 24px;
  overflow: hidden;
  vertical-align: top;
  width: 7px;
}
.label1 .center {
  background: url("../assets/img/res/img/tip_bg.png") repeat-x;
  display: inline-block;
  height: 24px;
  font-size: 12px;
  line-height: 24px;
}
.label1 .right {
  background: url("../assets/img/res/img/tip_r.png") -1px 0 no-repeat;
  display: inline-block;
  height: 24px;
  overflow: hidden;
  width: 6px;
}
.label1 .left-move {
  background: url("../assets/img/res/img/tip_l_blue.png") 1px 0 no-repeat;
  display: inline-block;
  height: 24px;
  overflow: hidden;
  vertical-align: top;
  width: 7px;
}
.label1 .center-move {
  background: url("../assets/img/res/img/tip_bg_blue.png") repeat-x;
  display: inline-block;
  height: 24px;
  font-size: 12px;
  line-height: 24px;
}
.label1 .right-move {
  background: url("../assets/img/res/img/tip_r_blue.png") -1px 0 no-repeat;
  display: inline-block;
  height: 24px;
  overflow: hidden;
  width: 6px;
}
/* 둥둥이 업그레이드 */
/* 지도위에 로드뷰의 위치와 각도를 표시하기 위한 map walker 아이콘의 스타일 */

.MapWalker {
  position: absolute;
  margin: -26px 0 0 -51px;
}

.MapWalker .figure {
  position: absolute;
  width: 25px;
  left: 38px;
  top: -2px;
  height: 39px;
  background: url(https://t1.daumcdn.net/localimg/localimages/07/2012/roadview/roadview_minimap_wk.png) -298px -114px
    no-repeat;
}

.MapWalker .angleBack {
  width: 102px;
  height: 52px;
  background: url(https://t1.daumcdn.net/localimg/localimages/07/2012/roadview/roadview_minimap_wk.png) -834px -2px
    no-repeat;
}

.MapWalker.m0 .figure {
  background-position: -298px -114px;
}

.MapWalker.m1 .figure {
  background-position: -335px -114px;
}

.MapWalker.m2 .figure {
  background-position: -372px -114px;
}

.MapWalker.m3 .figure {
  background-position: -409px -114px;
}

.MapWalker.m4 .figure {
  background-position: -446px -114px;
}

.MapWalker.m5 .figure {
  background-position: -483px -114px;
}

.MapWalker.m6 .figure {
  background-position: -520px -114px;
}

.MapWalker.m7 .figure {
  background-position: -557px -114px;
}

.MapWalker.m8 .figure {
  background-position: -2px -114px;
}

.MapWalker.m9 .figure {
  background-position: -39px -114px;
}

.MapWalker.m10 .figure {
  background-position: -76px -114px;
}

.MapWalker.m11 .figure {
  background-position: -113px -114px;
}

.MapWalker.m12 .figure {
  background-position: -150px -114px;
}

.MapWalker.m13 .figure {
  background-position: -187px -114px;
}

.MapWalker.m14 .figure {
  background-position: -224px -114px;
}

.MapWalker.m15 .figure {
  background-position: -261px -114px;
}

.MapWalker.m0 .angleBack {
  background-position: -834px -2px;
}

.MapWalker.m1 .angleBack {
  background-position: -938px -2px;
}

.MapWalker.m2 .angleBack {
  background-position: -1042px -2px;
}

.MapWalker.m3 .angleBack {
  background-position: -1146px -2px;
}

.MapWalker.m4 .angleBack {
  background-position: -1250px -2px;
}

.MapWalker.m5 .angleBack {
  background-position: -1354px -2px;
}

.MapWalker.m6 .angleBack {
  background-position: -1458px -2px;
}

.MapWalker.m7 .angleBack {
  background-position: -1562px -2px;
}

.MapWalker.m8 .angleBack {
  background-position: -2px -2px;
}

.MapWalker.m9 .angleBack {
  background-position: -106px -2px;
}

.MapWalker.m10 .angleBack {
  background-position: -210px -2px;
}

.MapWalker.m11 .angleBack {
  background-position: -314px -2px;
}

.MapWalker.m12 .angleBack {
  background-position: -418px -2px;
}

.MapWalker.m13 .angleBack {
  background-position: -522px -2px;
}

.MapWalker.m14 .angleBack {
  background-position: -626px -2px;
}

.MapWalker.m15 .angleBack {
  background-position: -730px -2px;
}
</style>

<style lang="scss">
.map-overlaybox {
  & * {
    font-size: 12px;
  }
  & .box-title * {
    font-size: 13px;
  }
  & table {
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    width: 91%;
    & > tr {
      height: 22px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }
    & .left-first-child {
      -moz-border-radius: 10px 0 0 0;
      -webkit-border-radius: 10px 0 0 0;
      border-radius: 10px 0 0 0;
    }
    & .left-last-child {
      -moz-border-radius: 0 10px 0 0;
      -webkit-border-radius: 0 10px 0 0;
      border-radius: 0 10px 0 0;
    }
    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }
  }
}
</style>

<style>
#rvUI {
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
  top: 0px;
  left: 0px;
}

.tooltipSaveBtn {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
  font-weight: bold;
  border-radius: 10px;

  position: absolute;
  right: 21px;
  margin-top: 7px;
}
.tooltipSaveBtn:hover {
  background: #016aae;
}
</style>
