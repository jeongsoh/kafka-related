<template lang="pug">
.main-header(:value="headerStatue")
  .time-zone
    span {{now_time}}
    .setting-time
      span 점등 {{pad(dashboard.light_time.ON_Hour, 2)}}:{{pad(dashboard.light_time.ON_Min, 2)}} &nbsp;
      span 소등 {{pad(dashboard.light_time.OFF_Hour, 2)}}:{{pad(dashboard.light_time.OFF_Min, 2)}}
  .dashboard-area
    .dashboard-content(@click="movePanel('total')")
      span 전체
      span.dashboard-blue {{dashboard.light_count}}
    .dashboard-division
    .dashboard-content(@click="movePanel('search')")
      span 정상
      span.dashboard-green {{dashboard.light_normal_count}}
    .dashboard-division
    .dashboard-content(@click="movePanel('error')")
      span 고장
      span.dashboard-red {{dashboard.error_count}}
    .dashboard-division
    .dashboard-content(@click="movePanel('complain')")
      span 민원
      span.dashboard-orange {{dashboard.complaint_count}}
  .dashboard-dashed
    span &hellip;
  .select-area
    .dashboard-menu-icon(v-if="headerLocal == 'geoje'" )
      .dashboard-img
        a(href="https://www.hanbill.com/main.do" target="_blank")
          img.billing(:src="require('@/assets/img/res/img/logo_kor_billing.png')" title="한국인터넷빌링")
      .dashboard-division
    .dashboard-menu-icon(v-if="headerLocal == 'geoje'" )
      .dashboard-img(style="width:35px;")
        a(href="http://home.kepco.co.kr/kepco/main.do" target="_blank")
          img.billing(:src="require('@/assets/img/res/img/logo-kepco.png')" title="한국전력공사")
      .dashboard-division
    .dashboard-menu-icon(v-if="headerLocal == 'geoje'" )
      .dashboard-img(style="width:60px;")
        a(href="https://pccs.kepco.co.kr/iSmart/" target="_blank")
          img.geoje(:src="require('@/assets/img/res/img/logo_ismart.png')" title="I Smart")
      .dashboard-division
    .dashboard-img
      a(href="https://gdnet.creatorlink.net/" target="_blank")
        img.guardian(:src="require('@/assets/img/res/img/logo_guardian.png')" title="가디언이엔지")
    .dashboard-select
      .item-td(tabindex="-1")
        .dropdown
          .dropdown__header(@click="toggleDropdown($event)")
            span#visible_light_type_temp(:value="lightType") {{selectType[lightType]}}
            i.fas.fa-chevron-down
            i.fas.fa-chevron-up
          .dropdown__content
            ul
              li(@click="selectTypeLight(key)" v-for="value, key in selectType") {{value}}
                .search-division-line
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
export default {
  props: {
    headerStatue: {
      type: Boolean,
      required: false
    }
  },
  data() {
    return {
      selectType: {
        "-1": "전체",
        "1": "보안등/중계기",
        "0": "가로등/분전함"
      },
      lightType: -1,
      dashboard: {
        complaint_count: 0,
        light_count: 0,
        light_normal_count: 0,
        error_count: 0,
        complaints: [],
        light_time: {
          OFF_Hour: 0,
          OFF_Min: 0,
          ON_Hour: 0,
          ON_Min: 0
        }
      },
      resData: {
        total: {
          percent: 100,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        normal: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        error: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        complain: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        }
      },
      searchData: "",
      searchType: true,
      now_time: "1999-01-01 AM 12:00"
    };
  },
  computed: {
    headerLocal() {
      if (this.$store.getters.config_area == "geoje") {
        return "geoje";
      } else if (this.$store.getters.config_area == "hygn") {
        return "hygn";
      } else {
        return "";
      }
    }
  },
  methods: {
    selectTypeLight(type) {
      window.selectTypeLight(type);
      this.lightType = type;
      this.clickDropDown();
    },
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown() {
      $(".dashboard-select .dropdown__header").removeClass("is-active");
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    getMidnightDashboard() {
      var vm = this;
      setTimeout(() => {
        vm.now_time = vm.datepickerNowFormatter(
          new Date().setDate(new Date().getDate())
        );
        vm.GetPcWhiteDashboard();
        vm.getMidnightDashboard();
      }, 2000);
    },
    datepickerNowFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD A hh:mm");
    },
    GetPcWhiteDashboard() {
      var vm = this;
      this.$_API_GET("pc/dashboard/count").then(function(res) {
        vm.dashboard.light_time.OFF_Hour = res.time.OFF_Hour;
        vm.dashboard.light_time.OFF_Min = res.time.OFF_Min;
        vm.dashboard.light_time.ON_Hour = res.time.ON_Hour;
        vm.dashboard.light_time.ON_Min = res.time.ON_Min;
        vm.initDashboardData();
        vm.makeDashboard(res);
        vm.dashboard.light_count = vm.resData["total"].cnt;
        vm.dashboard.light_normal_count = vm.resData["normal"].cnt;
        vm.dashboard.error_count = vm.resData["error"].cnt;
        vm.dashboard.complaint_count = vm.resData["complain"].cnt;
        EventBus.$emit("setDashboard", res);
      });
    },
    initDashboardData() {
      // NOTE :: 데이터 초기화용
      this.resData = {
        total: {
          percent: 100,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        normal: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        error: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        complain: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        }
      };
    },
    makeDashboard(res) {
      for (let key in res) {
        if (key != "time") {
          this.inputDataToDashboard(key, res[key]);
        }
      }
    },
    inputDataToDashboard(iot_total, item) {
      // 직접 데이터를 하나하나 넣어준다.
      // 현재 현황판이 세로로 데이터가 넣어진다 생각해야함.
      for (let key in item) {
        let value = item[key];
        key = key.split("_");
        let light_sec_etc = key[0];
        let total_noraml_complain_error = key[1];
        if (total_noraml_complain_error != "total") {
          this.resData[total_noraml_complain_error][iot_total][
            light_sec_etc
          ] = value;
        }
        if (
          total_noraml_complain_error != "total" &&
          total_noraml_complain_error != "complain"
        ) {
          this.resData["total"][iot_total][light_sec_etc] += value;
        }
        if (iot_total == "total") {
          // 퍼센트 아래 총 갯수는 cnt로 들어감
          this.resData[total_noraml_complain_error]["cnt"] += value;
          if (total_noraml_complain_error != "complain") {
            this.resData["total"]["cnt"] += value;
          }
        }
      }
    },
    pad(n, width) {
      n = n + "";
      return n.length >= width
        ? n
        : new Array(width - n.length + 1).join("0") + n;
    },
    onClickChangeDashboard() {
      this.searchType = !this.searchType;
      console.log(this.searchType);
    },
    onClickSearch() {
      if (this.searchType) {
        this.getPcFacilityCountAPI();
      } else {
        window.getValue(this.searchData);
      }
    },
    getPcFacilityCountAPI() {
      var vm = this;
      this.$_API_GET("pc/facility/count", { SL_SLNAME: this.searchData }).then(
        function(res) {
          console.log(res);
          if (res.length == 0) {
            vm.$emit(
              "onAlert",
              "black",
              null,
              "검색된 결과가 없습니다",
              null,
              null,
              true,
              false
            );
          } else if (res.length == 1) {
            var point = window.setCoordsFromPoint(
              res[0].SL_MAP_X,
              res[0].SL_MAP_Y,
              vm.$store.getters.panel_location_name
            );
            window.SetPositionLevel(point.getLng(), point.getLat(), 1);
          } else {
            vm.searchLight();
          }
        }
      );
    },
    searchLight() {
      // NOTE :: 검색 결과가 많으면 상세 검색에서 검색되도록 처리
      this.$store.commit("sidebar_content", "VPDeviceSearch");
      this.$store.commit("sidebar_onHeader", "상세 검색");
      var vm = this;
      Vue.nextTick(function() {
        EventBus.$emit("getPcfacilityAPI", vm.searchData, vm.searchType);
      });
    },
    ep(name, data, type) {
      console.log("ep", name);
      if (name == "modalOpen") {
        EventBus.$emit(name, data, type);
      } else {
        this.$emit(name, data, type);
      }
    },
    searchEnter(e) {
      if (e.key == "Enter") {
        this.onClickSearch();
      }
    },
    movePanel(index) {
      // NOTE :: vuex를 통해 Panel 제어
      if (index == "total") {
        this.$store.commit("sidebar_content", "VPDashboard");
        this.$store.commit("sidebar_onHeader", "현황판");
      } else if (index == "search") {
        this.$store.commit("sidebar_content", "VPDeviceSearch");
        this.$store.commit("sidebar_onHeader", "상세 검색");
      } else if (index == "complain") {
        this.$store.commit("sidebar_content", "VPComplaintList");
        this.$store.commit("sidebar_onHeader", "민원 목록");
      } else if (index == "error") {
        this.$store.commit("sidebar_content", "VPDeviceTrouble");
        this.$store.commit("sidebar_onHeader", "실시간 고장내역");
      }
    }
  },
  mounted() {
    this.now_time = this.datepickerNowFormatter(new Date());
    this.getMidnightDashboard();
    $(".main-header .condition").focusout(function(e) {
      $(".main-header .dropdown__header").removeClass("is-active");
    });
  }
};
</script>

<style>
.dashboard-select {
  margin-left: 10px;
  min-width: 110px;
}
.main-header {
  background: white;
  pointer-events: auto;
  height: 54px;
  display: flex;
}
.main-header .time-zone {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-left: 14px;
  margin-right: 52px;
}
.main-header > div {
  float: left;
}
.main-header .time-zone span,
.main-header .dashboard-area span {
  font-size: 13px;
  white-space: nowrap;
  font-weight: 600;
}
.main-header .time-zone span {
  position: relative;
  top: 3px;
}
.main-header .time-zone .setting-time {
  position: relative;
  top: -4px;
}
.main-header .dashboard-area span {
  /* line-height: 54px; */
}
.main-header .dashboard-area {
  display: flex;
  justify-content: center;
  align-items: center;
}
.main-header .dashboard-dashed {
  display: flex;
  justify-content: center;
  align-items: center;
  flex: 1;
}
.main-header .dashboard-dashed {
  font-size: 35px;
}
.main-header .dashboard-area .dashboard-division {
  height: 18px;
  width: 2px;
  background: #c4c4c4;
  margin-right: 15px;
}
.main-header .dashboard-area .dashboard-content {
  width: 79px;
  margin-right: 13px;
  cursor: pointer;
}
.main-header .dashboard-area .dashboard-content .dashboard-blue {
  line-height: 2.2;
  color: #0e89c2;
}
.main-header .dashboard-area .dashboard-content .dashboard-green {
  line-height: 2.2;
  color: #279835;
}
.main-header .dashboard-area .dashboard-content .dashboard-red {
  line-height: 2.2;
  color: #b43030;
}
.main-header .dashboard-area .dashboard-content .dashboard-orange {
  line-height: 2.2;
  color: #db961f;
}
.main-header .dashboard-area .dashboard-content span:last-child {
  float: right;
}
.main-header .search-area {
  display: flex;
  justify-content: center;
  align-items: center;
  float: right;
  height: 100%;
  flex: 1;
  justify-content: flex-end;
}
.main-header .condition-input input {
  border: 0px;
  background: #eeeeee;
  padding: 5px 30px 5px 11px;
  height: 32px;
  font-size: 12px;
  color: #000000;
  border-radius: 10px;
  width: 139px;
  margin: 0px 8px 0px 6px;
}
.main-header .condition-input button {
  position: absolute;
  top: 14px;
  right: 10px;
  outline: none;
}
.main-header .condition-input button i {
  color: #000000;
}
</style>

<style>
.main-header .select-area .dashboard-division {
  min-width: 1px;
  height: 18px;
  width: 2px;
  background: #c4c4c4;
  margin: 0px 10px 0px 10px;
}
.main-header .select-area .dashboard-select {
  width: 110px;
}
.main-header .select-area {
  display: flex;
  align-items: center;
  float: right;
  height: 100%;
  flex: 1;
  justify-content: flex-end;
  padding-right: 10px;
}
.main-header .select-area .dashboard-menu-icon {
  display: flex;
}
.main-header .select-area .dashboard-img {
  text-align: center;
  width: 20px;
  min-width: 25px;
  line-height: 10px;
}
.main-header .select-area .dashboard-img img {
  width: 70%;
  float: center;
  vertical-align: middle;
  border-style: none;
}

.main-header .select-area .dashboard-img img.geoje {
  width: 90%;
  float: center;
}

.main-header .search-area .logo-select {
  /* NOTE onoffswitch 바꾼 부분*/
  display: inline-flex;
  /* position: relative; */
  width: 100%;
  text-align: center;
  /* width: 79px; */
  /* height: 32px; */
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.main-header .search-area .onoffswitch-checkbox {
  display: none;
}
.main-header .search-area .onoffswitch-label {
  display: block;
  overflow: hidden;
  cursor: pointer;
  border-radius: 10px;
}
.main-header .search-area .onoffswitch-inner {
  display: block;
  width: 200%;
  margin-left: -100%;
  transition: margin 0.14s ease-in 0s;
}
.main-header .search-area .onoffswitch-inner:before,
.main-header .search-area .onoffswitch-inner:after {
  display: block;
  float: left;
  width: 50%;
  height: 32px;
  padding: 0;
  line-height: 32px;
  font-size: 14px;
  color: white;
  font-family: Trebuchet, Arial, sans-serif;
  font-weight: bold;
  box-sizing: border-box;
}
.main-header .search-area .onoffswitch-inner:before {
  content: "표찰명";
  font-size: 14px;
  padding-left: 6px;
  background-color: #eee;
  color: #000000;
}
.main-header .search-area .onoffswitch-inner:after {
  content: "주소";
  font-size: 14px;
  padding-right: 14px;
  background-color: red;
  color: #000000;
  text-align: right;
}
.main-header .search-area .onoffswitch-switch {
  display: block;
  width: 22px;
  margin: 5px;
  background: #ffffff;
  position: absolute;
  top: 0;
  bottom: 0;
  right: 47px;
  border-radius: 8px;
  transition: all 0.2s ease-in 0s;
}
.main-header
  .search-area
  .onoffswitch-checkbox:checked
  + .onoffswitch-label
  .onoffswitch-inner {
  margin-left: 0;
}
.main-header
  .search-area
  .onoffswitch-checkbox:checked
  + .onoffswitch-label
  .onoffswitch-switch {
  right: 0px;
}
</style>
<style lang="scss">
// NOTE :: DropDown CSS
.select-area {
  & .dropdown {
    width: 100%;
    &__header {
      border-radius: 10px;
      background: #eee;
      font-size: 12px;
      cursor: pointer;
      line-height: 30px;
      position: relative;
      text-overflow: ellipsis;
      color: #484848;
      width: 100%;
      height: 30px;
      i.fas {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 12px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &.is-active {
        outline: none;
        // outline: -webkit-focus-ring-color auto 1px;
        // outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
        }
      }
      & span {
        padding-left: 11px;
      }
    }
    &__content {
      z-index: 1011;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #eee;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #484848;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>
