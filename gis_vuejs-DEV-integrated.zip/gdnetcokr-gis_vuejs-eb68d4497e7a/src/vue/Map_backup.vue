<template lang="pug">
#map
  vue-daum-map#_map(
    ref="vueDaumMap"
    :appKey="appKey"
    :center="center"
    :level.sync="level"
    :mapTypeId="mapTypeId"
    :libraries="libraries"
    @load="onLoad")

</template>

<script>
import VueDaumMap from "vue-daum-map";

export default {
  components: {
    VueDaumMap
  },
  data() {
    return {
      appKey: "6353f7b8ce76cc0661c9b68ad071a226", // 테스트용 appkey
      center: { lat: 34.880584, lng: 128.621222 }, // 지도의 중심 좌표
      level: 3, // 지도의 레벨(확대, 축소 정도)
      mapTypeId: VueDaumMap.MapTypeId.NORMAL, // 맵 타입
      libraries: [], // 추가로 불러올 라이브러리
      map: null, // 지도 객체. 지도가 로드되면 할당됨.
      reqFacility: {
        latitude: "",
        longitute: "",
        light_type: -1,
        lasttime: 0
      },
      lightUpdtedAt: 0
    };
  },
  methods: {
    onLoad(map) {
      window.map = this.map = map;

      // NOTE 쉽게 바뀌지 않을 것 같아서 idx 직접 지정 (다음 맵 링크, 축적 등이 나오는 div임)
      //      만약 바뀐다면 다음 지도 링크 있는 div 찾아내면 될 것
      $("#_map > *")
        .eq(1)
        .addClass("related_panel")
        .attr("id", "daum_link");
      $("#daum_link").insertAfter("#center_mark");

      kakao.maps.event.addListener(map, "zoom_changed", function() {
        console.log("zoom_changed:", map.getLevel());
      });
    },
    getFacilityAPI() {
      this.reqFacility.latitude = this.center.lat;
      this.reqFacility.longitute = this.center.lng;
      this.reqFacility.lasttime = this.lightUpdtedAt;
      var vm = this;
      this.$_API_GET("facility", this.reqFacility).then(function(res) {
        console.log("getfacility", res);
        if (res.light.length > 0) {
          vm.lightUpdtedAt = res.time;
        } else if (vm.lightUpdtedAt == 0) {
          vm.lightUpdtedAt = 1;
        }

        var markerSize;
        var markerurl;
        for (var light in res.light) {
          markerSize = vm.GetLightImageSize(res.light[light].SL_DATA_1);
          console.log(markerSize);
        }
      });
    },
    GetLightImageSize(LAMP_TYPE) {
      var TYPE_BOX_DISTRIBUTION = 4; //분전함
      var TYPE_BOX_REPEATER = 5; //중계기
      var TYPE_LIGHTHOUSE_LANTERN = 6; //등명기
      var TYPE_BOX_DISTRIBUTION_MINI = 10;
      var width = 0;
      var height = 0;
      if (
        $.inArray(parseInt(LAMP_TYPE), [
          TYPE_BOX_DISTRIBUTION,
          TYPE_BOX_REPEATER,
          TYPE_LIGHTHOUSE_LANTERN,
          TYPE_BOX_DISTRIBUTION_MINI
        ]) >= 0
      ) {
        width = 22;
        height = 22;
      } else {
        width = 18;
        height = 18;
      }
      return {
        width: width,
        height: height
      };
    },
    GetLightImagePath2() {},
    AddMarker() {}
  },
  created() {},
  mounted() {
    this.getFacilityAPI();
  }
};
</script>

<style>
#_map {
  width: 100%;
  height: 100%;
}

#daum_link {
  margin: 0px !important;
  pointer-events: auto;
}
.top #daum_link,
.right #daum_link {
  margin: 0px !important;
}
.left #daum_link {
  margin-bottom: 0px !important;
}
.bottom #daum_link {
  margin-left: 0px !important;
}

#center_mark {
  position: absolute;
  width: 64px;
  height: 64px;
  margin: -32px;
  z-index: 1;
  opacity: 0.5;
  pointer-events: none;
}
.hidden + #map #center_mark {
  margin: -32px !important;
}
.left #center_mark,
.top #center_mark {
  left: 50%;
  top: 50%;
}
.right #center_mark,
.bottom #center_mark {
  right: 50%;
  bottom: 50%;
}
.left #center_mark {
  margin-top: -32px !important;
}
.bottom #center_mark {
  margin-right: -32px !important;
}
.right #center_mark {
  margin-bottom: -32px !important;
  margin-left: 0px !important;
}
.top #center_mark {
  margin-bottom: 0px !important;
  margin-left: -32px !important;
}

#row_line {
  position: absolute;
  top: 50%;
  margin-top: -2px;
  width: 100%;
  height: 4px;
  background: tomato;
}
#col_line {
  position: absolute;
  left: 50%;
  margin-left: -2px;
  width: 4px;
  height: 100%;
  background: tomato;
}
</style>
