<template lang="pug">
#layout
  #print_div(style="position:absolute; width:100%; height:100%;")
  map_#map_wrap.map_wrap(:class="this.$store.getters.roadviewMap == 'roadview'? 'map_sub' : ''" :style="this.$store.getters.roadviewMap == 'roadview'?{width: this.$store.getters.rvSizeW+'px', height: this.$store.getters.rvSizeH+'px'}:{width: 100+'%', height: 100+'%'}" v-on:onAlert="onAlert")
  #main
    sidebar_#sidebar(v-on:clickMenu="onClickMenu" v-on:onAlert="onAlert" :value="sidebarStatue")
    .main-content
      #content(v-bind:class="panelLocationName")
        #panel(:class="$store.getters.panel_class")
          panel_
        #anchorFlash.ptr-evt--a
          a(href="http://get.adobe.com/flashplayer/" target="_blank" id="anchorFlash" style="display:block; position:absolute; height:100%; width:100%; z-index:9999;")
            p(style="position:absolute; top:50%; width:100%;text-align: center; font-size: 24px") 브라우저로부터 Adobe Flash 권한이 허용되지 않았습니다. 여기를 눌러주세요.
        .main-header-area
          .sidebar-side-line
            .sidebar-side-btn(v-show="sidebarStatue" @click="sidebarOpenClose('close')")
              font-awesome-icon.result-awssome(icon='angle-left' )
            .sidebar-side-btn( v-show="!sidebarStatue" @click="sidebarOpenClose('open')")
              font-awesome-icon.result-awssome(icon='angle-right')
          header_(:headerStatue="headerStatue" @resize="console.log('asd')" v-show="!headerStatue" v-on:onAlert="onAlert")
          .header-hide-line
            .header-hide-btn(v-show="!headerStatue" @click="headerOpenClose('close')")
              font-awesome-icon.result-awssome-header-up(icon='angle-up')
            .header-hide-btn(v-show="headerStatue" @click="headerOpenClose('open')")
              font-awesome-icon.result-awssome-header-down(icon='angle-down')
          #visible_map
            #center_mark(v-if="this.$store.getters.status == ''")
              #row_line
              #col_line
            #center_mark_sub(v-else)
              img(:src="require('@/assets/img/res/img/light_add_position.png')")
            #map_typecontrol.ptr-evt--a
              #typecontrol-btn-group
                //- button(@click='clickMarker') 임시! 마커용
                button#typecontrol-btn(type='button' @click="setMapType('roadmap')" :class="btnControl(1)") 지도
                button#typecontrol-btn(type='button' @click="setMapType('skyview')" :class="btnControl(3)") 위성
            #map_roadview.ptr-evt--a( @mouseover="mouseHover('#map_roadview_bubble', true)" @mouseleave="mouseHover('#map_roadview_bubble', false)" )
              i.fa.fa-map-marker#roadview-btn.unseleted_btn(icon="map-pin" :class="controlStatusClass('roadview')" @click="setRvMode")
            #map_print.ptr-evt--a
              font-awesome-icon#print(icon="print" @click="print" @mouseover="mouseHover('#map_print_bubble', true)" @mouseleave="mouseHover('#map_print_bubble', false)" :class="controlStatusClass('print')" @mousedown="controlStatus.print = !controlStatus.print"  @mouseup="controlStatus.print = !controlStatus.print")
            //- #map_gps.ptr-evt--a
            //-   button#typecontrol-btn(type='button' @click="") gps
            #map_zoom.ptr-evt--a.zoom
              .tool-area(@click="zoomIn" @mouseover="mouseHover('#map_plus_bubble', true)" @mouseleave="mouseHover('#map_plus_bubble', false)" @mousedown="controlStatus.zoomIn = !controlStatus.zoomIn" @mouseup="controlStatus.zoomIn = !controlStatus.zoomIn")
                font-awesome-icon#zoom-plus(icon='plus' exp='줌인' :class="controlStatusClass('zoomIn')" )
              .tool-area(@click="zoomOut")
                font-awesome-icon#zoom-minus(icon='minus' exp='줌아웃' @mouseover="mouseHover('#map_minus_bubble', true)" @mouseleave="mouseHover('#map_minus_bubble', false)" :class="controlStatusClass('zoomOut')" @mousedown="controlStatus.zoomOut = !controlStatus.zoomOut"  @mouseup="controlStatus.zoomOut = !controlStatus.zoomOut")
            #map_tools.ptr-evt--a.icon
              .tool-area.ruler-click(@click="setRulerMode" @mouseover="mouseHover('#map_distance_bubble', true)" @mouseleave="mouseHover('#map_distance_bubble', false)")
                i.fas.fa-road#icon-distance(icon='road' exp='거리재기' :class="controlStatusClass('distance')" )
              .tool-area.polygon-click(@click="setpolygonMode"  @mouseover="mouseHover('#map_area_bubble', true)" @mouseleave="mouseHover('#map_area_bubble', false)")
                i.fas.fa-expand#icon-area(icon='expand' exp='면적재기' :class="controlStatusClass('area')")
              .tool-area.drawing-click(@click="setdrawingMode" @mouseover="mouseHover('#map_radical_bubble', true)" @mouseleave="mouseHover('#map_radical_bubble', false)")
                i.far.fa-compass#icon-radical(:class="controlStatusClass('radical')" )
            #map_info.ptr-evt--a.icon(@click="controlStatus.clickInfo = !controlStatus.clickInfo" @mouseover="mouseInfoHover(true)" @mouseleave="mouseInfoHover(false)")
              i.fas.fa-info#icon-info( exp='인포' :class="controlStatusClass('clickInfo')")
            .search-area.ptr-evt--a
              label.switch
                input#togBtn(type='checkbox' checked @click="onClickChangeDashboard")
                .slider.round
                  span.slname 표찰명
                  span.name 주소
              //- input.onoffswitch-checkbox(type="checkbox" name="onoffswitch" id="headeronoffswitch" checked  @click="onClickChangeDashboard")
              //- label.onoffswitch-label(for="headeronoffswitch")
              //-   span.onoffswitch-inner
              //-   span.onoffswitch-switch
              .condition-input
                input(v-model="searchData" v-on:keyup="searchEnter($event)" style="ime-mode:active;")
                button(@click="onClickSearch")
                  i.fa.fa-search
            //- .light_typecontrol.ptr-evt--a  //NOTE : 0808 미래를 위한 주석 -> visible_light_type_temp 가 현재 사용중, map js 포함
            //-   select.map-header-arrow#visible_light_type.radius_border.placeholder.map_light_type(v-model="lightType" @click="onClickLightTypeSelect")
            //-     option(value='1') 보안등/중계기
            //-     option(value='0') 가로등/분전함
            //-     option(value='-1') 전체
            #map_add_sub.ptr-evt--a
              button.map_light_cancel(type='button' @click="addLightCancle" v-if="this.$store.getters.status == 'createLight'") 설치 취소
              button.map_light_complate(type='button' @click="addLightComplate" v-if="this.$store.getters.status == 'createLight'") 설치 완료
            #map_add_sub.ptr-evt--a
              button.map_light_cancel(type='button' @click="addLightCancle" v-if="this.$store.getters.status == 'moveLight'") 이동 취소
              button.map_light_complate(type='button' @click="MoveLightComplate" v-if="this.$store.getters.status == 'moveLight'") 이동 완료
            #map_daum_copyright.ptr-evt--a
              .daum_copyright
            #map_roadview_bubble.ptr-evt--a
              .bubble-top
                p.bubble-text 로드뷰
            #map_print_bubble.ptr-evt--a
              .bubble-top
                p.bubble-text 프린트
            #map_plus_bubble.ptr-evt--a
              .bubble
                p.bubble-text 확대
            #map_minus_bubble.ptr-evt--a
              .bubble
                p.bubble-text 축소
            #map_distance_bubble.ptr-evt--a
              .bubble
                p.bubble-text 거리재기
            #map_area_bubble.ptr-evt--a
              .bubble
                p.bubble-text 면적재기
            #map_radical_bubble.ptr-evt--a
              .bubble
                p.bubble-text 반경재기
            #map_info_bubble_1.ptr-evt--a
              .bubble
                p.bubble-text 일반
              img.info-icon(:src="require('@/assets/img/res/img/info_green.png')")
            #map_info_bubble_2.ptr-evt--a
              .bubble
                p.bubble-text 소등
              img.info-icon(:src="require('@/assets/img/res/img/info_black.png')")
            #map_info_bubble_3.ptr-evt--a
              .bubble
                p.bubble-text 심야소등
              img.info-icon(:src="require('@/assets/img/res/img/info_gray.png')")
            #map_info_bubble_4.ptr-evt--a
              .bubble
                p.bubble-text 점등
              img.info-icon(:src="require('@/assets/img/res/img/info_yellow.png')")
            #map_info_bubble_5.ptr-evt--a
              .bubble
                p.bubble-text 일시불량
              img.info-icon(:src="require('@/assets/img/res/img/info_orange.png')")
            #map_info_bubble_6.ptr-evt--a
              .bubble
                p.bubble-text 불량
              img.info-icon(:src="require('@/assets/img/res/img/info_red.png')")
            #rvWrapper(:style="this.$store.getters.roadviewMap == 'roadview'?{width: '100%', height: '100%'}:{}")
              #roadview.ptr-evt--a(:class="this.$store.getters.roadviewMap == 'roadview'? 'roadview_main' : ''" :style="this.$store.getters.roadviewMap == 'map'?{width: this.$store.getters.rvSizeW+'px', height: this.$store.getters.rvSizeH+'px'}:{width: 100+'%', height: 100+'%'}")
                //- .roadview-expand(v-show="!roadviewSizeCheck" @click="roadviewSize('expand')")
                //- .roadview-reduce(v-show="roadviewSizeCheck" @click="roadviewSize('reduce')" style="display:none")
              .change-main-map(v-show="this.$store.getters.roadviewMap == 'map'" @click="changeRoadviewMap('roadview')")
              .exit-rv(v-show="this.$store.getters.roadviewMap == 'map'" @click="exitRV")
            #light_add_caution.ptr-evt--a(v-if="this.$store.getters.status != ''")
              span 신규 시설물 설치 중에는 다른 작업을 진행하실 수 없습니다
              br
              span 현재 작업이 완료 된 후에 진행해주세요
  #map_top_area
    #map_add.light_movecontrol.ptr-evt--a
        .tap-menu
          .bnt
            button#btn_move_cancel.btn.btn-default(type='button' @click="cancelMoving(false)") 취소
            button#btn_move_confirm.btn.btn-info(type='button' @click='saveFacility') 설치
        .info.ptr-evt--a
          span.info-content 시설물을 설치중입니다.
    #map_add_btn.ptr-evt--a
      img#light_add(:src="require('@/assets/img/res/img/light_add.png')" @click="addLight" v-if="this.$store.getters.status == ''"  @mouseover="mouseHover('#map_add_bubble', true)" @mouseleave="mouseHover('#map_add_bubble', false)")
    #map_add_bubble.ptr-evt--a
      .bubble(style="width:75px")
        p.bubble-text 시설물 추가
  #modal_area(v-show="this.$store.getters.status == ''")
    modal_(v-for="(val, key) in this.$store.getters.modals"
      v-bind:key="key"
      v-bind:id="val.id"
      v-bind:type="val.type"
      v-bind:count="count")
  vm-alert(ref="alert" @event="alertEvent")
  vm-picture(v-if="picture.status" v-on:exitAlert="picture.status = false" :pictureID="picture.id" :pictureIndexFirst="picture.index")  
</template>

<script>
import Vue from "vue";
import SideBar from "@/vue/SideBar";
import Map from "@/vue/Map";
import Header from "@/vue/Header";

import VModal from "@/components/VModal";
import VPanel from "@/components/VPanel";
import VMPicture from "@/components/modal/VMPicture";

import { EventBus } from "@/main";

export default {
  components: {
    sidebar_: SideBar,
    map_: Map,
    modal_: VModal,
    panel_: VPanel,
    header_: Header,
    "vm-picture": VMPicture
  },
  data() {
    return {
      drwaing: false,
      polygon: false,
      lightType: -1,
      controlType: 1,
      controlStatus: {
        roadview: false,
        distance: false,
        area: false,
        radical: false,
        clickInfo: false,
        zoomIn: false,
        zoomOut: false,
        print: false
      },
      count: 0,
      picture: {
        status: false,
        id: "",
        index: 0
      },
      rvSize: {
        rvW: 400,
        rvH: 400
      },
      sidebarStatue: true,
      searchType: true,
      roadviewSizeCheck: false,
      roadviewChange: false,
      searchData: "",
      headerStatue: false,
      resizeChangeVal: 959
    };
  },
  updated() {},
  watch: {
    "$store.getters.sidebar_content": function(val) {
      var vm = this;
      Vue.nextTick(function() {
        vm.adjustPanelRelated();
        if ($("#roadview").is(":visible")) {
          window.evtRvPositionChanged();
        }
      });
    }
  },
  computed: {
    panelLocationName() {
      return this.$store.getters.panel_location_name;
    }
  },
  methods: {
    searchEnter(e) {
      if (e.key == "Enter") {
        this.onClickSearch();
      }
    },
    onClickSearch() {
      if (this.searchType) {
        this.getPcFacilityCountAPI();
      } else {
        window.getValue(this.searchData);
      }
    },
    getPcFacilityCountAPI() {
      var vm = this;
      this.$_API_GET("pc/facility/count", { SL_SLNAME: this.searchData }).then(
        function(res) {
          console.log(res.length == 0);
          if (res.length == 0) {
            vm.$refs.alert.init(
              "black",
              null,
              "검색된 결과가 없습니다",
              null,
              null,
              true,
              false
            );
            console.log(vm.alert);
          } else if (res.length == 1) {
            var point = window.setCoordsFromPoint(
              res[0].SL_MAP_X,
              res[0].SL_MAP_Y,
              vm.$store.getters.panel_location_name
            );
            window.SetPositionLevel(point.getLng(), point.getLat(), 1);
            if ($("#roadview").is(":visible")) {
              window.isToggleRvJustNow = true;
              window.evtRvPositionChanged();
            }
          } else {
            vm.searchLight();
          }
        }
      );
    },
    searchLight() {
      // TODO :: 리스트 검색 결과가 많으면 상세 검색 패널로 넘어가서 검색하는 방식을 지도쪽에서 나오는 형태로 회의 및 수정 필요
      if (!$("#sidebar").is(":visible")) {
        this.sidebarOpenClose("open");
      }
      this.$store.commit("sidebar_content", "VPDeviceSearch");
      this.$store.commit("sidebar_onHeader", "상세 검색");

      var vm = this;
      Vue.nextTick(function() {
        EventBus.$emit("getPcfacilityAPI", vm.searchData, vm.searchType);
      });
    },
    cancelMoving(flag) {
      // NOTE :: 이동취소, 설치 취소 등 기기 취소 버튼 누르면 작동
      window.cancelMoving(flag);
      $("#modal_area").removeClass("hidden");
    },
    saveFacility() {
      if (window.installFlag) {
        this.addLightComplate();
        $("#map_add.light_movecontrol *").css("visibility", "collapse");
        window.installFlag = false;
        window.tooltipDataObj.isMoving = false;
        let data = window.tooltipDataObj.data;
        let panel_level = window.tooltipDataObj.panel_level;
        window.makeToolTip(data, panel_level);
        return;
      }
      let marker =
        window.overlayObjects[window.overlayObjects.length - 1]["Object"];
      let slcode = window.installMoveSLCODE;
      let xPos = marker.getPosition().getLat();
      let yPos = marker.getPosition().getLng();
      window.installMoveStatus = false;
      window.installMoveSLCODE = false;
      window.overlayObjects[window.overlayObjects.length - 1]["Object"].setMap(
        null
      );
      this.$_API_UPDATE("Facilitypos", {
        xPos: m_movedX,
        yPos: m_movedY,
        SL_SLCODE: slcode
      }).then(function(res) {
        console.log(res);
        window.invalidateLight = true;
      });
      this.cancelMoving(true);
    },
    onAlert(
      alertType,
      headerTitle,
      firstText,
      secondText,
      inputPlaceHolder,
      okBtn,
      cancelBtn
    ) {
      this.$refs.alert.init(
        alertType,
        headerTitle,
        firstText,
        secondText,
        inputPlaceHolder,
        okBtn,
        cancelBtn
      );
    },
    controlStatusClass(data) {
      if (this.controlStatus[data] == true) {
        return "control-status-on";
      } else {
        return "";
      }
    },
    btnControl(data) {
      if (this.controlType == data) {
        return "btn-control-on";
      } else {
        return "";
      }
    },
    onWindowResize(event) {
      if ($(".main-header-area .main-header").width() > this.resizeChangeVal) {
        $(".main-header-area .dashboard-area").show();
        $(".main-header-area .dashboard-dashed").hide();
      } else {
        $(".main-header-area .dashboard-area").hide();
        $(".main-header-area .dashboard-dashed").show();
      }
      this.adjustPanelSizeOptions();
    },
    adjustPanelSizeOptions() {
      // 64 is center_mark size
      // let maxWidth = $("#content").width();
      // let maxHeight = $("#content").height();
      // NOTE :: resize size
      let maxWidth = 900;
      let maxHeight = 900;
      $("#panel").resizable("option", "maxWidth", maxWidth);
      $("#panel").resizable("option", "maxHeight", maxHeight);
      $("#panel").width(Math.min($("#panel").width(), maxWidth));
      $("#panel").height(Math.min($("#panel").height(), maxHeight));
      this.adjustPanelRelated();
    },
    adjustPanelRelated() {
      // NOTE :: resize relate
      $("#panel").width(this.$store.state.settings.panel.size);
      $("#panel").height(this.$store.state.settings.panel.size);
      $("#panel").css("min-width", this.$store.state.settings.panel.size);
      $("#panel").css("min-height", this.$store.state.settings.panel.size);
      if (this.$store.state.settings.panel.location % 2 == 0) {
        $("#panel").css(
          "max-width",
          $("#panel").resizable("option", "maxWidth")
        );
        $("#panel").css("max-height", "100%");
      } else {
        $("#panel").css("max-width", "100%");
        $("#panel").css(
          "max-height",
          $("#panel").resizable("option", "maxHeight")
        );
      }
      if ($(".main-header-area .main-header").width() > this.resizeChangeVal) {
        $(".main-header-area .dashboard-area").show();
        $(".main-header-area .dashboard-dashed").hide();
      } else {
        $(".main-header-area .dashboard-area").hide();
        $(".main-header-area .dashboard-dashed").show();
      }
      // if (this.$store.state.settings.panel.location == 0) {
      //   if ($("#panel").is(":visible")) {
      //     $("#map_canvas")
      //       .children()
      //       .eq(2)
      //       .css("left", 230 + $("#panel").width() + "px");
      //   } else {
      //     $("#map_canvas")
      //       .children()
      //       .eq(2)
      //       .css("left", "230px");
      //   }
      // }
    },
    onClickMenu(idx) {
      console.log("onClickMenu: " + idx);
      if (idx == 0) {
        // test - on, off
        // console.log("toggle");
        // $("#panel").toggleClass("hidden");
      } else if (idx == "panelRotate") {
        this.$store.commit("panel_rotate");
        if (
          this.$store.getters.panel_location_name == "left" ||
          this.$store.getters.panel_location_name == "right"
        ) {
          $("#panel_area").css("overflow", "unset");
        } else {
          $("#panel_area").css("overflow", "auto");
        }
        console.log(this.$store.getters.panel_location_name);
        window.panelPosition = this.$store.getters.panel_location_name;
        Vue.nextTick(function() {
          if ($("#roadview").is(":visible")) {
            window.evtRvPositionChanged();
          }
        });
      } else if (idx == "openModal") {
        EventBus.$emit("modalOpen", "Modal", "VMLight");
      } else if (idx == 3) {
        let modal_keys = Object.keys(this.$store.state.modals);
        if (modal_keys.length >= 1) {
          this.modalClose(modal_keys[0]);
        }
      }
      // console.log(this.$store.state.settings.panel.size);
      this.adjustPanelRelated();
    },
    onRoadViewResize(e, ui) {
      this.$store.commit("rvSize", {
        width: ui.size.width,
        height: ui.size.height
      });

      Vue.nextTick(function() {
        window.rv.relayout();
      });
      $("#rvWrapper").css("width", ui.size.width);
      $("#rvWrapper").css("height", ui.size.height);
      $("#rvWrapper").css({ top: "", opacity: "" });
      $("#rvWrapper").css({ left: "", opacity: "" });

      if (this.$store.getters.roadviewMap == "map") {
        var add_btn_right = parseInt($("#roadview").css("width")) + 10;
        $("#map_add_btn").css("right", add_btn_right + "px");
      }
    },
    onMapResize(e, ui) {
      // NOTE :: roadview resize
      this.$store.commit("rvSize", {
        width: ui.size.width,
        height: ui.size.height
      });

      Vue.nextTick(function() {
        window.map.relayout();
        var rvPosition = window.rv.getPosition();
        var panel_level = getPanelLevel();
        var point = window.setCoordsFromPoint(
          rvPosition.getLng(),
          rvPosition.getLat(),
          panel_level
        );
        window.map.setCenter(point);
      });

      $("#map_wrap").css("width", ui.size.width);
      $("#map_wrap").css("height", ui.size.height);
      $("#map_wrap").css({ top: "", opacity: "" });
      $("#map_wrap").css({ left: "", opacity: "" });
    },
    onPanelResize(e, ui) {
      // console.log("onPanelResize", ui.size.width, ui.size.height);
      if (this.$store.state.settings.panel.location % 2 == 0) {
        this.$store.commit("panel_size", ui.size.width);
      } else {
        this.$store.commit("panel_size", ui.size.height);
      }
      if ($("#roadview").is(":visible")) {
        window.evtRvPositionChanged();
      }
      if ($(".main-header-area .main-header").width() > this.resizeChangeVal) {
        $(".main-header-area .dashboard-area").show();
        $(".main-header-area .dashboard-dashed").hide();
      } else {
        $(".main-header-area .dashboard-area").hide();
        $(".main-header-area .dashboard-dashed").show();
      }
      this.adjustPanelRelated();
    },
    onCloseModal(key) {
      console.log("hi?", key);
      this.$delete(this.$store.modals, key);
    },
    modalOpen(modalID, modalType) {
      if (this.count == 5) {
        this.count = 1;
      } else {
        this.count = this.count + 1;
      }
      this.$store.commit("modal_open", { id: modalID, type: modalType });
    },
    modalClose(key) {
      this.$store.commit("modal_close", key);
    },
    print() {
      // var g_oBeforeBody = document.getElementById("map_canvas").innerHTML;
      // window.onbeforeprint = function(ev) {
      //   document.body.innerHTML = g_oBeforeBody;
      // };
      // document.body.style.zoom = 0.7;
      // document.body.style.zoom = 1;
      // location.reload();
      // window.print();
      // TODO :: 프린트 방식을 새탭, 새창, 다른 형식으로 갈지 회의를 하여 다른 형식으로 지도 프린트 되는 작업 필요
      window.printMap();
      // let route = this.$router.resolve({ path: "/print/map" });
      // window.open(route.href, "_blank");
    },
    zoomIn() {
      window.map.setLevel(window.map.getLevel() - 1);
      this.manageMapLevel();
    },
    zoomOut() {
      window.map.setLevel(window.map.getLevel() + 1);
      this.manageMapLevel();
    },
    manageMapLevel(m_zoomLevel) {
      window.tooltipManager();
    },
    setRulerMode(e) {
      this.controlStatus.distance = !this.controlStatus.distance;
      this.setTools("Ruler");
      window.setRulerModeAtSide(e.target);
    },
    setRvMode(e) {
      this.$store.commit("roadviewMap", "map");
      this.controlStatus.roadview = !this.controlStatus.roadview;
      window.setRvModeAtSide(e.target);
      // console.log("setRvMode : ", this.$store.getters.roadviewMap);
      // console.log("controlStatus : ", this.controlStatus.roadview);
      // console.log("roadviewChange : ", this.roadviewChange);

      if (this.controlStatus.roadview) {        
        var add_btn_right = parseInt($("#roadview").css("width")) + 10;        
        if (add_btn_right == 10){
          $("#map_add_btn").css("right", 410 + "px");  
        } else {
          $("#map_add_btn").css("right", add_btn_right + "px");
        }        
      } else {
        $("#map_add_btn").css("right", 10 + "px");
      }
    },
    setMapType(maptype) {
      if (maptype === "roadmap") {
        window.map.setMapTypeId(kakao.maps.MapTypeId.ROADMAP);
      } else if (maptype === "skyview") {
        window.map.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
      }
      this.controlType = window.map.getMapTypeId();
    },
    setdrawingMode() {
      this.controlStatus.radical = !this.controlStatus.radical;
      this.setTools("drawing");

      if (this.drwaing) {
        window.removeCircles();
        this.drwaing = false;
      } else {
        window.drawingMode();
        this.drwaing = true;
      }
    },
    setpolygonMode() {
      this.controlStatus.area = !this.controlStatus.area;
      this.setTools("polygon");
      if (this.polygon) {
        window.removePolygon();
        this.polygon = false;
      } else {
        window.polygonMode();
        this.polygon = true;
      }
    },
    setTools(type) {
      if (type == "Ruler") {
        if (this.drwaing) {
          window.removeCircles();
          this.drwaing = false;
          this.controlStatus.radical = !this.controlStatus.radical;
        }
        if (this.polygon) {
          window.removePolygon();
          this.polygon = false;
          this.controlStatus.area = !this.controlStatus.area;
        }
      } else if (type == "drawing") {
        if (this.controlStatus.distance) {
          $(".ruler-click").click();
        }
        if (this.polygon) {
          window.removePolygon();
          this.polygon = false;
          this.controlStatus.area = !this.controlStatus.area;
        }
      } else if (type == "polygon") {
        if (this.controlStatus.distance) {
          $(".ruler-click").click();
        }
        if (this.drwaing) {
          window.removeCircles();
          this.drwaing = false;
          this.controlStatus.radical = !this.controlStatus.radical;
        }
      }
    },
    addLight() {
      console.log("시설물 추가");
      EventBus.$emit("modalOpen", "Modal", "VMLightAdd");
    },
    addLightCancle() {
      $("#sidebar > *").removeClass("pointer-events-none");
      $("#sidebar").unbind("click");
      this.$store.commit("status", "");
    },
    addLightComplate() {
      // this.$store.commit("modal_close", "Modal:VMLightAdd");
      $("#sidebar > *").removeClass("pointer-events-none");
      $("#sidebar").unbind("click");
      console.log(window.map.getCenter().ib);
      console.log(window.map.getCenter().jb);
      var vm = this;
      Vue.nextTick(function() {
        EventBus.$emit("postFacilityAPI");
      });
    },
    MoveLightComplate() {
      $("#sidebar > *").removeClass("pointer-events-none");
      $("#sidebar").unbind("click");
      var vm = this;
      Vue.nextTick(function() {
        EventBus.$emit(vm.$store.getters.moveID + "postPcFacilityposAPI");
      });
    },
    mouseHover(e, status) {
      if (status) {
        $(e).css("display", "block");
      } else {
        $(e).css("display", "none");
      }
    },
    mouseInfoHover(status) {
      if (this.controlStatus.clickInfo) {
        $("#map_info").css("height", "220px");
        $("#map_info_bubble_1").css("display", "block");
        $("#map_info_bubble_2").css("display", "block");
        $("#map_info_bubble_3").css("display", "block");
        $("#map_info_bubble_4").css("display", "block");
        $("#map_info_bubble_5").css("display", "block");
        $("#map_info_bubble_6").css("display", "block");
      } else {
        if (status) {
          $("#map_info").css("height", "220px");
          $("#map_info_bubble_1").css("display", "block");
          $("#map_info_bubble_2").css("display", "block");
          $("#map_info_bubble_3").css("display", "block");
          $("#map_info_bubble_4").css("display", "block");
          $("#map_info_bubble_5").css("display", "block");
          $("#map_info_bubble_6").css("display", "block");
        } else {
          $("#map_info").css("height", "35px");
          $("#map_info_bubble_1").css("display", "none");
          $("#map_info_bubble_2").css("display", "none");
          $("#map_info_bubble_3").css("display", "none");
          $("#map_info_bubble_4").css("display", "none");
          $("#map_info_bubble_5").css("display", "none");
          $("#map_info_bubble_6").css("display", "none");
        }
      }
    },
    onClickChangeDashboard() {
      this.searchType = !this.searchType;
      console.log(">>>>", this.searchType);
    },
    onClickLightTypeSelect() {
      console.log("aaaaaaaaaaaaaaa");
    },
    sidebarOpenClose(value) {
      console.log(value);

      if (value == "open") {
        this.sidebarStatue = true;
        if (this.$store.getters.panel_size != 0) {
          this.$store.commit("panel_class", "");
        }
        $("#sidebar").css("display", "");
        var vm = this;
        Vue.nextTick(function() {
          if (
            $(".main-header-area .main-header").width() > vm.resizeChangeVal
          ) {
            $(".main-header-area .dashboard-area").show();
            $(".main-header-area .dashboard-dashed").hide();
          } else {
            $(".main-header-area .dashboard-area").hide();
            $(".main-header-area .dashboard-dashed").show();
          }
        });
      } else if (value == "close") {
        this.sidebarStatue = false;
        this.$store.commit("panel_class", "hidden");
        $("#sidebar").css("display", "none");
        $(".main-header-area .dashboard-area").show();
        $(".main-header-area .dashboard-dashed").hide();
      }
    },
    headerOpenClose(value) {
      if (value == "open") {
        this.headerStatue = false;
      } else if (value == "close") {
        this.headerStatue = true;
      }
    },
    roadviewSize(data) {
      if (data == "expand") {
        this.roadviewSizeCheck = true;
        $("#roadview").width(700);
        $("#roadview").height(700);
      } else {
        this.roadviewSizeCheck = false;
        $("#roadview").width(400);
        $("#roadview").height(400);
      }
    },
    changeRoadviewMap(data) {
      if (data == "roadview") {
        this.roadviewChange = true;
        $("#rvWrapper .ui-resizable-handle.ui-resizable-nw").css(
          "display",
          "none"
        );
        $("#map_wrap .ui-resizable-handle.ui-resizable-nw").css(
          "display",
          "block"
        );
        $("#map_add_btn").css("display","none");
      } else {
        this.roadviewChange = false;
      }
      this.$store.commit("roadviewMap", data);
      console.log($("#roadview").width());
      console.log($("#roadview").height());
      // $('.map_sub').width()
      // $('.map_sub').height()
      // $(".map_sub").css("width", $("#roadview").width());
      // $(".map_sub").css("height", $("#roadview").height());
      Vue.nextTick(function() {
        window.map.relayout();
        window.rv.relayout();
        var rvPosition = window.rv.getPosition();
        var panel_level = getPanelLevel();
        var point = window.setCoordsFromPoint(
          rvPosition.getLng(),
          rvPosition.getLat(),
          panel_level
        );
        window.map.setCenter(point);
      });
    },
    facilityModalOpen(modalID, modalType) {
      this.modalOpen(modalID, modalType);
      if (modalType == "VMComplainHistory") {
        Vue.nextTick(function() {
          EventBus.$emit("getComplainHistoryInfo", modalID);
        });
      }
    },
    exitRV() {
      $("#roadview-btn").click();
    },
    alertEvent(key, inputData) {
      console.log("alert key", key);
      console.log("alert inputData", inputData);
    }
  },
  created() {
    this.$store.commit("modal_init");
    var vm = this;
    EventBus.$on("clickMenu", function(data) {
      vm.onClickMenu(data);
    });
    EventBus.$on("modalOpen", function(modalID, modalType) {
      vm.modalOpen(modalID, modalType);
    });
    EventBus.$on("pictureShow", function(status, data, index) {
      console.log("pictureShow", status);
      console.log("pictureShow", data);
      vm.picture.status = status;
      vm.picture.id = data;
      vm.picture.index = index;
    });
  },
  mounted() {
    if (this.$store.getters.config_area == "geoje") {
      this.resizeChangeVal = 959;
    } else {
      this.resizeChangeVal = 867;
    }
    window.vue = this;
    window.addEventListener("resize", this.onWindowResize);
    // this.$store.commit("panel_class", "");
    // $("#panel").addClass("hidden");
    // NOTE :: resizable 등록
    $("#panel").resizable({
      handles: "n, e, s, w",
      resize: this.onPanelResize,
      minWidth: 400,
      minHeight: 400,
      maxWidth: 900,
      maxHeight: 900
    });
    $("#rvWrapper").resizable({
      handles: "nw",
      resize: this.onRoadViewResize,
      minWidth: 400,
      minHeight: 400,
      maxWidth: 650,
      maxHeight: 650
    });
    $("#map_wrap").resizable({
      handles: "nw",
      resize: this.onMapResize,
      minWidth: 400,
      minHeight: 400,
      maxWidth: 650,
      maxHeight: 650
    });
    this.adjustPanelSizeOptions();
    // NOTE :: 모달, 로드뷰 관련 설정 초기화
    this.$store.commit("modalIndex", 2000);
    this.$store.commit("roadviewMap", "");
    this.$store.commit("rvSize", {
      width: 400,
      height: 400
    });
    if (
      this.$store.getters.panel_location_name == "left" ||
      this.$store.getters.panel_location_name == "right"
    ) {
      $("#panel_area").css("overflow", "unset");
    } else {
      $("#panel_area").css("overflow", "auto");
    }

    this.$store.commit("sidebar_content", "");
    this.$store.commit("sidebar_onHeader", "");

    window.facilityModalOpen = this.facilityModalOpen;
    $("#map_wrap .ui-resizable-handle.ui-resizable-nw").css("display", "none");
  },
  beforeDestroy: function() {
    window.removeEventListener("resize", this.onWindowResize);
    EventBus.$off("clickMenu");
    EventBus.$off("modalOpen");
    EventBus.$off("pictureShow");
  }
};
</script>

<style>
@import url(//fonts.googleapis.com/earlyaccess/notosanskr.css);

html,
body,
#layout,
#layout > * {
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
  font-family: "Noto Sans KR", sans-serif !important;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
  height: 100%;
  width: 100%;
}

.hidden {
  display: none !important;
}

#map {
  z-index: 0;
}
#main {
  z-index: 1;
  display: flex;
  pointer-events: none; /* mouse event for map */
}
#sidebar,
#panel {
  pointer-events: auto;
}

#sidebar {
  background-color: #424242;
  z-index: 100;
  min-width: 85px;
}

#content {
  flex: 1;
  display: flex;
  position: relative;
}
#content.left {
  flex-flow: row;
}
#content.right {
  flex-flow: row-reverse;
}
#content.top {
  flex-flow: column;
}
#content.bottom {
  flex-flow: column-reverse;
}

#panel {
  position: relative;
  background: black; /* for test */
  z-index: 1011;
}
.left #panel {
  top: 0 !important;
  left: 0 !important;
  height: 100% !important;
}
.right #panel {
  left: auto !important; /* for IE */
  top: 0 !important;
  right: 0 !important;
  height: 100% !important;
}
.top #panel {
  top: 0 !important;
  left: 0 !important;
  width: 100% !important;
}
.bottom #panel {
  top: auto !important; /* for IE */
  left: 0 !important;
  bottom: 0 !important;
  width: 100% !important;
}
.ui-resizable-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  display: none;
}
#map_wrap .ui-resizable-handle,
#rvWrapper .ui-resizable-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background: url("../assets/img/res/img/roadview-zoom.png") top no-repeat;
  background-size: 15px 15px;
  display: none;
}
.left .ui-resizable-handle.ui-resizable-e {
  display: block;
  cursor: w-resize;
  height: 100% !important;
  top: 0;
  right: -4px;
  position: absolute;
}
.bottom .ui-resizable-handle.ui-resizable-n {
  display: block;
  cursor: n-resize;
  width: 100% !important;
  top: 0;
}
.right .ui-resizable-handle.ui-resizable-w {
  display: block;
  cursor: e-resize;
  height: 100% !important;
  top: 0;
  left: 0;
}
.top .ui-resizable-handle.ui-resizable-s {
  display: block;
  cursor: s-resize;
  width: 100% !important;
  bottom: 0;
}
.ui-resizable-handle.ui-resizable-nw {
  display: block;
  cursor: nw-resize;
  height: 3% !important;
  top: 0;
  left: 0;
}
#map_wrap .ui-resizable-handle.ui-resizable-nw,
#rvWrapper .ui-resizable-handle.ui-resizable-nw {
  display: block;
  cursor: nw-resize;
  height: 15px !important;
  top: 5px;
  left: 5px;
  width: 15px;
  z-index: 1001 !important;
  pointer-events: auto;
}
.roadview-expand,
.roadview-reduce {
  position: absolute;
  top: 5px;
  left: 5px;
  width: 15px;
  height: 15px;
  z-index: 1;
}
.map_add_rv {
  position: absolute;
  bottom: 10px;
  right: 10px;
  width: 50px;
  height: 50px;
  z-index: 1;
  cursor: pointer;
  background: url("../assets/img/res/img/light_add.png") top no-repeat;
  background-size: 50px;
}
.exit-rv {
  position: absolute;
  top: 5px;
  right: 5px;
  width: 15px;
  height: 15px;
  z-index: 1001;
  cursor: pointer;
  pointer-events: auto;
}
.change-main-map,
.change-main-roadview {
  position: absolute;
  top: 5px;
  left: 25px;
  width: 15px;
  height: 15px;
  z-index: 1001;
  cursor: pointer;
  pointer-events: auto;
}
.roadview-expand {
  background: url("../assets/img/res/img/roadview-expand.png") top no-repeat;
  background-size: 15px 15px;
}
.roadview-reduce {
  background: url("../assets/img/res/img/roadview-reduce.png") top no-repeat;
  background-size: 15px 15px;
}
.change-main-map {
  background: url("../assets/img/res/img/reverse_roadview_map.png") top
    no-repeat;
  background-size: 15px 15px;
}
.exit-rv {
  background: url("../assets/img/res/img/roadview_exit.png") top no-repeat;
  background-size: 15px 15px;
}
.change-main-roadview {
  background: url("../assets/img/res/img/reverse_roadview_map.png") top
    no-repeat;
  background-size: 15px 15px;
}

#visible_map {
  flex: 1;
  position: relative;
}
#visible_map > * {
  position: absolute;
}

#modal_area {
  pointer-events: none;
}

#map_typecontrol {
  position: absolute;
  top: 10px;
  right: 90px;
  z-index: 1;
}

#typecontrol-btn {
  color: black;
  font-weight: 550;
  font-size: 14px;
  border-radius: 8px;
  width: 50px;
  height: 26px;
  outline: none;
}

#typecontrol-btn-group {
  background-color: white;
  border-radius: 8px;
  padding: 3.5px 4px 4px 4px;
  height: 35px;
  width: 110px;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  text-align: center;
}
#map_roadview {
  position: absolute;
  top: 10px;
  right: 50px;
  z-index: 1;
  border-radius: 8px;
  background-color: white;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  width: 35px;
  height: 35px;
  text-align: center;
}

#map_print {
  position: absolute;
  top: 10px;
  border-radius: 8px;
  background-color: white;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  width: 35px;
  height: 35px;
  text-align: center;
  /* top: 10px; */
  right: 10px;
  z-index: 1;
}
#map_gps {
  position: absolute;
  top: 40px;
  right: 10px;
  z-index: 1;
}
#map_zoom {
  position: absolute;
  top: 75px;
  right: 10px;
  z-index: 1;
  border-radius: 8px;
  background-color: white;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  width: 35px;
  height: 70px;
  text-align: center;
}
#map_tools {
  position: absolute;
  top: 150px;
  right: 10px;
  z-index: 1;
  border-radius: 8px;
  background-color: white;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  width: 35px;
  height: 105px;
  text-align: center;
}
#typecontrol-btn-group,
#map_roadview,
#map_print,
#map_zoom,
#map_tools,
#map_info {
  border: 1px #bcbcbc solid;
}

#map_info {
  position: absolute;
  top: 260px;
  right: 10px;
  z-index: 1;
  border-radius: 8px;
  background-color: white;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  width: 35px;
  height: 35px;
  text-align: center;
}
#map_top_area {
  height: 100%;
  z-index: 3;
  pointer-events: none;
}
#map_top_area #map_add {
  position: absolute;
  width: calc(85px + 100%);
}
#map_top_area #map_add > div {
  pointer-events: none;
}
#map_top_area #map_add > .tap-menu > .bnt > button {
  pointer-events: auto;
}
#map_add {
  z-index: 1001 !important;
}
#map_add_btn,
#map_add:not(.light_movecontrol) {
  position: absolute;
  bottom: 10px;
  right: 10px;
  z-index: 1;
}
#map_add.light_movecontrol {
  /* position: absolute;
  bottom: 20px;
  z-index: 1; */
  visibility: collapse;
  /* left: 40%; */

  /* position: relative; */
  /* z-index: 1; */
  /* justify-content: center; */
  /* left: 40%; */
  bottom: 20px;
  display: flex;
  flex-direction: column;
  text-align: center;
  width: 100%;
  padding-right: 1px;
}
#map_add.light_movecontrol button {
  margin: 2px;
  font-size: 12px;
  font-weight: bold;
  border-radius: 10px;
  color: white;
  background: #424242;
  border-color: #424242;
  outline: 0;
  -webkit-box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.25);
  box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.25);
  border: 0px;
}
#map_add.light_movecontrol button:hover {
  background: #016aae;
}
#map_add.light_movecontrol .tap-menu {
  text-align: center;
  margin-bottom: 10px;
}
#map_add.light_movecontrol .info-content {
  background: white;
  -moz-border-radius: 10px;
  -webkit-border-radius: 10px;
  border-radius: 10px;
  padding: 5px 15px 5px 15px;
  font-size: 14px;
}
#map_add_sub {
  position: absolute;
  top: 60%;
  left: 50%;
  z-index: 1;
  transform: translateX(-50%);
}
#map_daum_copyright {
  position: absolute;
  bottom: 0px;
  left: 0px;
  z-index: 1;
  border-radius: 8px;
  width: 190px;
  height: 25px;
  text-align: center;
}
.ptr-evt--a {
  pointer-events: auto;
  cursor: pointer;
}

#light_add_caution {
  position: absolute;
  top: -12%;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1;
  background-color: white;
  display: inline-table;
  padding: 20px 30px 20px 30px;
  border-radius: 5px;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
}

#light_add {
  cursor: pointer;
  width: 50px;
  height: 50px;
}

#light_add_caution > * {
  font-size: 13px;
  font-weight: 800;
}

#center_mark_sub {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: 1;
}

#roadview-btn,
#print,
#zoom-minus,
#zoom-plus,
#icon-distance,
#icon-area,
#icon-radical,
#icon-info {
  font-size: 21px;
  cursor: pointer;
  color: #aaaaaa;
}
#icon-radical,
#icon-area,
#icon-distance {
  margin-top: 9px;
}
#icon-info,
#roadview-btn,
#print,
#zoom-minus {
  margin-top: 7px;
}

#roadview-btn {
  margin-top: 0px;
  padding: 7px 10px 8px 10px;
}
#zoom-plus {
  margin-top: 10px;
}
.btn-control-on {
  background-color: #424242;
  color: white !important;
}
.control-status-on {
  color: #1980e0 !important;
}
#map_roadview_bubble {
  position: absolute;
  top: 52px;
  right: 51px;
  z-index: 1;
  display: none;
}
#map_print_bubble {
  position: absolute;
  top: 52px;
  right: 10px;
  z-index: 1;
  display: none;
}
#map_plus_bubble {
  position: absolute;
  top: 85px;
  right: 55px;
  z-index: 1;
  display: none;
}
#map_minus_bubble {
  position: absolute;
  top: 115px;
  right: 55px;
  z-index: 1;
  display: none;
}
#map_distance_bubble {
  position: absolute;
  top: 160px;
  right: 55px;
  z-index: 1;
  display: none;
}
#map_area_bubble {
  position: absolute;
  top: 194px;
  right: 55px;
  z-index: 1;
  display: none;
}
#map_radical_bubble {
  position: absolute;
  top: 229px;
  right: 55px;
  z-index: 1;
  display: none;
}

.bubble-text {
  font-size: 12px;
  color: white;
}

.bubble {
  position: relative;
  width: 63px;
  height: 20px;
  padding: 0px;
  background: rgba(112, 112, 112, 1);
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  text-align: center;
}

.bubble:after {
  content: "";
  position: absolute;
  border-style: solid;
  border-width: 4px 0 4px 7px;
  border-color: transparent #707070;
  display: block;
  width: 0;
  z-index: 1;
  right: -6px;
  top: 6px;
}

.bubble-top {
  position: relative;
  width: 63px;
  height: 20px;
  padding: 0px;
  background: rgba(112, 112, 112, 1);
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  text-align: center;
}

.bubble-top:after {
  content: "";
  position: absolute;
  border-style: solid;
  border-width: 0 4px 7px;
  border-color: #707070 transparent;
  display: block;
  width: 0;
  z-index: 1;
  top: -6px;
  left: 42px;
}

.info-icon {
  position: absolute;
  width: 25px;
  height: 25px;
  top: -2px;
  left: 78px;
}

#map_info_bubble_1,
#map_info_bubble_2,
#map_info_bubble_3,
#map_info_bubble_4,
#map_info_bubble_5,
#map_info_bubble_6 {
  position: absolute;
  right: 55px;
  z-index: 1;
  display: none;
}
#map_info_bubble_1 {
  top: 300px;
}
#map_info_bubble_2 {
  top: 330px;
}
#map_info_bubble_3 {
  top: 360px;
}
#map_info_bubble_4 {
  top: 390px;
}
#map_info_bubble_5 {
  top: 420px;
}
#map_info_bubble_6 {
  top: 450px;
}
#map_add_bubble {
  position: absolute;
  right: 70px;
  z-index: 1;
  display: none;
  bottom: 27px;
}
.map_light_type {
  left: 10px;
  top: 10px;
  border: 0px;
  position: absolute;
  border-radius: 10px;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  padding: 4px 10px 4px 10px;
}
.map_light_complate,
.map_light_cancel {
  font-size: 14px;
  padding: 10px 20px 10px 20px;
  border-radius: 10px;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  color: white;
}
.map_light_cancel {
  background-color: #aaaaaa;
  margin-right: 10px;
}
.map_light_complate {
  background-color: #1980e0;
  margin-left: 10px;
}
.light_typecontrol * {
  font-size: 14px;
}
</style>

<style>
.dot {
  overflow: hidden;
  float: left;
  width: 12px;
  height: 12px;
  background: url("http://t1.daumcdn.net/localimg/localimages/07/mapapidoc/mini_circle.png");
}

.dotOverlay {
  position: relative;
  bottom: 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
  border-bottom: 2px solid #ddd;
  float: left;
  font-size: 12px;
  padding: 5px;
  background: white;
}

.dotOverlay:nth-of-type(n) {
  border: 0;
  box-shadow: 0px 1px 2px #888;
}

.number {
  font-weight: bold;
  color: #ee6152;
}

.dotOverlay:after {
  content: "";
  position: absolute;
  margin-left: -6px;
  left: 50%;
  bottom: -8px;
  width: 11px;
  height: 8px;
  background: url("http://t1.daumcdn.net/localimg/localimages/07/mapapidoc/vertex_white_small.png");
}

.distanceInfo {
  position: relative;
  top: 5px;
  left: 5px;
  list-style: none;
  margin: 0;
}

.distanceInfo .label {
  display: inline-block;
  color: black;
  width: 50px;
}

.distanceInfo:after {
  content: none;
}
.tool-area {
  padding-bottom: 2px;
}
.map-header-arrow {
  background: url("../assets/img/res/img/panel-header-arrow.png") no-repeat
    right #fff;
  -webkit-appearance: none;
  -moz-appearance: none;
  padding-right: 30px !important;
  background-size: 30px;
  padding-left: 12px;
}
#anchorFlash {
  background-color: white;
  display: none;
}
#rvWrapper {
  position: absolute;
  /*width: 100%;
  height: 100%;*/
  overflow: hidden;
  bottom: 0;
  right: 0;
}
#roadview {
  position: relative !important;
  cursor: default !important;
  height: 400px;
  width: 400px;
  bottom: 0px;
  z-index: 1000;
  right: 0px;
  display: none;
}
#layout #main .roadview_main {
  width: 100% !important;
  height: 100% !important;
}
</style>

<style>
#layout #map_wrap {
  height: 100vh;
  /* height: calc(100vh - 54px);
  top: 54px; */
}
#layout #map_wrap.map_sub {
  z-index: 2;
  right: 0px;
  bottom: 0px;
  top: auto;
  /* width: 400px;
  height: 400px; */
}
#layout #main .main-content {
  width: 100%;
  height: 100%;
}
#layout #main .main-content #content {
  height: 100%;
}
#layout #main .main-content .main-header-area {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}
#layout #main .main-content .main-header-area .sidebar-side-btn {
  width: 10px;
  height: 65px;
  border-left: 10px solid #016aae;
  border-top: 5px solid transparent;
  border-bottom: 5px solid transparent;
  pointer-events: auto;
  cursor: pointer;
  display: flex;
  align-items: center;
}
#layout
  #main
  .main-content
  .main-header-area
  .header-hide-line
  .header-hide-btn {
  width: 65px;
  height: 10px;
  border-top: 10px solid #bcbcbc;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  pointer-events: auto;
  cursor: pointer;
  display: flex;
  justify-content: center;
}
#layout
  #main
  .main-content
  .main-header-area
  .sidebar-side-btn
  .result-awssome {
  position: absolute;
  left: 0px;
  width: 8px;
  height: 20px;
}
#layout .sidebar-side-btn .result-awssome {
  color: #fff;
}
#layout #main .main-content .main-header-area .sidebar-side-line {
  display: flex;
  width: 20px;
  height: 100%;
  position: absolute;
  /* background: #016aae; */
  border-left: 4px solid #016aae;
  align-items: center;
  z-index: 1010;
}
#layout #main .main-content .main-header-area .header-hide-line {
  width: 100%;
  height: 2px;
  border-top: 2px solid #bcbcbc;
  display: flex;
  top: 54px;
  justify-content: center;
  z-index: 1010;
  margin-left: 4px;
}
#layout
  #main
  .main-content
  .main-header-area
  .header-hide-line
  .result-awssome-header-up {
  position: absolute;
  top: 50px;
  width: 10px;
  height: 20px;
  color: white;
}
#layout
  #main
  .main-content
  .main-header-area
  .header-hide-line
  .result-awssome-header-down {
  position: absolute;
  top: -4px;
  width: 10px;
  height: 20px;
  color: white;
}
</style>

<style>
/* .ui-resizable-n {
}

.ui-resizable-e {
}

.ui-resizable-s {
}

.ui-resizable-w {
} */
</style>

<style>
.main-content .search-area .slname,
.name {
  font-family: "Noto Sans KR", sans-serif !important;
}
.main-content .search-area {
  display: flex;
  justify-content: center;
  align-items: center;
  float: right;
  /* height: 100%; */
  flex: 1;
  justify-content: flex-end;
  z-index: 10;
  padding: 4px;
}

.main-content
  .search-area
  .onoffswitch-checkbox:checked
  + .onoffswitch-label
  .onoffswitch-inner {
  margin-left: 0px;
}
.main-content
  .search-area
  .onoffswitch-checkbox:checked
  + .onoffswitch-label
  .onoffswitch-switch {
  /* 슬라이더에서 공 위치, 오른쪽에서 얼마나 떨어져있을지*/
  right: 0px;
}

.main-content .condition-input input:focus {
  outline: none;
}
.main-content .condition-input input[type="text"] {
  -webkit-ime-mode: active;
  -moz-ime-mode: active;
  -ms-ime-mode: active;
  ime-mode: active;
}
.main-content .condition-input input {
  border: 0px;
  background: #fff;
  padding: 5px 30px 5px 11px;
  height: 32px;
  font-size: 12px;
  color: #000000;
  border-radius: 10px;
  width: 139px;
  margin: 0px 0px 0px 6px;
}
.main-content .condition-input button {
  /* 돋보기 버튼 */
  position: absolute;
  top: 8px;
  right: 10px;
  outline: none;
}
.main-content .condition-input button i {
  /* 돋보기 색깔 */
  color: #000000;
  margin-right: 3px;
}
.main-content .search-area .onoffswitch-checkbox {
  /*체크박스, 역할만 해야하기에 none으로 보여주지않는다.*/
  display: none;
  /* background: red; */
}
.main-content .search-area .onoffswitch-label {
  /*표찰명 뒤에 있는 공간.*/
  display: block;
  overflow: hidden;
  cursor: pointer;
  border-radius: 10px;
}
.main-content .search-area .onoffswitch-inner {
  /*표찰명 뒤에 있는 공간2.*/
  display: block;
  width: 100%;
  padding: 10px 0px 0px 10px;
  transition: margin 0.14s ease-in 0s;
  /* margin-left: -100%; */
}

.main-content .search-area .onoffswitch-inner:before,
.main-content .search-area .onoffswitch-inner:after {
  border-radius: 10px;
  display: block;
  float: left;
  width: 50%;
  height: 32px;
  padding: 0;
  line-height: 32px;
  font-size: 14px;
  color: white;
  font-family: Trebuchet, Arial, sans-serif;
  font-weight: bold;
  box-sizing: border-box;
}
.main-content .search-area .onoffswitch-inner:before {
  content: "표찰명";
  font-size: 14px;
  padding-left: 6px;
  background-color: #fff;
  color: #000000;
}
.main-content .search-area .onoffswitch-inner:after {
  content: "주소";
  font-size: 14px;
  padding-right: 14px;
  background-color: #fff;
  color: #000000;
  text-align: right;
}
.main-content .search-area .onoffswitch-switch {
  display: block;
  height: 25px;
  margin: 17px 160px 3px 3px;
  width: 25px;
  background: #eee;
  position: absolute;
  top: 0;
  bottom: 0;
  border-radius: 50px;
  transition: all 0.2s ease-in 0s;
}
</style>

<style>
#layout .switch {
  margin: 0px 3px 0px 6px;
  position: relative;
  display: inline-block;
  width: 90px;
  height: 33px;
}

#layout .switch input {
  display: none;
  font-size: 14px;
}

#layout .slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #fff;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}

#layout .slider:before {
  position: absolute;
  content: "";
  height: 24px;
  width: 24px;
  left: 5px;
  bottom: 4px;
  background-color: #eee;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}

#layout .switch input:checked + .slider {
  background-color: #fff;
}

#layout .switch input:focus + .slider {
  box-shadow: 0 0 1px #2196f3;
}

#layout .switch input:checked + .slider:before {
  -webkit-transform: translateX(50px);
  -ms-transform: translateX(50px);
  transform: translateX(56px);
}

#layout .slname {
  display: none;
}

#layout .slname,
.name {
  color: #000000;
  position: absolute;
  transform: translate(-50%, -50%);
  top: 50%;
  font-size: 12px;
  font-family: Trebuchet, Arial, sans-serif;
}

#layout .slname {
  left: 40%;
}
#layout .name {
  margin-left: 50px;
  right: 40;
}
#layout input:checked + .slider .slname {
  display: block;
}

#layout input:checked + .slider .name {
  display: none;
}

#layout .slider.round {
  border-radius: 10px;
}

#layout .slider.round:before {
  border-radius: 40%;
}
</style>
