import Vue from "vue";

// import "./lib/css"
// import "./lib/script"
// import "./lib/global"

import "./assets/css/reset.css";
// import "font-awesome/css/font-awesome.css";

import "./lib/utils";
import "jquery";
window.$ = window.jQuery = require("jquery");
// import "expose?$!expose?jQuery!jquery";
import "expose-loader?$!expose-loader?jQuery!jquery";

import "jquery-ui/ui/widgets/resizable";
import "jquery-ui/ui/widgets/draggable";
import "jquery-ui/ui/effect";

import "bootstrap/dist/css/bootstrap.css";
import BootstrapVue from "bootstrap-vue";
import "bootstrap-vue/dist/bootstrap-vue.css";
Vue.use(BootstrapVue);
import "bootstrap/dist/js/bootstrap.min.js";

import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel";

// TODO :: font-awesome lib 사용한 형태인데 font-awesome manager kit 형태로 바꾸는게 좋음
import { library } from "@fortawesome/fontawesome-svg-core";
import {
  faCoffee,
  faPrint,
  faCompass,
  faRoad,
  faExpand,
  faInfo,
  faPlus,
  faMinus,
  faAngleDoubleLeft,
  faAngleDoubleRight,
  faAngleLeft,
  faAngleRight,
  faMapPin,
  faAngleUp,
  faAngleDown
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";
library.add(
  faCoffee,
  faPrint,
  faRoad,
  faCompass,
  faExpand,
  faInfo,
  faPlus,
  faMinus,
  faAngleDoubleLeft,
  faAngleDoubleRight,
  faAngleLeft,
  faAngleRight,
  faMapPin,
  faAngleUp,
  faAngleDown
);
Vue.component("font-awesome-icon", FontAwesomeIcon);
import moment from "moment";
Vue.prototype.moment = moment;

import _ from "lodash";
Object.defineProperty(Vue.prototype, "$_", { value: _ });

// NOTE :: 공용 Alert Component 지정
import VMAlert from "@/components/modal/VMAlert";
Vue.component("vm-alert", VMAlert);

Vue.config.productionTip = false;

import router from "@/router";
import store from "@/store";

import App from "@/vue/App.vue";

import APIPlugin from "@/plugin/api.js";
Vue.use(APIPlugin);

// import VueApexCharts from 'vue-apexcharts'
// Vue.use(VueApexCharts)
// // Vue.component('apexchart', VueApexCharts)

import "vue2-daterange-picker/dist/lib/vue-daterange-picker.min.css";

import "./assets/js/canvasResize.js";
import "./assets/js/jquery.canvasResize.js";
import "./assets/js/jquery.exif.js";

export const EventBus = new Vue();

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
