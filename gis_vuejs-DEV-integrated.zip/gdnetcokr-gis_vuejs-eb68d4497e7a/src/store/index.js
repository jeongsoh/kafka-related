import Vue from "vue";
import Vuex from "vuex";
import createPersistedState from "vuex-persistedstate";

Vue.use(Vuex);

function initialState() {
  return {
    settings: {
      panel: {
        location: 0,
        size: "0", // px
        class: "hideen"
      }
    },
    config: {
      AREA_NAME: "guardian",
      S3_PATH: "guardian",
      S3_BASE: "facility-images",
      START_LAT: "",
      START_LNG: "",
      DEFAULT_ON_DEVIATION: "",
      DEFAULT_OFF_DEVIATION: ""
    },
    modals: {},
    status: "",
    moveID: "",
    modalIndex: 2000,
    sidebar: {
      dashboardList: [
        {
          name: "현황판",
          component: "VPDashboard"
        }
      ],
      deviceList: [
        {
          name: "상세 검색",
          component: "VPDeviceSearch"
        },
        {
          name: "실시간 고장내역",
          component: "VPDeviceTrouble"
        }
      ],
      complainList: [
        {
          name: "민원 목록",
          component: "VPComplaintList"
        }
      ],
      jajeList: [
        {
          name: "자재 현황",
          component: "VPJajeList"
        },
        {
          name: "자재 입출고",
          component: "VPJajeIO"
        }
      ],
      reportList: [
        {
          name: "시설물 장애이력",
          component: "VPReportTrouble"
        },
        {
          name: "보수/점검 일지",
          component: "VPReportInspection"
        },
        {
          name: "자재 수불대장",
          component: "VPReportJaje"
        }
      ],
      onHeader: "",
      content: ""
    },
    filter: {
      filter_1: "필터1",
      filter_2: "필터2"
    },
    crossHairPostion: "",
    roadviewMap: "",
    rvSize: {
      rvW: 400,
      rvH: 400
    }
  };
}

export default new Vuex.Store({
  state: initialState,
  getters: {
    panel_location_name: state => {
      switch (state.settings.panel.location) {
        case 0:
          return "left";
        case 1:
          return "bottom";
        case 2:
          return "right";
        case 3:
          return "top";
      }
    },
    panel_size: state => {
      return state.settings.panel.size;
    },
    panel_class: state => {
      return state.settings.panel.class;
    },
    config_area: state => {
      return state.config.AREA_NAME;
    },
    config_s3_path: state => {
      return state.config.S3_PATH;
    },
    config_s3_base: state => {
      return state.config.S3_BASE;
    },
    config_lat: state => {
      return state.config.START_LAT;
    },
    config_lng: state => {
      return state.config.START_LNG;
    },
    config_on_deviation: state => {
      return state.config.DEFAULT_ON_DEVIATION;
    },
    config_off_deviation: state => {
      return state.config.DEFAULT_OFF_DEVIATION;
    },
    modals: state => {
      return state.modals;
    },
    status: state => {
      return state.status;
    },
    moveID: state => {
      return state.moveID;
    },
    modalIndex: state => {
      return state.modalIndex;
    },
    sidebar_content: state => {
      return state.sidebar.content;
    },
    sidebar_dashboardList: state => {
      return state.sidebar.dashboardList;
    },
    sidebar_deviceList: state => {
      return state.sidebar.deviceList;
    },
    sidebar_complainList: state => {
      return state.sidebar.complainList;
    },
    sidebar_jajeList: state => {
      return state.sidebar.jajeList;
    },
    sidebar_reportList: state => {
      return state.sidebar.reportList;
    },
    sidebar_onHeader: state => {
      return state.sidebar.onHeader;
    },
    filter: state => {
      return state.filter;
    },
    crossHairPostion: state => {
      return state.crossHairPostion;
    },
    roadviewMap: state => {
      return state.roadviewMap;
    },
    rvSizeW: state => {
      return state.rvSize.rvW;
    },
    rvSizeH: state => {
      return state.rvSize.rvH;
    }
  },
  mutations: {
    reset(state) {
      // acquire initial state
      let area = state.config.AREA_NAME;
      let s3_path = state.config.S3_PATH;
      let s3_base = state.config.S3_BASE;
      let lat = state.config.START_LAT;
      let lng = state.config.START_LNG;
      let on_deviation = state.config.DEFAULT_ON_DEVIATION;
      let off_deviation = state.config.DEFAULT_OFF_DEVIATION;
      const s = initialState();
      Object.keys(s).forEach(key => {
        state[key] = s[key];
      });
      state.config.AREA_NAME = area;
      state.config.S3_PATH = s3_path;
      state.config.S3_BASE = s3_base;
      state.config.START_LAT = lat;
      state.config.START_LNG = lng;
      state.config.DEFAULT_ON_DEVIATION = on_deviation;
      state.config.DEFAULT_OFF_DEVIATION = off_deviation;
    },
    panel(state, data) {
      state.settings.panel = data;
    },
    panel_rotate(state) {
      state.settings.panel.location += 1;
      state.settings.panel.location %= 4;
    },
    panel_location(state, data) {
      state.settings.panel.location = data;
    },
    panel_size(state, data) {
      state.settings.panel.size = data;
    },
    panel_class(state, data) {
      state.settings.panel.class = data;
    },
    config_area(state, data) {
      state.config.AREA_NAME = data;
    },
    config_s3_path(state, data) {
      state.config.S3_PATH = data;
    },
    config_s3_base(state, data) {
      state.config.S3_BASE = data;
    },
    config_lat(state, data) {
      state.config.START_LAT = data;
    },
    config_lng(state, data) {
      state.config.START_LNG = data;
    },
    config_on_deviation(state, data) {
      state.config.DEFAULT_ON_DEVIATION = data;
    },
    config_off_deviation(state, data) {
      state.config.DEFAULT_OFF_DEVIATION = data;
    },
    modal_init(state) {
      // remove before modal instance
      state.modals = {};
    },
    modal_open(state, data) {
      console.log(state);
      console.log(data);
      Vue.set(state.modals, data.id + ":" + data.type, {
        id: data.id,
        type: data.type
      });
      // NOTE :: modal 열면 index 증가하여 모달 중 최상위가 되도록 설정
      Vue.nextTick(function () {
        state.modalIndex = state.modalIndex + 1;
        $("#" + data.id + "\\:" + data.type).css("z-index", state.modalIndex);
      });
    },
    modal_close(state, key) {
      console.log(state, key);
      Vue.delete(state.modals, key);
      // delete state.modals[key];
    },
    modal_all_close(state, key) {
      Object.keys(state.modals).forEach(val => {
        if (val.indexOf(key) == 0) {
          Vue.delete(state.modals, val);
        }
      });
      // delete state.modals[key];
    },
    status(state, data) {
      state.status = data;
    },
    moveID(state, data) {
      state.moveID = data;
    },
    modalIndex(state, data) {
      state.modalIndex = data;
    },
    sidebar_content(state, data) {
      state.sidebar.content = data;
      if (data == "") {
        state.settings.panel.class = "hidden";
        state.settings.panel.size = 0;
      } else {
        state.settings.panel.class = "";
      }
    },
    sidebar_onHeader(state, data) {
      state.sidebar.onHeader = data;
    },
    sidebar_dashboardList(state, data) {
      state.sidebar.dashboardList.push(data);
    },
    sidebar_deviceList(state, data) {
      state.sidebar.deviceList.push(data);
    },
    sidebar_complainList(state, data) {
      state.sidebar.complainList.push(data);
    },
    sidebar_jajeList(state, data) {
      state.sidebar.jajeList.push(data);
    },
    sidebar_reportList(state, data) {
      state.sidebar.reportList.push(data);
    },
    filter1(state, data) {
      state.filter.filter_1 = data;
    },
    filter2(state, data) {
      state.filter.filter_2 = data;
    },
    crossHairPostion(state, data) {
      state.crossHairPostion = data;
    },
    roadviewMap(state, data) {
      state.roadviewMap = data;
    },
    rvSize(state, data) {
      state.rvSize.rvW = data.width;
      state.rvSize.rvH = data.height;
    }
  },
  actions: {},
  plugins: [
    createPersistedState({
      key: "vuex",
      storage: {
        getItem: key => localStorage.getItem(key),
        setItem: (key, value) => localStorage.setItem(key, value),
        removeItem: key => localStorage.removeItem(key)
      }
    })
  ]
});
