/* eslint-disable */

window.DEBUG_MODE = false;

window.API_SERVER = '/';
window.API_STAGE = 'lora';

window.UPDATE_DASHBOARD_DURATION = 10000; // 10초

window.API_GATEWAY = API_SERVER + (API_STAGE != null ? API_STAGE + '/' : '');

window.NULL_TEXT = '--------------------------------------------------------------';

window.TYPE_LIGHT_STREET = 0;		//가로등
window.TYPE_LIGHT_SECURITY = 1;	//보안등
window.TYPE_BOX_DISTRIBUTION = 4;	//분전함
window.TYPE_BOX_REPEATER = 5;		//중계기
window.TYPE_LIGHTHOUSE_LANTERN = 6;	// 등명기
window.TYPE_LIGHT_MONITOR = 7;	// 등주감시기
window.TYPE_BOX_DISTRIBUTION_SUB_MODULE_A = 8;
window.TYPE_BOX_DISTRIBUTION_SUB_MODULE_B = 9;
window.TYPE_BOX_DISTRIBUTION_MINI = 10;
window.TYPE_NAME_LIGHT_STREET = "가로등";
window.TYPE_NAME_LIGHT_SECURITY = "보안등";
window.TYPE_NAME_BOX_DISTRIBUTION = "분전함";
window.TYPE_NAME_BOX_REPEATER = "중계기";
window.TYPE_NAME_LIGHTHOUSE_LANTERN = "등명기";
window.TYPE_NAME_LIGHT_MONITOR = "등주감시기";
window.TYPE_NAME_BOX_DISTRIBUTION_SUB_MODULE_A = "분전함 격등-A";
window.TYPE_NAME_BOX_DISTRIBUTION_SUB_MODULE_B = "분전함 격등-B";
window.TYPE_NAME_BOX_DISTRIBUTION_MINI = "분전함(미니)"

window.TYPES_IDS = [TYPE_LIGHT_STREET, TYPE_LIGHT_SECURITY, TYPE_BOX_DISTRIBUTION, TYPE_BOX_REPEATER, TYPE_LIGHTHOUSE_LANTERN, TYPE_LIGHT_MONITOR, TYPE_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_BOX_DISTRIBUTION_SUB_MODULE_B, TYPE_BOX_DISTRIBUTION_MINI];
window.TYPES_NAMES = [TYPE_NAME_LIGHT_STREET, TYPE_NAME_LIGHT_SECURITY, TYPE_NAME_BOX_DISTRIBUTION, TYPE_NAME_BOX_REPEATER, TYPE_NAME_LIGHTHOUSE_LANTERN, TYPE_NAME_LIGHT_MONITOR, TYPE_NAME_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_NAME_BOX_DISTRIBUTION_SUB_MODULE_B, TYPE_NAME_BOX_DISTRIBUTION_MINI];

window.spinnerCount = 0;

String.prototype.format = String.prototype.format ||
  function () {
    "use strict";
    var str = this.toString();
    if (arguments.length) {
      var t = typeof arguments[0];
      var key;
      var args = ("string" === t || "number" === t) ?
        Array.prototype.slice.call(arguments)
        : arguments[0];

      for (key in args) {
        str = str.replace(new RegExp("\\{" + key + "\\}", "gi"), args[key]);
      }
    }
    return str;
  };

String.prototype.hashCode = function () {
  var hash = 0;
  if (this.length == 0) return hash;
  for (i = 0; i < this.length; i++) {
    char = this.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash;
}

window.padDigits = function(number, digits) {
  return Array(Math.max(digits - String(number).length + 1, 0)).join(0) + number;
}

$(document).ajaxSend(function () {
  // showSpinner();
});
$(document).ajaxComplete(function () {
  // hideSpinner();
});
$(document).ajaxError(function () {
  // hideSpinner();
});

window.showSpinner = function(e) {
  if (spinnerCount == 0) {
    var spinner = "<div id='spinner' style='position:fixed; height:100%; width:100%; display:table; background:rgba(0,0,0,0.5); z-index:9999;'><div align='center' style='vertical-align:middle; display:table-cell;'><svg width='96px' height='96px' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' preserveAspectRatio='xMidYMid' class='uil-default'><rect x='0' y='0' width='100' height='100' fill='none' class='bk'></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(0 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-1s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(30 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.9166666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(60 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.8333333333333334s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(90 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.75s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(120 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.6666666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(150 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.5833333333333334s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(180 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.5s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(210 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.4166666666666667s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(240 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.3333333333333333s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(270 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.25s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(300 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.16666666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(330 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.08333333333333333s' repeatCount='indefinite'/></rect></svg><div id='spinnerText' style='color:white;'></div></div></div>";
    refer: https://loading.io/css/
    var spinner = "<div id='spinner' style='position:absolute; height:100%; width:100%; display:table; background:rgba(0,0,0,0.5); z-index:9999; bottom:0px; border-radius:0 0 4px 4px;'><div align='center' style='vertical-align:middle; display:table-cell;'>";
    spinner += "<div class='lds-spinner'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>";
    spinner += "<div id='spinnerText' style='color:white;'></div>";
    $(e).prepend(spinner)
    // $(e).prepend(spinner).hide().fadeIn(1500)
  }
  spinnerCount++;
}

window.hideSpinner = function(e) {
  spinnerCount--;
  if (spinnerCount <= 0) {
    spinnerCount = 0;
    // $(e).remove();
    $(e).fadeOut(1500,function(){
      $(e).remove();
  })
  }
}

window.API_GET = function(url, data, cacheTime, hasSpinner, ignoreError) {
  return API('GET', url, data, cacheTime, hasSpinner, ignoreError);
}
window.API_POST = function(url, data) {
  return API('POST', url, data);
}
window.API_UPDATE = function(url, data) { // API_PUT
  if (data == undefined)
    data = {}
  data['_httpMethod'] = 'UPDATE';
  return API_POST(url, data);
}
window.API_DELETE = function(url, data) {
  if (data == undefined)
    data = {}
  data['_httpMethod'] = 'DELETE';
  return API_POST(url, data);
}

window.API = function(method, url, data, cacheTime, hasSpinner, ignoreError) {
  if (hasSpinner) {
    showSpinner();
  }

  var deferred = $.Deferred();

  var localCache = false;
  if (cacheTime) { // Hours
    localCache = true;
  }

  if (ignoreError == undefined) {
    ignoreError = false;
  }

  if (data == undefined) {
    data = {}
  }
  data['_apiKey'] = getCache(CACHE_API_KEY);

  if (method != 'GET') {
    data = JSON.stringify(data);
  }

  // textStatus = success | error
  // jqXHR.status = 200 | 0 | ...
  var baseURL = null
  if (process.env.VUE_APP_DEBUG == "true") {
    baseURL = process.env.VUE_APP_URL + API_GATEWAY + url;
  } else {
    baseURL = API_GATEWAY + url;
  }
  $.ajax({
    type: method,
    url: baseURL,
    dataType: 'json',
    jsonp: false,
    data: data,
    localCache: localCache,
    cacheTTL: cacheTime,
  })
    .done(function (data, textStatus, jqXHR) {
      // console.log('done');
      // console.log(data);
      // console.log(textStatus);
      // console.log(jqXHR);
      deferred.resolve(data, textStatus, jqXHR);
    })
    .fail(function (jqXHR, textStatus, errorThrown) {
      // console.log('fail');
      // console.log(jqXHR);
      // console.log(textStatus);
      // console.log(errorThrown);
      // NOTE :: 로그인 없어서 임시로 주석 fail 아래부분 전체
      // var data = jqXHR.responseJSON;
      // if (data != undefined && typeof (data.data) == 'string' && data.data[0] == 'T' && data.data.indexOf('AssertionError: ') != -1) {
      //   var msg = data.data.split('AssertionError: ')[1].trim();
      //   if (msg == '로그인 후 이용할 수 있습니다.') {
      //     delCache(CACHE_API_KEY);
      //     if (!DEBUG_MODE) window.location = 'index.html';
      //   } else if (msg == '인증시간만료, 다시 로그인 해주십시오.') {
      //     delCache(CACHE_API_KEY);
      //     if (!DEBUG_MODE) window.location = 'index.html';
      //   } else if (msg != '') {
      //     if (!ignoreError) {
      //       alert("다음의 오류가 발생하여 처리되지 않았습니다.\n- " + msg);
      //     }
      //     deferred.reject(jqXHR, textStatus, errorThrown);
      //   }
      // } else {
      //   if (!ignoreError) {
      //     // alert("오류가 발생하여 정상적으로 처리되지 않았습니다.");
      //   }
        deferred.reject(jqXHR, textStatus, errorThrown);
      // }
    })
    .always(function () {//data|jqXHR, textStatus, jqXHR|errorThrown) {
      // console.log('always');
      // console.log(jqXHR);
      // console.log(textStatus);
      // console.log(errorThrown);
      if (hasSpinner) {
        hideSpinner();
      }
    });
  return deferred.promise();
}

window.GetLightTypeNameByNo = function(typeNo) {
  switch (typeNo) {
    case TYPE_LIGHT_STREET:
      return TYPE_NAME_LIGHT_STREET;
    case TYPE_LIGHT_SECURITY:
      return TYPE_NAME_LIGHT_SECURITY;
    case TYPE_BOX_DISTRIBUTION:
      return TYPE_NAME_BOX_DISTRIBUTION;
    case TYPE_BOX_REPEATER:
      return TYPE_NAME_BOX_REPEATER;
  }
  return null;
}

if (!localStorage) {
  alert('Local cache is not available.');
}

window.CACHE_DEVICE_EUI = '__DEVICE_EUI__'
window.CACHE_GD_SERIAL = '__DEVICE_SN__'
window.CACHE_TIME_DIVISION = '__TIME_DIVISION__'
window.CACHE_TTL_KEY = '__TTL__';
window.CACHE_API_KEY = '__APIKEY__';
window.CACHE_VAL_ID = '__ID__';
window.CACHE_AREA_NAME = "__AREANAME__";
//다른 페이지에서 맵 특정 좌표로 이동할때 사용
window.CACHE_DIRECT_MAP = '__MAP__';
//특정시설물의 민원으로 바로 이동할때 사용
window.CACHE_DIRECT_COMPLAIN = '__COMPLAIN__';
//이전 페이지를 기록할 필요가 있을경우 사용
window.CACHE_PREVIOUS_PAGE = '__PREVIOUS_PAGE__';
window.CACHE_VAL_JSON_PREFIX = '_JSON_:';
window.CACHE_FACILITY_SEARCH_RADIUS = '__FACILITY_SEARCH_RADIUS__';

window.setCache = function(key, val, TTL_ms) {
  if (localStorage) {
    if (typeof (val) == 'object') {
      val = CACHE_VAL_JSON_PREFIX + JSON.stringify(val);
    }
    localStorage[key] = val;
    if (typeof (TTL_ms) == 'number') {
      localStorage[CACHE_TTL_KEY + '.' + key] = (Date.now() + TTL_ms);
    } else if (TTL_ms != undefined) {
      console.error('TTL_ms must be number..');
    }
  }
}

window.getCache = function(key, defaultVal) {
  if (localStorage && key in localStorage) {
    window.ttlKey = CACHE_TTL_KEY + '.' + key;
    if (ttlKey in localStorage && localStorage[ttlKey] <= Date.now()) {
      if (key == CACHE_API_KEY) {
        // NOTE api key의 validation 체크는 서버 루틴을 통한다.
        //window.location = 'index.html';
      }
      return defaultVal;
    }
    var val = localStorage[key];
    if (val.substr(0, CACHE_VAL_JSON_PREFIX.length) == CACHE_VAL_JSON_PREFIX) {
      val = val.substr(CACHE_VAL_JSON_PREFIX.length);
      val = JSON.parse(val);
    }
    return val;
  }
  return defaultVal;
}

window.delCache = function(key) {
  if (localStorage && key in localStorage) {
    ttlKey = CACHE_TTL_KEY + '.' + key;
    if (ttlKey in localStorage)
      delete localStorage[ttlKey]

    if (key in localStorage) {
      delete localStorage[key]
      return true;
    }
  }
  return false;
}

window.clearCache = function(showMsg) {
  if (localStorage) {
    var lightType = localStorage['light_type'];
    var accessToken = localStorage[CACHE_API_KEY];
    var start_len = localStorage['INITIAL_LAT_Value'];
    var start_leg = localStorage['INITIAL_LNG_Value'];
    var search_radius = localStorage[CACHE_FACILITY_SEARCH_RADIUS];
    
    localStorage.clear();

    localStorage[CACHE_API_KEY] = accessToken;
    localStorage['light_type'] = lightType;
    localStorage['INITIAL_LAT_Value'] = start_len;
    localStorage['INITIAL_LNG_Value'] = start_leg;
    localStorage[CACHE_FACILITY_SEARCH_RADIUS] = search_radius;
  }
  // Android app 캐시 제거
  if (window.Android != undefined) {
    window.Android.clearCache();
  }

  if (showMsg) {
    alert('성공적으로 업데이트 했습니다.');
  }
  window.location.reload();
}

window.signout = function() {
  // SIGNED_KEY = '';
  delCache(CACHE_API_KEY);
  window.location = '';
}

window.jsBackButton = function() {
  if ($('body.sidebar-open').length) {
    $('.content-wrapper').click();
  } else if ($('.modal.fade.in').length) {
    $('.modal.fade.in').last().modal('hide')
  } else {
    window.Android.pressBack();
  }
}

// 위도 경도 설정
window.SetBasicCoordinate = function(lat, lng) {
    setCache('INITIAL_LAT_Value', lat);
    setCache('INITIAL_LNG_Value', lng);
}

//
window.SetFacilitySearchRadius = function(radius){
  setCache(CACHE_FACILITY_SEARCH_RADIUS,radius)
}