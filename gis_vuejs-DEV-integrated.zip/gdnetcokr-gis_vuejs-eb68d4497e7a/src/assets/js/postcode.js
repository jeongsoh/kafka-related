/* eslint-disable */
// refer - http://egloos.zum.com/tiger5net/v/5667935

window.postcode = {};
window.SIDOSGG_CD = undefined
window.addrStep = 3;

window.getAddrNameBySLCODE = function(slcode) {
  // if(a.substr(0,5) != "46870") {
  //   alert('현재는 영광에 대해서만 사용할 수 있습니다.');
  //   return;
  // }
  //디폴트: 5글자
  var SIDOSGG_PARSE_INDEX = (SIDOSGG_CD && SIDOSGG_CD.length) == 4 ? [4,2,3,3]: [5,3,2,2];

  slcode = slcode.substr(SIDOSGG_PARSE_INDEX[0]); // 46870 영광 제거
  var _addr1 = slcode.substr(0, SIDOSGG_PARSE_INDEX[1]);
  for (var key in postcode) {
    if (_addr1 == key.split(':')[1]) {
      _addr1 = key;
      break;
    }
  }
  var _addr2 = slcode.substr(SIDOSGG_PARSE_INDEX[1], SIDOSGG_PARSE_INDEX[2]);
  var _addr3 = slcode.substr(SIDOSGG_PARSE_INDEX[1] + SIDOSGG_PARSE_INDEX[2], SIDOSGG_PARSE_INDEX[3]);
  for (var key in postcode[_addr1]) {
    if (_addr2 == key.split(':')[1]) {
      for (var i = 0; i < postcode[_addr1][key].length; i += 1) {
        var key2 = postcode[_addr1][key][i]
        if (_addr3 == key2.split(':')[1]) {
          _addr2 = key;
          _addr3 = key2;
          return [_addr1.split(':')[0], _addr2.split(':')[0], _addr3.split(':')[0]];
        }
      }
    }
  }
}

window.updateAddr1 = function(parent, optAll) {
  $(parent + "#addr1 option").remove();
  if (optAll) {
    $(parent + "#addr1").append("<option value=''>전체</option>");
  }
  var addr1;
  Object.keys(postcode).sort().forEach(function (element, index, array) {
    if (index == 0)
      addr1 = element;
    var keys = element.split(":");
    $(parent + "#addr1").append("<option value='{1}'>{0}</option>".format(keys[0], keys[1]));
  });
  updateAddr2(parent, optAll, addr1);
}
window.updateAddr2 = function(parent, optAll, addr1) {
  $(parent + "#addr2 option").remove();
  if (optAll) {
    $(parent + "#addr2").append("<option value=''>전체</option>");
    if ($(parent + "#addr1 option:selected").val() == '') {
      updateAddr3(parent, optAll, addr1);
      return;
    }
  }
  var addr2;
  Object.keys(postcode[addr1]).sort().forEach(function (element, index, array) {
    if (index == 0)
      addr2 = element;
    var keys = element.split(":");
    $(parent + "#addr2").append("<option value='{1}'>{0}</option>".format(keys[0], keys[1]));
  });
  updateAddr3(parent, optAll, addr1, addr2);
}
window.updateAddr3 = function(parent, optAll, addr1, addr2) {
  $(parent + "#addr3 option").remove();
  if (optAll) {
    $(parent + "#addr3").append("<option value=''>전체</option>");
    if ($(parent + "#addr2 option:selected").val() == '') {
      return;
    }
  }
  postcode[addr1][addr2].sort().forEach(function (element, index, array) {
    var keys = element.split(":");
    $(parent + "#addr3").append("<option value='{1}'>{0}</option>".format(keys[0], keys[1]));
  });
  // check for updated
  $(parent + "#addr3").change();

  // NOTE :: 2단계, 3단계 주소 같을 경우 마지막칸 안보이게 단계 설정 작업
  if (postcode[addr1][addr2].length == 1 && postcode[addr1][addr2] == addr2) {
    $(parent + "#addr3").hide();
    addrStep = 2
  } else {
    addrStep = 3
    $(parent + "#addr3").show();
  }
}

window.updateAddr = function(parent, optAll) {
  var deferred = $.Deferred();

  if (parent == undefined) {
    parent = '';
  } else {
    parent += ' ';
  }
  if (optAll == undefined) {
    optAll = false;
  }

  API_GET('postcode', {}, 24 * 7) // 7 days
    .done(function (res) {
      console.log("postcode", res)
      postcode = res['data'];

      SIDOSGG_CD = postcode['SIDOSGG_CD']
      delete postcode['SIDOSGG_CD']

      updateAddr1(parent, optAll);

      $(parent + "#addr1").unbind('change');
      $(parent + "#addr1").change(function () {
        addr1 = $(this).children("option:selected").text() + ":" + $(this).val();
        updateAddr2(parent, optAll, addr1);
      });
      $(parent + "#addr2").unbind('change');
      $(parent + "#addr2").change(function () {
        _addr1 = $(parent + '#addr1 option:selected');
        addr1 = _addr1.text() + ':' + _addr1.val();
        addr2 = $(this).children("option:selected").text() + ":" + $(this).val();
        updateAddr3(parent, optAll, addr1, addr2);
      });
      deferred.resolve();
    })
    /*
    .fail(function() {
      console.log( "error" );
      alert('서버 접속이 불안정합니다.');
    })*/
    .always(function () {
    });

  return deferred;
}