/* eslint-disable */
//가로등 마커 관련한 내용 
window.IS_GUARDIAN = ($.inArray(getCache(CACHE_VAL_ID), ['guardian', 'sales']) != -1);

window.AREA_NAME = getCache(CACHE_AREA_NAME);
if (window.AREA_NAME == 'geoje') {
    window.IS_GUARDIAN = true;
}

window.TYPE_LIGHT_ALL = -1 // 전체, 옵션 값으로만 사용

window.TYPE_LIGHT_STREET = 0; //가로등
window.TYPE_LIGHT_SECURITY = 1; //보안등
window.TYPE_LIGHT_ETC1 = 2; //경관등
window.TYPE_LIGHT_ETC2 = 3; //공원등
window.TYPE_BOX_DISTRIBUTION = 4; //분전함
window.TYPE_BOX_REPEATER = 5; //중계기
window.TYPE_LIGHTHOUSE_LANTERN = 6; //등명기
window.TYPE_LIGHT_MONITOR = 7; //등주감시기
window.TYPE_BOX_DISTRIBUTION_SUB_MODULE_A = 8;
window.TYPE_BOX_DISTRIBUTION_SUB_MODULE_B = 9;
window.TYPE_BOX_DISTRIBUTION_MINI = 10;

window.pin0_png_hash = require("@/assets/img/res/img/pin0.png");
window.pin4_png_hash = require("@/assets/img/res/img/pin4.png");
window.pin5_png_hash = require("@/assets/img/res/img/pin5.png");
window.pin6_png_hash = require("@/assets/img/res/img/pin6.png");
window.on0_png_hash = require("@/assets/img/res/img/on0.png");
window.on4_png_hash = require("@/assets/img/res/img/on4.png");
window.on5_png_hash = require("@/assets/img/res/img/on5.png");
window.on6_png_hash = require("@/assets/img/res/img/on6.png");
window.off0_png_hash = require("@/assets/img/res/img/off0.png"); // 보안등
window.off4_png_hash = require("@/assets/img/res/img/off4.png");
window.off5_png_hash = require("@/assets/img/res/img/off5.png");
window.off6_png_hash = require("@/assets/img/res/img/off6.png"); // 가로등
window.error4_png_hash = require("@/assets/img/res/img/error4.png");
window.error04_png_hash = require("@/assets/img/res/img/error04.png");
window.error5_png_hash = require("@/assets/img/res/img/error5.png");
window.error05_png_hash = require("@/assets/img/res/img/error05.png");
window.moving_icon = require("@/assets/img/res/img/moving_icon.png");
window.night0_png_hash = require("@/assets/img/res/img/night0.png");
window.night4_png_hash = require("@/assets/img/res/img/night4.png");
window.night5_png_hash = require("@/assets/img/res/img/error52.png");
window.night6_png_hash = require("@/assets/img/res/img/night6.png");

window.GetLightType = function(light, pintype) {
    if(light.SL_SLNAME == "거제면(분)01"){
        window.test1 = light
    }
    window.test2 = pintype

    if (pintype == "pin") {
        if (light.SL_DATA_1 == TYPE_BOX_REPEATER)
            return pin5_png_hash;
        else if(light.SL_DATA_1 == TYPE_LIGHT_STREET){
            return pin6_png_hash;
        }
        else if ($.inArray(light.SL_DATA_1, [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
            return pin4_png_hash;
        else if ($.inArray(light.SL_DATA_1, [TYPE_LIGHT_SECURITY, TYPE_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_BOX_DISTRIBUTION_SUB_MODULE_B]) >= 0)
            return pin0_png_hash;
        else
            return pin6_png_hash;
    }
    else if(pintype=='move'){
        return moving_icon
    }
    else if (pintype == "on") {
        if (light.SL_DATA_1 == TYPE_BOX_REPEATER)
            return on5_png_hash;
        else if ($.inArray(light.SL_DATA_1, [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
            return on4_png_hash;
        else if ($.inArray(light.SL_DATA_1, [TYPE_LIGHT_SECURITY, TYPE_LIGHT_STREET, TYPE_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_BOX_DISTRIBUTION_SUB_MODULE_B]) >= 0)
            return on0_png_hash;
        else
            return on6_png_hash;
    }
    else if (pintype == "night") {
        if (light.SL_DATA_1 == TYPE_BOX_REPEATER)
            return night5_png_hash;
        if ($.inArray(light.SL_DATA_1, [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
            return night4_png_hash;
        else if ($.inArray(light.SL_DATA_1, [TYPE_LIGHT_SECURITY, TYPE_LIGHT_STREET, TYPE_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_BOX_DISTRIBUTION_SUB_MODULE_B]) >= 0)
            return night0_png_hash;
        else
            return night6_png_hash;    
    } else {
        if (light.SL_DATA_1 == TYPE_BOX_REPEATER)
            return off5_png_hash;
        else if ($.inArray(light.SL_DATA_1, [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
            return off4_png_hash;
        else if ($.inArray(light.SL_DATA_1, [TYPE_LIGHT_SECURITY, TYPE_LIGHT_STREET, TYPE_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_BOX_DISTRIBUTION_SUB_MODULE_B]) >= 0)
            return off0_png_hash;
        else
            return off6_png_hash;
    }
}

window.GetNightOutNow = function(light, light_time) {
    // 심야 소등 설정된 시간일경우
    // NOTE: 심야소등 설정시간일 경우 LIGHT_TEST도 불가능 하다.
    if ('NIGHT_OUT' in light && light['NIGHT_OUT'] != null){
        var now = new Date()
        var nowTs = now.getTime();

        var offFromHour = 0;
        var offToHour = 0;
        var offFromMin = 0;
        var offToMin = 0;

        var fromTime = new Date();
        var toTime = new Date();

        var lightOffTs = 0;
        var lightOffTime = 0;

        if(Object.keys(light['NIGHT_OUT']).length == 2){
            for(var data in light['NIGHT_OUT']){
                offFromHour = light['NIGHT_OUT'][data].OFF_FROM_HOUR
                offToHour   = light['NIGHT_OUT'][data].OFF_TO_HOUR
                offFromMin  = light['NIGHT_OUT'][data].OFF_FROM_MIN
                offToMin    = light['NIGHT_OUT'][data].OFF_TO_MIN

                fromTime = new Date().setHours(offFromHour, offFromMin, 0);
                toTime = new Date().setHours(offToHour, offToMin, 0);

                lightOffTs = new Date().setHours(light_time.OFF_Hour, light_time.OFF_Min, 0);
                lightOffTime = new Date(lightOffTs);
                lightOffTime.setMinutes(lightOffTime.getMinutes() + light['NIGHT_OUT'].OFF_DEVIATION);
                lightOffTs = lightOffTime.getTime();

                if( fromTime > toTime){
                    if (nowTs < toTime && nowTs < lightOffTs) {
                        return true;
                    }
                    toTime = new Date(toTime + 86400000).getTime()
                }

                if( fromTime <= nowTs && nowTs <= toTime ){
                    // NOTE: 점등시에만 심야설정 표시를 한다.
                    if (now.getHours() < light_time.OFF_Hour ||
                        (now.getHours() == light_time.OFF_Hour && now.getMinutes() <= light_time.OFF_Min)) {
                        return true;
                    } else if (now.getHours() > light_time.ON_Hour ||
                        (now.getHours() == light_time.ON_Hour && now.getMinutes() >= light_time.ON_Min)) {
                        return true;
                    }
                }
            }
        }else if (Object.keys(light['NIGHT_OUT']).length > 0){
            offFromHour = light['NIGHT_OUT'].OFF_FROM_HOUR
            offToHour   = light['NIGHT_OUT'].OFF_TO_HOUR
            offFromMin  = light['NIGHT_OUT'].OFF_FROM_MIN
            offToMin    = light['NIGHT_OUT'].OFF_TO_MIN

            fromTime = new Date().setHours(offFromHour, offFromMin, 0);
            toTime = new Date().setHours(offToHour, offToMin, 0);

            lightOffTs = new Date().setHours(light_time.OFF_Hour, light_time.OFF_Min, 0);
            lightOffTime = new Date(lightOffTs);
            lightOffTime.setMinutes(lightOffTime.getMinutes() + light['NIGHT_OUT'].OFF_DEVIATION);
            lightOffTs = lightOffTime.getTime();

            if( fromTime > toTime){
                if (nowTs < toTime && nowTs < lightOffTs) {
                    return true;
                }
                toTime = new Date(toTime + 86400000).getTime()
            }

            if( fromTime <= nowTs && nowTs <= toTime ){
                // NOTE: 점등시에만 심야설정 표시를 한다.
                if (now.getHours() < light_time.OFF_Hour ||
                    (now.getHours() == light_time.OFF_Hour && now.getMinutes() <= light_time.OFF_Min)) {
                    return true;
                } else if (now.getHours() > light_time.ON_Hour ||
                    (now.getHours() == light_time.ON_Hour && now.getMinutes() >= light_time.ON_Min)) {
                    return true;
                }
            }
        }
    }
    return false;
}

window.GetLightErrorName = function(light, light_time) {    
    var light_real_time = JSON.parse(JSON.stringify(light_time));
    if (light['DEVIATION'] != null) {
        array = [['ON_Hour', 'ON_Min', 'ON'], ['OFF_Hour', 'OFF_Min', 'OFF']];

        array.forEach(function (element) {
            dt = new Date('2000', '1', '1', light_real_time[element[0]], light_real_time[element[1]]);
            dt.setMinutes(dt.getMinutes() + parseInt(light.DEVIATION[element[2]]));
            light_real_time[element[0]] = dt.getHours();
            light_real_time[element[1]] = dt.getMinutes();
        });
    }

    if ('light_value' in light) {
        if (light['GFCI_error'] != null) {
            return "(누전차단기)";
        } else if (light['AC_RELAY_error'] != null) {
            return "(릴레이)";
        } else if (light['SMPS_error'] != null) {
            if (light['SL_DATA_6'] == 4) { // LED
                return "(SMPS)";
            } else if (light['LF_1_LAMP'] == 'LED' || light['LF_2_LAMP'] == 'LED' || light['LF_3_LAMP'] == 'LED') { // LED
                return "(SMPS)";
            } else { // 그 외 (나트륨, 할로겐 등)
                return "(안정기)";
            }
        } else if (light['LAMP_error'] != null) {
            return "(램프)";
        } else if (light['BLACKOUT_error'] != null) {
            if (light['SL_DATA_1'] == TYPE_LIGHT_MONITOR) { // 등주감시기는 따로 처리
                //} else if (light['WORK_TYPE'] == -1) { // 스마트LED
                //  return "(AC차단)";
            } else {
                return "(정전)";
            }
        } else if (light['MG_error'] != null) {
            return "(마그네트)"
        } else if (light['ELB_A_error'] != null) {
            return "(ELB_A)"
        } else if (light['ELB_B_error'] != null) {
            return "(ELB_B)"
        }
    }

    if (GetNightOutNow(light, light_real_time) == true) {
        return "(심야)"
    }

    // NOTE 위에 중복되는 로직이 있다. 추후 구조 개선하여 정리 필요
    var light_off_hm = parseInt(padDigits(light_time.OFF_Hour, 2) + padDigits(light_time.OFF_Min, 2));
    var now = new Date();
    var now_hm = parseInt(padDigits(now.getHours(), 2) + padDigits(now.getMinutes(), 2));
    var last_status = new Date(light['updated_at']);
    var last_status_hm = parseInt(padDigits(last_status.getHours(), 2) + padDigits(last_status.getMinutes(), 2));
    var has_today_status = (now.toDateString() == last_status.toDateString());
    var its_after_0830_today = now_hm >= 830;
    var time_1hours = 1000 * 60 * 60;
    var time_12hours = time_1hours * 12;
    var time_24hours = time_1hours * 24;

    if (light['WORK_TYPE'] == -1 // LoRa 통신의 경우
    && 'updated_at' in light // 최근 상태가 존재하면서
    && (IS_GUARDIAN || light['SL_DATA_1'] == TYPE_LIGHT_MONITOR)) {
    //     // 테스트 점소등
    //     if (light['light_test']) {
    //         if ((now - last_status) > time_1hours) {
    //             return "(통신불량)";
    //         }
    //         //return "(테스트)";
    //     }
    //     // 통신 불량
    //     if (its_after_0830_today) {
    //         if (!has_today_status) {
    //             return "(통신불량)";
    //         }
    //     } else if ((now - last_status) > time_12hours) {
    //         return "(통신불량)";
    //     }
        // 24시간 지나면 통신불량
        if ((now - last_status) > time_24hours) {
            return "(통신불량)";
        }
    }
    return "";
}

window.width = 0
window.height = 0
window.GetLightImageSize = function(LAMP_TYPE) {
    if ($.inArray(parseInt(LAMP_TYPE), [TYPE_BOX_DISTRIBUTION, TYPE_BOX_REPEATER, TYPE_LIGHTHOUSE_LANTERN, TYPE_BOX_DISTRIBUTION_MINI]) >= 0) {
        width = 22;
        height = 22;
    } else {
        width = 22;
        height = 22;
    }
    return {
        'width': width,
        'height': height
    };
}

window.GetLightImagePath = function(LAMP_STATUS, LAMP_TYPE) {
    // NOTE 설치 상황에서 사용
    // NOTE LAMP_STATUS 항상 0 으로 들어옴
    var markerurl = '';
    var type = "pin"
    if(LAMP_STATUS==='move'){
        type=LAMP_STATUS
    }
    markerurl = GetLightType({ SL_DATA_1: parseInt(LAMP_TYPE) }, type);
    return markerurl;
}

window.GetLightImagePath2 = function(light, light_time_origin) {
    //값복사
    var light_time = JSON.parse(JSON.stringify(light_time_origin));

    if (light['DEVIATION'] != null) {
        window.array = [['ON_Hour', 'ON_Min', 'ON'], ['OFF_Hour', 'OFF_Min', 'OFF']];

        array.forEach(function (element) {
            window.dt = new Date('2000', '1', '1', light_time[element[0]], light_time[element[1]]);
            dt.setMinutes(dt.getMinutes() + parseInt(light.DEVIATION[element[2]]));
            light_time[element[0]] = dt.getHours();
            light_time[element[1]] = dt.getMinutes();
        });
    }

    // 모드가 있고 / 테스트 점소등이 아니며 / 등주감시기가 아닐때 모드를 표현함
    // FIXME 분전함 뷰가 수정될때 같이 수정 되어야 함.
    if (light['MODE'] != null && light['light_test'] == false && light['SL_DATA_1'] != TYPE_LIGHT_MONITOR){
        window.MODE_TIMETABLE = "0";
        window.MODE_ALWAYS_ON = "1";
        window.MODE_ALWAYS_OFF = "2";

        window.nowMajorMode = light['MODE'].substring(0,1);

        switch (nowMajorMode) {
            case MODE_TIMETABLE:
                break;
            case MODE_ALWAYS_ON:
                return GetLightType(light, "on");
            case MODE_ALWAYS_OFF:
                return GetLightType(light, "off");
            default:
                break;
        }
    }

    if ('light_value' in light) {
        // 가로등 분전함의 경우, 센서 0의 값이 일정 이하면 누전차단기 에러와 같은 상황이다.
        if (light.SL_DATA_1 == TYPE_LIGHTHOUSE_LANTERN) {
            if (light.sensor_value_1 < 512) { // FIXME 수치 변경 필요
                light['GFCI_error'] = 1;
            }
        }
        // 빨강
        if ((light['GFCI_error'] != null) || (light['AC_RELAY_error'] != null) || (light['LAMP_error'] != null) || (light['MG_error'] != null)) {
            if ($.inArray(light['SL_DATA_1'], [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
                return error5_png_hash
            return error05_png_hash
        }
        if (light['SMPS_error'] != null) {
            //if (light['SL_DATA_6'] == 4) {} // DC LED인 경우만
            if ($.inArray(light['SL_DATA_1'], [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
                return error5_png_hash
            return error05_png_hash
        }
        // 주황
        if (light['BLACKOUT_error'] != null) {
            if (light['SL_DATA_1'] == TYPE_LIGHT_MONITOR) { // 등주감시기는 따로 처리
                //} else if (light['WORK_TYPE'] == -1) { // 스마트LED // FIXME 수정 필요..
                return GetLightType(light, "off");
            } else {
                if (!IS_GUARDIAN) {
                    if ($.inArray(light['SL_DATA_1'], [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
                        return error4_png_hash
                    return error04_png_hash
                }
            }
        }
        //빨강
        if ((light['ELB_A_error'] != null) || (light['ELB_B_error'] != null)) {
            if ($.inArray(light['SL_DATA_1'], [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
                return error5_png_hash
            return error05_png_hash
        }

        var light_off_hm = parseInt(padDigits(light_time.OFF_Hour, 2) + padDigits(light_time.OFF_Min, 2));
        var now = new Date();
        var now_hm = parseInt(padDigits(now.getHours(), 2) + padDigits(now.getMinutes(), 2));
        var last_status = new Date(light['updated_at']);
        var last_status_hm = parseInt(padDigits(last_status.getHours(), 2) + padDigits(last_status.getMinutes(), 2));
        var has_today_status = (now.toDateString() == last_status.toDateString());
        var its_after_0830_today = now_hm >= 830;
        var time_1hours = 1000 * 60 * 60;
        var time_12hours = time_1hours * 12;
        var time_24hours = time_1hours * 24;

        // 테스트 점소등
        if (light['light_test']) {
            // NOTE 테스트로 인해 점소등이 보이고, 통신불량이 안떠있으면 더 큰 문제일것으로 예상
            if ((now - last_status) > time_1hours) {
                return error04_png_hash // 주황, 통신불량
            } else if (light['light_value'] == 0) {
                return GetLightType(light, "off");
            }
            return GetLightType(light, "on");
        }
        if (light['SL_DATA_1'] == TYPE_LIGHT_MONITOR) {
            console.log();
        }

        if (GetNightOutNow(light, light_time) == true){
            return GetLightType(light, "night");
        }

        // 통신 불량
        // * 오늘 8시 30분이 넘었다면 --> 오늘 상태 정보 유무로 체크
        // * 오늘 8시 30분이 넘지 않았다면 --> 12시간 이내 상태 정보 유무로 체크
        if (IS_GUARDIAN || light['SL_DATA_1'] == TYPE_LIGHT_MONITOR) {
            // if (its_after_0830_today) {
            //     if (!has_today_status) {
            //         return error04_png_hash // 주황, 통신불량
            //     }
            // } else if ((now - last_status) > time_12hours) {
            //     return error04_png_hash // 주황, 통신불량
            // }
            // 24시간 지나면 통신불량
            if ((now - last_status) > time_24hours) {
                return error04_png_hash // 주황, 통신불량
            }
        }

        if (light['SL_DATA_1'] == TYPE_LIGHT_MONITOR) {
            // NOTE 등주감시기 예외 로직
            //      0) 에러 체크 (통신불량 외)
            //         * 정전은 AC차단으로 정상상태 off임
            //      1) 통신 불량 체크
            //         * 오늘 8시 30분이 넘었다면 --> 오늘 상태 점검 정보 유무로 체크
            //         * 오늘 8시 30분이 넘지 않았다면 --> 12시간 이내 상태 점검 정보 유무로 체크
            // 2) 지금 시간이 자체 서버 시간(소등) ~ 8:30 이라면,
            //    * 소등으로 처리함
            if (!its_after_0830_today) {
                if (now_hm >= light_off_hm) {
                    return GetLightType(light, "off");
                }
            }
            // 3) 오늘 8시 30분이 넘었다면,
            //    * 오늘 8시 30분 이후 상태 정보를 정상적으로 반영
            //    * 그 전까지는 소등 상태를 그대로 유지함
            else if (has_today_status) {
                if (last_status_hm < 830) {
                    return GetLightType(light, "off");
                }
            }
            // 4) 오늘 8시 30분이 넘지 않았다면,
            //    * 상태 정보를 그대로 유지함.
            if (light['light_value'] > 0) {
                return GetLightType(light, "on");
            } else {
                return GetLightType(light, "off");
            }
        }
        if (now.getHours() < light_time.OFF_Hour ||
            (now.getHours() == light_time.OFF_Hour && now.getMinutes() <= light_time.OFF_Min)) {
            return GetLightType(light, "on");
        } else if (now.getHours() > light_time.ON_Hour ||
            (now.getHours() == light_time.ON_Hour && now.getMinutes() >= light_time.ON_Min)) {
            return GetLightType(light, "on");
        } else {
            return GetLightType(light, "off");
        }
    } else {
        // FIXME LoRa로 상태 받아오기 전?
        // NOTE 경관등, 중계기등 기타 등 이미지가 변하게 하지 않기 위해서 분전함만 예외처리
        if ($.inArray(light['SL_DATA_1'], [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_MINI, TYPE_LIGHTHOUSE_LANTERN]) >= 0)
            return GetLightType(light, "pin");
        else if(light['SL_DATA_1'] == 0)
            return pin6_png_hash
        else if(light['SL_DATA_1'] == 6)
            return pin0_png_hash
        else
            return pin0_png_hash
    }
}