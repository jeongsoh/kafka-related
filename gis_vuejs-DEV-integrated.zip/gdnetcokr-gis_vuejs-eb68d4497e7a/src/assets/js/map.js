/* eslint-disable */
//<input type = "hidden" name="CHANGED_ZOOM" ID="CHANGED_ZOOM"> 
import store from '../../store/index.js'

updateAddr('#modal-info');
window.WATER_TEST = false;

window.CrossHeadPosition = false

window.map = null;
window.flagicon = null;
window.flagMarker = null;
window.JJPolygon = null;
window.overlayObjects = new Array;
window.tooltipObjects = null;
window.bounds = null;
window.m_center = null;
window.m_clickID = "NO";
window.m_clickAddress = "NO";
window.installObj = {}

window.m_geocoder = null;

window.po1 = null;
window.po2 = null;

window.m_movedX = "-1";
window.m_movedY = "-1";

window.m_zoomlevel = null;

window.m_GPS = 0;

window.UPDATE_DISTANCE = 0.3;
window.FACILITY_DISTANCE = getCache(CACHE_FACILITY_SEARCH_RADIUS, 0.5);

window.INITIAL_LAT = getCache('INITIAL_LAT_Value', 0);
window.INITIAL_LNG = getCache('INITIAL_LNG_Value', 0);

// 1:보안등/중계기
// 0:가로등/분전함
// -1: 전체
window.INITIAL_VISIBLE_LIGHT_TYPE = -1;

window.ID_MOTHER_MAX = 31;
window.ID_GROUP_MAX = 8;
window.ID_INDIVIDUAL_MAX = 32;

window.centerPos = {
  'Lat': 0,
  'Lng': 0
};
window.waitForUpdate = false; // light 정보 서버에 호출 중인지
window.invalidateLight = true; // light 정보 강제 업데이트 여부

window.light_info = null; // 시설물 정보 임시 저장

window.light_add_type = 1;

window.datacode = null;
window.MODAL_INFO_ADD_TITLE = '시설물 추가';
window.needUpdateStep = '';
window.sidebarWidth = 0;
window.headerHeight = 0;

window.thumnailImageSize = 300
window.originImageSize = 1920

window.coordsFromPoint = function () {

  if ($('#sidebar').attr("value") != undefined) {
    window.sidebarWidth = 42.5;
  } else {
    window.sidebarWidth = 0;
  }
  if ($('.main-header').attr("value") != undefined) {
    window.headerHeight = 0;
  } else {
    window.headerHeight = 27.5;
  }
  var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(window.map.getCenter()).x + window.sidebarWidth, window.map.getProjection().pointFromCoords(window.map.getCenter()).y + window.headerHeight);
  return window.map.getProjection().coordsFromPoint(point);
}
window.panelPosition = ""
window.setCoordsFromPoint = function (x, y, position, notmoveflag, rvFlag) {
  // NOTE :: 패널, 헤더의 활성화 여부, 크기 등을 게산하여 좌표 이동 하는 형태로 변경됨.
  if (notmoveflag != true) {
    map.setLevel(1)
  }
  if ($('#sidebar').attr("value") != undefined) {
    window.sidebarWidth = 42.5;
  } else {
    window.sidebarWidth = 0;
  }
  if ($('.main-header').attr("value") != undefined) {
    window.headerHeight = 0;
  } else {
    window.headerHeight = 27.5;
  }
  if (map.getLevel() > 1) {
    window.sidebarWidth = 0
  }
  if ($('#map_wrap').hasClass('map_sub')) {
    window.sidebarWidth = 0;
    window.headerHeight = 0;
  }
  var latlng = new kakao.maps.LatLng(y, x);
  if (position == "left") {
    if (store.getters.panel_class != "hidden") {
      if (notmoveflag === true) { // drawcircle 때매 추가
        if (rvFlag === true) {
          var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth - ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y - window.headerHeight);
        } else {
          var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x + ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y);
        }
      } else {
        var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth - ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y - window.headerHeight);
      }
    } else {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y - window.headerHeight);
    }
  } else if (position == "bottom") {
    if (store.getters.panel_class != "hidden") {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y + ($("#panel").height() / 2) - window.headerHeight);
    } else {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y - window.headerHeight);
    }
  } else if (position == "right") {
    if (store.getters.panel_class != "hidden") {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth + ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y - window.headerHeight);
    } else {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y - window.headerHeight);
    }
  } else if (position == "top") {
    if (store.getters.panel_class != "hidden") {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y - ($("#panel").height() / 2) - window.headerHeight);
    } else {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y - window.headerHeight);
    }
  } else if (position == "roadview") {
    // 지도위에 오버레이할 때
    if (store.getters.panel_class != "hidden") {
      if (panelPosition == "left") {
        var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth - ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y);
      } else if (panelPosition == "bottom") {
        var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y + ($("#panel").height() / 2));
      } else if (panelPosition == "right") {
        var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth + ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y);
      } else if (panelPosition == "top") {
        var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y - ($("#panel").height() / 2));
      }
    } else {
      var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y);

    }
    // 화면 반 채울 떄
    // if(store.getters.panel_class != "hidden"){
    //   if(panelPosition == "left"){
    //       console.log("aaaaleft")
    //       var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x -window.sidebarWidth - ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y  + ($("#roadview").height() / 2));
    //   }else if(panelPosition == "bottom"){
    //     var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y + ($("#panel").height() / 2)  + ($("#roadview").height() / 2));
    //   }else if(panelPosition == "right"){
    //     var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth + ($("#panel").width() / 2), window.map.getProjection().pointFromCoords(latlng).y  + ($("#roadview").height() / 2));
    //   }else if(panelPosition == "top"){
    //     var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y - ($("#panel").height() / 2)  + ($("#roadview").height() / 2));
    //   }
    // }else{
    //   var point = new kakao.maps.Point(window.map.getProjection().pointFromCoords(latlng).x - window.sidebarWidth, window.map.getProjection().pointFromCoords(latlng).y + ($("#roadview").height() / 2));

    // }
  }
  return window.map.getProjection().coordsFromPoint(point);
}

window.modeLightMove = function (enable, modalScreen) {
  if (enable) {
    needUpdateStep = 'move';
    modalScreen == undefined ? $("#modal-info").modal('hide') : modalScreen.modal('hide');
    $('.navbar-custom-menu a').hide()
    $('.light_movecontrol *').show();
  } else {
    $('.light_movecontrol *').hide();
    $('.navbar-custom-menu a').show()
    modalScreen == undefined ? $("#modal-info").modal('show') : modalScreen.modal('show')
    needUpdateStep = 'moved';
  }
}

window.LIGHT_ON_OFF_ERROR_DEVIATION = 1800000; // 점등 시간 30분 이후, 소등 시간 30분 이후는 각각 이상 상태
window.STATUS_UPDATE_DURATION = 3000;
window.isStatusUpdating = false;
window.statusUpdatesIn = 0; // Client Update Time
window.statusUpdatedAt = 0; // Server Time
window.settingProcess = false;

/* 분전함 관제 */
window.isInfoUpdatesIn = 0             //분전함 상태창 주기 갱신 Timer  
window.distributorModalData = null;    //분전함 상태창 갱신 재사용 데이터
window.focusedScreen = null;        //이동 하는 시설물 상태창 (light, 분전함)

window.lightUpdatesIn = 0;
window.lightUpdtedAt = 0;

window.mapMovedDelay = 0;
window.MAP_MOVE_GPS_DELAY = 3000;

window.GPS_ACCURACY_THRESHOLD = 100;
window.GPS_FAIL_THRESHOLD = 3;
window.GPS_UPDATE_DURATION = 500;

window.isGpsTracking = false;
window.gpsUpdatesIn = 0;
window.validGpsPos = null;
window.gpsTryCount = 0;

window.geoTrackingNo = null;
window.geoOptions = {
  enableHighAccuracy: true,
  // maximumAge: 15000,
  timeout: 10000,
}


window.getGps = function () {
  if (geoTrackingNo != null) {
    return;
  } else if (mapMovedDelay > Date.now()) {
    return;
  } else if (gpsUpdatesIn > Date.now()) {
    return;
  }

  geoTrackingNo = navigator.geolocation.watchPosition(
    function (position) {
      gpsUpdatesIn = Date.now() + GPS_UPDATE_DURATION;
      gpsTryCount = 0;
      if (validGpsPos == position.coords) {
        return;
      } else if (position.coords.accuracy > GPS_ACCURACY_THRESHOLD) {
        return;
      }

      if ($('.gps_control').hasClass('try')) {
        $('.gps_control').removeClass('try');
        $('.gps_control').addClass('on');
      }

      navigator.geolocation.clearWatch(geoTrackingNo);
      geoTrackingNo = null;
      validGpsPos = position.coords;
      // console.log(validGpsPos.accuracy, validGpsPos.longitude, validGpsPos.latitude);
      SetMyLocation('MyMarker', 1, validGpsPos.longitude, validGpsPos.latitude, 20, 20, require("@/assets/img/res/img/me.png"));
    },
    function (res) {
      gpsTryCount++;
      geoTrackingNo = null;
      if (gpsTryCount >= GPS_FAIL_THRESHOLD) {
        triggerGPS();
        alert('위치 확인에 실패했습니다.');
      }
    }, geoOptions);
  // console.log('call:'+Date.now()+', '+geoTrackingNo);
}

window.GPSOn = function (androidCanGps) {
  // Android GPS Check
  if (window.Android != undefined) {
    if (androidCanGps == undefined) {
      window.Android.checkGPS();
      return;
    } else if (androidCanGps == false) {
      alert('위치 확인에 실패했습니다.');
      return;
    }
  }
  gpsTryCount = 0;
  isGpsTracking = true;
  $('.gps_control').addClass('try');
  getGps();
}

window.GPSOff = function () {
  if (geoTrackingNo) {
    navigator.geolocation.clearWatch(geoTrackingNo);
    geoTrackingNo = null;
  }
  isGpsTracking = false;
  $('.gps_control').removeClass('try');
  $('.gps_control').removeClass('on');
}

window.triggerGPS = function (androidCanGps) {
  if (!isGpsTracking && geoTrackingNo == null) {
    GPSOn(androidCanGps);
  } else {
    GPSOff();
  }
}

/*
 * ParkDyel
 * 2018.06.18
 * Ver 1.0.0
 * 거리 구하기 기능
 */

window.isRulerOn = false;

window.activeRuler = function () {
  // 지도에 클릭 이벤트를 등록합니다
  // 지도를 클릭하면 선 그리기가 시작됩니다 그려진 선이 있으면 지우고 다시 그립니다
  kakao.maps.event.addListener(map, 'click', evtfnLineLeftClick);
  // 지도에 마우스무브 이벤트를 등록합니다
  // 선을 그리고있는 상태에서 마우스무브 이벤트가 발생하면 그려질 선의 위치를 동적으로 보여주도록 합니다
  kakao.maps.event.addListener(map, 'mousemove', evtfnLineMouseMove);
  // 지도에 마우스 오른쪽 클릭 이벤트를 등록합니다
  // 선을 그리고있는 상태에서 마우스 오른쪽 클릭 이벤트가 발생하면 선 그리기를 종료합니다
  kakao.maps.event.addListener(map, 'rightclick', evtfnLineRightClick);
}
window.drawingMode = function () {
  kakao.maps.event.addListener(map, 'click', drawingClick);
  kakao.maps.event.addListener(map, 'mousemove', drawingMouseMove);
  kakao.maps.event.addListener(map, 'rightclick', drawingRightClick);
}
window.polygonMode = function () {
  kakao.maps.event.addListener(map, 'click', polygonClick);
  kakao.maps.event.addListener(map, 'mousemove', polygonMousemove);
  kakao.maps.event.addListener(map, 'rightclick', polygonRightClick);
}

window.disableRuler = function () {
  /*
   * 모바일 버전에서나, 급하신 분들이 우클릭이벤트를 발생시키지 않아
   * 생길 수 있는 문제점을 방지하고자, 우클릭 이벤트를 강제 발생시킵니다.
   */
  kakao.maps.event.trigger(map, 'rightclick', 'hello');
  kakao.maps.event.removeListener(map, 'click', evtfnLineLeftClick);
  kakao.maps.event.removeListener(map, 'mousemove', evtfnLineMouseMove);
  kakao.maps.event.removeListener(map, 'rightclick', evtfnLineRightClick);
  deleteClickLine();
  deleteCircleDot();
  deleteDistnce();
}

window.triggerRuler = function (id) {
  if (isRulerOn == false) {
    activeRuler();
  } else {
    disableRuler();
  }
  isRulerOn = !isRulerOn
}

window.setRulerModeAtSide = function (e) {
  if (isRulerOn == false) {
    if (isRvOn == true) {
      removeEventOfRv();
    }
    activeRuler();
    e.classList.remove('unseleted_btn');
    e.classList.add('selected_btn');
    $('#btn_sideBar').children().addClass('enable')
  } else {
    if (isRvOn == true) {
      addEventOfRv();
    } else {
      $('#btn_sideBar').children().removeClass('enable')
    }
    disableRuler();
    e.classList.remove('selected_btn');
    e.classList.add('unseleted_btn');
    $('#a_control-sidebar').click();
  }
  isRulerOn = !isRulerOn
}

window.evtfnLineRightClick = function (mouseEvent) {
  // 지도 오른쪽 클릭 이벤트가 발생했는데 선을 그리고있는 상태이면
  if (drawingFlag) {
    // 마우스무브로 그려진 선은 지도에서 제거합니다
    window.moveLine.setMap(null);
    window.moveLine = null;
    // 마우스 클릭으로 그린 선의 좌표 배열을 얻어옵니다
    var path = window.clickLine.getPath();
    // 선을 구성하는 좌표의 개수가 2개 이상이면
    if (path.length > 1) {
      // 마지막 클릭 지점에 대한 거리 정보 커스텀 오버레이를 지웁니다
      if (dots[dots.length - 1].distance) {
        dots[dots.length - 1].distance.setMap(null);
        dots[dots.length - 1].distance = null;
      }
      var distance = Math.round(window.clickLine.getLength()), // 선의 총 거리를 계산합니다
        content = getTimeHTML(distance); // 커스텀오버레이에 추가될 내용입니다
      // 그려진 선의 거리정보를 지도에 표시합니다
      showDistance(content, path[path.length - 1]);
    } else {
      // 선을 구성하는 좌표의 개수가 1개 이하이면 
      // 지도에 표시되고 있는 선과 정보들을 지도에서 제거합니다.
      deleteClickLine();
      deleteCircleDot();
      deleteDistnce();
    }
    // 상태를 false로, 그리지 않고 있는 상태로 변경합니다
    drawingFlag = false;
  }
}

window.evtfnLineLeftClick = function (mouseEvent) {
  // 마우스로 클릭한 위치입니다 
  var clickPosition = mouseEvent.latLng;
  // 지도 클릭이벤트가 발생했는데 선을 그리고있는 상태가 아니면
  if (!drawingFlag) {
    // 상태를 true로, 선이 그리고있는 상태로 변경합니다
    drawingFlag = true;
    // 지도 위에 선이 표시되고 있다면 지도에서 제거합니다
    deleteClickLine();
    // 지도 위에 커스텀오버레이가 표시되고 있다면 지도에서 제거합니다
    deleteDistnce();
    // 지도 위에 선을 그리기 위해 클릭한 지점과 해당 지점의 거리정보가 표시되고 있다면 지도에서 제거합니다
    deleteCircleDot();
    // 클릭한 위치를 기준으로 선을 생성하고 지도위에 표시합니다
    window.clickLine = new kakao.maps.Polyline({
      map: map, // 선을 표시할 지도입니다 
      path: [clickPosition], // 선을 구성하는 좌표 배열입니다 클릭한 위치를 넣어줍니다
      strokeWeight: 3, // 선의 두께입니다 
      strokeColor: '#db4040', // 선의 색깔입니다
      strokeOpacity: 1, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
      strokeStyle: 'solid' // 선의 스타일입니다
    });
    // 선이 그려지고 있을 때 마우스 움직임에 따라 선이 그려질 위치를 표시할 선을 생성합니다
    moveLine = new kakao.maps.Polyline({
      strokeWeight: 3, // 선의 두께입니다 
      strokeColor: '#db4040', // 선의 색깔입니다
      strokeOpacity: 0.5, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
      strokeStyle: 'solid' // 선의 스타일입니다    
    });
    // 클릭한 지점에 대한 정보를 지도에 표시합니다
    displayCircleDot(clickPosition, 0);
  } else { // 선이 그려지고 있는 상태이면
    // 그려지고 있는 선의 좌표 배열을 얻어옵니다
    var path = window.clickLine.getPath();
    // 좌표 배열에 클릭한 위치를 추가합니다
    path.push(clickPosition);
    // 다시 선에 좌표 배열을 설정하여 클릭 위치까지 선을 그리도록 설정합니다
    window.clickLine.setPath(path);
    var distance = Math.round(window.clickLine.getLength());
    displayCircleDot(clickPosition, distance);
  }
}

window.evtfnLineMouseMove = function (mouseEvent) {

  // 지도 마우스무브 이벤트가 발생했는데 선을 그리고있는 상태이면
  if (drawingFlag) {
    // 마우스 커서의 현재 위치를 얻어옵니다 
    var mousePosition = mouseEvent.latLng;
    // 마우스 클릭으로 그려진 선의 좌표 배열을 얻어옵니다
    var path = window.clickLine.getPath();
    // 마우스 클릭으로 그려진 마지막 좌표와 마우스 커서 위치의 좌표로 선을 표시합니다
    var movepath = [path[path.length - 1], mousePosition];
    window.moveLine.setPath(movepath);
    window.moveLine.setMap(map);
    var distance = Math.round(window.clickLine.getLength() + window.moveLine.getLength()), // 선의 총 거리를 계산합니다
      content = '<div class="dotOverlay distanceInfo">총거리 <span class="number">' + distance +
        '</span>m</div>'; // 커스텀오버레이에 추가될 내용입니다
    // 거리정보를 지도에 표시합니다
    showDistance(content, mousePosition);
  }
}

window.drawingFlag = false; // 선이 그려지고 있는 상태를 가지고 있을 변수입니다
window.moveLine = null; // 선이 그려지고 있을때 마우스 움직임에 따라 그려질 선 객체 입니다
window.clickLine = null; // 마우스로 클릭한 좌표로 그려질 선 객체입니다
window.distanceOverlay = null; // 선의 거리정보를 표시할 커스텀오버레이 입니다
window.dots = {}; // 선이 그려지고 있을때 클릭할 때마다 클릭 지점과 거리를 표시하는 커스텀 오버레이 배열입니다.


// 클릭으로 그려진 선을 지도에서 제거하는 함수입니다
window.deleteClickLine = function () {
  if (window.clickLine) {
    window.clickLine.setMap(null);
    window.clickLine = null;
  }
}

// 마우스 드래그로 그려지고 있는 선의 총거리 정보를 표시하거
// 마우스 오른쪽 클릭으로 선 그리가 종료됐을 때 선의 정보를 표시하는 커스텀 오버레이를 생성하고 지도에 표시하는 함수입니다
window.showDistance = function (content, position) {

  if (distanceOverlay) { // 커스텀오버레이가 생성된 상태이면

    // 커스텀 오버레이의 위치와 표시할 내용을 설정합니다
    distanceOverlay.setPosition(position);
    distanceOverlay.setContent(content);

  } else { // 커스텀 오버레이가 생성되지 않은 상태이면

    // 커스텀 오버레이를 생성하고 지도에 표시합니다
    distanceOverlay = new kakao.maps.CustomOverlay({
      map: map, // 커스텀오버레이를 표시할 지도입니다
      content: content, // 커스텀오버레이에 표시할 내용입니다
      position: position, // 커스텀오버레이를 표시할 위치입니다.
      xAnchor: 0,
      yAnchor: 0,
      zIndex: 3
    });
  }
}

// 그려지고 있는 선의 총거리 정보와 
// 선 그리가 종료됐을 때 선의 정보를 표시하는 커스텀 오버레이를 삭제하는 함수입니다
window.deleteDistnce = function () {
  if (window.distanceOverlay) {
    window.distanceOverlay.setMap(null);
    window.distanceOverlay = null;
  }
}

// 선이 그려지고 있는 상태일 때 지도를 클릭하면 호출하여 
// 클릭 지점에 대한 정보 (동그라미와 클릭 지점까지의 총거리)를 표출하는 함수입니다
window.displayCircleDot = function (position, distance) {

  // 클릭 지점을 표시할 빨간 동그라미 커스텀오버레이를 생성합니다
  var circleOverlay = new kakao.maps.CustomOverlay({
    content: '<span class="dot"></span>',
    position: position,
    zIndex: 1
  });

  // 지도에 표시합니다
  circleOverlay.setMap(map);

  if (distance > 0) {
    // 클릭한 지점까지의 그려진 선의 총 거리를 표시할 커스텀 오버레이를 생성합니다
    var distanceOverlay = new kakao.maps.CustomOverlay({
      content: '<div class="dotOverlay">거리 <span class="number">' + distance + '</span>m</div>',
      position: position,
      yAnchor: 1,
      zIndex: 2
    });

    // 지도에 표시합니다
    distanceOverlay.setMap(map);
  }

  // 배열에 추가합니다
  dots.push({
    circle: circleOverlay,
    distance: distanceOverlay
  });
}

// 클릭 지점에 대한 정보 (동그라미와 클릭 지점까지의 총거리)를 지도에서 모두 제거하는 함수입니다
window.deleteCircleDot = function () {
  var i;

  for (i = 0; i < dots.length; i++) {
    if (dots[i].circle) {
      dots[i].circle.setMap(null);
    }

    if (dots[i].distance) {
      dots[i].distance.setMap(null);
    }
  }

  dots = [];
}

// 마우스 우클릭 하여 선 그리기가 종료됐을 때 호출하여 
// 그려진 선의 총거리 정보와 거리에 대한 도보, 자전거 시간을 계산하여
// HTML Content를 만들어 리턴하는 함수입니다
window.getTimeHTML = function (distance) {

  // 도보의 시속은 평균 4km/h 이고 도보의 분속은 67m/min입니다
  var walkkTime = distance / 67 | 0;
  var walkHour = '',
    walkMin = '';

  // 계산한 도보 시간이 60분 보다 크면 시간으로 표시합니다
  if (walkkTime > 60) {
    walkHour = '<span class="number">' + Math.floor(walkkTime / 60) + '</span>시간 '
  }
  walkMin = '<span class="number">' + walkkTime % 60 + '</span>분'

  // 자전거의 평균 시속은 16km/h 이고 이것을 기준으로 자전거의 분속은 267m/min입니다
  var bycicleTime = distance / 227 | 0;
  var bycicleHour = '',
    bycicleMin = '';

  // 계산한 자전거 시간이 60분 보다 크면 시간으로 표출합니다
  if (bycicleTime > 60) {
    bycicleHour = '<span class="number">' + Math.floor(bycicleTime / 60) + '</span>시간 '
  }
  bycicleMin = '<span class="number">' + bycicleTime % 60 + '</span>분'

  // 거리와 도보 시간, 자전거 시간을 가지고 HTML Content를 만들어 리턴합니다
  var content = '<ul class="dotOverlay distanceInfo">';
  content += '    <li>';
  content += '        <span class="label">총거리</span><span class="number">' + distance + '</span>m';
  content += '    </li>';
  content += '    <li>';
  content += '        <span class="label">도보</span>' + walkHour + walkMin;
  content += '    </li>';
  content += '    <li>';
  content += '        <span class="label">자전거</span>' + bycicleHour + bycicleMin;
  content += '    </li>';
  content += '</ul>'

  return content;
}


//////////////////////////////////////////
//////////////////////////////////////////

window.deleteLight = function () {
  var focusScreen = focusedScreen == null ? $('#modal-info') : focusedScreen;
  var slname = focusedScreen == null ? $('#modal-info #title').text() : focusedScreen.find('#title').text();

  var val = prompt('[' + slname + '] 시설물을 삭제하시겠습니까?\n삭제하시려면 해당 시설물의 이름을 입력해주세요.');
  if (val == slname) {
    API_DELETE('facility', {
      SL_SLCODE: focusScreen.find('#slcode').val(),
      SL_SLNAME: slname,
    }).done(function () {
      invalidateLight = true;
      focusScreen.modal('toggle');
    })
  } else if (val != null) {
    alert('시설물 이름이 일치하지 않습니다.');
  }
}

window.complainItem = function () {
  var focusScreen = focusedScreen == null ? $('#modal-info') : focusedScreen;

  var addr1 = $('#modal-info #addr1 option:selected');
  var addr2 = $('#modal-info #addr2 option:selected');
  var addr3 = $('#modal-info #addr3 option:selected');

  setCache(CACHE_DIRECT_COMPLAIN, {
    'addr1': addr1.text() + ':' + addr1.val(),
    'addr2': addr2.text() + ':' + addr2.val(),
    'addr3': addr3.text() + ':' + addr3.val(),
    'SL_SLNAME': focusScreen.find('#title').text(),
  });
  window.location = '/complain.html?v=d5e68e1';
}

window.lightValSlider = null;

window._called_by_window_android_check_version = function (version) {
  if (version >= 1) {
    // NOTE version 1에서 QR코드 카메라 기능 추가됨
    $('#modal-info #btn-camera').show();
    $('#modal-info #inputstyle').addClass('input-group input-group-sm');
  }
}

$(document).ready(function () {
  // onloadmap();
  // adminlte 의 layout 사이즈 조정과 잘못 겹치면 지도 로딩에 문제가 발생한다.
  // window.setTimeout(onloadmap, 300);

  // 초기화
  try {
    UpdateDateTime();

    $('.select').on('click', '.placeholder', function () {
      var parent = $(this).closest('.select');
      if (!parent.hasClass('is-open')) {
        parent.addClass('is-open');
        $('.select.is-open').not(parent).removeClass('is-open');
      } else {
        parent.removeClass('is-open');
      }
    }).on('click', 'ul>li', function () {
      var parent = $(this).closest('.select');
      var current = parent.removeClass('is-open').find('.placeholder')
      current.text($(this).text());
      current[0].id = $(this)[0].id;
      $('#visible_light_type').val(current[0].id).change();
      window.external.ChangedLightType(current[0].id);
    });

    $('.select .placeholder').text($("#visible_light_type :selected").text());

    window.external.RefreshMap();
    window.external.RefreshLightCount();

    isPCApp = true;
  } catch (e) { }

  /* BOOTSTRAP SLIDER */
  // With JQuery
  lightValSlider = $('#lightValSlider').slider({
    tooltip_position: 'bottom',
    formatter: function (value) {
      return '밝기:' + value + '%';
    }
  });

  // modal keyboard 기본 값을 false로 수정
  $.fn.modal.Constructor.DEFAULTS.keyboard = false

  $('#modal-info').on('hide.bs.modal', function () {
    lightUpdatesIn = 0; // 등 상태 변경되었을 수 있기 때문에 업데이트  
    if (needUpdateStep == 'moved') {
      invalidateLight = true;
      needUpdateStep = '';
    } else if (needUpdateStep != 'move') {
      $('.light_movecontrol *').hide();
    }
  });

  $('#modal-info').on('show.bs.modal', function () {

    $('#modal-info #btn-camera').hide();
    $('#modal-info #inputstyle').removeClass('input-group input-group-sm');
    try {
      // NOTE 구 버전의 앱에는 아래 interface가 없음
      window.Android.check_version();
    } catch (exception) { }

    if (needUpdateStep == 'move') {
      needUpdateStep = 'moved';
    }
  });

  $('#modal-info #btn-camera').click(function () {
    window.Android.qrcodeCamera();
  });

  $('#modal-distributor-info').on('hide.bs.modal', function () {
    lightUpdatesIn = 0; // 등 상태 변경되었을 수 있기 때문에 업데이트  
    invalidateLight = true; // 분전함 창이 내려가면 강제 업데이트
    if (needUpdateStep == 'moved') {
      invalidateLight = true;
      needUpdateStep = '';
    } else if (needUpdateStep != 'move') {
      $('.light_movecontrol *').hide();
    }
  });
  $('#modal-distributor-info').on('show.bs.modal', function () {
    if (needUpdateStep == 'move') {
      needUpdateStep = 'moved';
    }
  });

  for (var i = 0; i <= ID_MOTHER_MAX; i++) {
    $('#mother_id').append('<option>' + i + '</option>');
  }
  for (var i = 0; i <= ID_GROUP_MAX; i++) {
    $('#group_id').append('<option>' + i + '</option>');
  }
  for (var i = 0; i <= ID_INDIVIDUAL_MAX; i++) {
    $('#individual_id').append('<option>' + i + '</option>');
  }

  $('#modal-info #light_type').change(function () {
    var type = Number($(this).children("option:selected").val());
    if ($.inArray(type, [TYPE_BOX_DISTRIBUTION, TYPE_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_BOX_DISTRIBUTION_SUB_MODULE_B]) >= 0) {
      //$('#modal-info #cdma').attr('disabled', false);
      $('#modal-info #light_type').attr('disabled', true);
    } else {
      //$('#modal-info #cdma').attr('disabled', true);
      $('#modal-info #light_type').attr('disabled', false);
    }
  });

  $('#phone').change(function () {
    if ($(this).val().length > 0)
      $('#phone_call').attr('href', 'tel:' + $(this).val());
    else
      $('#phone_call').attr('href', 'javascript:;');
  });
  $('#tel').change(function () {
    if ($(this).val().length > 0)
      $('#tel_call').attr('href', 'tel:' + $(this).val());
    else
      $('#phone_call').attr('href', 'javascript:;');
  });

  $('#btn_move_confirm').click(function () {

    if (m_movedY != -1 && m_movedX != -1) {
      $("#modal-info #moved_location").html(m_movedY + ",<br/>" + m_movedX);
    }

    //신규 시설물 설치
    if ($('#modal-info #title').text() == MODAL_INFO_ADD_TITLE) {
      //창을 닫아주고, 플래그 변환하고, 저장
      modeLightMove(false, $('#EMPTY_OBJECT'))
      $('#modal-info').trigger('hide.bs.modal')
      modalSave()
    }
    //기존 시설물 이동
    else {
      modeLightMove(false, focusedScreen);
      if (focusedScreen != null && focusedScreen.attr('id') == 'modal-distributor-info') {
        API_UPDATE('Facilitypos', {
          xPos: m_movedX,
          yPos: m_movedY,
          SL_SLCODE: focusedScreen.find('#slcode').val()
        }).done(function (res) {
        });
      }
    }
  });

  $('#btn_move_cancel').click(function () {
    modeLightMove(false, focusedScreen);
  });

  $('#btn_change_title').click(function () {
    var newname = '';
    while (newname.search(/^[~!@#$%^&*()_+|<>?:{}가-힣ㄱ-ㅎㅏ-ㅣa-zA-Z0-9]{1,16}$/) == -1) {
      newname = prompt("변경하려는 시설물의 이름으로 입력해주세요. \n(공백,스페이스바는 입력할수 없습니다.)\n(최대 16글자) ");
    }

    if ((newname != '') && (newname != null)) {

      var requestData = {
        "slname": newname
      };

      API_GET('slname/overlap', requestData)
        .done(function (res) {

          //중복되는 값이 있으면
          if (res['data'].length > 0) {
            var text = '중복되는 이름의 시설물이 {0}개 있습니다. 변경하시겠습니까?\n'.format(res['data'].length)
            res['data'].forEach(function (element) {
              text = text + ' * {0} ({1})\n'.format(element.SL_SLNAME, element.SL_ADDR)
            });

            //물어봄
            if (confirm(text)) {
              // Save it!
              $('#modal-info #title').text(newname);
            } else {
              // Do nothing!
            }
          }

          //중복되는 값이 없으면
          else {
            $('#modal-info #title').text(newname);
          }
        });
    }
  });

  $('#modal-info #btn_delete').click(function () {
    deleteLight()
  });

  $('#modal-info #btn_complain').click(function () {
    complainItem()
  });

  $('#modal-info #btn_control').click(function () {
    ResetStatus();
    $("#modal_control_title").text('[테스트] ' + $('#modal-info #title').text());
    $("#modal-control #btnTest").removeClass('btn-danger');
    $("#modal-control #btnTest").addClass('btn-success');
    $("#modal-control #btnTest").text("정상");
    $("#modal-control").modal('show');
  });

  // 테스트 창 닫은 후 info 화면 스크롤 안되는 문제 해결 
  $('#modal-control').on('hidden.bs.modal', function (e) {
    if ($('.modal').is(':visible')) {
      $('body').addClass('modal-open');
    }
    if (clickedSyncSetting) {
      ShowLightInfo($('#modal-info #slcode').val());
      clickedSyncSetting = false;
    }
  })

  // 분전함 상세정보창 닫은 후 info 화면 스크롤 안되는 문제 해결
  $('#modal-info').on('hidden.bs.modal', function (e) {
    if ($('.modal').is(':visible')) {
      $('body').addClass('modal-open');
    }
  })

  // modal 정보 초기화
  //// FIXME day 의 경우 월에 따라서 계산해서 넣어주면 좋다.
  $('.date_month option').remove();
  for (var i = 1; i <= 12; i++) {
    $('.date_month').append('<option value=' + i + '>' + i + '월</option>');
  }
  $('.date_day option').remove();
  for (var i = 1; i <= 31; i++) {
    $('.date_day').append('<option value=' + i + '>' + i + '일</option>');
  }
  $('.date_hour option').remove();
  for (var i = 0; i <= 23; i++) {
    $('.date_hour').append('<option value=' + i + '>' + i + '시</option>');
  }
  $('.date_minute option').remove();
  for (var i = 0; i <= 59; i++) {
    $('.date_minute').append('<option value=' + i + '>' + i + '분</option>');
  }

  $('.time_deviation option').remove();
  for (var i = -90; i <= 90; i++) {
    $('.time_deviation').append('<option value=' + i + '>' + (i >= 0 ? '+' : '') + i + '분</option>');
  }
  $('.time_deviation').val(0);

  $('#night_dim_val option').remove();
  for (var i = 0; i <= 100; i += 10) {
    $('#night_dim_val').append('<option value=' + i + '>' + i + '%</option>');
  }

  // smps 에러 검침선 결선 목록 체크박스 체크시 동작
  $('#enable_smps_sensor').change(function () {
    if (this.checked) {
      if ($("#lamp_type").val() != 4) {
        alert('램프종류: LED 일 경우에만 동작합니다.');
        $('#enable_smps_sensor').prop('checked', false);
      }
    }
  });

  // 램프타입 변경시 smps 옵션 비활성화 옵션
  var previous_lamp_type
  $("#lamp_type").on('click', function () {
    previous_lamp_type = this.value;
  }).change(function () {
    LAMP_TYPE_LED = 4
    smps_option_isChecked = $('#enable_smps_sensor').is(":checked")
    if (previous_lamp_type == LAMP_TYPE_LED && this.value != LAMP_TYPE_LED && smps_option_isChecked) {
      alert('smps 에러 검침선 결선 옵션은 \n LED에서만 동작합니다.');
      $('#enable_smps_sensor').prop('checked', false);
    }
  });
  // $('#night_out_range input').val(moment().format('YYYY-MM-DD HH:mm') + ' ~ ' + moment().format('YYYY-MM-DD HH:mm'));
  // $('#night_out_range').daterangepicker(
  //   {
  //     timePicker: true,
  //     timePicker24Hour: true,
  //     startDate: moment(),
  //     endDate: moment(),
  //   },
  //   function (start, end) {
  //     $('#night_out_range span').html(start.format('YYYY-MM-DD HH:mm') + ' ~ ' + end.format('YYYY-MM-DD HH:mm'));
  //   }
  // );

  idArray = [['#on_deviation', '#today_start_time', '#final-today_start_time'], ['#off_deviation', '#today_end_time', '#final-today_end_time']];
  idArray.forEach(function (element) {
    $(element[0]).change(function () {
      texts = $(element[1]).val().split(':')
      dt = new Date('1992', '09', '28', texts[0], texts[1]);
      dt.setMinutes(dt.getMinutes() + parseInt($(element[0]).val()))
      $(element[2]).val(padDigits(dt.getHours(), 2) + ':' + padDigits(dt.getMinutes(), 2));
    })
  });

  $('.night_out').attr('disabled', true);
  $('#night_dim_val').attr('disabled', true);
  $('#night_out').change(function () {
    var selVal = $(this).children("option:selected").val();
    $('.night_out').attr('disabled', true);
    $('#night_dim_val').attr('disabled', true);
    $("#startMonth").val(9);
    $("#startDay").val(22);
    $("#endMonth").val(12);
    $("#endDay").val(31);
    switch (selVal) {
      case "미설정":
        break;
      // 0922 ~ 1231
      // > 콩: 21:00 ~ 08:00
      // > 깨: 22:00 ~ 09:00
      // > 벼: 23:00 ~ 10:00
      case "콩":
        $("#startHour").val(21);
        $("#endHour").val(8);
        break;
      case "깨":
        $("#startHour").val(22);
        $("#endHour").val(9);
        break;
      case "벼":
        $("#startHour").val(23);
        $("#endHour").val(10);
        break;
      case "개별":
        $('.night_out').attr('disabled', false);
        $('#night_dim_val').attr('disabled', false);
        break;
    }
  });

  // $('#night_out').attr('disabled', true);
  // $('#night_out_range').attr('disabled', true);
  // $('#night_out').change(function () {
  //   if ($(this).children("option:selected").val() == 0) {
  //     $('#night_out_range').attr('disabled', true);
  //   } else {
  //     $('#night_out_range').attr('disabled', false);
  //   }
  // });
  // $('#night_out_range').daterangepicker({
  //   parentEl: "#modal-info",
  //   timePicker: true,
  //   timePicker24Hour: true,
  //   timePickerIncrement: 1,
  //   locale: {
  //     format: 'YYYY-MM-DD HH:mm'
  //   }
  // });

  window.modalSave = function () {
    console.log("Start modalSave")
    var data = {
      'SL_SLNAME': $('#modal-info #title').text(),
      'SL_SLCODE': $('#modal-info #slcode').val(),

      'CDMA': $('#cdma').val(),
      'GD_SERIAL': $('#serial').val(),
      'PARENT_NO': $('#mother').val(),

      'MANAGE_ID': Number($('#mother_id').val()),
      'GROUP_ID': Number($('#group_id').val()),
      'INDIVIDUAL_ID': Number($('#individual_id').val()),

      'SL_DATA_1': $('#light_type').val(),
      'SL_DATA_5': $('#light_shape').val(),
      'SL_SLNO': $('#telegraph_pole_1').val() + $('#telegraph_pole_2').val(),

      'ESCO': $('#esco').val(),
      'WORK_TYPE': $('#operation_method').val(),
      'ENABLE_SMPS_SENSOR': $('#enable_smps_sensor').is(":checked"),

      'SL_DATA_6': $('#lamp_type').val(),
      'SL_DATA_7': $('#use_power').val(),
      'SL_DATA_2': $('#price_type').val(),
      'SL_MAN': $('#admin').val(),
      'SL_TEL': $('#tel').val(),
      'SL_HAND': $('#phone').val(),
      'SL_ETC': $('#memo').val(),

      'ON_DEVIATION': padDigits($('#on_deviation').val(), 2),
      'OFF_DEVIATION': padDigits($('#off_deviation').val(), 2),

      'SPECIAL_TITLE': $('#night_out').val(),

      'OFF_FROM_MONTH': padDigits($('#startMonth').val(), 2),
      'OFF_FROM_DAY': padDigits($('#startDay').val(), 2),
      'OFF_FROM_HOUR': padDigits($('#startHour').val(), 2),
      'OFF_FROM_MIN': padDigits($('#startMinute').val(), 2),

      'OFF_TO_MONTH': padDigits($('#endMonth').val(), 2),
      'OFF_TO_DAY': padDigits($('#endDay').val(), 2),
      'OFF_TO_HOUR': padDigits($('#endHour').val(), 2),
      'OFF_TO_MIN': padDigits($('#endMinute').val(), 2),

      'DIM_VALUE': $('#night_dim_val').val(),
    };

    var loc = $('#modal-info #moved_location').text().split(',');
    if (loc.length == 2) {
      data['latitude'] = loc[0];
      data['longitute'] = loc[1];
    }

    API_METHOD = API_UPDATE;
    if ($('#modal-info #title').text() == MODAL_INFO_ADD_TITLE) {
      API_METHOD = API_POST;
      data['SL_ADDR'] = "{0} {1} {2}".format(
        $('#modal-info #addr1 option:selected').text(),
        $('#modal-info #addr2 option:selected').text(),
        $('#modal-info #addr3 option:selected').text());
      console.log(data);
      if (!('latitude' in data)) {
        alert('시설물의 위치를 지정해야 합니다.')
        return;
      }
    }

    showSpinner();
    settingProcess = true;
    $('#spinnerText').text('기기에 설정 값을 저장 중입니다.. (통신망 요청 중)');

    API_METHOD('facility', data)
      .done(function (res) {
        if (res.data.special_setting == null) {
          hideSpinner();
          $("#modal-info").modal('hide');
          invalidateLight = true;
          settingProcess = false;
        } else {
          $('#spinnerText').text('기기에 설정 값을 저장 중입니다.. (통신망 전달 완료)');
          needUpdateStep = '';
          control_resource_id = res.data.special_setting[0].mgc.exin[0].ri;
          control_expire_time = Date.now() + CONTROL_EXPIRE_DURATION;
        }
      }).fail(function (jqXHR, textStatus, errorThrown) {
        settingProcess = false;
        hideSpinner();
        alert('기기에 설정 값 저장을 실패했습니다..' + (DEBUG_MODE ? '\n' + jqXHR.responseText : ''));
      });
    console.log("End modalSave")
  }
  $('#modal-info #btn_save').click(function () {
    // 시설물 신규 저장시 시설물 설치 창으로
    if ($('#modal-info #title').text() == MODAL_INFO_ADD_TITLE) {
      $("#modal-info #btn_move").trigger("click");
    }
    // 기존 시설물 저장시
    else {
      modalSave();
    }
  });

  $("#search").click(function () {
    updateAddr('#modal-search');
  });
  $('#add').click(function () {
    API_GET('facility/info').done(function (res) {
      modal_info_for_add = true;
      $('#modal-info #title').text(MODAL_INFO_ADD_TITLE);
      $('#btn_change_title').hide()

      $('#modal-info #picture-div').hide()

      //신규 설치시 시리얼, 심야소등탭 비활성화
      $('#modal-info #section-settings').hide()
      $('#modal-info #section-serial').hide()

      //설치 칭 에서는 분전함 조회 가능 light_type 분전함
      $('#modal-info').find('#light_type').find("[value=" + TYPE_BOX_DISTRIBUTION + "]").show()

      var pm = $('#modal-info')
      pm.find('#addr1').attr('disabled', false);
      pm.find('#addr2').attr('disabled', false);
      pm.find('#addr3').attr('disabled', false);

      $('#mother option').remove();
      res['data']['parentno'].forEach(function (val) {
        $('#mother').append('<option>' + val + '</option>')
      });
      $('#mother').val('없음');

      $('#cdma').val('');
      $('#serial').val('');
      $('#managed_cnt').val('');
      $('#mother_id').val(0);
      $('#group_id').val(0);
      $('#individual_id').val(0);

      $('#light_type').val(light_add_type).trigger('change');
      $('#light_shape').val(0);
      $('#telegraph_pole_1').val('');
      $('#telegraph_pole_2').val('');
      $('#esco').val(0);
      $('#operation_method').val(0);
      $('#lamp_type').val(0);
      $('#use_power').val(0);
      $('#price_type').val(0);
      $('#admin').val('');
      $('#tel').val('').trigger('change');
      $('#phone').val('').trigger('change');
      $('#memo').val('');

      $('#night_out').val("미설정");

      $('#modal-info #btn_save').show();

      $('#modal-info #btn_delete').hide();
      $('#modal-info #btn_move').hide();
      $('#modal-info #btn_complain').hide();

      $("#modal-info #moved_location").text('');

      $('#modal-info #btn_move').text('설치');
      $('#btn_move_cancel').text('설치 취소');
      $('#btn_move_confirm').text('설치 완료');

      $('#enable_smps_sensor').prop('checked', false);

      $('#modal-info #btn_move').unbind('click');
      $('#modal-info #btn_move').click(function () {
        //설치 상황에서는 상황에 관계없이 modal-info
        focusedScreen = $('#modal-info');

        modeLightMove(true);
        RemoveAllOverlays();
        //기존의 lamp_type 은 나트륨, LED 등을 구분하는것  light_type 이 맞음
        var img = GetLightImagePath(0, $('#light_type').val());
        var size = GetLightImageSize($('#light_type').val());
        AddDragMarker("objIDName", 0, map.getCenter().getLng(), map.getCenter().getLat(), size.width, size.height, img, '');
      });

      $('#modal-info #btn_move').attr('disabled', false);
      $('#modal-info #btn_delete').attr('disabled', false);
    });
  })

  API_GET('datacode', undefined, 1)
    .done(function (res) {
      datacode = res['data'];
      datacode = {}
      res['data'].forEach(function (value) {
        if (!(value.SL_GRP in datacode)) {
          datacode[value.SL_GRP] = [value]
        } else {
          datacode[value.SL_GRP].push(value);
        }
      });

      // 시설물 종류
      datacode['D1'].forEach(function (val) {
        if ($.inArray(val.SL_VALUE, TYPES_IDS) >= 0) {
          if ($.inArray(val.SL_VALUE, [TYPE_BOX_DISTRIBUTION_SUB_MODULE_A, TYPE_BOX_DISTRIBUTION_SUB_MODULE_B]) >= 0)
            $('#light_type').append('<option value=' + val.SL_VALUE + ' style="display: none;">' + val.SL_DESC + '</option>');
          else
            $('#light_type').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
        }
      });
      // 등기구 형태
      datacode['D5'].forEach(function (val) {
        $('#light_shape').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
      });
      // 운영방식
      datacode['D8'].sort(function (a, b) {
        return a.SL_VALUE > b.SL_VALUE;
      });
      datacode['D8'].forEach(function (val) {
        $('#operation_method').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
      });
      // 램프종류
      datacode['D6'].forEach(function (val) {
        $('#lamp_type').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
      });
      // 소비전력
      datacode['D7'].forEach(function (val) {
        $('#use_power').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
      });
      // 요금형태
      datacode['D2'].forEach(function (val) {
        $('#price_type').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
      });
    });

  //     disabled 된 영역에 대해서 마우스 이벤틀르 가져올수 없다.
  //     $('#inputAddrStr').attr('disabled', true);
});

window.showDiv = function (vid) {
  var id = vid;
  var myLayer;
  if (document.getElementById) {
    myLayer = document.getElementById(id);
    myLayer.style.display = 'block';
    myLayer.style.left = document.body.clientWidth / 2 - 22;
    myLayer.style.top = document.body.clientHeight / 2 - 22;
  }
}

window.hideDiv = function (vid) {
  var id = vid;
  if (document.getElementById) {
    document.getElementById(id).style.display = 'none';
  }
}

window.changed_zoom = function () {
  //var level = map.getLevel();
  //if (level > 1)
  {
    external.ChangedZoom();
  }
}

// Converts numeric degrees to radians
window.toRad = function (Value) {
  return Value * Math.PI / 180;
}

window.calcCrow = function (lat1, lon1, lat2, lon2) {
  var R = 6371; // km
  var dLat = toRad(lat2 - lat1);
  var dLon = toRad(lon2 - lon1);
  var lat1 = toRad(lat1);
  var lat2 = toRad(lat2);

  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  var d = R * c;
  return d;
}

/*
 * ParkDyel
 * 2018.06.07
 * Ver 1.0.0
 * 로드뷰 기능
 */

// 로드뷰 활성화 상태를 나타내는 state 변수입니다.
window.isRvOn = false;

window.container = document.getElementsByClassName('content-wrapper')[0] // 지도와 로드뷰를 감싸고 있는 div 입니다
window.mapWrapper = document.getElementsByClassName('map_wrap')[0] // 지도를 감싸고 있는 div 입니다
window.mapContainer = document.getElementById('map_canvas') // 지도를 표시할 div 입니다 
window.rvContainer = document.getElementById('roadview') //로드뷰를 표시할 div 입니다

// 새로운 맵 워커입니다!
// NOTE 김현기 민원 시설물 바로 이동 기능: 좌표 초기화시 문제 발생 하여 documnet Ready 에서 이동하였음
window.mapPosCache = getCache(CACHE_DIRECT_MAP, null);
if (mapPosCache != null) {
  INITIAL_LNG = mapPosCache.SL_MAP_X;
  INITIAL_LAT = mapPosCache.SL_MAP_Y;
}

// 익명 로그인 기능 사용시 튕기고 다시 올수도 있기 때문에 캐시 삭제 안함
if (getCache(CACHE_PREVIOUS_PAGE) == undefined)
  delCache(CACHE_DIRECT_MAP);

window.mapWalker = null;
window.overlayOn = false;
window.position = new kakao.maps.LatLng(store.getters.config_lat, store.getters.config_lng) // (INITIAL_LAT, INITIAL_LNG)
window.mapCenter = position
window.mapOption = {
  center: position,
  level: 1,
  mapTypeId: kakao.maps.MapTypeId.ROADMAP,
  draggable: true
}
window.map = new kakao.maps.Map(document.getElementById('map_canvas'), mapOption);
// window.map.setCopyrightPosition(kakao.maps.CopyrightPosition.BOTTOMRIGHT, true);
window.init = function () {
  // window.map = new kakao.maps.Map(document.getElementById('map_canvas'), mapOption);
  invalidateLight = true
  WatchPosition()
  addDaumZoomListener()
  addDaumClickListener()
}
// 지도를 표시할 div와 지도 옵션으로 지도를 생성합니다
window.rv = undefined;
window.rvClient = undefined;

window.isFirstTryToUsingRv = true;
window.isToggleRvJustNow = false;

window.evtRvPositionChanged = function () {
  console.log('Map Event : ' + isToggleRvJustNow);
  if (isToggleRvJustNow == false) {
    // 일반적인 이동
    // 현재 로드뷰의 위치 좌표를 얻어옵니다 
    var rvPosition = rv.getPosition();
    let panel_level = getPanelLevel()
    var point_with_panel = window.setCoordsFromPoint(
      rvPosition.getLng(), rvPosition.getLat(), panel_level, true, true
    );
    console.log(point_with_panel)
    // 지도의 중심을 현재 로드뷰의 위치로 설정합니다
    map.setCenter(point_with_panel);
    // var mapWalkerPoint = window.setCoordsFromPoint(rvPosition.ib, rvPosition.jb,"roadview");

    // var isValidatePoint = true;
    // $.each(mapWalkerPoint, function(index, value) {
    //   if(isNaN(value)) {
    //     isValidatePoint = false;
    //   }
    // });
    // if(isValidatePoint == false) {
    //   return;
    // }
    // map.setCenter(mapWalkerPoint);
    // 지도위에 로드뷰를 오버레이하면 필요 없음
    // $("#center_mark").css("top", "25%")
    // 지도 위에 로드뷰 도로 오버레이가 추가된 상태이면
    if (overlayOn) {
      // 마커의 위치를 현재 로드뷰의 위치로 설정합니다
      mapWalker.setPosition(rvPosition);
    }
  } else {
    var rvPosition = map.getCenter();
    toggleRoadview(rvPosition);
    // isToggleRvJustNow = false;
  }
  // setMarkerDisplayAsZoomLevel(m_zoomlevel);
}

window.evtMapClicked = function (mouseEvent) {
  // 지도 위에 로드뷰 도로 오버레이가 추가된 상태가 아니면 클릭이벤트를 무시합니다 
  if (!overlayOn) {
    return;
  }
  // 클릭한 위치의 좌표입니다 
  var position = mouseEvent.latLng;
  // 마커를 클릭한 위치로 옮깁니다
  mapWalker.setPosition(position);
  // 클락한 위치를 기준으로 로드뷰를 설정합니다
  toggleRoadview(position);
  isToggleRvJustNow = true;
}

window.evtRvViewPoinChanged = function () {
  // 로드뷰가 초기화 된 후, 추가 이벤트를 등록한다.
  // 로드뷰를 상,하,좌,우,줌인,줌아웃을 할 경우 발생한다.
  // 로드뷰를 조작할때 발생하는 값을 받아 map walker의 상태를 변경해 준다.

  // 이벤트가 발생할 때마다 로드뷰의 viewpoint값을 읽어, map walker에 반영
  var viewpoint = rv.getViewpoint();
  mapWalker.setAngle(viewpoint.pan);

}

window.evtRvSizeChagned = function () {
  // var width_map = $('#map_wrap').css('width').replace(/[^-\d\.]/g, '');
  // var width_leftbar = 50;
  // if( $('.user_logo').length ){
  //   var width = width_map;
  // } else {
  //   var width = width_map > 767 ? width_map - width_leftbar : width_map;
  // }  
  // $('#roadview').css('width', "400px");
}

window.initEventOfRv = function (rv, mapCenter) {
  // 로드뷰에 올릴 마커를 생성합니다.
  var rMarker = new kakao.maps.Marker({
    position: mapCenter,
    map: rv //map 대신 rv(로드뷰 객체)로 설정하면 로드뷰에 올라갑니다.
  });

  // 로드뷰에 올릴 장소명 인포윈도우를 생성합니다.
  var rLabel = new kakao.maps.InfoWindow({
    position: mapCenter,
    content: '스페이스 닷원'
  });
  rLabel.open(rv, rMarker);

  // 로드뷰 마커가 중앙에 오도록 로드뷰의 viewpoint 조정 합니다.
  var projection = rv.getProjection(); // viewpoint(화면좌표)값을 추출할 수 있는 projection 객체를 가져옵니다.

  // 마커의 position과 altitude값을 통해 viewpoint값(화면좌표)를 추출합니다.
  var viewpoint = projection.viewpointFromCoords(rMarker.getPosition(), rMarker.getAltitude());
  rv.setViewpoint(viewpoint); //로드뷰에 뷰포인트를 설정합니다.

  //각 뷰포인트 값을 초기화를 위해 저장해 놓습니다.
  rvResetValue.pan = viewpoint.pan;
  rvResetValue.tilt = viewpoint.tilt;
  rvResetValue.zoom = viewpoint.zoom;
}

window.addEventOfRv = function () {
  kakao.maps.event.addListener(rv, 'position_changed', evtRvPositionChanged);
  kakao.maps.event.addListener(map, 'click', evtMapClicked);
  kakao.maps.event.addListener(rv, 'viewpoint_changed', evtRvViewPoinChanged);
  $(window).on('resize', evtRvSizeChagned);
}

// maps에 등록된 이벤트를 제거하는 랩 함수입니다.
window.removeEventOfRv = function () {
  kakao.maps.event.removeListener(rv, 'position_changed', evtRvPositionChanged);
  kakao.maps.event.removeListener(map, 'click', evtMapClicked);
  kakao.maps.event.removeListener(rv, 'viewpoint_changed', evtRvViewPoinChanged);
}


// 로드뷰 기능을 처음 활성화 할 때 사용하는 랩함수입니다.
// flash 기능이 활성화 되어 있지 않다면 anchorFlahs 를 디스플레이합니다.
window.initRv = function () {
  try {
    console.log('hello initRv');
    rv = new kakao.maps.Roadview(rvContainer);
    rvClient = new kakao.maps.RoadviewClient();
    mapWalker = new MapWalker(mapCenter);
    isFirstTryToUsingRv = false;
    // addEventOfRv()
    // initEventOfRv(rv, mapCenter);

    window.CrossHeadPosition = checkCrossHead()
    saveCrossHead()
  } catch (error) {
    console.error(error)
    $('.content-wrapper').hide();
    $('#anchorFlash').css("display", "block")
  }
}

window.checkCrossHead = function () {
  let panel_level = window.getPanelLevel();
  var point_origin = window.coordsFromPoint();
  var point_with_panel = window.setCoordsFromPoint(
    point_origin.getLng(), point_origin.getLat(), panel_level, true
  );
  if (store.getters.panel_class != "hidden") {
    return point_with_panel
  } else {
    return point_origin
  }
}

// 사용자가 flash를 활성화 하지않고 로드뷰 기능을 끈 경우 호출하는 랩함수입니다.
window.unInitRv = function () {
  $('.content-wrapper').show();
  $('#anchorFlash').hide();
}

// 전달받은 좌표(position)에 가까운 로드뷰의 파노라마 ID를 추출하여
// 로드뷰를 설정하는 함수입니다
window.toggleRoadview = function (position) {
  rvClient.getNearestPanoId(position, 50, function (panoId) {
    // 파노라마 ID가 null 이면 로드뷰를 숨깁니다
    // if (panoId === null) {
    // 위치에 없다고 닫히는게 신경쓰여서 없앴습니다.
    // toggleMapWrapper(true, position);
    // } else {
    toggleMapWrapper(false, position);
    // panoId로 로드뷰를 설정합니다
    try {
      //console.log('rv.setPanoId(' + panoId + ',' + position + ')');
      rv.setPanoId(panoId, position);
      isToggleRvJustNow = false;
    } catch (error) {
      console.log(error)
    }
    // }
  });
}

// 지도를 감싸고 있는 div의 크기를 조정하는 함수입니다
window.toggleMapWrapper = function (active, position) {
  if (active) {
    // 로드뷰 비활성화

    // 지도를 감싸고 있는 div의 높이가 100%가 되도록 class를 변경합니다
    $("#map_wrap").removeClass('view_roadview'); //mapWrapper.classList.remove("view_roadview");

    // 지도의 크기가 변경되었기 때문에 relayout 함수를 호출합니다
    map.relayout();

    // 지도의 너비가 변경될 때 지도중심을 입력받은 위치(position)로 설정합니다
    // 하지만 로드뷰를 활성화 한 후 map을 이용해서 이동한 후에 로드뷰 위치를 조정하면 초기화됩니다.
    // map.setCenter(position);
    // rv div를 감춥니다.
    rvContainer.style.display = 'none'
  } else {
    // 로드뷰 활성화

    // 지도만 보여지고 있는 상태이면 지도의 너비가 50%가 되도록 class를 변경하여
    // 로드뷰가 함께 표시되게 합니다
    // if (mapWrapper.className.indexOf('view_roadview') === -1) {
    // 지도를 감싸고 있는 div의 높이가 50%가 되도록 class를 변경합니다.
    $("#map_wrap").addClass('view_roadview'); //mapWrapper.classList.add('view_roadview');
    // 지도의 크기가 변경되었기 때문에 relayout 함수를 호출합니다
    map.relayout();
    // 지도의 너비가 변경될 때 지도중심을 입력받은 위치(position)로 설정합니다
    let panel_level = getPanelLevel()
    var point_with_panel = window.setCoordsFromPoint(
      position.getLng(), position.getLat(), panel_level, true
    );
    // NOTE :: 뒷부분에 rv위치를 재정의하고 setCenter하는 부분이 있는데 여기서 2중으로하면 화면을 왔다갔다 거리는 문제가 발생하여 제거
    // map.setCenter(point_with_panel);
    // rv div를 디스플레이합니다.
    rvContainer.style.display = 'block';

    // 넓이가 767보다 넓은 경우 발생하는 에러를 픽스하기 위해 추가되었습니다.
    evtRvSizeChagned();
    // 2020-11-17 RoadView 위치가 좌측 상단에 떠서 우측 하단으로 변경
    $("#roadview").css("position", "absolute");
    // 로드뷰를 호출할 때 발생하는 에러(맵의 위치와 상관없이 로드뷰 초기 위치로 이동)를 방지하기 위해 state를 만들었습니다.
    isToggleRvJustNow = true;
    // }
  }
}

// 지도 위의 로드뷰 도로 오버레이를 추가,제거하는 함수입니다
window.toggleOverlay = function (active) {
  if (active) {
    overlayOn = true;
    // 지도 위에 로드뷰 도로 오버레이를 추가합니다
    map.addOverlayMapTypeId(kakao.maps.MapTypeId.ROADVIEW);
    // 지도 위에 마커를 표시합니다
    mapWalker.setMap(map);
    // 마커의 위치를 지도 중심으로 설정합니다 
    mapWalker.setPosition(map.getCenter());
    // map.getCenter()
    // 로드뷰의 위치를 지도 중심으로 설정합니다
    toggleRoadview(map.getCenter());
    // 로드뷰가 활성화 되었음을 나타내는 state
    isRvOn = true;
    if (isRulerOn == false) {
      addEventOfRv();
    }
  } else {
    overlayOn = false;
    // 지도 위의 로드뷰 도로 오버레이를 제거합니다
    map.removeOverlayMapTypeId(kakao.maps.MapTypeId.ROADVIEW);
    // 지도 위의 마커를 제거합니다
    mapWalker.setMap(null);
    // 다른 함수들에게 Rv모드가 종료되었음을 알립니다.
    // 현재 거리재기 기능에서 필요합니다.
    isRvOn = false;
    removeEventOfRv();
  }
  // 중요한 친구입니다. 일을 잘합니다.
  // 없으면 로드뷰가 비활성화 된 후 맵의 크기가 조정되지 않습니다.
  map.relayout();
}

// 지도 위의 로드뷰 버튼을 눌렀을 때 호출되는 함수입니다
window.setRoadviewRoad = function () {
  var control = document.getElementById('roadviewControl');

  // 버튼이 눌린 상태가 아니면
  if (control.className.indexOf('active') === -1) {
    control.classList.add('active');
    toggleOverlay(true);
  } else {
    control.classList.remove('active')
    closeRoadview()
    // 로드뷰 도로 오버레이를 제거합니다
    toggleOverlay(false);
  }
}

window.setRvModeAtSide = function (e) {
  // 버튼이 눌린 상태가 아니면
  if (e.className.indexOf('control-status-on') == -1) {
    console.log("aaa")
    // 처음 로드뷰 실행시
    if (isFirstTryToUsingRv == true) {
      initRv();
    }
    try {
      // 로드뷰 도로 오버레이가 보이게 합니다
      toggleOverlay(true);
      // style 적용
    } catch (error) {
    }
    e.classList.remove('unseleted_btn');
    e.classList.add('selected_btn');
    $('#btn_sideBar').children().addClass('enable');

    // setMarkerDisplayAsZoomLevel(m_zoomlevel);
  } else {
    $("#center_mark").css("top", "50%")
    console.log("bbb")
    // 처음 로드뷰 실행했으나 권한 요청 안함.
    if (isFirstTryToUsingRv == true) {
      unInitRv()
    }
    if (isRulerOn == false) {
      $('#btn_sideBar').children().removeClass('enable')
    }
    try {
      closeRoadview();
      toggleOverlay(false);
    } catch (error) {
    }

    e.classList.remove('selected_btn');
    e.classList.add('unseleted_btn');
    // 2020-11-17 로드뷰 위치에 따른 시설물 추가 위치 변경
    $("#map_add_btn").css("right", "10px");
  }
  clickOnBtnSideBar();
}

// 로드뷰에서 X버튼을 눌렀을 때 로드뷰를 지도 뒤로 숨기는 함수입니다
window.closeRoadview = function () {
  var position = mapWalker.walker.getPosition();
  toggleMapWrapper(true, position);
}


window.MapWalker = function (position) {

  //커스텀 오버레이에 사용할 map walker 엘리먼트
  var content = document.createElement('div');
  var figure = document.createElement('div');
  var angleBack = document.createElement('div');

  //map walker를 구성하는 각 노드들의 class명을 지정 - style셋팅을 위해 필요
  content.className = 'MapWalker';
  figure.className = 'figure';
  angleBack.className = 'angleBack';

  content.appendChild(angleBack);
  content.appendChild(figure);

  //커스텀 오버레이 객체를 사용하여, map walker 아이콘을 생성
  var walker = new kakao.maps.CustomOverlay({
    position: position,
    content: content,
    yAnchor: 1
  });

  this.walker = walker;
  this.content = content;
}

//로드뷰의 pan(좌우 각도)값에 따라 map walker의 백그라운드 이미지를 변경 시키는 함수
//background로 사용할 sprite 이미지에 따라 계산 식은 달라 질 수 있음
MapWalker.prototype.setAngle = function (angle) {

  var threshold = 22.5; //이미지가 변화되어야 되는(각도가 변해야되는) 임계 값
  for (var i = 0; i < 16; i++) { //각도에 따라 변화되는 앵글 이미지의 수가 16개
    if (angle > (threshold * i) && angle < (threshold * (i + 1))) {
      //각도(pan)에 따라 아이콘의 class명을 변경
      var className = 'm' + i;
      this.content.className = this.content.className.split(' ')[0];
      this.content.className += (' ' + className);
      break;
    }
  }
};

//map walker의 위치를 변경시키는 함수
MapWalker.prototype.setPosition = function (position) {
  this.walker.setPosition(position);
};

//map walker를 지도위에 올리는 함수
MapWalker.prototype.setMap = function (map) {
  this.walker.setMap(map);
};

MapWalker.prototype.getPosition = function () {
  this.walker.getPosition();
};

window.clickOnBtnSideBar = function () {
  $('#a_control-sidebar').click();
  // ParkDyel
  // 2.2.5
  // 어떤 코드인가가 이 친구를 건드린다.
  // $('#right-sidebar').css("height", "140px");
  // $('#right-sidebar').css("min-height", "0");
}

/////////////////////////////////////////
/////////////////////////////////////////


/*
 * about map, basic.
 */

//Line
//Line
//Line
m_zoomlevel = map.getLevel();

// ParkDyel
// 2016.06.21
// 동작을 하지 않는 코드라 판단하여 죽였습니다.
// kakao.maps.event.addListener(map, 'zoom_changed', function () {

//   // 지도의 현재 레벨을 얻어옵니다
//   var level = map.getLevel();

//   //alert(m_zoomlevel);
//   //alert(level);

//   //if ((level == 2 && m_zoomlevel == 1) || (level == 1 && m_zoomlevel == 2))
//   if ((level == 4 && m_zoomlevel == 3) || (level == 3 && m_zoomlevel == 4)) {
//     //alert(m_zoomlevel);
//     //alert(level);

//     m_zoomlevel = level;
//     changed_zoom();
//     console.log('Work!')
//   }
// });

window.tooltipManager = function (zoom_level) {
  zoom_level = map.getLevel()
  if (zoom_level != 1 && window.tooltipDataObj.isOn == true) {
    window.customOverlay.setMap(null)
    window.tooltipDataObj.isZoomStatus = true
  } else if (zoom_level == 1 && window.tooltipDataObj.isOn == true) {
    let data = window.tooltipDataObj.data
    let panel_level = window.tooltipDataObj.panel_level
    window.makeToolTip(data, panel_level)
  }
  window.zooLevelOverLabel()
}

window.zooLevelOverLabel = function () {
  m_zoomlevel = map.getLevel()
  console.log(">>>> zoom", m_zoomlevel)
  if (m_zoomlevel >= 4) {
    $('.label1 marker_label').css('background', 'red')
    console.log($('.label1 marker_label'))
  }
}
// kakao.maps.event.addListener(map, 'center_changed', function() {
// setMarkerDisplayAsZoomLevel(m_zoomlevel);
// });


m_geocoder = new kakao.maps.services.Geocoder();

//map.addControl(new kakao.maps.MapTypeControl());
//map.addControl(new kakao.maps.ZoomControl());
window.intervalPosition = setInterval("WatchPosition();", 500);
window.clearPosition = function () {
  clearInterval(intervalPosition)
}
kakao.maps.event.addListener(map, 'dragstart', function () {
  mapMovedDelay = (new Date()).getTime() + (MAP_MOVE_GPS_DELAY * 10);
});
kakao.maps.event.addListener(map, 'dragend', function () {
  mapMovedDelay = (new Date()).getTime() + MAP_MOVE_GPS_DELAY;
});

kakao.maps.event.addListener(map, 'click', function (mouseEvent) {
  // for sidebar close
  /* NOTE : 맵 클릭시 이벤트 제어 부분 여기 인것 같은데 작동을 안함 */
  $('.content-wrapper').click();
  /* // 현재 사용 안함
      // 클릭한 위도, 경도 정보를 가져옵니다
      var latlng = mouseEvent.latLng;
      //var message = '위도는 ' + latlng.getLat() + ' 이고, ';
      //message += '경도는 ' + latlng.getLng() + ' 입니다';
    
      m_clickID = "NO";
      document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
    
      searchAddrFromCoords(mouseEvent.latLng, function (status, result) {
        if (status === kakao.maps.services.Status.OK) {
          //alert("kakao.maps.services.Status.OK");
    
          m_clickAddress = result[0].fullName;
    
          document.getElementById("mapMessage").innerHTML = "clickAddress;" + m_clickAddress;
    
          //marker.setPosition(mouseEvent.latLng);
          //marker.setMap(map);
          //infowindow.setContent(content);
          //infowindow.open(map, marker);
        }
        //else { alert("kakao.maps.services.Status.NOTOK"); }
      });
    */
});

window.setMapType = function (maptype) {
  var rodeMapControl = document.getElementById('btnRoadmap');
  var skyviewControl = document.getElementById('btnSkyview');
  if (rodeMapControl == null || rodeMapControl == undefined) {
    rodeMapControl = document.getElementById('btn_roadmap');
    skyviewControl = document.getElementById('btn_skyview');
  }
  if (maptype === 'roadmap') {
    map.setMapTypeId(kakao.maps.MapTypeId.ROADMAP);
    rodeMapControl.className = 'selected_btn';
    skyviewControl.className = 'unseleted_btn';
  } else {
    map.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
    skyviewControl.className = 'selected_btn';
    rodeMapControl.className = 'unseleted_btn';
  }
}

window.getAddress = function (x, y) {
  var coord = new kakao.maps.LatLng(y, x);
  searchAddrFromCoords(coord, function (status, result) {
    if (status === kakao.maps.services.Status.OK) {
      //alert("kakao.maps.services.Status.OK");

      m_clickAddress = result[0].fullName;

      document.getElementById("mapMessage").innerHTML = "clickAddress;" + m_clickAddress;

      //alert(m_clickAddress);

      //marker.setPosition(mouseEvent.latLng);
      //marker.setMap(map);
      //infowindow.setContent(content);
      //infowindow.open(map, marker);
    }
    //else { alert("kakao.maps.services.Status.NOTOK"); }
  });
}

window.setPositionByAddress = function (szAddress) {
  //alert(szAddress);

  var geocoder = new kakao.maps.services.Geocoder();

  //alert(szAddress);

  // 주소로 좌표를 검색합니다
  geocoder.addressSearch(szAddress, function (result, status) {
    // 정상적으로 검색이 완료됐으면 
    if (status === kakao.maps.services.Status.OK) {
      //var coords = new kakao.maps.LatLng(result.addr[0].lat, result.addr[0].lng);
      //m_center = center;

      //var center_str = "centerpos;" + result.addr[0].lng + ";" + result.addr[0].lat;
      //return center_str;

      SetPosition(result[0].x, result[0].y);
      window.external.RefreshMap();
    } else {
      alert("등록되지 않은 주소 입니다.\r\n다시 입력해주세요.");
    }
  });
}


/*
window.DrawCenterLine = function() {
    var center = map.getCenter();

    // 선을 구성하는 좌표 배열입니다. 이 좌표들을 이어서 선을 표시합니다
    var linePath = [
    new kakao.maps.LatLng(33.452344169439975, 126.56878163224233),
    new kakao.maps.LatLng(33.452739313807456, 126.5709308145358),
];

    // 지도에 표시할 선을 생성합니다
    var polyline = new kakao.maps.Polyline({
        path: linePath, // 선을 구성하는 좌표배열 입니다
        strokeWeight: 5, // 선의 두께 입니다
        strokeColor: '#FF0000', // 선의 색깔입니다
        strokeOpacity: 0.7, // 선의 불투명도 입니다 1에서 0 사이의 값이며 0에 가까울수록 투명합니다
        strokeStyle: 'dot' // 선의 스타일입니다
    });

    // 지도에 선을 표시합니다 
    polyline.setMap(map);  
}
*/

window.rdPoly = function () {
  if (po1 != null) {
    po1.setMap();
    po1 = null;
  }

  if (po2 != null) {
    po2.setMap();
    po2 = null;
  }

  sw = map.getBounds().getSouthWest();
  ne = map.getBounds().getNorthEast();
  c1 = map.getCenter().getLat();
  c2 = map.getCenter().getLng();
  p1 = (sw.getLat() + c1) / 2;
  p2 = (sw.getLng() + c2) / 2;
  p3 = (ne.getLat() + c1) / 2;
  p4 = (ne.getLng() + c2) / 2;
  path1 = [new kakao.maps.LatLng(p1, c2), new kakao.maps.LatLng(p3, c2)];
  path2 = [new kakao.maps.LatLng(c1, p2), new kakao.maps.LatLng(c1, p4)];

  po1 = new kakao.maps.Polyline({
    path: path1,
    strokeWeight: 2,
    strokeColor: '#FF0000',
    strokeOpacity: 0.8,
    strokeStyle: 'dashed'
  });
  po1.setMap(map);

  po2 = new kakao.maps.Polyline({
    path: path2,
    strokeWeight: 2,
    strokeColor: '#FF0000',
    strokeOpacity: 0.8,
    strokeStyle: 'dashed'
  });
  po2.setMap(map);
}


// 캐싱해야 함
// 줌 바뀔 때 업데이트 해야함
// 필터링 필요함
// 마커등록시 clickable false로 하면 마커땜에 드래그 안되는 일 없음.
// 민원 보는거 하자.
window.cacheLights = {}



window.control_resource_id = null;
window.control_expire_time = null;
window.CONTROL_EXPIRE_DURATION = 60000; // 60s, 기본 송수신시간
window.CONTROL_RESET_EXPIRE_DURATION = 60000; // 60s, 리셋도 동일 (기본,리셋 다른 시간 사용할때 사용)
window.control_type = null;

window.LightTest = function (type, data) {
  if (data == undefined) {
    data = {
      'GD_SERIAL': $('#modal-info #serial').val(),
      //'slcode': $('#modal-info #slcode').val(),
      'light_val': lightValSlider.slider('getValue')
    }
  }
  showSpinner();
  control_type = type;
  $('#spinnerText').text('제어 요청 중입니다.. (통신망 요청 중)');
  API_POST('test' + type, data).done(function (res) {
    $('#spinnerText').text('제어 요청 중입니다.. (통신망 전달 완료)');
    try {
      // for command
      control_resource_id = res.data[0].mgc.exin[0].ri;
    } catch (err) {
      // for reset
      control_resource_id = res.data.mgc.exin[0].ri;
    }
    if (control_type == 'reset') {
      // NOTE reset은 처리시간이 오ㄹ
      control_expire_time = Date.now() + CONTROL_RESET_EXPIRE_DURATION;
    } else {
      control_expire_time = Date.now() + CONTROL_EXPIRE_DURATION;
    }
  }).fail(function (jqXHR, textStatus, errorThrown) {
    alert('제어에 실패했습니다..\n' + (DEBUG_MODE ? '\n' + jqXHR.responseText : ''));
    hideSpinner();
  });
}

window.LightSyncStatus = function () {
  LightTest('syncstatus');
}
window.clickedSyncSetting = false;

window.LightSyncSetting = function () {
  clickedSyncSetting = true;
  LightTest('syncsetting');
}

window.LightTestOff = function () {
  LightTest('off');
}

window.LightTestDim = function () {
  if (lightValSlider.slider('getValue') == 100) {
    LightTest('on');
  } else {
    LightTest('dim');
  }
}

window.LightTestReset = function () {
  LightTest('reset');
}

window.ResetStatus = function (data) {
  statusUpdatedAt = 0;
  lightValSlider.slider('setValue', 100)

  statusDialog = $('#modal-control');

  statusDialog.find('span').text("");
  statusDialog.find('span').each(function () {
    $(this).removeClass(function (index, className) {
      return (className.match(/(^|\s)bg-\S+/g) || []).join(' ');
    });
  });
}
window.watt = function (data) {
  data['Watt'] = ((data['AC_output_A'] * 5.0 / 1024.0 * 0.5128) * 220).toFixed(2) + ' W';
  ['SUM_MONTH_STORE_VAL', 'SUM_MONTH_STORE_EST', 'SUM_YEAR_STORE_VAL', 'SUM_YEAR_STORE_EST'].forEach(function (element) {
    data[element] = (data[element] / 1000).toFixed(1) + ' KW';
  })
  return data
}
window.UpdateStatus = function (data) {
  statusDialog = $('#modal-control');

  statusDialog.find('span').each(function () {
    $(this).removeClass(function (index, className) {
      return (className.match(/(^|\s)bg-\S+/g) || []).join(' ');
    });
  })

  if (data.light_value != 0) {
    lightValSlider.slider('setValue', data.light_value)
  }

  statusUpdatedAt = data['updated_at']; //new Date('2017-08-16T18:05:16').getTime();
  statusDialog.find('#updateTime').text(data['updated_at']);

  var lightTxt = '';
  if (data['light_value'] == 0) {
    lightTxt = '소등';
    // 소등 상태에서는 ac값이 나올수 없음
    data['AC_output_A'] = 0;
  } else {
    lightTxt = data['light_value'] + ' %';
  }
  if (data['light_test']) {
    lightTxt += ' (TEST)';
  }
  statusDialog.find('#light_val').text(lightTxt);
  if (data['light_value']) {
    statusDialog.find('#light_val').addClass('bg-yellow');
  }

  data['Watt'] = ((data['AC_output_A'] * 5.0 / 1024.0 * 0.5128) * 220).toFixed(2) + ' W';
  ['SUM_MONTH_STORE_VAL', 'SUM_MONTH_STORE_EST', 'SUM_YEAR_STORE_VAL', 'SUM_YEAR_STORE_EST'].forEach(function (element) {
    data[element] = (data[element] / 1000).toFixed(1) + ' KW';
  })

  data['AC_output_A'] = (data['AC_output_A'] * 5.0 / 1024.0 * 0.5128).toFixed(2) + ' A';

  data['SMPS_output_V'] += ' (raw value)';
  data['sensor_value_1'] += ''; {
    // 온도라고 가정
    var sensorV = data['sensor_value_2'] * 5.0 / 1024.0;
    var sensorR = 10000 * sensorV / (5 - sensorV);
    var kT = 1.0 / ((1.0 / (273.15 + 25.0)) + (1.0 / 4200.0) * Math.log(sensorR / 10000.0));
    var cT = kT - 273.15;
    //data['sensor_value_2'] = (cT < -20 ? 0 : cT).toFixed(2) + ' ℃'
  }
  ['SMPS_output_V', 'AC_output_A', 'sensor_value_1', 'sensor_value_2', 'Watt', 'SUM_MONTH_STORE_VAL', 'SUM_YEAR_STORE_VAL'].forEach(function (element) {
    statusDialog.find('#' + element).text(data[element]);
    statusDialog.find('#' + element).addClass('bg-blue');
  });

  ['SUM_MONTH_STORE_EST', 'SUM_YEAR_STORE_EST'].forEach(function (element) {
    statusDialog.find('#' + element).text(data[element]);
    statusDialog.find('#' + element).addClass('badge est');
  });

  $('.SMPS_used').show()
  if ($('#lamp_type').val() != 4) {
    // LED (DC)
    $('.SMPS_used').hide()
  }

  if ($('#operation_method').val() == 0) {
    // LoRa 점멸기
    $('#test_GFCI').show()
    $('#test_BLACKOUT td').first().text('정전여부')
  } else if ($('#light_type').val() == TYPE_LIGHT_MONITOR) {
    $('#test_BLACKOUT td').first().text('AC차단')
    //} else if ($('#operation_method').val() == -1) {
    //  // 스마트LED
    //  $('#test_GFCI').hide()
    //  $('#test_BLACKOUT td').first().text('AC차단(정전,누전차단)')
  }

  ['BLACKOUT_error', 'SMPS_error', 'LAMP_error', 'GFCI_error', 'AC_RELAY_error', 'ELB_A_error', 'ELB_B_error', 'MG_error'].forEach(function (element) {
    //console.log(data[element]);
    if (data[element] != null) {
      statusDialog.find('#' + element).text('오류');
      statusDialog.find('#' + element).addClass('bg-red');
    } else {
      statusDialog.find('#' + element).text('정상');
      statusDialog.find('#' + element).addClass('bg-green');
    }
  });

}

window.GetInfo = function () {

  if (isInfoUpdatesIn > Date.now()) {
    return;
  }

  if ($('#modal-info.fade.in').length != 0)
    return;

  isInfoUpdatesIn = Date.now() + STATUS_UPDATE_DURATION;

  if ($('#modal-distributor-info.fade.in').length != 0) {
    ShowDistributorInfo(slcode, true);
  }

}

window.GetStatus = function () {
  var today = new Date();
  var statusDialog = {
    length: 0
  };
  if ($('#modal-control.fade.in').length != 0)
    statusDialog = $('#modal-control.fade.in');

  if (statusDialog.length == 0 && settingProcess != true) {
    return;
  }

  if (isStatusUpdating) {
    return;
  }

  if (statusUpdatesIn > Date.now()) {
    return;
  }

  isStatusUpdating = true;

  var requestUrl = 'facility/status';

  var requestData = {
    "slcode": $('#modal-info #slcode').val(),
    "updated_at": statusUpdatedAt,
    "today": today.toDateString()
  };

  if (control_resource_id != null) {
    requestUrl = 'teststatus';
    requestData = {
      'resource_id': control_resource_id
    };
  }

  // DEBUG_MODE 에서도 캐싱하면 안됨
  API_GET(requestUrl, requestData, 0, false)
    .done(function (res) {
      statusUpdatesIn = Date.now() + STATUS_UPDATE_DURATION;
      isStatusUpdating = false;

      if (control_resource_id != null) {
        if (res.data.success == false) {
          control_resource_id = null;
          hideSpinner();
          alert('LoRa의 신호 세기가 미약합니다..');
        } else if (control_expire_time < Date.now()) {
          control_resource_id = null;
          settingProcess = false;
          hideSpinner();
          alert('LoRa의 신호 세기가 미약합니다.');
        } else if (res.data.received_at != null) {
          control_resource_id = null;
          statusUpdatesIn = Date.now();
          hideSpinner();
          if (res.data.received_at)
            if (settingProcess) {
              alert('기기에 설정 값이 정상적으로 반영됐습니다.');
              $("#modal-info").modal('hide');
              settingProcess = false;
              invalidateLight = true;
            } else {
              if (control_type == 'syncsetting') {
                ShowLightInfo($('#modal-info #slcode').val());
              }
              alert('제어가 성공적으로 완료됐습니다.');
            }
        } else if (res.data.delivered_at != null) {
          if (settingProcess) {
            $('#spinnerText').text('기기에 설정 값을 저장 중입니다.. (단말기 전달 완료)');
          } else {
            $('#spinnerText').text('제어 요청 중입니다.. (단말기 전달 완료)');
          }
        }
      } else {
        if (!$.isEmptyObject(res['data'])) {
          UpdateStatus(res['data']);
        }
      }
    });
}

window.WatchPosition = function () {
  var center = map.getCenter();
  // document.getElementById("mapMessage").innerHTML = "centerpos;" + center.getLng() + ";" + center.getLat();

  if (needUpdateStep != '') {
    return;
  }

  GetInfo();
  GetStatus();

  if (isGpsTracking) {
    getGps();
  }

  needUpdate = 1
  var distance = calcCrow(centerPos['Lat'], centerPos['Lng'], center.getLat(), center.getLng());
  var needUpdate = lightUpdatesIn < Date.now() && ($('#modal-info.fade.in').length == 0 && $('#modal-distributor-info.fade.in').length == 0);
  if (!waitForUpdate && (invalidateLight || needUpdate || distance >= UPDATE_DISTANCE)) {

    if (invalidateLight || (!waitForUpdate && distance >= UPDATE_DISTANCE)) {
      lightUpdtedAt = 0;
    }

    lightUpdatesIn = Date.now() + STATUS_UPDATE_DURATION;

    // 등 종류 잘못되서 무한loop 도는 것 방지
    let light_type = Number($('#visible_light_type_temp').attr('value'))
    if ($.inArray(light_type, [TYPE_LIGHT_ALL, TYPE_LIGHT_STREET, TYPE_LIGHT_SECURITY]) == -1) {
      return;
    }

    if (invalidateLight) {
      needUpdate = false;
    }

    invalidateLight = false;
    waitForUpdate = true;
    // 최초 요청을 제외하고는 백그라운드 체크임
    let panel_level = getPanelLevel()
    var point_origin = window.coordsFromPoint();

    var point_with_panel = window.setCoordsFromPoint(
      point_origin.getLat(), point_origin.getLng(), panel_level, true
    );

    window.getOptionIgnoreErr = lightUpdtedAt != 0 ? true : false;

    if (point_origin.getLat() == undefined || point_origin.getLng() == undefined) {

    } else {
      API_GET('facility', {
        "latitude": point_origin.getLat(),
        "longitute": point_origin.getLng(),
        "light_type": light_type,
        "lasttime": lightUpdtedAt,
      }, DEBUG_MODE ? 1 : undefined, false, getOptionIgnoreErr)
        .done(function (res) {
          if (!needUpdate) {
            RemoveAllOverlays();
          }

          if (res.data.light.length > 0) {
            lightUpdtedAt = res.data.time;
          } else if (lightUpdtedAt == 0) {
            lightUpdtedAt = 1;
          }

          if (isGpsTracking && validGpsPos != null) {
            if (mapMovedDelay <= (new Date()).getTime()) {
              if (validGpsPos.longitude != null && validGpsPos.latitude != null) {
                SetMyLocation('MyMarker', 1, validGpsPos.longitude, validGpsPos.latitude, 20, 20, require("@/assets/img/res/img/me.png"));
              }
            }
          }


          var markerSize;
          var markerurl;

          res['data']['light'].forEach(function (light) {
            markerSize = GetLightImageSize(light.SL_DATA_1);
            markerurl = GetLightImagePath2(light, res['data']['light_time']);
            window.errorName = GetLightErrorName(light, res['data']['light_time']);
            window.markerName = light.SL_SLNAME + ' ' + errorName;
            if (errorName) {
              markerName = '<b>' + markerName + '</b>';
            }
            if (needUpdate) {
              RemoveOverlay(light.SL_SLCODE);
            }
            AddMarker(light.SL_SLCODE, 0, light.SL_MAP_X, light.SL_MAP_Y, markerSize.width, markerSize.height, markerurl, markerName, light, light.SL_SLCODE);
          });

          if (!needUpdate) {
            let panel_level = getPanelLevel()
            var point_origin = window.coordsFromPoint();

            var point_with_panel = window.setCoordsFromPoint(
              point_origin.getLng(), point_origin.getLat(), panel_level, true
            );
            if (store.getters.panel_class != "hidden") {
              centerPos['Lat'] = point_with_panel.getLat();
              centerPos['Lng'] = point_with_panel.getLng();
              DrawCircle(point_with_panel.getLng(), point_with_panel.getLat(), FACILITY_DISTANCE * 1000);
            } else {
              centerPos['Lat'] = point_origin.getLat();
              centerPos['Lng'] = point_origin.getLng();
              DrawCircle(point_origin.getLng(), point_origin.getLat(), FACILITY_DISTANCE * 1000);
            }
            // DrawCircle(center.getLng(), center.getLat(), FACILITY_DISTANCE * 1000);
          }
        })
        /*
        .fail(function() {
            console.log( "error" );
        })*/
        .always(function () {
          waitForUpdate = false;
        });
    }
  }
}

window.GetCenterPosition = function () {
  var center = map.getCenter();
  m_center = center;

  //alert(center);
  /*    
      if (window.event.srcElement.tagName != "INPUT") {
          window.event.returnValue = false;
          window.event.cancelBubble = true;
      }
  */
  var center_str = "centerpos;" + center.getLng() + ";" + center.getLat();
  return center_str;
}

window.SetPosition = function (x, y) {
  //RemoveAllOverlays();
  map.panTo(new kakao.maps.LatLng(y, x));
}

window.SetPositionEx = function (x, y, title) {
  SetPosition(x, y);

  var marker = new kakao.maps.Marker({
    position: position
  });

  marker.setMap(map);

  if (title != "") {
    var infowindow = new kakao.maps.InfoWindow({
      content: title
    });
    infowindow.open(map, marker);
    overlayObjects.push({
      "Object": infowindow,
      "IDName": "IF"
    });
  }

  overlayObjects.push({
    "Object": marker,
    "IDName": "MK"
  });
}

window.SetPositionLevel = function (x, y, lvl) {
  map.setLevel(lvl);
  console.log("window >>>", x, y)
  console.log(new kakao.maps.LatLng(y, x))
  map.setCenter(new kakao.maps.LatLng(y, x));
}

window.SetMarkEx = function (bPosition, x, y, title) {
  if (bPosition == 0) {
    SetPositionEx(x, y, title)
  } else {
    var pt = new kakao.maps.LatLng(y, x);
    var marker = new kakao.maps.Marker({
      position: pt
    });
    marker.setMap(map);
    if (title != "") {
      var infowindow = new kakao.maps.InfoWindow({
        content: title
      });
      infowindow.open(map, marker);
      overlayObjects.push({
        "Object": infowindow,
        "IDName": "IF"
      });
    }
    overlayObjects.push({
      "Object": marker,
      "IDName": "MK"
    });
  }
}

window.InitJijukPolygon = function (cnt) {
  JJPolygon = new Array(cnt);
}

window.AddJijukPoint = function (idx, x, y) {
  JJPolygon[idx] = new kakao.maps.LatLng(y, x);
}

window.AddJijukPolygon = function (lineColor, lineWidth, faceColor, faceOpacity) {
  var dPolygon = new kakao.maps.Polygon({
    strokeWeight: lineWidth,
    strokeColor: lineColor,
    strokeOpacity: faceOpacity,
    fillColor: faceColor,
    fillOpacity: faceOpacity
  });
  dPolygon.setPath(JJPolygon);
  dPolygon.setMap(map);
  overlayObjects.push({
    "Object": dPolygon,
    "IDName": "JJ"
  });
}

window.AddJijukPolyline = function (lineColor, lineWidth) {
  //	var dPolyline = new kakao.maps.Polyline({strokeWeight:lineWidth,strokeOpacity:1, strokeColor:lineColor, fillOpacity:0}); 
  //	dPolyline.setPath(JJPolygon);
  //	dPolyline.setMap(map);
  //	overlayObjects.push ({ "Object" : dPolyline, "IDName" : "JJ" });

  var dPolygon = new kakao.maps.Polygon({
    strokeWeight: lineWidth,
    strokeColor: lineColor,
    strokeOpacity: 1,
    fillColor: lineColor,
    fillOpacity: 0
  });
  dPolygon.setPath(JJPolygon);
  dPolygon.setMap(map);
  overlayObjects.push({
    "Object": dPolygon,
    "IDName": "JJ"
  });
}

window.AddText = function (strMsg, x, y) {
  var marker = new SimpleTextMarker(new kakao.maps.LatLng(y, x), strMsg);
  marker.setMap(map);
  SetPosition(x, y);
  overlayObjects.push({
    "Object": marker,
    "IDName": "TT"
  });
}

window.SimpleTextMarker = function (position, text) {
  this.position = position;
  this.node = document.createElement('div');
  this.node.appendChild(document.createTextNode(text));
}
/*
SimpleTextMarker.prototype = new kakao.maps.AbstractOverlay;
SimpleTextMarker.prototype.onAdd = function() 
{ 
window.panel = this.getPanels().overlayLayer; 
panel.appendChild(this.node); 
};
*/

SimpleTextMarker.prototype.onRemove = function () {
  this.node.parentNode.removeChild(this.node);
};

SimpleTextMarker.prototype.draw = function () {
  var projection = this.getProjection();
  var point = projection.pointFromCoords(this.position);
  var width = this.node.offsetWidth;
  var height = this.node.offsetHeight;
  this.node.style.cssText = 'color: white; font-size:12px; position: absolute; white-space: nowrap; left: ' + (point.x - width / 2) + 'px; top: ' + (point.y - height / 2) + 'px';
};

window.AddCircle = function (x1, y1, x2, y2, r, lineWidth, lineColor, lineOpacity) {
  var dCircle = new kakao.maps.Circle({
    center: new kakao.maps.LatLng(y1 + ((y2 - y1) / 2), x1 + ((x2 - x1) / 2)),
    radius: r,
    strokeWeight: lineWidth,
    strokeColor: lineColor,
    strokeOpacity: lineOpacity
  });
  dCircle.setMap(map);
  overlayObjects.push({
    "Object": dCircle,
    "IDName": "CL"
  });
}

window.DrawCircle = function (x, y, r) {
  /*
  center LatLng : 중심 좌표
  fillColor String : #xxxxxx 형태의 채움 색 (기본값: ‘#F10000’)
  fillOpacity Number : 채움 불투명도 (0-1) (기본값: 0)
  radius Number : 미터 단위의 반지름
  strokeWeight Number : 픽셀 단위의 선 두께 (기본값: 3)
  strokeColor String : #xxxxxx 형태의 선 색 (기본값: ‘#F10000’)
  strokeOpacity Number : 선 불투명도 (0-1) (기본값: 0.6)
  strokeStyle String : 선 스타일 (기본값: ‘solid’)
  zIndex Number : z-index 값
  */

  var dCircle = new kakao.maps.Circle({
    center: new kakao.maps.LatLng(y, x),
    radius: r,
    strokeWeight: 1,
    strokeColor: '#0000FF',
    fillColor: '#E3E3FF',
    fillOpacity: 0.1,
    strokeOpacity: 1
  });
  dCircle.setMap(map);
  overlayObjects.push({
    "Object": dCircle,
    "IDName": "CL"
  });

  if (window.installMoveStatus == 'move') {
    var img = GetLightImagePath("move", $('#light_type').val());
    var size = GetLightImageSize($('#light_type').val());

    $('#map_add.light_movecontrol *').css('visibility', 'initial')

    AddDragMarker("objIDName", 0, window.installObj.MAP_X, window.installObj.MAP_Y, size.width, size.height, img, 'facilityMove');
    // window.overlayObjects[window.overlayObjects.length-1]['data'] = window.tooltipDataObj.data
    console.log("window.installMoveSLCODE", window.installMoveSLCODE)
    changeBgWhenMoving(window.installMoveSLCODE, true)
  } else if (window.installMoveStatus == 'install') {
    var img = GetLightImagePath("move", $('#light_type').val());
    var size = GetLightImageSize($('#light_type').val());
    AddDragMarker("objIDName", 0, window.installObj.MAP_X, window.installObj.MAP_Y, size.width, size.height, img, 'facilityInstall');
  }
}

window.AddPolyline = function (objIDName, lineColor, lineWidth, lineOpacity) {
  var pObject = new kakao.maps.Polyline({
    sstrokeWeight: lineWidth,
    strokeOpacity: lineOpacity,
    strokeColor: lineColor,
    fillOpacity: 0
  });
  pObject.setPath(JJPolygon);
  pObject.setMap(map);
  overlayObjects.push({
    "Object": pObject,
    "IDName": objIDName
  });
}

window.showTitle = function (show) {
  var i;
  for (i = 0; i < overlayObjects.length; i++) {
    if (overlayObjects[i].IDName == "title") {
      overlayObjects[i].Object.setVisible(show);
    }
  }
}

window.GenTooltipContent = function (arrData) {
  var labels = "관리번호<br/>시설물종류<br/>전주번호<br/>분전함번호<br/>무선 S/N<br/>그룹/개별 ID"; //<br/>개별점소등";
  var midLabels = "  :  <br/>  :  <br/>  :  <br/>  :  <br/>  :  <br/>  :  "; //<br/>  :  ";
  var values = "";
  if (arrData) {
    for (var i = 0; i < arrData.length; i++) {
      if (arrData[i] == null)
        arrData[i] = ""
      values += arrData[i];
      if (i != 2 && i != 6)
        values += "<br/>";
      else // 전주번호, 그룹/개별ID
        values += " / ";
    }
  }
  return '<div class="light_tooltip"><div>' + labels + '</div><div>' + midLabels + '</div><div>' + values + '</div></div>';
}

window.AddTooltipOverlay = function (objIDName, x, y, content) {
  if (tooltipObjects != null) {
    if (tooltipObjects.IDName == objIDName) {
      clearTimeout(tooltipObjects.timer);
      return;
    }

    RemoveTooltipOverlay(true);
  }

  position = new kakao.maps.LatLng(y, x);
  tooltipOverlay = new kakao.maps.CustomOverlay({
    position: position,
    content: content,
    xAnchor: -0.1,
    yAnchor: 0.05,
  });

  tooltipOverlay.setMap(map);
  tooltipObjects = {
    "Object": tooltipOverlay,
    "IDName": objIDName,
    timer: null
  };
}

window.SuspendTooltipOverlay = function () {
  if (tooltipObjects != null) {
    clearTimeout(tooltipObjects.timer);
  }
}

window.RemoveTooltipOverlay = function (promptly) {
  if (tooltipObjects != null) {
    window.RemoveTooltipOverlayPromptly = function () {
      clearTimeout(tooltipObjects.timer);
      tooltipObjects.Object.setMap(null);
      tooltipObjects.Object = null;
      tooltipObjects.time = null;
      tooltipObjects = null;
    }
    if (promptly) {
      RemoveTooltipOverlayPromptly();
    } else {
      tooltipObjects.timer = setTimeout(RemoveTooltipOverlayPromptly, 300);
    }
  }
}

window.RemoveOverlay = function (objIDName) {
  var i;
  for (i = 0; i < overlayObjects.length; i++) {
    if (overlayObjects[i].IDName == objIDName) {
      overlayObjects[i].Object.setMap(null);
      overlayObjects[i].Object = null;
      overlayObjects[i].IDName = null;
    }
  }
}

window.RemoveAllOverlays = function () {
  RemoveTooltipOverlay();

  var i;
  for (i = 0; i < overlayObjects.length; i++) {
    if (overlayObjects[i].Object != null) {
      overlayObjects[i].Object.setMap(null);
      overlayObjects[i].Object = null;
      overlayObjects[i].IDName = null;
    }
  }
  overlayObjects.length = 0;
}

window.GetMovedMarkerCoord = function ( /*objIDName*/) {
  /*
      var i;
      var c_x = -1;
      var c_y = -1;
  
      for (i = 0; i < overlayObjects.length; i++) 
      {
      if (overlayObjects[i].IDName == objIDName) 
      {
      x = overlayObjects[i].x;
      y = overlayObjects[i].y;
      }
      }
      */
  var coord_str = "markerpos;" + m_movedX + ";" + m_movedY;
  return coord_str;
}

window.SetMyLocation = function (objIDName, show, x, y, width, height, markerurl) {
  if (map == null)
    return;

  RemoveOverlay(objIDName);

  if (show == 0) {
    return;
  }

  SetPosition(x, y);

  var pt = new kakao.maps.LatLng(y, x);

  var icon = new kakao.maps.MarkerImage(
    markerurl,
    new kakao.maps.Size(width, height),
    new kakao.maps.Point(width / 2, height / 2)
  );

  var marker = new kakao.maps.Marker({
    position: pt,
    image: icon,
    clickable: false // 마커를 클릭했을 때 지도의 클릭 이벤트가 발생하지 않도록 설정합니다
  });

  marker.setMap(map);

  overlayObjects.push({
    "Object": marker,
    "IDName": objIDName,
    "x": x,
    "y": y
  });
}

window.setGPS = function () {
  m_GPS++;
  //alert(m_GPS);
  var path = window.location;
  alert(path);
  //var img1 = document.GetElementById("btnGPS");
  //alert(m_GPS);

  if (m_GPS % 2 === 1) {
    btnGPS.src = "None";
    external.ON_GPS();
  } else {
    btnGPS.src = "None";
    external.OFF_GPS();
  }
}

window.OnClickOverlay = function (objIDName) {
  m_clickID = objIDName;
  //alert("OnClickOverlay : " + m_clickID);
  document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
}

window.OnDblclickOverlay = function (objIDName) {
  m_clickID = objIDName;
  //alert("OnDblclickOverlay : " + m_clickID);
  document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
}

window.OnMouseOverOverlay = function (objIDName) {
  m_clickID = objIDName;
  //alert("OnDblclickOverlay : " + m_clickID);
  document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
}

window.OnMouseOutOverlay = function () {
  m_clickID = "NO";
  //alert("OnDblclickOverlay : " + m_clickID);
  document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
}

window.ShowLightInfo = function (slcode, imgUrl) {
  API_GET('facility/info', {
    slcode: slcode
  })
    .done(function (res) {
      let data = ''
      light_info = res.data;
      data = res.data.light;

      $('#modal-info #title').text(data.SL_SLNAME)
      $('#modal-info #slcode').val(data.SL_SLCODE);
      if (data.SL_SLCODE.indexOf('|') != -1) {
        $('#modal-info #picture-div').hide()
      } else {
        $('#modal-info #picture-div').show()
      }
      if (focusedScreen == null) {
        pictureThumbSet(data.SL_SLCODE, data.PIC_01, data.PIC_02, data.PIC_03);
      }

      //설치시 시설물 종류:분전함 선택 불가능
      $('#modal-info').find('#light_type').find("[value=" + TYPE_BOX_DISTRIBUTION + "]").hide()

      var pm = $('#modal-info')
      var addr = data.SL_ADDR.split(' ');
      pm.find('#addr1').attr('disabled', true)
        .find('option:contains("' + addr[0] + '")')
        .prop('selected', true).trigger('change');
      pm.find('#addr2').attr('disabled', true)
        .find('option:contains("' + addr[1] + '")')
        .prop('selected', true).trigger('change');
      pm.find('#addr3').attr('disabled', true)
        .find('option:contains("' + addr[2] + '")')
        .prop('selected', true).trigger('change');

      $('#cdma').val(data.CDMA);
      $('#serial').val(data.GD_SERIAL);

      data.GD_SERIAL != null ? $('#modal-info #btn_control').show() : $('#modal-info #btn_control').hide();

      $('#mother option').remove();
      res['data']['parentno'].forEach(function (val) {
        $('#mother').append('<option>' + val + '</option>')
      });
      $('#mother').val(data.PARENT_NO);

      $('#managed_cnt').val('');
      $('#mother_id').val(data.MANAGE_ID);
      $('#group_id').val(data.GROUP_ID);
      $('#individual_id').val(data.INDIVIDUAL_ID);

      $('#light_type').val(data.SL_DATA_1).trigger('change');
      $('#light_shape').val(data.SL_DATA_5);

      $('#telegraph_pole_1').val('');
      $('#telegraph_pole_2').val('');
      if (data.SL_SLNO) {
        $('#telegraph_pole_1').val(data.SL_SLNO.substr(0, 5));
        $('#telegraph_pole_2').val(data.SL_SLNO.substr(5));
      }
      $('#esco').val(data.ESCO);
      $('#operation_method').val(data.WORK_TYPE);
      $('#lamp_type').val(data.SL_DATA_6);
      $('#use_power').val(data.SL_DATA_7);
      $('#price_type').val(data.SL_DATA_2);
      $('#admin').val(data.SL_MAN);
      $('#tel').val(data.SL_TEL).trigger('change');
      $('#phone').val(data.SL_HAND).trigger('change');
      $('#memo').val(data.SL_ETC);

      $('#today_start_time').val(padDigits(res.data.light_time.ON_Hour, 2) + ':' + padDigits(res.data.light_time.ON_Min, 2));
      $('#today_end_time').val(padDigits(res.data.light_time.OFF_Hour, 2) + ':' + padDigits(res.data.light_time.OFF_Min, 2));

      $('#enable_smps_sensor').prop('checked', !!data.ENABLE_SMPS_SENSOR);

      if (res.data.special_setting != null) {
        var setting = res.data.special_setting;
        $('#on_deviation').val(parseInt(setting.ON_DEVIATION));
        $('#off_deviation').val(parseInt(setting.OFF_DEVIATION));

        $('#night_out').val(setting.SPECIAL_TITLE);
        if (setting.SPECIAL_TITLE == '개별') {
          $('#night_dim_val').attr('disabled', false);
          $('.night_out').attr('disabled', false);
        } else {
          $('#night_dim_val').attr('disabled', true);
          $('.night_out').attr('disabled', true);
        }

        $('#startMonth').val(parseInt(setting.OFF_FROM_MONTH));
        $('#startDay').val(parseInt(setting.OFF_FROM_DAY));
        $('#startHour').val(parseInt(setting.OFF_FROM_HOUR));
        $('#startMinute').val(parseInt(setting.OFF_FROM_MIN));

        $('#endMonth').val(parseInt(setting.OFF_TO_MONTH));
        $('#endDay').val(parseInt(setting.OFF_TO_DAY));
        $('#endHour').val(parseInt(setting.OFF_TO_HOUR));
        $('#endMinute').val(parseInt(setting.OFF_TO_MIN));
      } else {
        // FIXME 설정관련된 초기값을 임시로 웹에서 처리
        if (store.getters.config_on_deviation != null) {
          $('#on_deviation').val(parseInt(store.getters.config_on_deviation));
        } else {
          $('#on_deviation').val(parseInt(-30));
        }

        if (store.getters.config_off_deviation != null) {
          $('#off_deviation').val(parseInt(store.getters.config_off_deviation));
        } else {
          $('#off_deviation').val(parseInt(+15));
        }

        $('#night_out').val('미설정');

        $('#startMonth').val(parseInt(1));
        $('#startDay').val(parseInt(1));
        $('#startHour').val(parseInt(0));
        $('#startMinute').val(parseInt(0));

        $('#endMonth').val(parseInt(12));
        $('#endDay').val(parseInt(31));
        $('#endHour').val(parseInt(23));
        $('#endMinute').val(parseInt(59));
      }

      $("#modal-info #moved_location").text('');

      $('#modal-info #btn_move').unbind('click');
      $('#modal-info #btn_move').click(function () {
        modeLightMove(true);
        RemoveAllOverlays();
        if (imgUrl == undefined)
          imgUrl = GetLightImagePath(0, data.SL_DATA_1)
        markerSize = GetLightImageSize(data.SL_DATA_1);
        AddDragMarker(data.SL_SLCODE, 0, data.SL_MAP_X, data.SL_MAP_Y, markerSize.width, markerSize.height, imgUrl, '');
      });

      // $('#modal-info #btn_save').prop('disabled', false);
      $('#modal-info #btn_save').show();
      $('#modal-info #btn_delete').show();
      $('#modal-info #btn_complain').show();

      // 기존 시설물 변경시 시리얼, 심야소등창 활성화
      $('#modal-info #section-settings').show();
      $('#modal-info #section-serial').show();

      $('#modal-info #btn_move').show();
      $('#modal-info #btn_move').text('이동');
      $('#btn_move_cancel').text('이동 취소');
      $('#btn_move_confirm').text('이동 완료');

      //최종 점,소등 시각 업데이트
      $('#on_deviation').trigger('change')
      $('#off_deviation').trigger('change')

      //$("#modal-info").modal('toggle');
      // 여러개 modal 뜬 상태에서 esc 키 안먹도록 (modal-control 뜬 상황) 
      $("#modal-info").modal({
        keyboard: false
      });
    });
}

window.ShowDistributorInfo = function (data, recycle, imgUrl) {
  if (recycle == true)
    data = distributorModalData;
  else
    distributorModalData = data;

  $('#modal-distributor-info #title').text(data.SL_SLNAME)
  $('#modal-distributor-info #slcode').val(data.SL_SLCODE)

  $('#modal-distributor-info #picture-div').show()

  var $info1 = $('#distributor-info-A')
  var $info2 = $('#distributor-info-B')

  var suffixList = [[$info1, '|01', 0], [$info2, '|02', 1]];

  var now_mode = [2, 2]

  requestData = {
    'slcode': data.SL_SLCODE,
    'slcodeA': data.SL_SLCODE + suffixList[0][1],
    'slcodeB': data.SL_SLCODE + suffixList[1][1],
  }
  API_GET('Distributor/Info', requestData)
    .done(function (resArray) {
      if (image_upload_check != true) {
        pictureThumbSet(data.SL_SLCODE, resArray.data[2].light.PIC_01, resArray.data[2].light.PIC_02, resArray.data[2].light.PIC_03);
      }
      suffixList.forEach(function (element) {
        var $info = element[0];
        var suffix = element[1];

        $info.find('#distributor-info-detail').unbind("click");
        $info.find('#distributor-info-detail').click(function () {
          ShowLightInfo(data.SL_SLCODE + suffix);
        });

        var res = {
          data: null
        };
        res.data = resArray.data[element[2]]

        $info.find('#distributor-info-name').text(res.data.light.SL_SLNAME)

        $info.find('#distributor-info-today_start_time').val(res.data.light_time.ON_Hour + ':' + res.data.light_time.ON_Min)
        $info.find('#distributor-info-today_end_time').val(res.data.light_time.OFF_Hour + ':' + res.data.light_time.OFF_Min)


        light = Object.assign({}, res.data.light, res.data.light_status);
        $info.find('#marker_image').attr('src', GetLightImagePath2(light, res.data.light_time));
        $info.find('#marker_error_text').text(GetLightErrorName(light, res.data.light_time));

        lightval = res.data.light_status != null ? res.data.light_status['light_value'] : '미설정';
        $info.find('#distributor-info-light-val').text(lightval);


        if (res.data.special_setting != null) {
          var setting = res.data.special_setting;
          $info.find('#distributor-info-on_deviation').val(parseInt(setting.ON_DEVIATION));
          $info.find('#distributor-info-off_deviation').val(parseInt(setting.OFF_DEVIATION));

          $info.find('#distributor-info-night_out').text('미설정');

          var NIGHT_OFF_FROM = setting.OFF_FROM_MONTH + '/' + setting.OFF_FROM_DAY + ' - ' + setting.OFF_FROM_HOUR + ':' + setting.OFF_FROM_MIN
          var NIGHT_OFF_TO = setting.OFF_TO_MONTH + '/' + setting.OFF_TO_DAY + ' - ' + setting.OFF_TO_HOUR + ':' + setting.OFF_TO_MIN

          $info.find('#distributor-info-dim-from').text('미설정');
          $info.find('#distributor-info-dim-to').text('미설정');
        }
        else {
          $info.find('#distributor-info-on_deviation').val('미설정');
          $info.find('#distributor-info-off_deviation').val('미설정');

          $info.find('#distributor-info-night_out').text('미설정');

          $info.find('#distributor-info-dim-from').text('미설정');
          $info.find('#distributor-info-dim-to').text('미설정');
        }

        var setting = res.data.special_setting;
        if (setting != null) {

          if (setting.MODE[0] == '2') {
            $info.find('#distributor-info-mode').text('미사용')
            $info.find('#distributor-info-mode').removeClass('distribution_mode_on')
            $info.find('#distributor-info-mode').addClass('distribution_mode_off')
          }
          else if (setting.MODE[0] == '3' || setting.MODE[0] == '0') {
            $info.find('#distributor-info-mode').text('사용')
            $info.find('#distributor-info-mode').removeClass('distribution_mode_off')
            $info.find('#distributor-info-mode').addClass('distribution_mode_on')
            now_mode[element[2]] = parseInt(setting.MODE[0])
          }

        }

        var pm = $('#modal-info')
        var addr = res.data.light.SL_ADDR.split(' ');
        pm.find('#addr1').find('option:contains("' + addr[0] + '")').prop('selected', true).trigger('change');
        pm.find('#addr2').find('option:contains("' + addr[1] + '")').prop('selected', true).trigger('change');
        pm.find('#addr3').find('option:contains("' + addr[2] + '")').prop('selected', true).trigger('change');

        window.modeChange = function (funcName) {
          API_METHOD = API_POST;
          showSpinner();
          settingProcess = true;
          $('#spinnerText').text('기기에 설정 값을 저장 중입니다.. (통신망 요청 중)');
          API_METHOD(funcName, { 'SL_SLCODE': res.data.light.SL_SLCODE, 'GD_SERIAL': res.data.light.GD_SERIAL })
            .done(function (res) {
              $('#spinnerText').text('기기에 설정 값을 저장 중입니다.. (통신망 전달 완료)');
              needUpdateStep = '';
              control_resource_id = res.data.special_setting[0].mgc.exin[0].ri;
              control_expire_time = Date.now() + CONTROL_EXPIRE_DURATION;
            }).fail(function (jqXHR, textStatus, errorThrown) {
              settingProcess = false;
              hideSpinner();
              alert('기기에 설정 값 저장을 실패했습니다..' + (DEBUG_MODE ? '\n' + jqXHR.responseText : ''));
            });
        }

        $info.find('#distributor-info-modeOff-btn').unbind("click");
        $info.find('#distributor-info-modeOff-btn').click(function () {
          modeChange('Distributon_Box_Mode_Off')
        });

        $info.find('#distributor-info-modeOn-btn').unbind("click");
        $info.find('#distributor-info-modeOn-btn').click(function () {
          modeChange('Distributon_Box_Mode_On')
        });
      });
    });



  //이동버튼 클릭했을떄 
  $('#modal-distributor-info #btn_move').unbind('click');
  $('#modal-distributor-info #btn_move').click(function () {
    modeLightMove(true, $('#modal-distributor-info'));
    RemoveAllOverlays();
    if (imgUrl == undefined)
      imgUrl = GetLightImagePath(0, data.SL_DATA_1)
    markerSize = GetLightImageSize(data.SL_DATA_1);
    AddDragMarker(data.SL_SLCODE, 0, data.SL_MAP_X, data.SL_MAP_Y, markerSize.width, markerSize.height, imgUrl, '');
  });

  //삭제버튼
  $('#modal-distributor-info #btn_delete').unbind('click');
  $('#modal-distributor-info #btn_delete').click(function () {
    deleteLight()
  });

  //신고버튼?
  $('#modal-distributor-info #btn_complain').unbind('click');
  $('#modal-distributor-info #btn_complain').click(function () {
    complainItem()
  });



  $('#modal-distributor-info').modal({ keyboard: false });
}



window.AddMarker = function (objIDName, evtmode, x, y, width, height, markerurl, text, data, slcode) {
  var pt = new kakao.maps.LatLng(y, x);

  var icon = new kakao.maps.MarkerImage(
    markerurl,
    new kakao.maps.Size(width, height),
    new kakao.maps.Point(width / 2, height / 2)
  );

  //var marker = new kakao.maps.Marker({position:pt, image: icon});
  var marker = new kakao.maps.Marker({
    position: pt,
    image: icon,
    clickable: true // true : 마커를 클릭했을 때 지도의 클릭 이벤트가 발생하지 않도록 설정합니다
  });

  if (evtmode == 0) {
    marker.setTitle(slcode);
  }
  var level = map.getLevel();

  //alert(level);

  //if (evtmode != 0)
  // if (level < 4) {
  var content;

  //content = '<div background-color: #FFFFF0; ondragstart="return false"; onselectstart="return false"; onmouseover="OnMouseOverOverlay(' + objIDName + ')"; onmouseout="OnMouseOutOverlay()">'
  //+ '<font size="2">' + text + '</font></div>';

  content = '<div class ="label1 marker_label">' +
    '<span class="left"></span><span class="center" date-img-value="' + slcode + '">' + text + '</span><span class="right"></span></div>';
  // origin
  // content = '<div class ="label1" ondragstart="return false" onselectstart="return false" onmouseover="OnMouseOverOverlay(' + objIDName + ')" onmouseout="OnMouseOutOverlay()">' 
  // + '<span class="left"></span><span class="center">' + text + '</span><span class="right"></span></div>';

  //         content = '<div class ="label1" ondragstart="return false" onselectstart="return false" onmouseover="OnMouseOverOverlay(' + objIDName + ')" onmouseout="OnMouseOutOverlay()">'
  //          + text + '</div>';



  //content = '<b><font size="3">' + text + '</font></b>';


  //content = '<div class ="label1" ondragstart="return false" onselectstart="return false" onmouseover="OnOverOverlay(' + objIDName + ')" ondblclick="OnDblclickOverlay(' + objIDName + ')" onclick="OnClickOverlay(' + objIDName + ')">'
  //+ '<span class="left"></span><span class="center">' + text + '</span><span class="right"></span></div>';

  //content = '<div class ="label1" ondragstart="return false" onselectstart="return false" ><span class="left"></span><span class="center">' + text + '</span><span class="right"></span></div>';

  var position = new kakao.maps.LatLng(y, x);

  var gap = 0.5;

  if (width == 22 & height == 22)
    gap = 0.55; //0.55;
  else if (width == 43 & height == 40)
    gap = 0.62;
  else /* if (width == 15 & height == 15) */
    gap = 0.52; //0.5;

  //alert(map.getLevel());

  // 커스텀 오버레이를 생성합니다
  var customOverlay = new kakao.maps.CustomOverlay({
    clickable: false, // true : 마커를 클릭했을 때 지도의 클릭 이벤트가 발생하지 않도록 설정합니다
    //zIndex: 0,
    position: position,
    content: content,
    xAnchor: 0.5,
    yAnchor: 1.5 //gap
  });

  customOverlay.setMap(map);

  overlayObjects.push({
    "Object": customOverlay,
    "IDName": objIDName,
    "x": x,
    "y": y
  });
  // }

  marker.setMap(map);

  overlayObjects.push({ "Object": marker, "IDName": objIDName, "x": x, "y": y });
  /*
      kakao.maps.event.addListener(marker, 'click', function(mouseEvent) {
          var message = marker.getPosition();
  //alert("click");
          m_clickID = objIDName;
          document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
      });
  */

  kakao.maps.event.addListener(marker, 'rightclick', function () {
    // NOTE :: 우클릭하면 시설물 모달창으로 연결
    showFacilityDetail(data.SL_SLCODE)
  });
  kakao.maps.event.addListener(marker, 'click', function () {
    // NOTE :: 좌클릭하면 tooltip 연결
    if (isRulerOn == true) {
      return;
    }
    areaAction(data.SL_SLCODE)
    $('#btn_change_title').show()
    // AddTooltipOverlay(objIDName, x, y, GenTooltipContent());
    if ('SL_DATA_1' in data && data.SL_DATA_1 == 4) {
      focusedScreen = $('#modal-distributor-info')
      // FIXME 김현기 격등 이동, 삭제 버튼 비활성화 (시설물 설치 과정에도 문제가 있어 현재 주석처리)
      $('#modal-info #btn_move').attr('disabled', true);
      $('#modal-info #btn_delete').attr('disabled', true);
      ShowDistributorInfo(data, false, markerurl);
    }
    else {
      focusedScreen = null
      $('#modal-info #btn_move').attr('disabled', false);
      $('#modal-info #btn_delete').attr('disabled', false);
      ShowLightInfo(data.SL_SLCODE, markerurl)
    }

    // // tooltip 방식
    // var conData = [];
    // conData.push(data.SL_SLCODE);
    // conData.push(GetLightTypeNameByNo(data.SL_DATA_1));
    // if (data.SL_SLNO && data.SL_SLNO != "NULL") {
    //   var a, b;
    //   b = data.SL_SLNO.substr(-3);
    //   a = data.SL_SLNO.substr(0, data.SL_SLNO.length - 3)
    //   conData.push(a);
    //   conData.push(b);
    // } else {
    //   conData.push(" ");
    //   conData.push(" ");
    // }
    // conData.push(data.PARENT_NO);
    // conData.push(data.SN);
    // conData.push(data.GROUP_ID);
    // conData.push(data.INDIVIDUAL_ID);

    // AddTooltipOverlay(objIDName, x, y, GenTooltipContent(conData));
  });
  // 마커에 마우스오버 이벤트를 등록합니다
  kakao.maps.event.addListener(marker, 'mouseover', function () {
    if (isRulerOn == false) {
      var message = marker.getPosition();

      m_clickID = objIDName;
      document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
    }


    // SuspendTooltipOverlay();
  });

  // 마커에 마우스아웃 이벤트를 등록합니다
  kakao.maps.event.addListener(marker, 'mouseout', function () {
    if (isRulerOn == false) {
      var message = marker.getPosition();

      m_clickID = "NO";
      document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
    }

    // RemoveTooltipOverlay();
  });

  window.labelManager(map.getLevel())
}

window.AddDragMarker = function (objIDName, evtmode, x, y, width, height, markerurl, text) {

  //    RemoveOverlay(objIDName);
  // RemoveAllOverlays();

  var pt = new kakao.maps.LatLng(y, x);

  var icon = new kakao.maps.MarkerImage(
    markerurl,
    new kakao.maps.Size(width, height),
    new kakao.maps.Point(width / 2, height / 2)
  );

  //var marker = new kakao.maps.Marker({position:pt, image: icon});
  var marker = new kakao.maps.Marker({
    position: pt,
    image: icon,
    draggable: true,
    clickable: true // 마커를 클릭했을 때 지도의 클릭 이벤트가 발생하지 않도록 설정합니다
  });

  kakao.maps.event.addListener(marker, 'dragstart', function () {
    // 출발 마커의 드래그가 시작될 때 마커 이미지를 변경합니다
    // marker.setImage(icon);
  });

  m_movedY = y;
  m_movedX = x;
  // 출발 마커에 dragend 이벤트를 등록합니다
  kakao.maps.event.addListener(marker, 'dragend', function () {
    // 출발 마커의 드래그가 종료될 때 마커 이미지를 원래 이미지로 변경합니다
    // marker.setImage(icon);
    m_movedY = marker.getPosition().getLat();
    m_movedX = marker.getPosition().getLng();
    window.installObj.MAP_X = m_movedX
    window.installObj.MAP_Y = m_movedY
    //alert("m_movedX is " + m_movedX);
  });

  if (evtmode == 0) {
    marker.setTitle(text);
  }
  marker.setMap(map);

  if (evtmode != 0) {
    var content;
    /*        
            if (width == 16 & height == 16)
                content = '<div class ="label1"><span class="left"></span><span class="center">' + text + '</span><span class="right"></span></div>';
            else if (width == 16 & height == 26)
                content = '<div class ="label2"><span class="left"></span><span class="center">' + text + '</span><span class="right"></span></div>';
            else
                content = '<div class ="label3"><span class="left"></span><span class="center">' + text + '</span><span class="right"></span></div>';
    */
    content = '<div class ="label1"><span class="left"></span><span class="center">' + text + '</span><span class="right"></span></div>';

    var gap = 0.5;

    if (width == 22 & height == 22)
      gap = 0.55;
    else if (width == 43 & height == 40)
      gap = 0.65;
    else /* if (width == 15 & height == 15) */
      gap = 0.5;

    var position = new kakao.maps.LatLng(y, x);
    // 커스텀 오버레이를 생성합니다
    // var customOverlay = new kakao.maps.CustomOverlay({
    //     position: position,
    //     content: content,
    //     xAnchor: 0.5,
    //     yAnchor: gap
    // });
    // customOverlay.setMap(map);
    // overlayObjects.push({ "Object": customOverlay, "IDName": objIDName });
  }

  overlayObjects.push({
    "Object": marker,
    "IDName": objIDName
  });

  kakao.maps.event.addListener(marker, 'click', function () {
    var message = marker.getPosition();

    m_clickID = objIDName;
    document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
  });

  // 마커에 마우스오버 이벤트를 등록합니다
  kakao.maps.event.addListener(marker, 'mouseover', function () {
    var message = marker.getPosition();

    m_clickID = objIDName;
    document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
  });

  // 마커에 마우스아웃 이벤트를 등록합니다
  kakao.maps.event.addListener(marker, 'mouseout', function () {
    var message = marker.getPosition();

    m_clickID = "NO";
    document.getElementById("mapMessage").innerHTML = "clickNO;" + m_clickID;
  });
}

window.GetClickMarkerNO = function () {
  var clcik_str = "clickNO;" + m_clickID;
  return clcik_str;
}

window.GetClickAddress = function () {
  var clcik_str = "clickAddress;" + m_clickAddress;
  return clcik_str;
}

window.SetCenterAndZoomFromBounds = function (l, t, r, b) {
  map.setBounds(new kakao.maps.LatLngBounds(new kakao.maps.LatLng(b, l), new kakao.maps.LatLng(t, r)));
}

window.InitBounds = function () {
  bounds = null;
  bounds = new kakao.maps.LatLngBounds();
}

window.MouseWheelProc = function (op) {
  if (op < 0) {
    m_zoomlevel = map.getLevel();
    map.setLevel(map.getLevel() + 1);
  } else {
    m_zoomlevel = map.getLevel();
    map.setLevel(map.getLevel() - 1);
  }
}

window.searchAddrFromCoords = function (coords, callback) {
  // 좌표로 주소 정보를 요청합니다
  m_geocoder.coord2addr(coords, callback);
}

// 지도 확대, 축소 컨트롤에서 확대 버튼을 누르면 호출되어 지도를 확대하는 함수입니다
window.zoomIn = function () {
  m_zoomlevel = map.getLevel();
  map.setLevel(map.getLevel() - 1);
}

// 지도 확대, 축소 컨트롤에서 축소 버튼을 누르면 호출되어 지도를 확대하는 함수입니다
window.zoomOut = function () {
  m_zoomlevel = map.getLevel();
  map.setLevel(map.getLevel() + 1);
}

window.setMarkerDisplayAsZoomLevel = function (zoomLevel) {
  var thresholdLevel = 3;
  if (zoomLevel < thresholdLevel) {
    var styleSheet = '/markerlabel_visible.css?v=3ef5980';
    $('#markerlabel[rel=stylesheet]').attr('href', styleSheet);
  } else {
    var styleSheet = '/markerlabel_invisible.css?v=7a0b2b9';
    $('#markerlabel[rel=stylesheet]').attr('href', styleSheet);
  }
}

///////////////////////////////////////////////////////////////////////////////
/////////////////////////////////

$("#visible_light_type").val(getCache('visible_light_type', INITIAL_VISIBLE_LIGHT_TYPE));

window.selectTypeLight = function (light_type_value) {
  if (light_type_value != getCache('visible_light_type', INITIAL_VISIBLE_LIGHT_TYPE)) {
    setCache('visible_light_type', light_type_value);
    invalidateLight = true;
  }
}

$("#visible_light_type").change(function () {
  if ($(this).val() != getCache('visible_light_type', INITIAL_VISIBLE_LIGHT_TYPE)) {
    setCache('visible_light_type', $(this).val());
    invalidateLight = true;
  }
});

/*
주소로 위치 찾기!(수정)
ParkDyel
2018.06.25
*/
$("#addr").submit(function (event) {

  if (form_cursor) {
    msg = {
      "addr": "{0} {1} {2}".
        format($("#addr1 option:selected").text(),
          $("#addr2 option:selected").text(),
          $("#addr3 option:selected").text())
    }
  }
  else {
    var input_text = $('#inputAddrStr').val();
    if (input_text.length < 2) {
      alert('2글자 이상 입력해주세요.');
      return;
    }

    msg = {
      "name": "{0}".format(input_text)
    }
  }

  API_GET('facility', msg)
    .done(function (res) {
      $("#search-result div").remove();

      $('#searchResultCount').remove()
      var searchResultCount = '<div id="searchResultCount" style="margin:10px 5px;">검색결과: {0} 건 </div>'.format(res['data']['light'].length)
      $('#addr').after(searchResultCount);

      res['data']['light'].forEach(function (element, index, array) {
        var SL_SLNAME = element.SL_SLNAME;
        if (element.SL_MAN.length > 0) {
          SL_SLNAME = SL_SLNAME + ' (' + element.SL_MAN + ')';
        }
        $("#search-result").append('<div class="box-footer" style="padding:5px;">{0}<button onclick="GPSOff();SetPosition({1}, {2});" type="button" class="btn btn-default pull-right" data-dismiss="modal">이동</button></div>'
          .format(SL_SLNAME, element.SL_MAP_X, element.SL_MAP_Y));
      });

      //주소검색인데 길이가 0이면 주소검색
      if (!form_cursor && res['data']['light'].length == 0) {
        ret = getValue(input_text);
      }
    })
});


/*
주소로 위치 찾기!
ParkDyel
2018.06.25
*/
// form 사용 선택을 나타내는 전역 변수입니다.
window.form_cursor = true;
// 
window.evtfnInputAddrStrClick = function (e) {
  if (!(this.classList.contains('selected'))) {
    // 만약 전달된 요소에 클래스 selected가 추가되어 있지 않다면 선택자를 토글합니다.
    e.preventDefault()
    $('#addr .form-group .form-control').toggleClass('selected');
    form_cursor = !form_cursor;
    //     disabled 영역에 대해 마우스 이벤트를 받을 수 없습니다.
    //     $('#addr .form-group .form-control').attr('disabled', !$('#addr .form-group .form-control').attr('disabled'))
  }
  // 전달된 요소에 클래스 selected가 이미 추가되어 있다면 아무일도 하지 않습니다.
}

// form-control에 click 이벤트를 추가합니다.
// 이 이벤트는 CSS 관련 Class와 global variable을 토글합니다.
$('#addr .form-group .form-control').on('click', evtfnInputAddrStrClick)

// 주소 검색 결과에 따라 에러 메세지를 출력하거나
// 위치로 이동합니다
window.controlTab = function (flag) {
  e = $('#addrStrErrBox');
  if (flag == false) {
    if (e.length == 0) {
      var errDiv = '<div id="addrStrErrBox" style="margin:10px 5px;color:#FF4444;">잘못된 주소를 입력하셨습니다</div>'
      $('#addr').after(errDiv);
    }
  } else {
    e.remove();
    $('.modal-header .close').click();
  }
}

// 주소를 기반으로 맵을 이동합니다.
window.getValue = function (inputString) {
  var geocoder = new kakao.maps.services.Geocoder();
  var address = inputString;
  var ret = false;

  geocoder.addressSearch(address, function (result, status) {
    // 정상적으로 검색이 완료됐으면 
    if (status === kakao.maps.services.Status.OK) {
      // console.log(result)
      // var coords = new kakao.maps.LatLng(result[0].y, result[0].x);

      // 지도의 중심을 결과값으로 받은 위치로 이동시킵니다
      map.setCenter(window.setCoordsFromPoint(result[0].x, result[0].y, panelPosition));
      if (isRvOn) {
        // toggleRoadview(coords);
        window.isToggleRvJustNow = true;
        window.evtRvPositionChanged();
      }
      console.log("ret", ret)
      ret = true;
      console.log("ret", ret)
    } else {
      window.modalAlert("black",
        null,
        "잘못된 주소를 입력하셨습니다",
        null,
        null,
        true,
        false)
    }
  })
}

window.image_upload_check = false;
window.imageSave = function (img_name, original_img_base64, Thumbnail_img_base64, picture_slcode) {
  var focusScreen = null;
  if (focusedScreen == null) {
    focusScreen = focusedScreen == null ? $('#modal-info') : focusedScreen;
  } else {
    focusScreen = focusedScreen;
  }

  showSpinner();
  image_upload_check = true;
  var thumbnail_position = null;
  focusScreen.find('#picture-body').children().each(function (index) {
    if (focusScreen.find(this).data("check") == false) {
      focusScreen.find(this).attr('src', 'data:image/jpeg;base64,' + Thumbnail_img_base64);
      focusScreen.find(this).css('padding', '2px').css('background-color', 'darkgray').css('border', '');
      focusScreen.find(this).data("check", true);
      thumbnail_position = this;
      return false;
    }
  })
  $('#spinnerText').text('업로드 중');
  return API_POST('imagesave', {
    "slcode": picture_slcode,
    "img_name": img_name,
    "original_img_base64": encodeURIComponent(original_img_base64),
    "Thumbnail_img_base64": encodeURIComponent(Thumbnail_img_base64)
  })
    .done(function (res) {
      image_upload_check = false;
      if (process.env.VUE_APP_DEBUG == "true") {
        focusScreen.find(thumbnail_position).attr('src', 'https://s3.ap-northeast-2.amazonaws.com/' + process.env.VUE_APP_S3_PATH + '/' + process.env.VUE_APP_S3_DB + '/' + focusScreen.find('#slcode').val() + "_" + img_name + "_thumb.jpg");
      } else {
        focusScreen.find(thumbnail_position).attr('src', 'https://s3.ap-northeast-2.amazonaws.com/' + store.getters.config_s3_path + '/' + store.getters.config_s3_base + '/' + focusScreen.find('#slcode').val() + "_" + img_name + "_thumb.jpg");
      }
      hideSpinner();
    })
    .fail(function () {
      image_upload_check = false;
      if (thumbnail_position != null) {
        focusScreen.find(thumbnail_position).attr('src', require("@/assets/img/res/img/pic_plus.png"));
        focusScreen.find(thumbnail_position).css('padding', '').css('background-color', '').css('border', '4px dashed #D3D3D3');
        focusScreen.find(thumbnail_position).data("check", false);
      }
      hideSpinner();
    })
    .always(function () {
    });
}

window.doubleTap_android = function () {
  var image_matrix = $('#original-picture').panzoom("getMatrix").toString().split(',');
  if (image_matrix[0] == '1') {
    $('#original-picture').panzoom("zoom", {
      increment: 0.6,
    });
  } else {
    $('#original-picture').css('transform', '');
    $('#original-picture').panzoom("reset");
  }
}

$(window).resize(function () {
  //창크기 변화 감지
  $('#picture_div').css('width', window.innerWidth);
  $('#picture_div').css('height', window.innerHeight);
  $("#image_preview").css('max-height', window.innerHeight * 0.75 + "px");
});

window.image_nameinfo = null;
window.image_scale_check = null;
window.image_click = function (iddata) {
  $(iddata).click(function () {
    var focusScreen = focusedScreen == null ? $('#modal-info') : focusedScreen;
    if ($(iddata).data("check") == false) {
      if (window.Android != undefined) {
        window.Android.imgCamera();
      } else {
        //nginx 업로드 제한 문제가 해결되기 전까지는 이미지 업로드 기능을 사용하지 않음
        //eventOccur(document.getElementById('web-fileUpload'),'click');
      }
    } else {
      $('#modal-picture').modal('show');
      $("#modal-picture").on('hidden.bs.modal', function (event) {
        if ($('.modal:visible').length) { // 모달 갯수 확인
          $('body').addClass('modal-open');//add class to body
        }
      })

      $('#original-picture').attr('src', $(iddata).attr('src').replace('_thumb', ''));

      $('#panzoom-parent').css('text-align', 'center');
      $('#picture_div').css('width', window.innerWidth);
      $('#picture_div').css('height', window.innerHeight);
      $('#picture_div').css('display', 'table-cell');
      $('#picture_div').css('vertical-align', 'middle');
      $('#original-picture').css('transform', '');

      var img = new Image();
      img.src = $('#original-picture').attr('src');

      // 영역외 이동 작업용
      // var panzoom = $('#panzoom-parent').panzoom({
      //   $set : $('#original-picture').panzoom({
      //     contain: "automatic",
      //     minScale: 0.8
      //   }),
      //   minScale: 0.8
      // });
      var panzoom = $('#original-picture').panzoom({
        contain: "automatic",
        minScale: 0.8
      });

      image_scale_check = false;
      panzoom.on('mousewheel.focal', function (e) {
        e.preventDefault();
        var delta = e.delta || e.originalEvent.wheelDelta;
        var zoomOut = delta ? delta < 0 : e.originalEvent.deltaY > 0;
        image_scale_check = true;
        $('#original-picture').panzoom('zoom', zoomOut, {
          increment: 0.2,
          animate: false,
        });
      });

      panzoom.on('panzoomstart', function (e) {

      });

      panzoom.on('panzoomend', function (e) {

      });

      $('#panzoom-parent').dblclick('doubletap', function (evt, touch) {
        if (image_scale_check == false) {
          $('#original-picture').panzoom("zoom", {
            increment: 0.6,
          });
          image_scale_check = true;
        } else {
          $('#original-picture').css('transform', '');
          image_scale_check = false;
        }
      });

      var image_src_info = $(iddata).attr('src').split('_');
      image_nameinfo = image_src_info[image_src_info.length - 2]
      var date_time = image_src_info[image_src_info.length - 2].split('T');
      var image_date = date_time[0].substr(0, 4) + '-' + date_time[0].substr(4, 2) + '-' + date_time[0].substr(6, 2);
      var image_time = date_time[1].substr(0, 2) + ':' + date_time[1].substr(2, 2) + ':' + date_time[1].substr(4, 2);
      $('#original-picture-info').html(focusScreen.find('#title').text() + '<br>' + image_date + " " + image_time);
    }
  })
}

window.eventOccur = function (evEle, evType) {
  if (evEle.fireEvent) {
    evEle.fireEvent('on' + evType);
  } else {
    var mouseEvent = document.createEvent('MouseEvents');

    mouseEvent.initEvent(evType, true, false);

    evEle.dispatchEvent(mouseEvent);
  }
}

window.thumnailResizedataURL = function (file, datas, wantedlength) {
  $.canvasResize(file, {
    width: wantedlength,
    height: wantedlength,
    crop: true,
    callback: function (data, width, height) {
      var d = new Date();
      var imgName = d.getFullYear() + ("00" + (d.getMonth() + 1)).slice(-2) + ("00" + d.getDate()).slice(-2) + "T" + ("00" + d.getHours()).slice(-2) + ("00" + d.getMinutes()).slice(-2) + ("00" + d.getSeconds()).slice(-2);
      $("#modal-image-upload").modal('show');
      $("#modal-image-upload").on('hidden.bs.modal', function (event) {
        if ($('.modal:visible').length) {
          $('body').addClass('modal-open');
        }
      });

      $("#img-name").val(imgName);
      var imageResize = data.split(',');
      $("#img-thum").val(imageResize[1]);
    }
  });
}

window.originalResizedataURL = function (file, datas, wantedlength) {
  var img = document.createElement('img');

  img.onload = function () {
    var resizewidth = 0;
    var resizeHeight = 0;
    if (img.width > wantedlength || img.height > wantedlength) {
      if (img.height > img.width) {
        resizeHeight = wantedlength;
        resizewidth = Math.round((img.width * wantedlength) / img.height);
      } else {
        resizewidth = wantedlength;
        resizeHeight = Math.round((img.height * wantedlength) / img.width);
      }
    } else {
      resizewidth = img.width
      resizeHeight = img.height
    }
    $.canvasResize(file, {
      width: resizewidth,
      height: resizeHeight,
      crop: false,
      callback: function (data, width, height) {
        $("#image_preview").attr('src', data);
        $("#image_preview").css('max-height', window.innerHeight * 0.75 + "px");

        $("#web-fileUpload").val(null);
        var imageResize = data.split(',');
        $("#img-origin").val(imageResize[1]);
      }
    });
  }
  img.src = datas;
}

$("#btn_image_upload").click(function () {
  imageSave($("#img-name").val(), $("#img-origin").val(), $("#img-thum").val());
});

window.loadImg = function (value) {
  if (value.files && value.files[0]) {
    var reader = new FileReader();
    reader.onload = function (e) {
      if (thumnailImageSize != '') {
        thumnailResizedataURL(value.files[0], e.target.result, thumnailImageSize);
      } else {
        thumnailResizedataURL(value.files[0], e.target.result, 150);
      }

      if (originImageSize != '') {
        originalResizedataURL(value.files[0], e.target.result, originImageSize);
      } else {
        originalResizedataURL(value.files[0], e.target.result, 1920);
      }
    }
    reader.readAsDataURL(value.files[0]);

  }
}

$('#modal-info #picture-body').children().each(function (index) {
  image_click(this);
})

$('#modal-distributor-info #picture-body').children().each(function (index) {
  image_click(this);
})

$('#picture-delete-btn').click(function () {
  if (confirm("정말 삭제하시겠습니까?")) {
    var focusScreen = focusedScreen == null ? $('#modal-info') : focusedScreen;
    API_POST('imagedelete', {
      "slcode": focusScreen.find('#slcode').val(),
      "image_nameinfo": image_nameinfo
    })
      .done(function (res) {
        var pic_data = res.data.light;
        pictureThumbSet(pic_data.SL_SLCODE, pic_data.PIC_01, pic_data.PIC_02, pic_data.PIC_03);
        $('#modal-picture-delete').modal('hide');
        $('#modal-picture').modal('hide');
      })
      .fail(function () {
        console.log("오류 : 이미지 삭제 실패하였습니다.");
      })
      .always(function () {

      });
  }
})

window.pictureThumbSet = function (slcode, pic01, pic02, pic03) {
  var focusScreen = null;
  if (focusedScreen == null) {
    focusScreen = focusedScreen == null ? $('#modal-info') : focusedScreen;
  } else {
    focusScreen = focusedScreen;
  }

  var picture_id = ['first-picture', 'second-picture', 'third-picture'];
  var picture_count = 0;
  [pic01, pic02, pic03].forEach(function (element) {
    if (element != null) {
      if (process.env.VUE_APP_DEBUG == "true") {
        focusScreen.find('#' + picture_id[picture_count]).attr('src', 'https://s3.ap-northeast-2.amazonaws.com/' + process.env.VUE_APP_S3_PATH + '/' + process.env.VUE_APP_S3_DB + '/' + slcode + "_" + element + "_thumb.jpg");
      } else {
        focusScreen.find('#' + picture_id[picture_count]).attr('src', 'https://s3.ap-northeast-2.amazonaws.com/' + store.getters.config_s3_path + '/' + store.getters.config_s3_base + '/' + slcode + "_" + element + "_thumb.jpg");
      }
      focusScreen.find('#' + picture_id[picture_count]).data("check", true);
      focusScreen.find('#' + picture_id[picture_count]).css('padding', '2px').css('background-color', 'darkgray').css('border', '');
    } else {
      focusScreen.find('#' + picture_id[picture_count]).attr('src', require("@/assets/img/res/img/pic_plus.png"));
      focusScreen.find('#' + picture_id[picture_count]).data("check", false);
      focusScreen.find('#' + picture_id[picture_count]).css('border', '4px dashed #D3D3D3').css('padding', '').css('background-color', '');
    }
    picture_count++;
  })
}

window.setQRCodeSN = function (data) {
  $('#modal-info #serial').val(data);
}

window.getFormatDate = function (date) {
  var year = date.getFullYear();//yyyy
  var month = (1 + date.getMonth());                     //M
  month = month >= 10 ? month : '0' + month;// month 두자리로 저장
  var day = date.getDate();//d
  day = day >= 10 ? day : '0' + day;//day 두자리로 저장
  return month + '/' + day;

}

window.modal_show = function () {
  $("#modal-Watt-graph").modal('show');
  $("#modal-Watt-graph").on('hidden.bs.modal', function (event) {
    if ($('.modal:visible').length) { // 모달 갯수 확인
      $('body').addClass('modal-open');//add class to body
    }
  })
}

window.modal_close = function () {
  $('#wattchart').empty();
  $('#modal-Watt-graph #watt_time').empty();
}

window.msie = function () { // 얘 없으면 버튼이 클릭이 안됨, 연 그래프 버튼
  jQuery.browser = {};
  jQuery.browser.msie = false;
  jQuery.browser.version = 0;
  if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
    jQuery.browser.msie = true;
    jQuery.browser.version = RegExp.$1;
  }
}

$("#modal-Watt-graph .close").click(function () {
  modal_close()
  $("#container").remove()
})


$(document).on("click", "#container .next", function (e) {
  next_prev_year()
});

$(document).on("click", "#container .prev", function (e) {
  next_prev_year()
});

window.next_prev_year = function () {
  var tr = $('.datepicker-switch').html()
  var year = tr.split(' ')[1]
  ShowAccumulateYearGraph($('#modal-info #slcode').val(), year);
}

$('#btn_watt_year_graph').click(function () {
  msie()
  modal_show()
  $("#watt_body").append(" <div id='container'> <div id='left-box'></div> <div id='center-date'></div> <div id='right-box'></div> </div>")

  $("#center-date").datepicker({
    format: "mm-yyyy",
    startView: "months",
    minViewMode: "months"
  });
  //$(".datepicker-switch").unbind();
  $(".datepicker-switch").click(function (e) {
    e.stopPropagation();
  });
  $(".datepicker-switch").css("cursor", "default");
  var today = new Date().toISOString()
  ShowAccumulateYearGraph($('#modal-info #slcode').val(), today);
})

window.ShowAccumulateYearGraph = function (slcode, today) {
  API_GET('facility/accumulateyear', {
    "slcode": slcode,
    'date': today
  })
    .done(function (res) {
      $('#modal-Watt-graph #watt_time').empty();
      var dataSet = res['data']
      var objKeys = Object.keys(dataSet)
      var all_month = []
      var category = []
      var TEMP = ["LAST_STORE_VAL", "LAST_STORE_EST", "STORE_VAL", "STORE_EST"]
      if (objKeys.length == 0) {
        $('#modal-Watt-graph #watt_time').html(
          "데이터가 충분치 않습니다"
        )
        TEMP.forEach(function (i) {
          all_month.push([i, null])
        })
      } else {
        objKeys.forEach(function (i, k) {
          mon_list = dataSet[i]
          mon_list.unshift(i)
          all_month.push(mon_list)
        })
        category.push(TEMP.slice(0, 2))
        category.push(TEMP.slice(2))
      }
      setTimeout(function () {
        return draw_bar_chart(all_month, category, today, bar_color_list);
      }, 300)
    })
}

window.line_color_list = {
  "STORE_VAL": '#0B01FF',
  "STORE_EST": '#0084FF',
  "LAST_STORE_VAL": '#007B04',
  "LAST_STORE_EST": '#36D304'
}

window.bar_color_list = {
  "STORE_VAL": '#29437A',
  "STORE_EST": '#79B2D2',
  "LAST_STORE_VAL": '#800080',
  "LAST_STORE_EST": '#ffc0cb'
}
Array.prototype.contains = function (element) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] == element) {
      return true;
    }
  }
  return false
}
window.bar_data_id = null;
window.draw_bar_chart = function (dataSet, category, month, color_list) {
  var name_list = {
    STORE_VAL: '당년 실제',
    STORE_EST: '당년 추정',
    LAST_STORE_VAL: '작년 실제',
    LAST_STORE_EST: '작년 추정'
  }
  var chart = c3.generate({
    bindto: "#wattchart",
    padding: {
      right: 30,
    },
    size: {
      height: 400
    },
    data: {
      columns: dataSet,
      type: 'bar',
      groups: category,
      order: 'asc',
      names: name_list,
      colors: color_list,
      onmouseover: function (d) {
        bar_data_id = d['id']
      }
    },
    tooltip: {
      contents: function (d, defaultTitleFormat, defaultValueFormat, color) {
        var arr = arguments[0]
        arr.sort(function (a, b) {
          var alc = a.id.toLowerCase(), blc = b.id.toLowerCase()
          return alc > blc ? 1 : alc < blc ? -1 : 0;
        });
        arguments[0] = arr
        var groups = category[0]
        var group_checker = groups.contains(bar_data_id)
        //console.log(bar_data_id)
        if (group_checker) {
          arguments[0] = arguments[0].slice(0, 2)
          var bar_list = d.slice(0, 2)
        } else {
          var bar_list = d.slice(2, 4)
          arguments[0] = arguments[0].slice(2, 4)
        }
        var sum = 0;
        bar_list.forEach(function (e) {
          sum += e.value / 1000
        })
        defaultTitleFormat = function (d) {
          return '총 계: ' + sum.toFixed(2) + 'KW'
        };
        return c3.chart.internal.fn.getTooltipContent.apply(this, arguments);
      }
    },
    bar: {
      width: {
        ratio: 0.5 // this makes bar width 50% of length between ticks
      }
    },
    axis: {
      x: {
        label: {
          text: '월',
          position: 'outter-right'
        },
        min: 1
      },
      y: {
        tick: {
          format: function (d) {
            return d / 1000 + " KW"
          }
        }
      }
    }
  });
}


$('#btn_watt_month_graph').click(function () {
  modal_show()
  ShowAccumulateGraph($('#modal-info #slcode').val());
});

window.ShowAccumulateGraph = function (slcode) {
  var today = new Date();
  var month = today.getMonth() + 1;
  var day = today.getDate()
  var date_string = new Date().toISOString()
  //console.log(date_string)
  API_GET('facility/accumulate', {
    "slcode": slcode,
    'date': date_string
  })
    .done(function (res) {
      $('#modal-Watt-graph #watt_time').empty();
      var dataSet = res.data
      var objKeys = Object.keys(dataSet)
      var all_month = []
      if (objKeys.length == 0) {
        $('#modal-Watt-graph #watt_time').html(
          "데이터가 충분치 않습니다"
        )
        key_name = ['LAST_STORE_VAL', 'LAST_STORE_EST', 'STORE_VAL', 'STORE_EST']
        key_name.forEach(function (i) {
          all_month.push([i, null])
        })
      } else {
        objKeys.forEach(function (i, v) {
          month_list = dataSet[i]
          month_list.unshift(i)
          all_month.push(month_list)
        })
      }
      setTimeout(function () {
        return draw_line_chart(all_month, day, month, line_color_list);
      }, 300)
    })
}

window.draw_line_chart = function (data, day_index, month, color_list) {
  var name_list = {
    STORE_VAL: month + '월 실제',
    STORE_EST: month + '월 추정',
    LAST_STORE_VAL: (month - 1) + '월 실제',
    LAST_STORE_EST: (month - 1) + '월 추정'
  }
  var chart = c3.generate({
    bindto: "#wattchart",
    padding: {
      right: 30,
    },
    size: {
      height: 400
    },
    data: {
      columns: data,
      regions: {
        'LAST_STORE_EST': [{ "style": "dashed" }],
        'STORE_EST': [{ "style": "dashed" }],
      },
      names: name_list,
      colors: color_list
    },
    grid: {
      x: {
        lines: [
          { value: day_index, text: '오늘', class: 'time_grid', position: 'end' }
        ],
        show: true
      },
      y: {
        show: true
      }
    },
    axis: {
      x: {
        label: {
          text: '일',
          position: 'outter-right'
        },
        min: 1
      },
      y: {
        min: 0,
        tick: {
          format: function (d) {
            return d / 1000 + " KW"
          }
        }
      }
    }
  })
}

$('#btn_watt_graph').click(function () {
  modal_show()
  ShowWattGraph($('#modal-info #slcode').val());
});


window.ShowWattGraph = function (slcode) {
  Array.prototype.insert = function (index, item) {
    this.splice(index, 0, item);
  };
  var today = new Date();
  var yy = today.getFullYear();
  var dd = today.getDate();
  var mm = today.getMonth() + 1;
  var hh = today.getHours();

  var temp_today = getFormatDate(today);

  today.setDate(today.getDate() + 1)
  var temp_tommorow = getFormatDate(today)

  today.setDate(today.getDate() - 2)
  var temp_yesterday = getFormatDate(today)

  today.setDate(today.getDate() - 14)
  var temp_max_min = getFormatDate(today)

  API_GET('facility/hist', {
    "slcode": slcode,
    'year': yy,
    "month": mm,
    "day": dd,
    "hours": hh
  })
    .done(function (res) {
      var dataSet = res.data
      //console.log("debug", dataSet)
      var time_index = 'T' + hh.toString();
      time_index = dataSet.axis.indexOf(time_index)
      dataSet.res[0].insert(0, "최대")
      dataSet.res[1].insert(0, "최소")
      dataSet.res[2].insert(0, "어제")
      dataSet.res[3].insert(0, "오늘")
      $('#modal-Watt-graph #watt_time').html(
        "오늘 기준일 : " + temp_today + "<br>" +
        "어제 기준일 : " + temp_yesterday + "<br>" +
        "최대(최소) 산정 기간 : " + temp_max_min + "~ 오늘"
      )
      if (dataSet.axis[1] == 'error') {
        var watt_time = $('#modal-Watt-graph #watt_time').html()
        $('#modal-Watt-graph #watt_time').html(
          "현재 데이터가 충분치 않습니다" + "<br>" + watt_time)
      } else if (dataSet.axis.length > 3) {
        var day_index = dataSet.axis.indexOf('T00')
        dataSet.axis[0] = temp_today + " " + dataSet.axis[0]
        dataSet.axis[day_index] = temp_tommorow + " " + dataSet.axis[day_index]
      } else {
        $('#modal-Watt-graph #watt_time').html(
          "등록 되지 않은 기기 입니다" + "<br>")
      }
      setTimeout(function () {
        return draw_chart(dataSet, today, time_index);
      }, 300)
    }).fail(function (jqXHR, textStatus, errorThrown) {
      alert('저장된 데이터가 없습니다.' + (DEBUG_MODE ? '\n' + jqXHR.responseText : ''));
      $('#modal-Watt-graph #watt_time').html("저장된 데이터가 없습니다. 다음날 다시 확인해주세요 ")
    });
}
// C3js를 위한 코드

window.draw_chart = function (data, today, time_index) {
  c3.chart.internal.fn.getHorizontalAxisHeight = function (axisId) {
    var $$ = this, config = $$.config, h = 30;
    if (axisId === 'x' && !config.axis_x_show) { return 8; }
    if (axisId === 'x' && config.axis_x_height) { return config.axis_x_height; }
    if (axisId === 'y' && !config.axis_y_show) {
      return config.legend_show && !$$.isLegendRight && !$$.isLegendInset ? 10 : 1;
    }
    if (axisId === 'y2' && !config.axis_y2_show) { return $$.rotated_padding_top; }
    // Calculate x axis height when tick rotated
    if (axisId === 'x' && !config.axis_rotated && config.axis_x_tick_rotate) {
      h = 30 + $$.axis.getMaxTickWidth(axisId) * Math.cos(Math.PI * (90 - Math.abs(config.axis_x_tick_rotate)) / 180);
    }
    // Calculate y axis height when tick rotated
    if (axisId === 'y' && config.axis_rotated && config.axis_y_tick_rotate) {
      h = 30 + $$.axis.getMaxTickWidth(axisId) * Math.cos(Math.PI * (90 - Math.abs(config.axis_y_tick_rotate)) / 180);
    }
    return h + ($$.axis.getLabelPositionById(axisId).isInner ? 0 : 10) + (axisId === 'y2' ? -10 : 0);
  };
  var chart = c3.generate({
    bindto: "#wattchart",
    padding: {
      right: 30,
    },
    size: {
      height: 400
    },
    data: {
      columns: data.res,
      colors: {
        "최대": '#f90e02',
        "최소": '#f97d01',
        "어제": '#1ba503',
        "오늘": '#2607f2'
      }
    },
    grid: {
      x: {
        lines: [
          { value: time_index, text: '현재시간', class: 'time_grid', position: 'start' }
        ],
        show: true
      },
      y: {
        show: true
      }
    },
    axis: {
      x: {
        type: 'category',
        categories: data.axis,
        tick: {
          rotate: -45,
          multiline: false
        },
      },
      y: {
        min: 0,
        tick: {
          //count: 5,
          format: function (d) {
            return d.toFixed(2) + " W"
          }
        }
      }
    }
  });
};
window.facilityList = function () {
  requestData = {
    'slcode': "4687035030010",
    'page': 1
  };
  API_GET('facility/list', requestData)
    .done(function (res) {
      console.log("success", res)
    });
}



window.drawingFlag = false; // 원이 그려지고 있는 상태를 가지고 있을 변수입니다
window.centerPosition = null; // 원의 중심좌표 입니다
window.drawingCircle = null; // 그려지고 있는 원을 표시할 원 객체입니다
window.drawingLine = null; // 그려지고 있는 원의 반지름을 표시할 선 객체입니다
window.drawingOverlay = null; // 그려지고 있는 원의 반경을 표시할 커스텀오버레이 입니다
window.drawingDot = null; // 그려지고 있는 원의 중심점을 표시할 커스텀오버레이 입니다
window.drawingPolygon = null; // 그려지고 있는 다각형을 표시할 다각형 객체입니다
window.polygon = null; // 그리기가 종료됐을 때 지도에 표시할 다각형 객체입니다
window.areaOverlay = null; // 다각형의 면적정보를 표시할 커스텀오버레이 입니다
window.circles = []; // 클릭으로 그려진 원과 반경 정보를 표시하는 선과 커스텀오버레이를 가지고 있을 배열입니다

// 지도에 클릭 이벤트를 등록합니다
window.drawingClick = function (mouseEvent) {

  // 클릭 이벤트가 발생했을 때 원을 그리고 있는 상태가 아니면 중심좌표를 클릭한 지점으로 설정합니다
  if (!drawingFlag) {

    // 상태를 그리고있는 상태로 변경합니다
    drawingFlag = true;

    // 원이 그려질 중심좌표를 클릭한 위치로 설정합니다 
    centerPosition = mouseEvent.latLng;

    // 그려지고 있는 원의 반경을 표시할 선 객체를 생성합니다
    if (!drawingLine) {
      drawingLine = new kakao.maps.Polyline({
        strokeWeight: 3, // 선의 두께입니다
        strokeColor: '#00a0e9', // 선의 색깔입니다
        strokeOpacity: 1, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
        strokeStyle: 'solid' // 선의 스타일입니다
      });
    }

    // 그려지고 있는 원을 표시할 원 객체를 생성합니다
    if (!drawingCircle) {
      drawingCircle = new kakao.maps.Circle({
        strokeWeight: 1, // 선의 두께입니다
        strokeColor: '#00a0e9', // 선의 색깔입니다
        strokeOpacity: 0.1, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
        strokeStyle: 'solid', // 선의 스타일입니다
        fillColor: '#00a0e9', // 채우기 색깔입니다
        fillOpacity: 0.2 // 채우기 불투명도입니다 
      });
    }

    // 그려지고 있는 원의 반경 정보를 표시할 커스텀오버레이를 생성합니다
    if (!drawingOverlay) {
      drawingOverlay = new kakao.maps.CustomOverlay({
        xAnchor: 0,
        yAnchor: 0,
        zIndex: 1
      });
    }
  }
}

// 지도에 마우스무브 이벤트를 등록합니다
// 원을 그리고있는 상태에서 마우스무브 이벤트가 발생하면 그려질 원의 위치와 반경정보를 동적으로 보여주도록 합니다
window.drawingMouseMove = function (mouseEvent) {

  // 마우스무브 이벤트가 발생했을 때 원을 그리고있는 상태이면
  if (drawingFlag) {

    // 마우스 커서의 현재 위치를 얻어옵니다 
    var mousePosition = mouseEvent.latLng;

    // 그려지고 있는 선을 표시할 좌표 배열입니다. 클릭한 중심좌표와 마우스커서의 위치로 설정합니다
    var linePath = [centerPosition, mousePosition];

    // 그려지고 있는 선을 표시할 선 객체에 좌표 배열을 설정합니다
    drawingLine.setPath(linePath);

    // 원의 반지름을 선 객체를 이용해서 얻어옵니다 
    var length = drawingLine.getLength();

    if (length > 0) {

      // 그려지고 있는 원의 중심좌표와 반지름입니다
      var circleOptions = {
        center: centerPosition,
        radius: length,
      };

      // 그려지고 있는 원의 옵션을 설정합니다
      drawingCircle.setOptions(circleOptions);

      // 반경 정보를 표시할 커스텀오버레이의 내용입니다
      var radius = Math.round(drawingCircle.getRadius()),
        content = '<div class="dotOverlay distanceInfo">반경 <span class="number">' + radius + '</span>m</div>';

      // 반경 정보를 표시할 커스텀 오버레이의 좌표를 마우스커서 위치로 설정합니다
      drawingOverlay.setPosition(mousePosition);

      // 반경 정보를 표시할 커스텀 오버레이의 표시할 내용을 설정합니다
      drawingOverlay.setContent(content);

      // 그려지고 있는 원을 지도에 표시합니다
      drawingCircle.setMap(map);

      // 그려지고 있는 선을 지도에 표시합니다
      drawingLine.setMap(map);

      // 그려지고 있는 원의 반경정보 커스텀 오버레이를 지도에 표시합니다
      drawingOverlay.setMap(map);

    } else {

      drawingCircle.setMap(null);
      drawingLine.setMap(null);
      drawingOverlay.setMap(null);

    }
  }
}

// 지도에 마우스 오른쪽 클릭이벤트를 등록합니다
// 원을 그리고있는 상태에서 마우스 오른쪽 클릭 이벤트가 발생하면
// 마우스 오른쪽 클릭한 위치를 기준으로 원과 원의 반경정보를 표시하는 선과 커스텀 오버레이를 표시하고 그리기를 종료합니다
window.drawingRightClick = function (mouseEvent) {

  if (drawingFlag) {

    // 마우스로 오른쪽 클릭한 위치입니다 
    var rClickPosition = mouseEvent.latLng;

    // 원의 반경을 표시할 선 객체를 생성합니다
    var polyline = new kakao.maps.Polyline({
      path: [centerPosition, rClickPosition], // 선을 구성하는 좌표 배열입니다. 원의 중심좌표와 클릭한 위치로 설정합니다
      strokeWeight: 3, // 선의 두께 입니다
      strokeColor: '#00a0e9', // 선의 색깔입니다
      strokeOpacity: 1, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
      strokeStyle: 'solid' // 선의 스타일입니다
    });

    // 원 객체를 생성합니다
    var circle = new kakao.maps.Circle({
      center: centerPosition, // 원의 중심좌표입니다
      radius: polyline.getLength(), // 원의 반지름입니다 m 단위 이며 선 객체를 이용해서 얻어옵니다
      strokeWeight: 1, // 선의 두께입니다
      strokeColor: '#00a0e9', // 선의 색깔입니다
      strokeOpacity: 0.1, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
      strokeStyle: 'solid', // 선의 스타일입니다
      fillColor: '#00a0e9', // 채우기 색깔입니다
      fillOpacity: 0.2  // 채우기 불투명도입니다 
    });

    var radius = Math.round(circle.getRadius()), // 원의 반경 정보를 얻어옵니다
      content = getTimeHTML(radius); // 커스텀 오버레이에 표시할 반경 정보입니다


    // 반경정보를 표시할 커스텀 오버레이를 생성합니다
    var radiusOverlay = new kakao.maps.CustomOverlay({
      content: content, // 표시할 내용입니다
      position: rClickPosition, // 표시할 위치입니다. 클릭한 위치로 설정합니다
      xAnchor: 0,
      yAnchor: 0,
      zIndex: 1
    });

    // 원을 지도에 표시합니다
    circle.setMap(map);

    // 선을 지도에 표시합니다
    polyline.setMap(map);

    // 반경 정보 커스텀 오버레이를 지도에 표시합니다
    radiusOverlay.setMap(map);

    // 배열에 담을 객체입니다. 원, 선, 커스텀오버레이 객체를 가지고 있습니다
    var radiusObj = {
      'polyline': polyline,
      'circle': circle,
      'overlay': radiusOverlay
    };

    // 배열에 추가합니다
    // 이 배열을 이용해서 "모두 지우기" 버튼을 클릭했을 때 지도에 그려진 원, 선, 커스텀오버레이들을 지웁니다
    circles.push(radiusObj);

    // 그리기 상태를 그리고 있지 않는 상태로 바꿉니다
    drawingFlag = false;

    // 중심 좌표를 초기화 합니다  
    centerPosition = null;

    // 그려지고 있는 원, 선, 커스텀오버레이를 지도에서 제거합니다
    drawingCircle.setMap(null);
    drawingLine.setMap(null);
    drawingOverlay.setMap(null);
  }
}
// 지도에 표시되어 있는 모든 원과 반경정보를 표시하는 선, 커스텀 오버레이를 지도에서 제거합니다
window.removeCircles = function () {
  if (drawingLine) {
    drawingLine.setMap(null);
    drawingLine = null;
  }
  if (drawingCircle) {
    drawingCircle.setMap(null);
    drawingCircle = null;
  }
  if (drawingOverlay) {
    drawingOverlay.setMap(null);
    drawingOverlay = null;
  }
  drawingFlag = false
  for (var i = 0; i < circles.length; i++) {
    circles[i].circle.setMap(null);
    circles[i].polyline.setMap(null);
    circles[i].overlay.setMap(null);
  }
  circles = [];
  kakao.maps.event.removeListener(map, 'click', drawingClick);
  kakao.maps.event.removeListener(map, 'mousemove', drawingMouseMove);
  kakao.maps.event.removeListener(map, 'rightclick', drawingRightClick);
}

// 마우스 우클릭 하여 원 그리기가 종료됐을 때 호출하여 
// 그려진 원의 반경 정보와 반경에 대한 도보, 자전거 시간을 계산하여
// HTML Content를 만들어 리턴하는 함수입니다
window.getTimeHTML = function (distance) {

  // 도보의 시속은 평균 4km/h 이고 도보의 분속은 67m/min입니다
  var walkkTime = distance / 67 | 0;
  var walkHour = '', walkMin = '';

  // 계산한 도보 시간이 60분 보다 크면 시간으로 표시합니다
  if (walkkTime > 60) {
    walkHour = '<span class="number">' + Math.floor(walkkTime / 60) + '</span>시간 '
  }
  walkMin = '<span class="number">' + walkkTime % 60 + '</span>분'

  // 자전거의 평균 시속은 16km/h 이고 이것을 기준으로 자전거의 분속은 267m/min입니다
  var bycicleTime = distance / 227 | 0;
  var bycicleHour = '', bycicleMin = '';

  // 계산한 자전거 시간이 60분 보다 크면 시간으로 표출합니다
  if (bycicleTime > 60) {
    bycicleHour = '<span class="number">' + Math.floor(bycicleTime / 60) + '</span>시간 '
  }
  bycicleMin = '<span class="number">' + bycicleTime % 60 + '</span>분'

  // 거리와 도보 시간, 자전거 시간을 가지고 HTML Content를 만들어 리턴합니다
  var content = '<ul class="dotOverlay distanceInfo">';
  content += '    <li>';
  content += '        <span class="label">총거리</span><span class="number">' + distance + '</span>m';
  content += '    </li>';
  content += '    <li>';
  content += '        <span class="label">도보</span>' + walkHour + walkMin;
  content += '    </li>';
  content += '    <li>';
  content += '        <span class="label">자전거</span>' + bycicleHour + bycicleMin;
  content += '    </li>';
  content += '</ul>'

  return content;
}



window.polygonClick = function (mouseEvent) {
  // 마우스로 클릭한 위치입니다 
  var clickPosition = mouseEvent.latLng;

  // 지도 클릭이벤트가 발생했는데 다각형이 그려지고 있는 상태가 아니면
  if (!drawingFlag) {

    // 상태를 true로, 다각형을 그리고 있는 상태로 변경합니다
    drawingFlag = true;

    // 지도 위에 다각형이 표시되고 있다면 지도에서 제거합니다
    if (polygon) {
      polygon.setMap(null);
      polygon = null;
    }

    // 지도 위에 면적정보 커스텀오버레이가 표시되고 있다면 지도에서 제거합니다
    if (areaOverlay) {
      areaOverlay.setMap(null);
      areaOverlay = null;
    }

    // 그려지고 있는 다각형을 표시할 다각형을 생성하고 지도에 표시합니다
    drawingPolygon = new kakao.maps.Polygon({
      map: map, // 다각형을 표시할 지도입니다
      path: [clickPosition], // 다각형을 구성하는 좌표 배열입니다 클릭한 위치를 넣어줍니다
      strokeWeight: 3, // 선의 두께입니다 
      strokeColor: '#00a0e9', // 선의 색깔입니다
      strokeOpacity: 1, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
      strokeStyle: 'solid', // 선의 스타일입니다
      fillColor: '#00a0e9', // 채우기 색깔입니다
      fillOpacity: 0.2 // 채우기 불투명도입니다
    });

    // 그리기가 종료됐을때 지도에 표시할 다각형을 생성합니다 
    polygon = new kakao.maps.Polygon({
      path: [clickPosition], // 다각형을 구성하는 좌표 배열입니다 클릭한 위치를 넣어줍니다 
      strokeWeight: 3, // 선의 두께입니다 
      strokeColor: '#00a0e9', // 선의 색깔입니다   
      strokeOpacity: 1, // 선의 불투명도입니다 0에서 1 사이값이며 0에 가까울수록 투명합니다
      strokeStyle: 'solid', // 선의 스타일입니다
      fillColor: '#00a0e9', // 채우기 색깔입니다
      fillOpacity: 0.2 // 채우기 불투명도입니다
    });


  } else { // 다각형이 그려지고 있는 상태이면 

    // 그려지고 있는 다각형의 좌표에 클릭위치를 추가합니다
    // 다각형의 좌표 배열을 얻어옵니다
    var drawingPath = drawingPolygon.getPath();

    // 좌표 배열에 클릭한 위치를 추가하고
    drawingPath.push(clickPosition);

    // 다시 다각형 좌표 배열을 설정합니다
    drawingPolygon.setPath(drawingPath);


    // 그리기가 종료됐을때 지도에 표시할 다각형의 좌표에 클릭 위치를 추가합니다
    // 다각형의 좌표 배열을 얻어옵니다
    var path = polygon.getPath();

    // 좌표 배열에 클릭한 위치를 추가하고
    path.push(clickPosition);

    // 다시 다각형 좌표 배열을 설정합니다
    polygon.setPath(path);
  }

}

// 지도에 마우스무브 이벤트를 등록합니다
// 다각형을 그리고있는 상태에서 마우스무브 이벤트가 발생하면 그려질 다각형의 위치를 동적으로 보여주도록 합니다
window.polygonMousemove = function (mouseEvent) {
  // 지도 마우스무브 이벤트가 발생했는데 다각형을 그리고있는 상태이면
  if (drawingFlag) {

    // 마우스 커서의 현재 위치를 얻어옵니다 
    var mousePosition = mouseEvent.latLng;

    // 그려지고있는 다각형의 좌표배열을 얻어옵니다
    var path = drawingPolygon.getPath();

    // 마우스무브로 추가된 마지막 좌표를 제거합니다
    if (path.length > 1) {
      path.pop();
    }

    // 마우스의 커서 위치를 좌표 배열에 추가합니다
    path.push(mousePosition);

    // 그려지고 있는 다각형의 좌표를 다시 설정합니다
    drawingPolygon.setPath(path);
  }
}

// 지도에 마우스 오른쪽 클릭 이벤트를 등록합니다
// 다각형을 그리고있는 상태에서 마우스 오른쪽 클릭 이벤트가 발생하면 그리기를 종료합니다
window.polygonRightClick = function (mouseEvent) {
  // 지도 오른쪽 클릭 이벤트가 발생했는데 다각형을 그리고있는 상태이면
  if (drawingFlag) {

    // 그려지고있는 다각형을  지도에서 제거합니다
    drawingPolygon.setMap(null);
    drawingPolygon = null;

    // 클릭된 죄표로 그릴 다각형의 좌표배열을 얻어옵니다
    var path = polygon.getPath();

    // 다각형을 구성하는 좌표의 개수가 3개 이상이면 
    if (path.length > 2) {

      // 지도에 다각형을 표시합니다
      polygon.setMap(map);

      var area = Math.round(polygon.getArea()), // 다각형의 총면적을 계산합니다
        content = '<div class="dotOverlay distanceInfo">총면적 <span class="number"> ' + area + '</span> m<sup>2</sup></div>'; // 커스텀오버레이에 추가될 내용입니다

      // 면적정보를 지도에 표시합니다
      areaOverlay = new kakao.maps.CustomOverlay({
        map: map, // 커스텀오버레이를 표시할 지도입니다 
        content: content,  // 커스텀오버레이에 표시할 내용입니다
        xAnchor: 0,
        yAnchor: 0,
        position: path[path.length - 1]  // 커스텀오버레이를 표시할 위치입니다. 위치는 다각형의 마지막 좌표로 설정합니다
      });


    } else {

      // 다각형을 구성하는 좌표가 2개 이하이면 다각형을 지도에 표시하지 않습니다 
      polygon = null;
    }

    // 상태를 false로, 그리지 않고 있는 상태로 변경합니다
    drawingFlag = false;
  }
}

window.removePolygon = function () {
  kakao.maps.event.removeListener(map, 'click', polygonClick);
  kakao.maps.event.removeListener(map, 'mousemove', polygonMousemove);
  kakao.maps.event.removeListener(map, 'rightclick', polygonRightClick);
  if (drawingPolygon) {
    drawingPolygon.setMap(null);
    drawingPolygon = null;
  }
  if (polygon) {
    polygon.setMap(null);
    polygon = null;
  }
  if (areaOverlay != null) {
    areaOverlay.setMap(null);
    areaOverlay = null;
  }
  drawingFlag = false;
}

window.customOverlay = null;
window.tooltipDataObj = {};
window.tooltipDataObj.isMoving = false
window.tooltipDataObj.isClickToolTip = false

window.closeToolTip = function (flag) {
  if (flag == 'map_click' && window.tooltipDataObj.isClickToolTip) {
    window.tooltipDataObj.isClickToolTip = false
    return
  }
  window.tooltipDataObj.isOn = false
  if (window.customOverlay != null) {
    window.customOverlay.setMap(null);
  }
  window.tooltipDataObj.isClickToolTip = false
  if (flag == 'moving') {
    window.tooltipDataObj.isMoving = true;
  }
  if (flag != 'moving') {
    window.tooltipDataObj.data = null;
  }
}

window.makeToolTip = function (data, panel_level) {
  // var iwRemoveable = true; X자 표시 유무
  // 마커를 클릭하면 tooltip을 만들어낸다.
  if (data == undefined) {
    return
  }
  if (window.tooltipDataObj.isMoving) {
    return
  }
  var userAuth = "";



  console.log("tooltip data", data)
  window.tooltipDataObj.data = data
  window.tooltipDataObj.isOn = true
  window.tooltipDataObj.panel_level = panel_level
  var category = data.SL_DATA_1
  var addr = data.SL_ADDR
  var addressNEW = ""
  if (data.ADDRESS_NEW != null) {
    addressNEW = data.ADDRESS_NEW
  }
  var addressOLD = ""
  if (data.ADDRESS_OLD != null) {
    addressOLD = data.ADDRESS_OLD
  }
  // var complainDate = data.SL_NTDATE != null ? data.SL_NTDATE.substr(2,8).replace(/-/gi, '.'):''
  var complainStatus = ""
  if (data.SL_MAINTENANCE == "READY") {
    complainStatus = " (미처리)"
  } else if (data.SL_MAINTENANCE == "INPROGRESS") {
    complainStatus = " (작업중)"
  } else if (data.SL_MAINTENANCE == "DONE") {
    complainStatus = " (처리)"
  }
  var complainInfo = data.SL_NTDATE != null ? data.SL_NTDATE.substr(2, 8).replace(/-/gi, '.') + complainStatus : ''
  var installDate = data.INSTALL_DATE != null ? data.INSTALL_DATE.substr(2, 8).replace(/-/gi, '.') : ''
  API_GET('pcauth')
    .done(function (res) {
      userAuth = res.data.grade.substr(0, 1)

      var content = '<div id = "map-overlaybox" class="map-overlaybox" onmousedown="window.clickToolTip()" style="background-color: rgb(255, 255, 255); border-color: rgb(189, 189, 189);">' +
        '<div class="box-header">' +
        '<div class="box-title">' +
        '<h6>' + data.SL_SLNAME + '</h6>' +
        '<h6 class="close tooltipclose" onclick="closeToolTip()">' + "&times" + '</h6>' +
        //   '<div class="box-name">' +
        //     '<span>' + data.SL_SLNAME + '</span>'+
        //   '</div>' +
        //   '<div class="box-close">' +
        //     '<span class="close" onclick="closeToolTip()">' + "X" + '</span>'+
        //   '</div>'+
        '</div>' +
        '<div class="box-table">' +
        '<table> ' +
        '<tr>' +
        '<th id="light_category" class="box-head left-first-child" style="width:30%";>조명구분</td>' +
        '<td class="left-last-child box-td">' + category + '</td>' +
        '</tr>' +
        '<tr>' +
        '<th id="light_addr" class="box-head">주소</td>' +
        '<td class="box-td">' + addressOLD + '</td>' +
        '</tr>' +
        '<tr>' +
        '<th id="light_indate" class="box-head">최근민원일</td>' +
        '<td class="box-td">' + complainInfo + '</td>' +
        '</tr>' +
        '<tr>' +
        '<th id="light_indate" class="box-head">최초설치일</td>' +
        '<td class="box-td">' + installDate + '</td>' +
        '</tr>' +
        '<tr>' +
        '<th id="light_etc" class="box-head right-first-child last-clear-bottom">메모</td>' +
        '<td class="last-clear-bottom" style="padding:0px;">' +
        '<textarea id="tooltipTextarea" style="border:0px;width:100%;height:100%;resize:none;padding-left: 6px;padding-right: 55px;vertical-align: bottom;">' + data.SL_ETC_2 + '</textarea>' +
        '<button onclick="window.facilitySaveTooltip(' + data.SL_SLCODE + ')" type="button" class="btn btn-outline-primary tooltipSaveBtn"> 저장 </button>' +
        '</td>' +
        '</tr>' +
        '</table>' +
        '</div>'
      if (userAuth == "U") {
        content += '<div class="tab_menu">' +
          '<button onclick="window.facilityComplain(' + data.SL_SLCODE + ',\'' + data.SL_SLNAME + '\')" type="button" class="btn btn-outline-primary"> 고장신고 </button>' +
          '<button onclick="window.facilityDetail()" type="button" class="btn btn-outline-primary"> 상세 </button>' +
          '</div>' +
          '<div id ="overlaybox-pointer" class="overlaybox-pointer"></div>' +
          '<div class="overlaybox-pointerBorder" style="display: none"></div>' +
          '</div>'
      } else {
        content += '<div class="tab_menu">' +
          '<button onclick="window.facilityComplain(' + data.SL_SLCODE + ',\'' + data.SL_SLNAME + '\')" type="button" class="btn btn-outline-primary"> 고장신고 </button>' +
          '<button onclick="window.facilityConfig()" type="button" class="btn btn-outline-primary"> 제어 </button>' +
          '<button onclick="window.facilityDetail()" type="button" class="btn btn-outline-primary"> 상세 </button>' +
          '<button onclick="window.facilityMove()" type="button" class="btn btn-outline-primary"> 이동 </button>' +
          '</div>' +
          '<div id ="overlaybox-pointer" class="overlaybox-pointer"></div>' +
          '<div class="overlaybox-pointerBorder" style="display: none"></div>' +
          '</div>'

      }

      var iwPosition = new kakao.maps.LatLng(data.SL_MAP_Y, data.SL_MAP_X); //인포윈도우 표시 위치입니다
      window.customOverlay = new kakao.maps.CustomOverlay({
        clickable: true,
        position: iwPosition,
        content: content,
        xAnchor: -0.11,
        yAnchor: 0.29
      });
      window.customOverlay.setMap(map);
      window.IscustomOverlay = true
      // NOTE : tooltip z-index 올리는 것
      $("#map-overlaybox").parent().css('z-index', 10)
    });
}

window.installMoveStatus = false
window.installMoveSLCODE = false

window.facilityMove = function () {
  // if(window.installMoveStatus == 'move'){
  //   alert("이동중입니다.")
  //   return;
  // }
  $("#modal_area").addClass("hidden");
  // 이동 버튼 누르면 > 크로스 헤어를 계산해서 마커로 옮기고, 원래 좌표에 드래그 이미지를 덮어씌움
  window.installMoveStatus = 'move'
  closeToolTip('moving')
  console.log(window.tooltipDataObj)
  var point = window.setCoordsFromPoint(
    window.tooltipDataObj.data.SL_MAP_X,
    window.tooltipDataObj.data.SL_MAP_Y,
    window.tooltipDataObj.panel_level
  );
  window.SetPositionLevel(point.getLng(), point.getLat(), 1);
  window.installObj.MAP_X = window.tooltipDataObj.data.SL_MAP_X
  window.installObj.MAP_Y = window.tooltipDataObj.data.SL_MAP_Y
  var img = GetLightImagePath("move", $('#light_type').val());
  var size = GetLightImageSize($('#light_type').val());

  $('#map_add.light_movecontrol *').css('visibility', 'initial')
  var content = '[' + window.tooltipDataObj.data.SL_SLNAME + '] ' + '시설물을 이동중 입니다'
  $('#map_add .info-content').text(content)
  $('#btn_move_cancel').text('이동 취소');
  $('#btn_move_confirm').text('이동 완료');
  AddDragMarker("objIDName", 0, window.tooltipDataObj.data.SL_MAP_X, window.tooltipDataObj.data.SL_MAP_Y, size.width, size.height, img, 'facilityMove');
  window.overlayObjects[window.overlayObjects.length - 1]['data'] = window.tooltipDataObj.data
  let slname = window.tooltipDataObj.data.SL_SLNAME
  let slcode = window.tooltipDataObj.data.SL_SLCODE
  window.installMoveSLCODE = slcode
  changeBgWhenMoving(slcode, true)
}

window.installFlag = false;

window.facilityInstall = function (panel_level) {
  window.installMoveStatus = 'install'
  closeToolTip('moving')
  var point_origin = window.coordsFromPoint();
  var point = window.setCoordsFromPoint(
    point_origin.getLng(), point_origin.getLat(), panel_level
  );
  window.SetPositionLevel(point.getLng(), point.getLat(), 1);
  var img = GetLightImagePath("move", $('#light_type').val());
  var size = GetLightImageSize($('#light_type').val());

  window.installFlag = true;
  $('#map_add.light_movecontrol *').css('visibility', 'initial')
  var content = '시설물을 설치중 입니다'
  $('#map_add .info-content').text(content)
  $('#btn_move_cancel').text('설치 취소');
  $('#btn_move_confirm').text('설치 완료');
  window.installObj.MAP_X = point_origin.getLng()
  window.installObj.MAP_Y = point_origin.getLat()
  AddDragMarker("objIDName", 0, point_origin.getLng(), point_origin.getLat(), size.width, size.height, img, 'facilityInstall');
}

window.changeBgWhenMoving = function (slname, flag) {
  // NOTE : 이동 시 마커 음영 추가해야하는 기능
  let sentence = `span[date-img-value*='${slname}']`
  let span_center = $(sentence);
  let span_left = span_center.siblings()[0]
  let span_right = span_center.siblings()[1]
  span_center = span_center[0]

  let lightSentence = `img[title*='${slname}']`
  // NOTE 장훈 : 이 위에 코드 내가 작성한것 같은데, 이거 지워도 잘 된다.. 뭐지
  if (flag) {
    $(lightSentence).parent().append('<img style="min-width: 0px; min-height: 0px; max-width: 99999px; max-height: none; border: 0px; display: block; position: absolute; user-select: none; -webkit-user-drag: none; clip: rect(0px, 22px, 22px, 0px); top: 0px; left: 0px; width: 22px; height: 22px;" src="' + require("@/assets/img/res/img/light_move_blue.png") + '" >')
    $(span_left).removeClass('left').addClass('left-move');
    $(span_center).removeClass('center').addClass('center-move');
    $(span_right).removeClass('right').addClass('right-move');
  } else {
    $(lightSentence).parent().children().last().remove()
    $(span_left).removeClass('left-move').addClass('left');
    $(span_center).removeClass('center-move').addClass('center');
    $(span_right).removeClass('right-move').addClass('right');
  }

  sentence = `img[title*='${slname}']`
  let marker_img = $(sentence);
  // $(marker_img).css({'background-image':'url("/Users/homekeeper/Desktop/gdnet/gis_vuejs/src/assets/img/res/img/facility_move_blue.png")', 'background-repeat' : 'no-repeat'})
  // $(marker_img).css({'background':'#40d3fd'})
  // $(sentence).parent().css({'background':'#40d3fd'})
}

window.cancelMoving = function (finish_flag) {
  if (window.installFlag) {
    // 설치 중 취소 눌렀을 경우임.
    $('#map_add.light_movecontrol *').css('visibility', 'collapse')
    $("#modal_area").removeClass("hidden");
    if (store.getters.sidebar_content != "") {
      store.commit("panel_class", "")
    }
    window.installFlag = false;
    window.overlayObjects[window.overlayObjects.length - 1]['Object'].setMap(null)
    window.tooltipDataObj.isMoving = false
    let data = window.tooltipDataObj.data
    let panel_level = window.tooltipDataObj.panel_level
    window.makeToolTip(data, panel_level)
    window.installMoveStatus = false;
    window.installMoveSLCODE = false;
    return
  }
  // 이동 취소 버튼 누를 시 마커와 버튼들 삭제하는 함수
  let slname = window.tooltipDataObj.data.SL_SLNAME
  let slcode = window.tooltipDataObj.data.SL_SLCODE
  $('#map_add.light_movecontrol *').css('visibility', 'collapse')
  window.overlayObjects[window.overlayObjects.length - 1]['Object'].setMap(null)
  window.tooltipDataObj.isMoving = false
  if (!finish_flag) {
    let data = window.tooltipDataObj.data
    let panel_level = window.tooltipDataObj.panel_level
    window.makeToolTip(data, panel_level)
    window.changeBgWhenMoving(slcode, false)
  }
  window.installMoveStatus = false;
  window.installMoveSLCODE = false;
}

window.clickToolTip = function () {
  window.tooltipDataObj.isClickToolTip = true
}
window.addDaumZoomListener = function () {
  kakao.maps.event.addListener(map, 'zoom_changed', function () {
    m_zoomlevel = map.getLevel();
    tooltipManager(m_zoomlevel)
    labelManager(m_zoomlevel)
    setMarkerDisplayAsZoomLevel(m_zoomlevel);
  })
};

window.addDaumClickListener = function () {
  kakao.maps.event.addListener(map, 'click', function () {
    if (!window.tooltipDataObj.isOn) {
      return
    }
    closeToolTip('map_click')
  })
}

window.labelManager = function (m_zoomlevel) {
  if (m_zoomlevel >= 4) {
    $('.center').addClass('is-zoomMax')
    $('.right').addClass('is-zoomMax')
    $('.left').addClass('is-zoomMax')
  } else {
    $('.center').removeClass('is-zoomMax')
    $('.right').removeClass('is-zoomMax')
    $('.left').removeClass('is-zoomMax')
  }
}

window.printX = 0;
window.printY = 0;
window.printWidth = 0;
window.printHeight = 0;

window.printMap = function (m_zoomlevel) {
  // 이전 기본 방식. 참고용
  // html2canvas($("#map_wrap"), {
  //   x:100,
  //   y:100,
  //     allowTaint: true,
  //     useCORS: true,
  //     onrendered: function(canvas) {
  //         $("#print_div").empty();
  //         $("#print_div").append(canvas);
  //         window.print();
  //     }
  // });

  if ($('#sidebar').attr("value") != undefined) {
    window.printX = 89;
    window.printWidth = 89;
  } else {
    window.printX = 0;
    window.printWidth = 109;
  }
  if ($('.main-header').attr("value") != undefined) {
    window.printY = 0;
    window.printHeight = 106;
  } else {
    window.printY = 56;
    window.printHeight = 56;
  }

  screenshot($("#map_wrap"), {
    x: printX,
    y: printY,
    width: $("#map_wrap").width() + printWidth,
    height: $("#map_wrap").height() + printHeight,
    allowTaint: true,
    useCORS: true,
  }).then(c => {
    $("#print_div").empty();
    $("#print_div").append(c);
    window.print();
  })
}


window.screenshot = function (element, options = {}) {
  let cropper = document.createElement('canvas').getContext('2d');
  let finalWidth = options.width || window.innerWidth;
  let finalHeight = options.height || window.innerHeight;
  if (options.x) {
    options.width = finalWidth + options.x;
  }
  if (options.y) {
    options.height = finalHeight + options.y;
  }
  return html2canvas(element, options).then(c => {
    cropper.canvas.width = finalWidth;
    cropper.canvas.height = finalHeight;
    cropper.drawImage(c, -(+options.x || 0), -(+options.y || 0));
    return cropper.canvas;
  });
}

window.facilitySaveTooltip = function (slcode) {
  console.log("slcode", slcode)
  console.log("data", $('#tooltipTextarea'))
  API_POST('pc/tooltip/memo', {
    "slcode": slcode,
    "memo": $('#tooltipTextarea').val()
  })
    .done(function (res) {
    })
    .fail(function () {
      console.log("오류 : 메모 저장 실패");
    })
    .always(function () {

    });
}