/* eslint-disable */
$(document).ready(function(){
    /* ***************메인 메뉴 Animation*************** */
    $('.sidebar-menu > li').hover(function(){
        $(this).children('ul').css('display', 'block');
    }, function(){
        $(this).children('ul').css('display', 'none');
    });
    /* ***************메인 메뉴 Animation*************** */

    /* ***************지도 메뉴 버튼 활성화/비활성화*************** */
    $('.map-kind .btn-group button').click(function(){
        var idx = $('.map-kind .btn-group button').index(this);
        
        if(idx === 0){
            $('.map-kind .btn-group button').eq(1).removeClass('on');
            $(this).addClass('on');
        }
        else if(idx === 1){
            $('.map-kind .btn-group button').eq(0).removeClass('on');
            $(this).addClass('on');
        }
        else if(idx === 2 || idx === 3){
            $(this).toggleClass('on');
        }    
    });
    /* ***************지도 메뉴 버튼 활성화/비활성화*************** */

    $('.sidebar-menu > li').click(function(){
        $('.custom-panel').css('display', 'block');
    });
});