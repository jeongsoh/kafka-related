<template lang="pug">
.print_map
  #layout
    map_#map_wrap.map_wrap(:class="this.$store.getters.roadviewMap == 'roadview'? 'map_sub' : ''")
</template>
<script>
import Map from "@/vue/Map";

export default {
  components: {
    map_: Map
  }
};
</script>
<style>
@import url(//fonts.googleapis.com/earlyaccess/notosanskr.css);

html,
body,
#layout,
#layout > * {
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
  font-family: "Noto Sans KR", sans-serif !important;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
  height: 100%;
  width: 100%;
}

#app,
.print_map,
.print_map #layout,
.print_map #map_wrap {
  width: 100%;
  height: 100%;
}
</style>
