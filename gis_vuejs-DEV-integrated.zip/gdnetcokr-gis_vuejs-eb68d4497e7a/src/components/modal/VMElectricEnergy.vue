<template lang="pug">
.modal-alert-background.vm-energy
  .modal-content.sub-modal-position
    .modal-header
      vm-alert(ref="alert" @event="alertEvent")
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-on:clickClose="onClickClose" v-bind:subTitle="subTitle")
    .now-message(v-if="loaded && nowloaded")
      span 오늘 기준일 {{nowMessage.baseToday}} | 어제 기준일 {{nowMessage.baseYesterday}}
      br
      span 최대(최소) 산정기간 {{nowMessage.baseMaxDay}} ~ 오늘
    .monthly-select(v-if="barloaded")
      .item-td(tabindex="-1")
        .dropdown
          .dropdown__header(@click="toggleDropdown($event)")
            span#visible_light_type_temp(:value="monthType") {{selectMonthRange[monthType]}}
            i.fas.fa-chevron-down
            i.fas.fa-chevron-up
          .dropdown__content
            ul
              li(@click="selectMonth(key)" v-for="value, key in selectMonthRange") {{value}}
    .modal-body
      LineChart(v-if="loaded" :chartdata="datacollection" :options="options")
      BarChart(v-if="barloaded" :chartdata="datacollection" :options="options")
    .modal-footer
      VMFooter(v-if="loaded || barloaded" :boxtype="boxtype")
    transition(name='modal' v-if="false")
      .modal-background
        .modal-position
          .loader
          br
          | 데이터를 불러오는 중입니다
          br
          | 잠시만 기다려주세요
</template>

<script>
/*
  TODO :: 현재 전력량 그래프의 기준과 선을 연결할지 어디서 끊는지 등의 조건이 애매하므로 그에 대한 회의가 필요
          지금의 전력량은 보기가 어려움.. 개선을 한다면 지금의 전력량을 수정하는게 아닌 아예 처음부터 만드는걸 추천함. 
 */
import Vue from "vue";
import { EventBus } from "@/main";

import LineChart from "@/components/modal/VMLineChart";
import BarChart from "@/components/modal/VMBarChart";
import VMFooter from "@/components/modal/VMFooter";

export default {
  components: {
    LineChart,
    VMFooter,
    BarChart
  },
  name: "vmelectricenergy",
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    },
    energyDataObj: {
      type: Object
    }
  },
  data() {
    return {
      key: "{0}:{1}LightAddr".format(this.id, this.type),
      isComponents: "",
      header: {
        icon: "",
        title: "",
        menu: [],
        exitBtn: true,
        tab: "",
        choiceTab: ""
      },
      subTitle: "",
      graphType: "",
      loaded: false,
      barloaded: false,
      nowloaded: false,
      monthType: "0",
      nowMessage: {
        baseToday: "",
        baseYesterday: "",
        baseMaxDay: ""
      },
      selectMonthRange: {
        "0": "2019",
        "-1": "2018",
        "-2": "2017",
        "-3": "2016"
      },
      reqData: {
        now: {
          slcode: "",
          year: new Date().getFullYear(),
          month: new Date().getMonth() + 1,
          day: new Date().getDate(),
          hours: new Date().getHours()
        },
        daily: {
          slcode: "",
          date: new Date().toISOString(),
          month: new Date().getMonth() + 1
        },
        monthly: {
          slcode: "",
          date: new Date().toISOString(),
          month: new Date().getMonth() + 1
        }
      },
      boxtype: "",
      LineChartNowConfig: {
        axis: [
          "T15",
          "T16",
          "T17",
          "T18",
          "T19",
          "T20",
          "T21",
          "T22",
          "T23",
          "T00",
          "T01",
          "T02",
          "T03",
          "T04",
          "T05",
          "T06",
          "T07",
          "T08",
          "T09"
        ],
        colors: ["#ff4560", "#feb019", "#008ffb", "#00e396"], // 최대 최소 어제 오늘 순서
        legends: ["최대", "최소", "어제", "오늘"],
        options: {
          scales: {
            yAxes: [
              {
                ticks: {
                  callback: function(value, index, values) {
                    return value.toFixed(1) + " W";
                  }
                }
              }
            ]
          },
          legend: {
            display: false
          }
        }
      },
      LineChartDailyConfig: {
        axis: [],
        colors: ["", "", "#008ffb", "#00e396"], // 지난달 추정, 지난달 실제, 이번잘 추정, 이번달 실제
        legends: ["추정", "실제"],
        options: {
          scales: {
            yAxes: [
              {
                ticks: {
                  callback: function(value, index, values) {
                    return value / 1000 + " KW";
                  }
                }
              }
            ],
            xAxes: [
              {
                ticks: {
                  // max: 31,
                  // min: 1,
                  // stepSize: 1
                  autoSkip: false
                }
              }
            ]
          },
          legend: {
            display: false
          }
        }
      },
      BarChartMonthConfig: {
        axis: [
          "1월",
          "2월",
          "3월",
          "4월",
          "5월",
          "6월",
          "7월",
          "8월",
          "9월",
          "10월",
          "11월",
          "12월"
        ],
        colors: ["", "", "#008ffb", "#00e396"], // 지난달 추정, 지난달 실제, 이번잘 추정, 이번달 실제
        legends: ["", "", "추정", "실제"],
        options: {
          scales: {
            yAxes: [
              {
                ticks: {
                  callback: function(value, index, values) {
                    return value / 1000 + " KW";
                  }
                }
              }
            ],
            xAxes: [
              {
                ticks: {
                  autoSkip: false
                }
              }
            ]
          },
          legend: {
            display: false
          }
        }
      },
      LineDataSet: [],
      baseDataSet: {
        label: "Data One",
        borderWidth: 1,
        data: "",
        fill: false, // 그래프 아래 음영
        pointRadius: 0 // 그래프 상에 포인트 radius 사이즈
      },
      datacollection: {
        labels: [],
        datasets: []
      },
      options: {}
    };
  },
  computed: {
    monthDateChecker: function() {
      return this.reqData.monthly.date;
    }
  },
  methods: {
    selectMonth(key) {
      this.monthType = key;
      this.clickDropDown();
      this.reqData.monthly.date = new Date(
        this.selectMonthRange[key]
      ).toISOString();
      this.getGraphMonthily();
    },
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown() {
      $(".monthly-select .dropdown__header").removeClass("is-active");
    },
    onClickClose(key) {
      this.loaded = false;
      this.nowloaded = false;
      this.barloaded = false;
      this.$emit("clickAddrClose");
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    async changeTitleWithModalType() {
      return new Promise(resolve => {
        let modaltype = this.energyDataObj.dataType;
        this.graphType = modaltype;
        if (modaltype == "now") {
          this.header.title = "현재 전력량";
        } else if (modaltype == "daily") {
          this.header.title = "일별 전력량";
        } else {
          this.header.title = "월별 전력량";
        }
        resolve(true);
      });
    },
    async changeFooterBoxes() {
      var vm = this;
      return new Promise(resolve => {
        let modaltype = this.energyDataObj.dataType;
        if (modaltype == "now") {
          this.boxtype = modaltype;
        } else if (modaltype == "daily") {
          this.header.title = "일별 전력량";
        } else {
          this.header.title = "월별 전력량";
        }
        resolve(true);
      });
    },
    alertIfNoData(content) {
      this.$refs.alert.init("black", null, content, null, null, true, false);
    },
    getGraphMonthily() {
      // NOTE 월별 전력량 , 예상치의 경우 실제값 + 해야하므로 중간에 json_index == 2로 비교하는 부분 있음 수정해야함
      var vm = this;
      this.reqData[this.graphType]["slcode"] = this.energyDataObj.slcode;
      // NOTE test용도
      // this.reqData[this.graphType]['slcode'] = '483103300000693'
      vm.LineDataSet = [];
      this.$_API_GET(
        "facility/accumulateyear",
        this.reqData[this.graphType]
      ).then(function(res) {
        vm.datacollection["labels"] = vm.BarChartMonthConfig.axis;
        let json_index = 0;
        if (JSON.stringify(res) == "{}") {
          vm.alertIfNoData("해당년도 데이터가 존재하지 않습니다.");
          for (var index = 0; index < 2; index++) {
            let accData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            let temp_baseSet = JSON.parse(JSON.stringify(vm.baseDataSet));
            temp_baseSet.label = vm.BarChartMonthConfig.legends[index + 2];
            temp_baseSet.backgroundColor =
              vm.BarChartMonthConfig.colors[index + 2];
            temp_baseSet.hoverBackgroundColor =
              vm.BarChartMonthConfig.colors[index + 2];
            temp_baseSet.data = accData;
            vm.LineDataSet.push(temp_baseSet);
          }
          vm.datacollection.datasets = vm.LineDataSet;
          vm.options = vm.BarChartMonthConfig.options;
          vm.barloaded = true;
          return;
        } else {
          for (var key in res) {
            let temp_baseSet = JSON.parse(JSON.stringify(vm.baseDataSet));
            let accData = res[key].slice(1, 13);
            if (json_index < 2) {
              json_index++;
              continue;
            } else if (json_index == 2) {
              for (var index in accData) {
                accData[index] += res["STORE_VAL"].slice(1, 13)[index];
              }
            }
            temp_baseSet.label = vm.BarChartMonthConfig.legends[json_index];
            temp_baseSet.backgroundColor =
              vm.BarChartMonthConfig.colors[json_index];
            temp_baseSet.hoverBackgroundColor =
              vm.BarChartMonthConfig.colors[json_index];
            temp_baseSet.data = accData;
            vm.LineDataSet.push(temp_baseSet);
            json_index++;
          }
          vm.datacollection.datasets = vm.LineDataSet;
          vm.options = vm.BarChartMonthConfig.options;
          vm.barloaded = true;
          return;
        }
      });
    },
    getGraphDaily() {
      var vm = this;
      this.reqData[this.graphType]["slcode"] = this.energyDataObj.slcode;
      // NOTE test용도
      // this.reqData[this.graphType]['slcode'] = '483103300000693'
      this.$_API_GET("facility/accumulate", this.reqData[this.graphType]).then(
        function(res) {
          let day = Number(new Date().getDate());
          if (JSON.stringify(res) == "{}") {
            vm.alertIfNoData("데이터가 존재하지 않습니다.");
          }
          console.log("일별 전력량", res);
          let temp_baseSet = JSON.parse(JSON.stringify(vm.baseDataSet));
          for (var i = 1; i < day + 2; i++) {
            vm.LineChartDailyConfig.axis.push(i);
          }
          vm.datacollection["labels"] = vm.LineChartDailyConfig.axis;
          let json_index = 0;
          for (var key in res) {
            if (json_index < 2) {
              json_index++;
              continue;
            }
            let accData = res[key];
            temp_baseSet.borderColor =
              vm.LineChartDailyConfig.colors[json_index];
            temp_baseSet.data = accData;
            vm.LineDataSet.push(temp_baseSet);
            json_index++;
          }
          vm.datacollection.datasets = vm.LineDataSet;
          vm.options = vm.BarChartMonthConfig.options;
          vm.loaded = true;
        }
      );
    },
    async getGraphNow() {
      return new Promise(resolve => {
        var vm = this;
        this.reqData[this.graphType]["slcode"] = this.energyDataObj.slcode;
        // NOTE test용도
        // this.reqData[this.graphType]['slcode'] = '483103300000693'
        this.$_API_GET("facility/hist", this.reqData[this.graphType]).then(
          function(res) {
            if (res.res[0][0] == null) {
              vm.alertIfNoData("데이터가 존재하지 않습니다.");
            }
            vm.datacollection["labels"] = vm.LineChartNowConfig.axis;
            res.res.forEach(function(accData, index, array) {
              let temp_baseSet = JSON.parse(JSON.stringify(vm.baseDataSet));
              temp_baseSet.label = vm.LineChartNowConfig.legends[index];
              temp_baseSet.borderColor = vm.LineChartNowConfig.colors[index];
              temp_baseSet.data = accData;
              vm.LineDataSet.push(temp_baseSet);
            });
            vm.datacollection.datasets = vm.LineDataSet;
            vm.options = vm.LineChartNowConfig.options;
            vm.loaded = true;
            vm.nowloaded = true;
          }
        );
        resolve(true);
      });
    },
    getGraphData() {
      if (this.graphType == "now") {
        this.getGraphNow();
      } else if (this.graphType == "daily") {
        this.getGraphDaily();
      } else if (this.graphType == "monthly") {
        this.getGraphMonthily();
      }
    },
    calcNowMessage() {
      var today = new Date();
      var temp_today = getFormatDate(today);
      today.setDate(today.getDate() + 1);
      var tommorow = getFormatDate(today);
      today.setDate(today.getDate() - 2);
      var yesterday = getFormatDate(today);
      today.setDate(today.getDate() - 14);
      var max_min = getFormatDate(today);
      this.nowMessage.baseToday = temp_today.replace("/", ".");
      this.nowMessage.baseYesterday = yesterday.replace("/", ".");
      this.nowMessage.baseMaxDay = max_min.replace("/", ".");
    }
  },
  created() {},
  async mounted() {
    await this.changeTitleWithModalType();
    await this.changeFooterBoxes();
    await this.getGraphData();
    this.calcNowMessage();
  },
  updated() {}
};
</script>
<style>
.th-item,
.td-item {
  text-align: center;
}
.input-padding {
  padding: 0px;
}
.tb-textarea {
  border: 0px;
  width: 100%;
  height: 150px;
}
.search-addr {
  border: 1.2px solid rgba(195, 195, 195, 0.3);
}
</style>
<style>
.vm-energy .modal-content .modal-header .modal-alert-background .modal-content {
  min-width: 300px;
}
.now-message {
  font-size: 12px;
  margin: 0px 0px 10px 20px;
  font-family: "Noto Sans KR", sans-serif !important;
}
</style>
<style>
/*드랍다운 css*/
.monthly-select {
  margin-left: 10px;
  min-width: 50px;
}
</style>
<style lang="scss">
// NOTE :: DropDown CSS
.monthly-select {
  & .dropdown {
    width: 70px;
    &__header {
      outline: none !important;
      position: absolute;
      top: -30px;
      left: 80px;
      border: 1px solid;
      border-radius: 10px;
      background: #fff;
      font-size: 12px;
      cursor: pointer;
      line-height: 25px;
      position: relative;
      text-overflow: ellipsis;
      width: 100%;
      height: 25px;
      i.fas {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 10px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &.is-active {
        outline: -webkit-focus-ring-color auto 1px;
        outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          top: -5px;
          left: 80px;
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
          background: #fff;
        }
      }
      & span {
        padding-left: 7px;
        display: table-cell;
        vertical-align: middle;
        line-height: 22px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #eee;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #484848;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>

<style>
.vm-energy .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
}

.vm-energy .tab_menu > button.modal-remove-btn {
  float: left;
}
.vm-energy .tab_menu button:hover {
  background: #016aae;
}
.vm-energy .tab_menu button.modal-remove-btn {
  background: rgb(181, 181, 181);
}
.vm-energy .tab_menu button.modal-remove-btn:hover {
  background: #a0a0a0;
}
.vm-energy .modal-position {
  font-size: 12px;
  height: 121px;
}
</style>
<style>
.modal-alert-background.vm-energy .modal-footer {
  margin: 0px;
  padding: 0px 10px 0px 0px;
  border-top: none;
}
.modal-alert-background.vm-energy .modal-body {
  padding: 0px 12px 0px 12px;
}
</style>
