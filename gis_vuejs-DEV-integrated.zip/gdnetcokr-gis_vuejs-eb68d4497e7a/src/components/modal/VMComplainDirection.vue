<template lang="pug">
.modal-complain-direction.vm-complain-direction
  .modal-body(style="padding:0px 12px 7px 12px")
    .complain-direction-main-area
      .left-main-area
        table(:class="!(!modifyDirection && dataCheck) ? 'table-modify' : ''")
          colgroup
            col(style="width:33%")
            col(style="width:66%")
          tr.tr-item
            th.th-item.left-first-child(:class="modifyDirectionMode()") &nbsp;&nbsp; 작업 지시 일자
            td.td-item.input-padding
              date-range-picker.left-last-child(:singleDatePicker="true" :ranges="false" :startDate="startDate" :endDate="endDate" @update="updateDatepicker" :locale-data="locale" :opens="openPosition" autoApply v-model="dataRange" style="width:100%; height:100%;" :show-dropdowns="true")
          tr.tr-item
            th.th-item(:class="modifyDirectionMode()") &nbsp;&nbsp; 유지보수 업체
            td.td-item.table-select-full-th(tabindex="-1")
              .dropdown
                .dropdown__header(@click="toggleDropdown($event)" :class="modifyDirectionMode()")
                  span {{req.grade}}
                  i.fas.fa-chevron-down
                  i.fas.fa-chevron-up
                .dropdown__content
                  ul
                    li(@click="clickDropDown('grade', value)" v-for="value in authList" :class="dropdownChoice(value, req.grade)") {{value}}
                      .search-division-line
          tr.tr-item
            th.th-item.complain-vertical-align.right-first-child(:class="modifyDirectionMode()") &nbsp;&nbsp; 지시 내용
            td.td-item.input-padding.complain-handle-td.last-clear-bottom
              textarea.focus-set.complain-handle-textarea.right-last-child(row='6' v-model="req.comment" :disabled="!modifyDirection && dataCheck")
        .tab_menu
          button.modal-cancel-btn(type="button" class="btn btn-outline-primary" @click="onClickClose(key)" v-if="modifyDirection && dataCheck") 취소
          button.modal-remove-btn(type="button" class="btn btn-outline-primary" @click="directionDelete = true" v-if="!modifyDirection && dataCheck") 작업지시 삭제
          button(type="button" class="btn btn-outline-primary" @click="modifyDirection = true" v-if="!modifyDirection && dataCheck") 수정
          button.modal-modify-btn(type="button" class="btn btn-outline-primary" @click="onClickDirection()" v-if="modifyDirection && dataCheck") 저장
          button.modal-modify-btn(type="button" class="btn btn-outline-primary" @click="onClickDirection()" v-if="!dataCheck") 작업 지시
          button.modal-modify-btn(type="button" class="btn btn-outline-primary" @click="onClickClose(key)" v-if="!dataCheck") 취소
      .right-main-area
        table
          colgroup
            col(style="width:33%")
            col(style="width:66%")
          tr.tr-item
            th.th-item.left-first-child &nbsp;&nbsp; 지시 일자
            td.item-td
              input.left-last-child(type="text" v-model="handling.SL_DRDATE" :disabled="true" )
          tr.tr-item
            th.th-item &nbsp;&nbsp; 지시 업체
            td.item-td
              input(type="text" v-model="handling.SL_ASSIGNED_ID" :disabled="true" )
          tr.tr-item
            th.th-item.right-first-child &nbsp;&nbsp; 지시 내용
            td.item-td.last-clear-bottom
              input.right-last-child(type="text" v-model="handling.SL_DRWORK" :disabled="true" )
        table.table-top-margin
          colgroup
            col(style="width:33%")
            col(style="width:66%")
          tr.tr-item
            th.th-item.left-first-child &nbsp;&nbsp; 보수 일자
            td.item-td
              input.left-last-child(type="text" v-model="handling.SL_DODATE" :disabled="true" )
          tr.tr-item
            th.th-item &nbsp;&nbsp; 보수 업체
            td.item-td
              input(type="text" v-model="handling.SL_DO_ASSIGNED" :disabled="true" )
          tr.tr-item
            th.th-item &nbsp;&nbsp; 보수 종류
            td.item-td
              input(type="text" v-model="handling.SL_WORKTYPE" :disabled="true" )
          tr.tr-item
            th.th-item.right-first-child &nbsp;&nbsp; 보수 내용
            td.item-td.last-clear-bottom
              input.right-last-child(type="text" v-model="handling.SL_WORK" :disabled="true" )
        .jaje-list-area
          table(style="border:0px;")
            tr
              th.th-item.left-first-child.td-center 분류
              th.th-item.td-center 자재명
              th.th-item.td-center 수량
              th.th-item.left-last-child.td-center 날짜
            tr(v-for="jaje in jajeList" v-if="jajeList != undefined || jajeList.length != 0" v-show="jaje.jaje!=undefined")
              td.td-center(style="width:40px")
                span {{jaje.jaje != undefined ? jaje.jaje.SL_JJ_TYPE == "I"?"입고":"출고":""}}
              td.td-center
                span {{jaje.code != undefined ? jaje.code.SL_JJ_NAME:""}}
              td.td-center
                span {{jaje.jaje != undefined ? jaje.jaje.SL_JJ_COUNT:""}}
              td.td-center
                span {{datepickerFormatter(jaje.jaje != undefined ? jaje.jaje.SL_JJ_DATE:"")}}
            tr(v-if="jajeList == undefined || jajeList.length == 0")
              td.td-center(colspan=4) 자재 이력이 없습니다.
  transition(name='modal' v-if="retry")
    .modal-background
      .modal-position
        | 일시적으로 데이터를 불러오지 못했습니다
        br
        | 다시 시도해주세요
        br
        button.spinner-btn(@click="getPcdirectionAPI") 다시 시도
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
  transition(name='modal' v-if="directionDelete")
    .modal-background
      .modal-position
        | [ {{SL_SLNAME}} ] 작업지시 내역을 삭제하시겠습니까?
        br
        | 삭제하시려면 해당 민원의 시설물 이름을 입력해주세요
        br
        | (작업지시 내역을 삭제하면 미처리 상태로 변경됩니다)
        br
        input.remove-input(type="text" v-model="removeName")
        br
        button.spinner-btn.spinner-left(@click="directionDelete = false") 취소
        button.spinner-btn.spinner-right(@click="onClickDirectionRemove") 확인
  vm-alert(ref="alert" @event="alertEvent")
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
import DateRangePicker from "vue2-daterange-picker";

export default {
  components: { DateRangePicker },
  props: {
    id: {
      type: String, // Number
      required: false
    },
    type: {
      type: String,
      requied: false
    },
    list: {
      type: Array,
      requied: false
    },
    basicModify: {
      type: Boolean,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "민원 처리",
        menu: [],
        exitBtn: true,
        tab: ["작업지시", "유지보수"],
        choiceTab: "작업지시"
      },
      req: {
        direction_date: "",
        grade: "",
        comment: "",
        SL_NT_NO: ""
      },
      SL_SLNAME: "",
      dataRange: {
        startDate: new Date(),
        endDate: new Date()
      },
      startDate: new Date(),
      endDate: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      retry: false,
      modifyDirection: false,
      dataCheck: false,
      tabChoice: "",
      loadData: false,
      authList: [],
      directionDelete: false,
      removeName: "",
      jajeList: [],
      handling: {
        SL_DRDATE: "",
        SL_ASSIGNED_ID: "",
        SL_DRWORK: "",
        SL_DODATE: "",
        SL_DO_ASSIGNED: "",
        SL_WORKTYPE: "",
        SL_WORK: ""
      }
    };
  },
  watch: {
    modifyDirection: function(val) {
      if (val) {
        $(".vm-complain-direction .form-control").css("pointer-events", "auto");
        $(".vm-complain-direction .form-control")
          .children()
          .css("pointer-events", "auto");
        $(".vm-complain-direction .dropdown__header").css(
          "pointer-events",
          "auto"
        );
        $(".vm-complain-direction .dropdown__header")
          .children()
          .css("pointer-events", "auto");
      } else {
        $(".vm-complain-direction .form-control").css("pointer-events", "none");
        $(".vm-complain-direction .form-control")
          .children()
          .css("pointer-events", "none");
        $(".vm-complain-direction .dropdown__header").css(
          "pointer-events",
          "none"
        );
        $(".vm-complain-direction .dropdown__header")
          .children()
          .css("pointer-events", "none");
      }
    },
    "dataRange.endDate": function(val) {
      console.log(val >= new Date());
      if (val >= new Date()) {
        this.$refs.alert.init(
          "black",
          null,
          "지시 일자는 최대 당일까지 선택이 가능합니다.",
          null,
          null,
          true,
          false
        );
        this.dataRange.startDate = new Date();
        this.dataRange.endDate = new Date();
      }
    }
  },
  computed: {
    openPosition() {
      if (this.$store.getters.panel_location_name == "right") {
        return "left";
      } else {
        return "right";
      }
    }
  },
  methods: {
    getComplainName() {
      // NOTE :: 민원 정보 가져옴
      var vm = this;
      this.$_API_GET("pc/complain/name", { SL_NT_NO: this.id }).then(function(
        items
      ) {
        console.log("complainname", items);
        vm.SL_SLNAME = items.info.SL_SLNAME;
        vm.handling.SL_DRDATE = items.info.SL_DRDATE;
        vm.handling.SL_ASSIGNED_ID = items.info.SL_ASSIGNED_ID;
        vm.handling.SL_DRWORK = items.info.SL_DRWORK;
        vm.handling.SL_DODATE = items.info.SL_DODATE;
        vm.handling.SL_DO_ASSIGNED = items.info.SL_DO_ASSIGNED;
        vm.handling.SL_WORKTYPE = items.info.SL_WORKTYPE;
        vm.handling.SL_WORK = items.info.SL_WORK;
        vm.jajeList = items.jaje;
        window.jajeList = vm.jajeList;
      });
    },
    modifyBackground() {
      if (!(!this.modifyDirection && this.dataCheck)) {
        return "background-padding-left";
      } else {
        return "background-none";
      }
    },
    modifyDirectionMode() {
      if (!(!this.modifyDirection && this.dataCheck)) {
        return "complain-modify-mode";
      } else {
        return "";
      }
    },
    onClickDirectionRemove() {
      if (this.SL_SLNAME == this.removeName) {
        var data = {
          SL_NT_NO: this.id
        };
        this.postPcRemoveDirectionAPI(data);
      } else {
        this.directionDelete = false;
        this.$refs.alert.init(
          "black",
          null,
          "민원의 시설물 이름이 맞지 않습니다",
          null,
          null,
          true,
          false
        );
      }
    },
    getModifyStatusClose() {
      return !(!this.modifyDirection && this.dataCheck);
    },
    getModifyStatus() {
      return this.modifyDirection;
    },
    onClickClose(key) {
      this.$emit("clickClose");
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    updateDatepicker(value) {},
    onClickDirection() {
      // NOTE :: 입력 데이터 검증
      if (this.req.grade == "") {
        this.$refs.alert.init(
          "black",
          null,
          "유지보수 업체를 선택해주세요",
          null,
          null,
          true,
          false
        );
        return;
      }
      this.req.direction_date = this.datepickerFormatter(
        this.dataRange.startDate
      );
      this.req.SL_NT_NO = this.id;
      this.postPcdirectionAPI(this.req);
      // this.onClickClose(this.key);
    },
    postPcdirectionAPI(data) {
      // NOTE :: 민원 작업 지시
      var vm = this;
      this.$_API_POST("pcdirection", data).then(function(res) {
        // vm.$refs.alert.init(
        //   "black",
        //   null,
        //   "작업 지시가 완료되었습니다.",
        //   null,
        //   null,
        //   true,
        //   false
        // );
        EventBus.$emit("searchComplaint");
        EventBus.$emit(vm.id + "setComplainInfo", vm.id);
        vm.onClickClose();
      });
    },
    postPcRemoveDirectionAPI(data) {
      // NOTE :: 민원 작업 지시 취소
      var vm = this;
      this.$_API_POST("pc/remove/direction", data).then(function(res) {
        // vm.$refs.alert.init(
        //   "black",
        //   null,
        //   "작업 지시가 삭제되었습니다.",
        //   null,
        //   null,
        //   true,
        //   false
        // );
        EventBus.$emit("searchComplaint");
        EventBus.$emit(vm.id + "setComplainInfo", vm.id);
        vm.onClickClose();
      });
    },
    getPcdirectionAPI() {
      // NOTE :: 민원 지시 정보 가져옴
      this.req.SL_NT_NO = this.id;
      var vm = this;
      this.$_API_GET("pcdirection", this.req)
        .then(function(res) {
          console.log("getpcdirection", res);
          if (res.SL_DRDATE != null) {
            vm.req.grade = res.SL_ASSIGNED_ID;
            vm.req.comment = res.SL_DRWORK;
            vm.startDate = new Date(res.SL_DRDATE);
            vm.retry = false;
            vm.dataCheck = true;
          }
          vm.loadData = false;
        })
        .catch(() => {
          vm.retry = true;
        });
    },
    showModifyCaution(value) {
      this.$refs.alert.init(
        "white",
        null,
        "수정 중 이동할 경우 수정한 내용들이 사라질 수 있습니다",
        "수정을 취소하고 다른 작업을 진행하시겠습니까?",
        null,
        "caution",
        true
      );
      this.tabChoice = value;
    },
    cancelBtn() {
      this.modifyDirection = false;
      this.initComplainDirection();
    },
    moveTab() {
      this.$refs.alert.close();
      this.modifyDirection = false;
      this.initComplainDirection();
      this.$emit("clickTab", this.tabChoice);
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        // console.log("pcauth", res);
        vm.authList.push(res.grade_MAN);

        if (res.grade.substring(0, 1) != "U") {
          for (var value in res.grade_list) {
            console.log("value", value);
            if (value != "contains") {
              vm.authList.push(res.grade_list[value]);
            }
          }
        }
      });
    },
    initComplainDirection() {
      this.loadData = true;
      this.getPcauthAPI();
      this.getPcdirectionAPI();
      this.getComplainName();
    },
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      this.req[type] = data;
      $(".vm-complain-direction .dropdown__header").removeClass("is-active");
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    alertEvent(key, inputData) {
      switch (key) {
        case "caution":
          this.moveTab();
          break;
        case "closeModal":
          this.onClickClose();
          break;
      }
    },
    closeEvent() {
      this.$refs.alert.init(
        "white",
        null,
        "수정 중인 내용들이 사라질 수 있습니다",
        "수정을 취소하고 종료를 진행하시겠습니까?",
        null,
        "closeModal",
        true
      );
    }
  },
  mounted() {
    console.log("direction!!!!!!!!!!!!!!", this.list);
    console.log("direction!!!!!!!!!!!!!!", this.id);
    this.initComplainDirection();
    var vm = this;
    Vue.nextTick(function() {
      $(".vm-complain-direction .td-item").focusout(function(e) {
        $(".vm-complain-direction .dropdown__header").removeClass("is-active");
      });
      setTimeout(function() {
        $(".vm-complain-direction .focus-set").focus();
      }, 0);
    });
  }
};
</script>

<style>
.complain-handle-textarea {
  resize: none;
}
</style>
<style>
.form-control {
  border: 0px;
}
.vm-complain-direction {
  height: 100%;
}
.vm-complain-direction .form-control {
  border-radius: 0 10px 0 0;
}
.complain-direction-main-area {
  display: flex;
}
.complain-direction-main-area .left-main-area,
.complain-direction-main-area .right-main-area {
  flex: 1;
}
.complain-direction-main-area .right-main-area {
  max-width: 271px;
}
</style>

<style lang="scss">
.vm-complain-direction {
  & * {
    font-size: 12px;
  }
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    &:not(:first-child) {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        // min-width: 92px;
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.complain-modify-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px !important;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0;
      -webkit-border-radius: 10px 0 0 0;
      border-radius: 10px 0 0 0;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0 0;
      -webkit-border-radius: 0 10px 0 0;
      border-radius: 0 10px 0 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>

<style lang="scss">
// NOTE :: DropDown CSS
.vm-complain-direction {
  & .dropdown {
    width: 100%;
    &__header {
      background: #fff;
      font-size: 12px;
      cursor: pointer;
      line-height: 20px;
      position: relative;
      text-overflow: ellipsis;
      color: #000;
      width: 100%;
      height: 21px;
      i.fas {
        position: absolute;
        right: 4px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 10px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &.is-active {
        outline: -webkit-focus-ring-color auto 1px;
        outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
        }
      }
      & span {
        padding-left: 7px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #fff;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #000;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>
