<template lang="pug">
.modal-alert-background.vm-alert(v-show="isAlert" :class="alertType == 'white' ? 'alert-white':''")
  .modal-alert
    .modal-content(:class="alertType == 'white' ? 'alert-white':''")
      .modal-body
        .modal-header(v-show="header.isHeader")
          VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn" v-on:clickClose="close")
        .alert-modal-body()
          .modal-text(v-for="data, index in body" :class="!header.isHeader && index == 0 ? 'first-body-margin-top': ''")
            span(v-if="data.type == 'text'") {{data.content}}
            input.input-box(v-else-if="data.type == 'input'" v-model="inputData[data.key]" :placeholder="data.placeholder")
          .alert-tab_menu
            button.spinner-btn(type="button" v-for="data in button" @click="onClickClose(data.event)") {{data.name}}
</template>

<script>
import Vue from "vue";

export default {
  data() {
    return {
      alertType: "white",
      isAlert: false,
      header: {
        isHeader: true,
        title: "",
        icon: "",
        menu: [],
        exitBtn: true
      },
      inputData: {},
      body: [
        { type: "text", content: "에러 : 관리자에게 문의 바랍니다." }
        // input sample
        // { type: "input", key: "keyValue", placeholder: "" },
      ],
      button: [{ name: "확인", event: "close" }]
    };
  },
  methods: {
    onClickClose(key) {
      if (key == "close") {
        this.close();
      } else {
        this.$emit("event", key, this.inputData);
      }
    },
    init(alertType, header, body, button) {
      // NOTE :: inputData default값이 없으므로 추가하려면 여기서 진행해야 함.
      console.log("alertType", alertType);
      if (alertType != undefined) {
        this.alertType = alertType;
      }
      if (header != undefined) {
        this.header = this.deepCopy(header);
      }
      if (body != undefined) {
        this.body = this.deepCopy(body);
      }
      if (button != undefined) {
        this.button = this.deepCopy(button);
      }
    },
    open() {
      this.isAlert = true;
    },
    close() {
      this.isAlert = false;
    }
  },
  created() {},
  mounted() {
    // 다른곳에서 사용 방법
    // vm.$refs.alert.init(
    //   "black",
    //   null,
    //   [
    //     { type: "text", content: "텍스트 테스트 1" },
    //     { type: "input", key: "removeName", placeholder: "플레이스 홀더" },
    //     { type: "text", content: "텍스트 테스트 3" }
    //   ],
    //   [
    //     { name: "취소", event: "close" },
    //     { name: "확인", event: "ok" }
    //   ]
    // );
    // vm.$refs.alert.open();
  },
  updated() {}
};
</script>

<style>
.vm-alert {
  z-index: 3000;
}
.vm-alert .modal-text {
  text-align: center;
  font-size: 12px;
}
.vm-alert .alert-tab_menu {
  width: 100%;
  text-align: center;
  margin-top: 12px;
}
.vm-alert .alert-tab_menu button {
  font-size: 12px;
  outline: none;
  margin-left: 4px;
  margin-right: 4px;
}
.vm-alert .alert-modal-body {
  padding: 10px;
}

.vm-alert .input-box {
  margin-top: 5px;
  margin-bottom: 5px;
  border: 1px solid rgb(25, 128, 223);
  border-radius: 5px;
  text-align: center;
  outline: none;
}
.vm-alert .first-body-margin-top {
  margin-top: 12px;
}
.vm-alert.alert-white {
  background: rgba(255, 255, 255, 0.95);
}
.modal-content.alert-white {
  border: 0px;
  box-shadow: none;
  background: none;
}
</style>
