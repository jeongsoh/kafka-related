<template lang="pug">
.modal-light.vm-light
  .modal-content(:id="key")
    .modal-header
      VMHeader(:id="id" v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key", v-bind:tab="header.tab", v-bind:choiceTab="header.choiceTab", v-on:clickTab="onClickTab" v-bind:subTitle="subTitle")
    VM-light-addr(:id="id" :type="type" :key="key" v-if="modalLightAddr" v-on:clickAddrClose="onClickAddrClose" v-on:changeTitle="onChangeTitle")
    VM-light-info(:id="id" :type="type" :auth="auth" v-show="handleTable == 'VMLightInfo'" ref="lightInfo" , v-on:clickTab="onClickTab", v-on:clickAddr="onClickAddr" v-on:changeTitle="onChangeTitle" v-on:clickQRcode="onClickQRcode")
    VM-light-config(:id="id" :type="type" :auth="auth" v-show="handleTable == 'VMLightConfig'" ref="lightConfig" , v-on:clickTab="onClickTab" v-on:changeTitle="onChangeTitle"  v-on:clickElectricEnergy="onClickElectricEnergy")
    vm-light-qrcode(:id="id" :type="type" :qrcode="qrcode" :slname="slname" :serial="serial" :key="key" v-if="modalLightQRCode" v-on:clickAddrClose="onClickAddrClose" v-on:changeTitle="onChangeTitle")
    vm-electric-energy(:id="id" :type="type" :content="content" :key="key" v-if="modalElectricEnergy" v-on:clickAddrClose="onClickAddrClose" v-on:changeTitle="onChangeTitle" :energyDataObj = "energyDataObj")
//-   component(:is="handleTable" :id="id" :type="type" :auth="auth")

</template>

<script>
// NOTE :: 시설물 모달 부모 Component
import Vue from "vue";
import { EventBus } from "@/main";
import DateRangePicker from "vue2-daterange-picker";
import VMLightInfo from "@/components/modal/VMLightInfo";
import VMLightConfig from "@/components/modal/VMLightConfig";
import VMLightAddr from "@/components/modal/VMLightAddr";
import VMLightQRCode from "@/components/modal/VMLightQRCode";
import VMElectricEnergy from "@/components/modal/VMElectricEnergy";

export default {
  components: {
    "VM-light-info": VMLightInfo,
    "VM-light-config": VMLightConfig,
    "VM-light-addr": VMLightAddr,
    "vm-light-qrcode": VMLightQRCode,
    "vm-electric-energy": VMElectricEnergy
  },
  props: {
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "",
        menu: [],
        exitBtn: true,
        tab: ["상세", "제어"],
        choiceTab: "상세"
      },
      lightUpdtedAt: 0,
      auth: false,
      modalLightAddr: false,
      subTitle: "",
      modalLightQRCode: false,
      modalElectricEnergy: false,
      qrcode: "1",
      slname: "",
      serial: "",
      content: [],
      energyDataObj: ""
    };
  },
  computed: {
    handleTable() {
      //   this.$refs.lightInfo.initLightInfo();
      if ("상세" == this.header.choiceTab) {
        return "VMLightInfo";
      } else if ("제어" == this.header.choiceTab) {
        return "VMLightConfig";
      } else {
        return "";
      }
    }
  },
  methods: {
    onClickAddrClose() {
      this.modalLightAddr = false;
      this.modalLightQRCode = false;
      this.modalElectricEnergy = false;
    },
    onClickAddr() {
      console.log("asdf");
      this.modalLightAddr = true;
    },
    onClickQRcode(val, name, serial) {
      console.log("qrcode click", val);
      console.log("qrcode click", name);
      this.qrcode = val;
      this.slname = name;
      this.serial = serial;
      this.modalLightQRCode = true;
    },
    onClickElectricEnergy(datafromchild) {
      this.energyDataObj = datafromchild;
      this.modalElectricEnergy = true;
    },
    onClickTab(value) {
      // NOTE :: 탭 이동에 따른 처리
      console.log("lightInfo", this.$refs.lightInfo.getModifyStatus());
      console.log(
        "onClickTab",
        ">>>>>>>>> go to",
        value,
        "from ",
        this.header.choiceTab,
        ">?>?>?>?>?>",
        this.$refs.lightInfo.getModifyStatus()
      );
      if (this.header.choiceTab == "상세") {
        if (this.$refs.lightInfo.getModifyStatus()) {
          this.$refs.lightInfo.showModifyCaution(value);
        } else {
          if (value == "제어") {
            this.$refs.lightConfig.initLightConfig();
          }
          console.log("제어 choicetab");
          this.header.choiceTab = value;
        }
      } else if (this.header.choiceTab == "제어") {
        if (this.$refs.lightConfig.getModifyStatus()) {
          this.$refs.lightConfig.showModifyCaution(value);
        } else {
          if (value == "상세") {
            this.$refs.lightConfig.clearInterval();
            this.$refs.lightInfo.initLightInfo();
          }
          this.header.choiceTab = value;
        }
      }
      console.log("now choicetab", this.header.choiceTab);
    },
    getLightHeader() {
      // NOTE :: Title에 들어갈 시설물 이름 처리
      var vm = this;
      this.$_API_GET("facility", {
        latitude: window.coordsFromPoint().getLat(),
        longitute: window.coordsFromPoint().getLng(),
        light_type: -1,
        lasttime: this.lightUpdtedAt
      }).then(function(res) {
        console.log("getLightHeader1", res);
        for (var value in res.light) {
          if (res.light[value].SL_SLCODE == vm.id) {
            var markerImg = GetLightImagePath2(
              res.light[value],
              res.light_time
            );
            vm.header.icon = (
              markerImg.split(".")[0] +
              "." +
              markerImg.split(".")[2]
            ).split("/")[2];
            vm.header.title = res.light[value].SL_SLNAME;
          }
        }
      });
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        if (res.grade.substring(0, 1) == "U") {
          vm.auth = false;
          vm.header.tab = ["상세"];
          vm.header.choiceTab = "상세";
        } else {
          vm.auth = true;
          vm.getPcQrcode();
        }
      });
    },
    getPcQrcode() {
      var vm = this;
      this.$_API_GET("pc/qrcode", { SL_SLCODE: this.id }).then(function(res) {
        console.log("getPcQrcode", res);
        if (res.GD_SERIAL == null && res.GD_SERIAL_2 == null) {
          vm.header.tab = ["상세", "제어"];
        } else {
          vm.header.tab = ["상세", "제어"];
        }
        // vm.header.choiceTab = "상세";
      });
    },
    onChangeTitle(val) {
      this.subTitle = val;
    }
  },
  created() {},
  mounted() {
    // $(".modal").modal({
    //   backdrop: false
    // });
    // $(".modal-content").draggable({
    //   handle: ".modal-header, .modal-body",
    //   containment: "#modal_area"
    // });
    var vm = this;
    EventBus.$on("getLightHeader" + this.id, function() {
      vm.getLightHeader();
    });
    this.getLightHeader();

    EventBus.$on("getHeaderQRcode" + this.id, function() {
      vm.getPcauthAPI();
    });
    this.getPcauthAPI();
    EventBus.$on("modalOpenParam" + this.id, function(
      slcode,
      modalname,
      dataParam
    ) {
      console.log("I am eventbut", slcode, modalname, dataParam["choiceTab"]);
      // vm.header.choiceTab = dataParam["choiceTab"];
      console.log("I am eventbut", vm.header.choiceTab);
      Vue.nextTick(function() {
        vm.onClickTab(dataParam["choiceTab"]);
      });
    });
  },
  beforeDestroy() {
    EventBus.$off("getLightHeader" + this.id);
    EventBus.$off("getHeaderQRcode" + this.id);
    EventBus.$off("modalOpenParam" + this.id);
  }
};
</script>

<style>
.vm-light .modal-content {
  min-width: 520px; /* NOTE: dialog에 따라 width 사이즈 다르게 설정 */
}
.th-item,
.td-item {
  text-align: center;
}
.input-padding {
  padding: 0px;
}
.tb-select {
  border: 0px;
  width: 100%;
  height: 100%;
  text-align-last: center;
}
.complain-handle-textarea {
  border: 0px;
  width: 100%;
  height: 100px;
}
.complain-vertical-align {
  vertical-align: middle;
}
</style>
