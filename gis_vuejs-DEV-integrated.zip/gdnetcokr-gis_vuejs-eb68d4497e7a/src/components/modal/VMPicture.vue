<template lang="pug">
.modal-alert-background.vm-picture
  .main-area
    .picture-header
      span.picture-title {{pictureTitle}}
      span.picture-exit(@click="onClickChoice") &times;
    .picture-content
      .owl-carousel.owl-theme
        .item(v-for="val in pictureData")
          .owl-content
            img.owl-item-img(:src="val")
    .picture-footer
      span.picture-date {{pictureDateInfo[pictureIndex]}}
      button.picture-remove(@click="removePicture = true") 해당 사진 삭제
  transition(name='modal' v-if="removePicture")
    .modal-background
      .modal-position
        br
        | 이미지를 삭제하시겠습니까?
        br
        br
        button.spinner-btn.spinner-left(@click="removePicture = false") 취소
        button.spinner-btn.spinner-right(@click="onClickPictureRemove") 삭제
    //- .modal-alert
    //-   .modal-content
    //-     .modal-body
    //-       .alert-modal-body
    //-         .alert-tab_menu
    //-           button.spinner-btn(type="button" @click="onClickChoice") 1확인
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
export default {
  props: {
    pictureID: {
      type: String,
      requied: false
    },
    pictureIndexFirst: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      pictureData: [],
      pictureTitle: "",
      pictureDateInfo: [],
      pictureIndex: 0,
      pictureSLCODE: [],
      pictureNameInfo: [],
      removePicture: false,
      initCheck: true
    };
  },
  computed: {
    a: () => {
      return $(".vm-picture .carousel__item.carousel__item--active")
        .eq(1)
        .attr("data-index");
    }
  },
  watch: {
    a: newVal => {
      console.log(`Oh! :`, newVal);
    }
  },
  methods: {
    onClickChoice() {
      this.$emit("exitAlert");
      EventBus.$emit(this.pictureID + "reloadImage");
    },
    getLightImage() {
      // NOTE :: 이미지 정보 가져오기
      console.log("getLightImagegetLightImagegetLightImage");
      var vm = this;
      this.$_API_GET("pc/facility/info", {
        slcode: this.pictureID
      })
        .then(function(res) {
          vm.pictureIndex = 0;
          $(".vm-picture .owl-carousel").trigger("destroy.owl.carousel");
          vm.pictureData = [];
          vm.pictureTitle = res.light["SL_SLNAME"];
          vm.pictureDateInfo = [];
          vm.pictureSLCODE = [];
          vm.pictureNameInfo = [];
          for (var val in [1, 2, 3, 4, 5, 6]) {
            if (val != 0 && val != "contains") {
              if (res.light["PIC_0" + val] != null) {
                if (process.env.VUE_APP_DEBUG == "true") {
                  vm.pictureData.push(
                    "https://s3.ap-northeast-2.amazonaws.com/" +
                      process.env.VUE_APP_S3_PATH +
                      "/" +
                      process.env.VUE_APP_S3_DB +
                      "/" +
                      res.light["SL_SLCODE"] +
                      "_" +
                      res.light["PIC_0" + val] +
                      ".jpg"
                  );
                } else {
                  vm.pictureData.push(
                    "https://s3.ap-northeast-2.amazonaws.com/" +
                      vm.$store.getters.config_s3_path +
                      "/" +
                      vm.$store.getters.config_s3_base +
                      "/" +
                      res.light["SL_SLCODE"] +
                      "_" +
                      res.light["PIC_0" + val] +
                      ".jpg"
                  );
                }
                vm.pictureDateInfo.push(
                  res.light["PIC_0" + val].substr(0, 4) +
                    "-" +
                    res.light["PIC_0" + val].substr(4, 2) +
                    "-" +
                    res.light["PIC_0" + val].substr(6, 2)
                );
                vm.pictureSLCODE.push(res.light["SL_SLCODE"]);
                vm.pictureNameInfo.push(res.light["PIC_0" + val]);
              }
            }
          }
          console.log("pictureData", vm.pictureData);
        })
        .catch(function() {})
        .finally(() => {});
    },
    onClickPictureRemove() {
      // NOTE :: 이미지 삭제
      var vm = this;
      this.$_API_POST("imagedelete", {
        slcode: this.pictureSLCODE[this.pictureIndex],
        image_nameinfo: this.pictureNameInfo[this.pictureIndex]
      })
        .then(function(res) {
          vm.removePicture = false;
          vm.getLightImage();
        })
        .finally(() => {
          if (vm.pictureData.length == 1) {
            vm.onClickChoice();
          }
        });
    },
    initPicture() {
      this.getLightImage();
    }
  },
  created() {},
  mounted() {
    console.log("pictureIndex", this.pictureIndexFirst);
    var vm = this;
    this.initPicture();
    $(".vm-picture .owl-carousel").trigger("destroy.owl.carousel");

    $(".vm-picture .owl-carousel").on("changed.owl.carousel", function(event) {
      console.log("owl change", event.page.index);
      if (event.page.index != -1) {
        vm.pictureIndex = event.page.index;
      }
    });
  },
  updated() {
    // $(".vm-picture .owl-carousel").trigger("refresh.owl.carousel");
    $(".vm-picture .owl-carousel").owlCarousel({
      items: 1,
      loop: true,
      nav: true,
      navText: [
        "<img class='owl-page-before' src=" +
          require("@/assets/img/res/img/page-before.png") +
          ">",
        "<img class='owl-page-after' src=" +
          require("@/assets/img/res/img/page-after.png") +
          ">"
      ]
    });
    if (this.initCheck) {
      $(".vm-picture .owl-carousel").trigger("to.owl.carousel", [
        this.pictureIndexFirst,
        0
      ]);
      this.initCheck = false;
    }
  }
};
</script>

<style>
.vm-picture {
  z-index: 2900;
}
.vm-picture .picture-header {
  background: rgba(0, 0, 0, 0.5);
  flex: 1;
}
.vm-picture .picture-header span {
  color: #fff;
}
.vm-picture .picture-header .picture-title {
  font-size: 14px;
  position: absolute;
  top: 18px;
  left: 20px;
}
.vm-picture .picture-header .picture-exit {
  font-size: 30px;
  position: absolute;
  top: 5px;
  right: 20px;
  cursor: pointer;
}
.vm-picture .picture-content {
  background: rgba(0, 0, 0, 0.5);
  flex: 13;
  height: 100%;
  overflow-y: auto;
}
.vm-picture .main-area {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
}
.vm-picture .picture-content .owl-carousel,
.vm-picture .picture-content .owl-stage-outer,
.vm-picture .picture-content .owl-stage,
.vm-picture .picture-content .owl-item,
.vm-picture .picture-content .owl-content {
  height: 100%;
  width: 100%;
}
.vm-picture .picture-content .owl-content {
  display: flex;
  justify-content: center;
  align-items: center;
}
.vm-picture .picture-content .owl-carousel .owl-prev {
  position: absolute;
  top: 47%;
  left: 15px;
  width: 30px;
  height: 30px;
  outline: none !important;
}
.vm-picture .picture-content .owl-carousel .owl-next {
  position: absolute;
  top: 47%;
  right: 15px;
  width: 30px;
  height: 30px;
  outline: none !important;
}
.vm-picture .picture-content .owl-carousel .owl-prev .owl-page-before,
.vm-picture .picture-content .owl-carousel .owl-next .owl-page-after {
  width: 15px;
  height: 30px;
}
.vm-picture .picture-content .item {
  height: 100%;
  width: 100%;
}
.vm-picture .picture-content .owl-item-img {
  height: 90%;
  width: auto;
}
.vm-picture .picture-footer {
  background: rgba(0, 0, 0, 0.5);
  flex: 1;
}
.vm-picture .picture-footer .picture-date {
  font-size: 14px;
  position: absolute;
  bottom: 20px;
  left: 20px;
  color: #fff;
}
.vm-picture .picture-footer .picture-remove {
  outline: none !important;
  background: #b5b5b5;
  color: #fff;
  position: absolute;
  bottom: 15px;
  border-radius: 10px;
  padding: 5px 10px 5px 10px;
  font-size: 14px;
  left: 45.5%;
}
.vm-picture .picture-footer .picture-remove:hover {
  background: #a0a0a0;
}
.vm-picture .example-slide {
  align-items: center;
  background-color: #666;
  color: #999;
  width: 50%;
}

.vm-picture .modal-background {
  position: absolute;
  height: 100%;
  width: 100%;
  display: table;
  background: rgba(0, 0, 0, 0.3);
  z-index: 9999;
  bottom: 0px;
  border-radius: 10px;
}
.vm-picture .modal-position {
  position: absolute;
  display: table;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  color: black;
  background: #fff;
  width: 200px;
  height: 113px;
  border-radius: 10px;
  font-size: 12px;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
  text-align: center;
}
</style>
