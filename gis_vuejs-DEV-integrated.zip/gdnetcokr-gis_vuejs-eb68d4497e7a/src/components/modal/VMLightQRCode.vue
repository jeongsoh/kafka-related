<template lang="pug">
.modal-alert-background.vm-light-qrcode
  .modal-content.sub-modal-position
    .modal-header
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-on:clickClose="onClickClose"  v-bind:subTitle="subTitle")
    .modal-body
      table.search-addr.table-modify
        colgroup
          col(style="width:40%")
          col(style="width:60%")
        tr.tr-item
          th.td-item.table-select-full-th.left-first-child(colspan=1) &nbsp;&nbsp;QR Code{{qrcode}}
          td.td-item.table-select-full-th.left-last-child(colspan=1) 
            input.left-last-child.focus-set(v-model="req.setting.GD_SERIAL")
      .tab_menu
        button.modal-modify-btn(type="button" class="btn btn-outline-primary" @click="onClickLightRegister") 개통
        button.modal-cancel-btn(type="button" class="btn btn-outline-primary" @click="onClickClose(key)") 취소
    transition(name='modal' v-if="false")
      .modal-background
        .modal-position
          .loader
          br
          | 데이터를 불러오는 중입니다
          br
          | 잠시만 기다려주세요
    transition(name='modal' v-if="modalAlert")
      .modal-background
        .modal-position
          .loader
          br
          | {{alertText}}
    transition(name='modal' v-if="errAlert")
      .modal-background
        .modal-position
          | 개통 오류
          br
          button.spinner-btn(@click="errAlert = false") 확인
    transition(name='modal' v-if="successAlert")
      .modal-background
        .modal-position
          | 개통 완료
          br
          button.spinner-btn(@click="successAlert = false") 확인
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
export default {
  name: "vmlightqrcode",
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    },
    qrcode: {
      type: String,
      requied: false
    },
    slname: {
      type: String,
      requied: false
    },
    serial: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}LightAddr".format(this.id, this.type),
      header: {
        icon: "",
        title: "{0} - QR Code".format(this.slname),
        menu: [],
        exitBtn: true
      },
      res: {},
      req: {
        SL_DATA_1: "01",
        setting: {
          SPECIAL_TITLE: "미설정",
          OFF_FROM_DAY: "01",
          OFF_FROM_HOUR: "00",
          OFF_FROM_MIN: "00",
          OFF_FROM_MONTH: "01",
          OFF_FROM_YEAR: "2019",
          OFF_TO_DAY: "31",
          OFF_TO_HOUR: "23",
          OFF_TO_MIN: "59",
          OFF_TO_MONTH: "12",
          OFF_TO_YEAR: "2019",
          ON_DEVIATION: "-30",
          OFF_DEVIATION: "15",
          DIM_VALUE: "0",
          ENABLE_SMPS_SENSOR: "0",
          GD_SERIAL: this.serial,
          light_val: ""
        },
        ON_Hour: 20,
        ON_Min: 15,
        OFF_Hour: 4,
        OFF_Min: 45
      },
      loadData: false,
      subTitle: "작성중",
      modalAlert: false,
      errAlert: false,
      successAlert: false,
      control_resource_id: null,
      control_expire_time: null,
      CONTROL_EXPIRE_DURATION: 60000,
      CONTROL_RESET_EXPIRE_DURATION: 60000,
      repeat: "",
      updated_at: 0,
      settingProcess: false,
      alertText: ""
    };
  },
  computed: {
    addrSub() {
      if (this.res[this.req.addr1] == null) {
        return "거제";
      } else {
        return this.res[this.req.addr1];
      }
    }
  },
  methods: {
    onClickClose(key) {
      this.$emit("clickAddrClose");
    },
    onClickLightChoice(key) {
      EventBus.$emit(
        this.id + "addr",
        this.req.addr1 + " " + this.req.addr2 + " " + this.req.addr2
      );
      this.$emit("clickAddrClose");
    },
    GetFacilityInfoAPI() {
      var vm = this;
      this.$_API_GET("postcode", {}, 24 * 7)
        .then(function(res) {
          console.log("GetFacilityInfoAPI", res);
          for (var key in res) {
            // console.log(key.split(":")[0]);
            for (var value in res[key]) {
              //   console.log(value.split(":")[0]);
              if (key != "SIDOSGG_CD") {
                vm.res[key.split(":")[0]] = value.split(":")[0];
              }
            }
          }
          vm.loadData = false;
          console.log("vm.res", vm.res);
        })
        .then(() => {
          vm.$forceUpdate();
        })
        .catch(function() {
          vm.modalAlert = false;
          vm.errAlert = true;
        });
    },
    onClickLightRegister() {
      // NOTE :: QRCode 개통 작업
      console.log("GD_SERIAL", this.req.setting.GD_SERIAL);
      if (this.req.setting.GD_SERIAL == "") {
        // 시리얼 없을 경우 처리
      } else {
        this.modalAlert = true;
        this.alertText = "기기에 설정 값을 저장 중입니다.. (통신망 요청 중)";
        this.req.setting.QRCODE = this.qrcode;
        this.req.setting.GD_SERIAL_2 = this.req.setting.GD_SERIAL;
        this.settingProcess = true;
        var vm = this;

        console.log("onClickLightRegister", this.req.setting);
        this.$_API_POST("pcfacilitysetting", this.req.setting)
          .then(function(res) {
            console.log("개통 pcfacilitysetting", res);
            vm.alertText =
              "기기에 설정 값을 저장 중입니다.. (통신망 전달 완료)";
            vm.control_resource_id = res.data.special_setting[0].mgc.exin[0].ri;
            vm.control_expire_time = Date.now() + vm.CONTROL_EXPIRE_DURATION;
          })
          .catch(function(err) {
            console.log("개통 오류");
            vm.modalAlert = false;
            vm.errAlert = true;
            // vm.modalAlert = false;
          });
      }
    },
    getLightInfo() {
      // NOTE :: 시설물 세팅값 가져오기
      var vm = this;
      this.$_API_GET("pc/facility/info", {
        slcode: this.id
      })
        .then(function(res) {
          console.log("config", res);
          if (res.special_setting != null) {
            vm.req.setting = res.special_setting;
            vm.req.setting.ENABLE_SMPS_SENSOR = res.light.ENABLE_SMPS_SENSOR;
          }
          if (res.light.GD_SERIAL != null) {
            vm.GD_SERIAL = res.light.GD_SERIAL;
          }
          if (res.light.GD_SERIAL_2 != null) {
            vm.GD_SERIAL_2 = res.light.GD_SERIAL_2;
          }
          // vm.req.setting.GD_SERIAL = vm.GD_SERIAL;
          vm.req.setting.SL_DATA_1 = res.light.SL_DATA_1;
          vm.req.setting.SL_SLCODE = vm.id;
          vm.req.ON_Hour = res.light_time.ON_Hour;
          vm.req.ON_Min = res.light_time.ON_Min;
          vm.req.OFF_Hour = res.light_time.OFF_Hour;
          vm.req.OFF_Min = res.light_time.OFF_Min;

          if (res.special_setting != null) {
            vm.req.setting = res.special_setting;
          } else {
            vm.req.setting.SPECIAL_TITLE = "미설정";
            vm.req.setting.OFF_FROM_DAY = "01";
            vm.req.setting.OFF_FROM_HOUR = "00";
            vm.req.setting.OFF_FROM_MIN = "00";
            vm.req.setting.OFF_FROM_MONTH = "01";
            vm.req.setting.OFF_FROM_YEAR = "2019";
            vm.req.setting.OFF_TO_DAY = "31";
            vm.req.setting.OFF_TO_HOUR = "23";
            vm.req.setting.OFF_TO_MIN = "59";
            vm.req.setting.OFF_TO_MONTH = "12";
            vm.req.setting.OFF_TO_YEAR = "2019";
            if (vm.$store.getters.config_on_deviation != undefined) {
              vm.req.setting.ON_DEVIATION = vm.$store.getters.config_on_deviation;
            } else {
              vm.req.setting.ON_DEVIATION = "-30";
            }
            if (vm.$store.getters.config_off_deviation != undefined) {
              vm.req.setting.OFF_DEVIATION = vm.$store.getters.config_off_deviation;
            } else {
              vm.req.setting.OFF_DEVIATION = "15";
            }
            vm.req.setting.DIM_VALUE = "0";
            vm.req.setting.ENABLE_SMPS_SENSOR = "0";
            // vm.req.setting.GD_SERIAL = "";
            vm.req.setting.light_val = "";
          }
          vm.loadData = false;
        })
        .catch(function() {});
    },
    getLightStatus() {
      var requestData = {
        slcode: this.id,
        updated_at: this.updated_at,
        today: new Date().toDateString(),
        device: this.qrcode
      };
      // console.log("requestData, ", requestData);
      if (this.req.setting.GD_SERIAL != "") {
        requestData.GD_SERIAL = this.req.setting.GD_SERIAL;
      }
      // console.log("requestData", requestData);
      var requestUrl = "facility/status";
      if (this.control_resource_id != null) {
        requestUrl = "teststatus";
        requestData = {
          resource_id: this.control_resource_id
        };
      }
      // console.log("requestUrl", requestUrl);
      var vm = this;
      this.$_API_GET(requestUrl, requestData).then(function(res) {
        vm.modalCheck = true;
        if (vm.statusUpdatesIn > Date.now()) {
          return;
        }
        vm.statusUpdatesIn = Date.now() + 3000;
        if (vm.control_resource_id != null) {
          if (res.success == false) {
            vm.control_resource_id = null;
            vm.modalAlert = false;
            vm.errAlert = true;
          } else if (vm.control_expire_time < Date.now()) {
            vm.control_resource_id = null;
            vm.settingProcess = false;
            vm.modalAlert = false;
            vm.errAlert = true;
          } else if (res.received_at != null) {
            vm.control_resource_id = null;
            vm.statusUpdatesIn = Date.now();
            vm.modalAlert = false;
            vm.successAlert = true;
            if (res.received_at)
              if (vm.settingProcess) {
                // $("#modal-info").modal("hide");
                vm.settingProcess = false;
                vm.invalidateLight = true;
              } else {
                // if (vm.control_type == "syncsetting") {
                // }
              }
          } else if (res.delivered_at != null) {
            if (vm.settingProcess) {
              vm.alertText =
                "기기에 설정 값을 저장 중입니다.. (단말기 전달 완료)";
            } else {
              vm.alertText = "제어 요청 중입니다.. (단말기 전달 완료)";
            }
          }
        }
      });
    }
  },
  created() {},
  mounted() {
    console.log("this.id", this.id);
    console.log("this.serial", this.serial);
    console.log("this.slname", this.slname);
    this.loadData = true;
    // this.GetFacilityInfoAPI();
    setTimeout(function() {
      $(".vm-light-qrcode .focus-set").focus();
    }, 0);
    this.getLightInfo();
    this.repeat = setInterval(() => {
      this.getLightStatus();
      // console.log("vm.error", this.error);
    }, 1000);
  },
  updated() {
    console.log("updated base modal");
  },
  beforeDestroy() {
    clearInterval(this.repeat);
  }
};
</script>

<style>
.th-item,
.td-item {
  text-align: center;
}
.input-padding {
  padding: 0px;
}
.tb-textarea {
  border: 0px;
  width: 100%;
  height: 150px;
}
.search-addr {
  border: 1.2px solid rgba(195, 195, 195, 0.3);
}
</style>
<style>
.vm-light-qrcode .modal-content {
  min-width: 300px !important;
  width: 300px;
}
</style>

<style lang="scss">
.vm-light-qrcode {
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    & * {
      font-size: 12px;
    }
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.modify-light-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 10px;
      -webkit-border-radius: 10px 0 0 10px;
      border-radius: 10px 0 0 10px;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 10px 0;
      -webkit-border-radius: 0 10px 10px 0;
      border-radius: 0 10px 10px 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>

<style>
.vm-light-qrcode .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
}

.vm-light-qrcode .tab_menu > button.modal-remove-btn {
  float: left;
}
.vm-light-qrcode .tab_menu button:hover {
  background: #016aae;
}
.vm-light-qrcode .tab_menu button.modal-remove-btn {
  background: rgb(181, 181, 181);
}
.vm-light-qrcode .tab_menu button.modal-remove-btn:hover {
  background: #a0a0a0;
}
.vm-light-qrcode .modal-position {
  font-size: 12px;
  height: 121px;
}
</style>
