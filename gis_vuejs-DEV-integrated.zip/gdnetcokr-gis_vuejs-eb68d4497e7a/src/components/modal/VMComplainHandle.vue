<template lang="pug">
.vm-complain-handle.modal-alert-background
  .modal-content.sub-modal-position(:id="key")
    .modal-header
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key", v-on:clickTab="onClickTab" v-on:clickClose="onClickCloseHeader" v-bind:subTitle="subTitle")
    //- component(:is="handleTable" :id="id" :type="type", :list="list")
    VM-complain-direction(:id="id" :type="type" v-show="handleTable == 'VMComplainDirection'" ref="direction" , v-on:clickTab="onClickTab" v-on:clickClose="onClickClose")
    VM-complain-change-direction(:id="id" :type="type" v-show="handleTable == 'VMComplainChangeDirection'" ref="changeDirection" , v-on:clickTab="onClickTab" v-on:clickClose="onClickClose" v-on:changeTitle="onChangeTitle")
    VM-complain-re-direction(:id="id" :type="type" v-show="handleTable == 'VMComplainReDirection'" ref="reDirection" , v-on:clickTab="onClickTab" v-on:clickClose="onClickClose" v-on:changeTitle="onChangeTitle")
    VM-complain-maintenance(:id="id" :type="type" v-show="handleTable == 'VMComplainMaintenance'" ref="maintenance" , v-on:clickTab="onClickTab" v-on:clickClose="onClickClose")
    VM-complain-re-maintenance(:id="id" :type="type" v-show="handleTable == 'VMComplainReMaintenance'" ref="reMaintenance" , v-on:clickTab="onClickTab" v-on:clickClose="onClickClose")
    
</template>

<script>
// NOTE :: 패널에 사용되는 민원 유지보수 관련 component의 부모
import Vue from "vue";
import { EventBus } from "@/main";
import DateRangePicker from "vue2-daterange-picker";
import VMComplainDirection from "@/components/modal/VMComplainDirection";
import VMComplainChangeDirection from "@/components/modal/VMComplainChangeDirection";
import VMComplainReDirection from "@/components/modal/VMComplainReDirection";
import VMComplainMaintenance from "@/components/modal/VMComplainMaintenance";
import VMComplainReMaintenance from "@/components/modal/VMComplainReMaintenance";

export default {
  components: {
    VMComplainDirection,
    VMComplainChangeDirection,
    VMComplainReDirection,
    VMComplainMaintenance,
    VMComplainReMaintenance
  },
  props: {
    id: {
      type: String, // Number
      required: false
    },
    type: {
      type: String,
      requied: false
    },
    showComponent: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}ComaplinHandle".format(this.id, this.type),
      header: {
        icon: "",
        title: "민원 처리",
        menu: [],
        exitBtn: true,
        tab: ["작업지시", "유지보수"],
        choiceTab: "작업지시"
      },
      req: {
        SL_SLNAME: "",
        user_addr: "",
        writer: "",
        repoter: "",
        phone: "",
        reply: "NONE",
        content: "미점등",
        comment: "",
        relocation: false,
        SL_NT_NO: ""
      },
      list: [],
      subTitle: "",
      mainComponent: ""
    };
  },
  watch: {
    mainComponent: function(val) {
      this.getPcauthAPI();
      this.getComplainName();
    }
  },
  computed: {
    handleTable() {
      // if (this.header.tab[0] == this.header.choiceTab) {
      //   return "VMComplainDirection";
      // } else if (this.header.tab[1] == this.header.choiceTab) {
      //   return "VMComplainMaintenance";
      // } else {
      //   return "VMComplainDirection";
      // }
      return this.mainComponent;
    }
  },
  methods: {
    onClickCloseHeader() {
      if (this.mainComponent == "VMComplainDirection") {
        if (!this.$refs.direction.getModifyStatusClose()) {
          this.onClickClose();
        } else {
          this.$refs.direction.closeEvent();
        }
      } else if (this.mainComponent == "VMComplainChangeDirection") {
        if (!this.$refs.changeDirection.getModifyStatusClose()) {
          this.onClickClose();
        } else {
          this.$refs.changeDirection.closeEvent();
        }
      } else if (this.mainComponent == "VMComplainMaintenance") {
        if (!this.$refs.maintenance.getModifyStatusClose()) {
          this.onClickClose();
        } else {
          this.$refs.maintenance.closeEvent();
        }
      } else if (this.mainComponent == "VMComplainReDirection") {
        if (!this.$refs.reDirection.getModifyStatusClose()) {
          this.onClickClose();
        } else {
          this.$refs.reDirection.closeEvent();
        }
      } else if (this.mainComponent == "VMComplainReMaintenance") {
        if (!this.$refs.reMaintenance.getModifyStatusClose()) {
          this.onClickClose();
        } else {
          this.$refs.reMaintenance.closeEvent();
        }
      }
    },
    onClickClose() {
      console.log(this.$emit);
      this.$emit("clickHandleClose");
      console.log("key", this.key.indexOf("VMComplainInfo"));
      if (this.key.indexOf("VMComplainInfo") == -1) {
        this.$store.commit(
          "modal_close",
          this.key.replace("ComaplinHandle", "")
        );
      }
    },
    onClickTab(value) {
      if (this.header.choiceTab == "작업지시") {
        if (this.$refs.direction.getModifyStatus()) {
          this.$refs.direction.showModifyCaution(value);
        } else {
          if (value == "유지보수") {
            this.$refs.maintenance.initComplainCmaintenance();
          }
          this.header.choiceTab = value;
        }
      } else if (this.header.choiceTab == "유지보수") {
        if (this.$refs.maintenance.getModifyStatus()) {
          this.$refs.maintenance.showModifyCaution(value);
        } else {
          if (value == "작업지시") {
            this.$refs.direction.initComplainDirection();
          }
          this.header.choiceTab = value;
        }
      }
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        // console.log("pcauth", res);
        if (res.grade.substring(0, 1) == "U") {
          // vm.header.tab = ["유지보수"];
          // vm.header.choiceTab = "유지보수";
        } else {
          vm.list = res.grade_list;
          console.log(vm.list);
        }
      });
    },
    getComplainName() {
      var vm = this;
      this.$_API_GET("pc/complain/name", { SL_NT_NO: this.id }).then(function(
        res
      ) {
        if (vm.mainComponent == "VMComplainDirection") {
          vm.header.title = "작업 지시";
          vm.subTitle = "작성중";
        } else if (vm.mainComponent == "VMComplainMaintenance") {
          vm.header.title = "작업 처리";
          vm.subTitle = "작성중";
        } else if (vm.mainComponent == "VMComplainChangeDirection") {
          vm.header.title = "작업 지시";
          vm.subTitle = "작성중";
        } else if (vm.mainComponent == "VMComplainReDirection") {
          vm.header.title = "재작업 지시";
          vm.subTitle = "작성중";
        } else if (vm.mainComponent == "VMComplainReMaintenance") {
          vm.header.title = "재작업 처리";
          vm.subTitle = "작성중";
        }
        if (res.info.SL_SLNAME != "") {
          vm.header.title += " - " + res.info.SL_SLNAME;
        } else {
          vm.header.title += " - " + res.info.SL_USR_ADDR;
        }
        console.log("getComplainName", res);
      });
    },
    onChangeTitle(val) {
      if (val) {
        this.subTitle = "작성중";
      } else {
        this.subTitle = "";
      }
    }
  },
  created() {},
  updated() {},
  mounted() {
    this.mainComponent = this.showComponent;
    this.getPcauthAPI();
    this.getComplainName();
    console.log("showComponent", this.showComponent);
    var vm = this;
    EventBus.$on(this.id + "complainHandle", function(data, division) {
      console.log("eventbus complain handle : ", data);
      console.log("eventbus complain handle : ", division);
      if (data.SL_MAINTENANCE == "READY") {
        if (division == "left") {
          vm.mainComponent = "VMComplainDirection";
        } else if (division == "center") {
          vm.mainComponent = "VMComplainMaintenance";
        }
      } else if (data.SL_MAINTENANCE == "INPROGRESS") {
        if (division == "left") {
          // NOTE :: 좌측에 버튼두는 용도인데 중간에 기획변경으로 사라졌는데 추후에 추가 가능성이 있는 부분
        } else if (division == "center") {
          vm.mainComponent = "VMComplainChangeDirection";
        } else if (division == "right") {
          vm.mainComponent = "VMComplainMaintenance";
        }
      } else if (data.SL_MAINTENANCE == "DONE") {
        if (division == "left") {
          vm.mainComponent = "VMComplainReDirection";
        } else if (division == "center") {
          vm.mainComponent = "VMComplainReMaintenance";
        }
      }
    });
  },
  beforeDestroy() {
    EventBus.$off(this.id + "complainHandle");
  }
};
</script>

<style>
.th-item,
.td-item,
.td-center {
  text-align: center;
}
.vm-complain-handle .td-center {
  text-align: center !important;
}
.input-padding {
  padding: 0px;
}
.complain-handle-textarea {
  border: 0px;
  width: 100%;
  height: 100px;
}
.complain-vertical-align {
  vertical-align: middle;
}
.vm-complain-handle .sub-modal-position {
  max-width: 580px;
  position: relative;
  height: 475px;
}
.vm-complain-handle .modal-title * {
  font-size: 13px;
}
.vm-complain-handle .modal-alert {
  width: 200px;
}
</style>

<style>
.vm-complain-handle {
  max-width: 600px; /* NOTE: dialog에 따라 width 사이즈 다르게 설정 */
  position: absolute;
}
.vm-complain-handle .input-padding {
  padding: 0px;
}
.vm-complain-handle .tb-textarea {
  border: 0px;
  width: 100%;
  resize: none;
}
.vm-complain-handle .complain-control {
  padding: 0px;
  text-align: center;
}
.vm-complain-handle .complain-control-btn {
  /* border: 1px solid rgba(25, 128, 223, 0.5); */
  background: #7d7d7d;
  color: #fff;
  padding: 1px 7px 1px 7px;
  border-radius: 15px;
  margin: 2px 0px 2px 7px;
  outline: none;
}
.vm-complain-handle .complain-check-sn {
  padding: 3px 20px 3px 7px;
}
.vm-complain-handle .complain-check-sn-img {
  position: absolute;
  height: 22px;
  right: 12px;
}
.vm-complain-handle input[type="radio"] {
  display: none;
}

.vm-complain-handle input[type="radio"] + label {
  color: #000;
}

.vm-complain-handle input[type="radio"] + label span {
  display: inline-block;
  width: 11px;
  height: 11px;
  /* margin: -3px 10px 0 0; */
  vertical-align: middle;
  background: url("../../assets/img/res/img/radio-btn-bg.png") top no-repeat;
  background-size: 11px;
  cursor: pointer;
}

.vm-complain-handle input[type="radio"]:checked + label span {
  background: url("../../assets/img/res/img/radio-btn.png") top no-repeat;
  background-size: 11px;
}
.vm-complain-handle .light-radio {
  height: 10px;
  width: 10px;
  margin-bottom: 0px;
}
.vm-complain-handle .light-radio-label {
  width: 50px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 15px;
}
.vm-complain-handle .radio-label > span {
  margin-top: 18x;
}
.vm-complain-handle .radio-label {
  margin-bottom: 0px;
  margin-left: 7px;
}
.vm-complain-handle .light-radio-label-space {
  margin-left: 56px;
}
.vm-complain-handle .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
  border-bottom: 1px solid #424242;
}
.vm-complain-handle .tab_menu > button.modal-remove-btn {
  float: left;
}
.vm-complain-handle .tab_menu button:hover {
  background: #016aae;
  border-bottom: 1px solid #016aae;
}
.vm-complain-handle .form-control {
  padding: 3px 12px 6px 3px;
  height: 22px;
}
.vm-complain-handle.modal-alert-background {
  border-radius: 10px;
}
.vm-complain-handle .jaje-add-list table tr th {
  background: #7d7d7d;
}
</style>
