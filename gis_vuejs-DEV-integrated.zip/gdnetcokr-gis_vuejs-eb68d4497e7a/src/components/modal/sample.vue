<template lang="pug">
.modal-content(:id="key")
  .modal-header
    VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key")
  .modal-body
    table
      colgroup
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
      tr.tr-item
        th.th-item(colspan=2) 표찰번호
        td.td-item.input-padding(colspan=3) 
          input(type="text")
        td.td-item(colspan=1) 검색
        td.td-item(colspan=1) 이동
        td.td-item(colspan=1) 상세
      tr.tr-item
        th.th-item(colspan=2) 주소
        td.td-item.input-padding(colspan=6) 
          input(type="text")
      tr.tr-item
        th.th-item(colspan=2) 신고인
        td.td-item.input-padding(colspan=2) 
          input(type="text")
        th.th-item(colspan=2) 연락처
        td.td-item.input-padding(colspan=2) 
          input(type="text")
      tr.tr-item
        th.th-item(colspan=2) 회신 방법
        td.td-item(colspan=6) 
          select.tb-select()
            option(value="all") 회신 받지 않음
            option(value="all") 문자
            option(value="all") 전화
      tr.tr-item
        th.th-item(colspan=2) 신고 내용
        td.td-item(colspan=6) 
          select.tb-select()
            option(value="all") 불이 안켜져요
            option(value="all") 기타
      tr.tr-item
        th.th-item(colspan=8) 신고 내용(상세)
      tr.tr-item
        td(colspan=8) 
          textarea.tb-textarea(row='6')
    .tab_menu
      button(type="button" class="btn btn-outline-primary") 인쇄
      button(type="button" class="btn btn-outline-primary") 수정
      button(type="button" class="btn btn-outline-primary") 저장
</template>

<script>
// NOTE :: (2020-05-27) 필요 없는 파일
export default {
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "민원 접수",
        menu: [],
        exitBtn: true
      }
    };
  },
  methods: {
    onClickClose(key) {
      console.log(key);
      this.$store.commit("modal_close", key);
    }
  },
  created() {},
  mounted() {
    // $(".modal").modal({
    //   backdrop: false
    // });
    // $(".modal-content").draggable({
    //   handle: ".modal-header, .modal-body",
    //   containment: "#modal_area"
    // });
  },
  updated() {
    console.log("updated base modal");
  }
};
</script>

<style>
.modal-content {
  max-width: 530px; /* NOTE: dialog에 따라 width 사이즈 다르게 설정 */
}
.th-item,
.td-item {
  text-align: center;
}
.input-padding {
  padding: 0px;
}
.tb-textarea {
  border: 0px;
  width: 100%;
  height: 150px;
}
</style>
