<template lang="pug">
.modal-alert-background.vm-complain-history(style="border-radius:10px")
  .modal-content.sub-modal-position(:id="key" style="max-width:580px;")
    .modal-header
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-on:clickClose="onClickClose" v-bind:subTitle="subTitle")
    .modal-body
      vm-alert(ref="alert" @event="alertEvent")
      #search_condition.result-area(style="height:100%" v-show="true")
        #search_result(style="max-height:425px;")
          table
            tr.tr-item
              th.th-item.th-center.left-first-child &nbsp;&nbsp; 작업 일자
              th.th-item.th-center &nbsp;&nbsp; 자재명
              th.th-item.th-center &nbsp;&nbsp; 수량
              th.th-item.th-center &nbsp;&nbsp; 작업 내용
              th.th-item.th-center.left-last-child &nbsp;&nbsp; 신고 내용
            tr.tr-item(v-for="data in history" v-if="history != ''")
              td.item-td
                input.td-center.left-last-child(type="text" v-model="data.SL_DODATE" :disabled="true" style="border-radius:0px 0px 0px 10px")
              td.item-td
                input.td-center(type="text" v-model="data.SL_JJ_NAME" :disabled="true" )
              td.item-td
                input.td-center(type="text" v-model="data.SL_JJ_COUNT" :disabled="true" )
              td.item-td
                input.td-center(type="text" v-model="data.SL_WORKTYPE" :disabled="true" )
              td.item-td
                input.td-center.right-last-child(type="text" v-model="data.SL_CONTENT" :disabled="true" )
            tr.tr-item(v-if="history==''")
              td.item-td.td-center(colspan=5) 민원 유지보수 이력이 없습니다.
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";

export default {
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: false
    },
    type: {
      type: String,
      requied: false
    },
    slcode: {
      type: String,
      requied: false
    },
    SL_NT_NO: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}ComplainAddr".format(this.id, this.type),
      header: {
        icon: "",
        title: "유지보수 이력",
        menu: [],
        exitBtn: true
      },
      req: {
        PAGE: 1
      },
      res: {},
      paging: [1, 1, false, false, 1],
      loadData: false,
      subTitle: "",
      handling: {
        SL_DRDATE: "",
        SL_ASSIGNED_ID: "",
        SL_DRWORK: "",
        SL_DODATE: "",
        SL_DO_ASSIGNED: "",
        SL_WORKTYPE: "",
        SL_WORK: ""
      },
      history: [],
      jajeCode: {}
    };
  },
  methods: {
    pageChoice(page) {
      if (page == this.req.PAGE) {
        return "result-page-choice";
      } else {
        return "";
      }
    },
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    onClickClose(key) {
      this.$emit("clickAddrClose");
    },
    setComplain() {
      this.GetPcaddress(this.req);
    },
    GetPcaddress(data) {
      var vm = this;
      this.$_API_GET("pcaddress", data)
        .then(function(res) {
          console.log(res);
          vm.res = res.content;
          vm.paging = res.paging;
          if (vm.paging[4] > 5) {
            vm.paging[1] = 5;
            vm.paging[3] = false;
            vm.paging[4] = 5;
          }
          console.log(vm.paging[4]);
          vm.loadData = false;
        })
        .catch(() => {
          console.log("주소 검색 에러");
        });
    },
    pageSelect(page) {
      this.req.PAGE = page;
      this.GetPcaddress(this.req);
    },
    movePage(check) {
      if (check == "down") {
        if (this.paging[2]) {
          this.req.PAGE = this.paging[0] - 5 > 0 ? this.paging[0] - 5 : 1;
        }
      } else if (check == "up") {
        if (this.paging[3]) {
          this.req.PAGE = this.paging[0] + 5;
        }
      } else if (check == "first") {
        this.req.PAGE = 1;
      } else if (check == "end") {
        this.req.PAGE = this.paging[4];
      }
      this.GetPcaddress(this.req);
    },
    onClickAddr(data) {
      EventBus.$emit(
        "setComplainAddr" + this.id,
        data.SL_SLNAME,
        data.SL_SLCODE,
        data.SL_MAP_X,
        data.SL_MAP_Y
      );
      this.onClickClose(this.key);
    },
    onClickMove(data) {
      var point = window.setCoordsFromPoint(
        data.SL_MAP_X,
        data.SL_MAP_Y,
        this.$store.getters.panel_location_name
      );
      window.SetPositionLevel(point.getLng(), point.getLat(), 1);
    },
    getComplainHistory(slcode) {
      // NOTE :: 민원 이력 리스트 가져옴
      console.log("민원 히스토리", slcode);
      var vm = this;
      this.$_API_GET("complaint/history", { slcode: slcode })
        .then(function(res) {
          console.log("complaint/history", res);
          for (var value in res) {
            if (value != "contains" && res[value].SL_NT_NO != vm.id) {
              var dic = {};
              dic["SL_DODATE"] = res[value].SL_DODATE;
              if (res[value].SL_JJ_CODE != undefined) {
                dic["SL_JJ_NAME"] =
                  vm.jajeCode[Number(res[value].SL_JJ_CODE)].SL_JJ_NAME;
                dic["SL_JJ_COUNT"] = res[value].SL_JJ_COUNT;
              } else {
                dic["SL_JJ_NAME"] = "";
                dic["SL_JJ_COUNT"] = "";
              }
              dic["SL_WORKTYPE"] = res[value].SL_WORKTYPE;
              dic["SL_CONTENT"] = res[value].SL_CONTENT;
              vm.history.push(dic);
            }
          }
          console.log("data", vm.history);
        })
        .catch(() => {
          console.log("이력 검색 에러");
        });
    },
    getJajeList(data, path) {
      var vm = this;
      // this.loadData = true;
      return this.$_API_GET("jaje", data)
        .then(function(res) {
          vm.jajeCode = res;
          // vm.loadData = false;
          console.log("vm.jajeCode", vm.jajeCode);
          vm.getComplainHistory(vm.slcode);
          vm.$forceUpdate();
        })
        .catch(() => {
          vm.loadData = false;
          vm.retry = true;
        });
    }
  },
  created() {},
  mounted() {
    console.log("complain History : ", this.slcode);
    this.getJajeList();
    var vm = this;
    EventBus.$on("setAddr", function(value) {
      vm.req.SL_SLNAME = value;
      vm.loadData = true;
      vm.setComplain();
    });
  },
  updated() {
    console.log("updated base modal");
  },
  beforeDestroy() {
    EventBus.$off("setAddr");
  }
};
</script>

<style>
.td-vertical-allign {
  vertical-align: middle;
}
.sub-addr {
  font-size: 11px;
}
.addr-blank {
  padding: 0px;
  margin: 0px;
}

.modal-page {
  text-align: center;
  margin-bottom: 20px;
}
.addr-search-btn {
  border-radius: 5px;
  width: 100%;
  color: white;
  height: 100%;
  background-color: rgb(0, 160, 234);
}

.vm-complain-history table > tr > td input[type="text"]:disabled {
  background: white !important;
}

.vm-complain-history #search_result tr td,
.vm-complain-history #search_result tr th {
  font-size: 12px;
}
</style>

<style lang="scss">
.vm-complain-history {
  & * {
    font-size: 12px;
  }
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.th-center {
        text-align: center;
      }
      & > th.complain-modify-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 50px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & > td.td-center {
        text-align: center;
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0;
      -webkit-border-radius: 10px 0 0 0;
      border-radius: 10px 0 0 0;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0 0;
      -webkit-border-radius: 0 10px 0 0;
      border-radius: 0 10px 0 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>
