<template lang="pug">
.vm-footer
  .modal-box
    ul
      li(v-for="(color_value, legend_key ,key) in boxes" :key="legend_key")
        .box
          .color(v-bind:style="{'background-color': color_value}") 
          .legend {{legend_key}}
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";

export default {
  name: "vmelectricenergyfooter",
  props: {
    boxtype: {
      type: String
    }
  },
  data() {
    return {
      boxes: {},
      nowBox: {
        최대: "#ff4560",
        최소: "#feb019",
        어제: "#008ffb",
        오늘: "#00e396"
      },
      otherBox: {
        추정: "#008ffb",
        실제: "#00e396"
      }
    };
  },
  methods: {},
  mounted() {
    if (this.boxtype == "now") {
      this.boxes = this.nowBox;
    } else {
      this.boxes = this.otherBox;
    }
  }
};
</script>
<style>
.vm-footer li {
  float: left;
}
.vm-footer {
  display: flex;
}
.vm-footer .box {
  display: inline-flex;
}
.vm-footer .box .legend {
  font-size: 12px;
  font-family: "Noto Sans KR", sans-serif !important;
  margin: 0px 5px 0px 0px;
}
.vm-footer .box .color {
  width: 14px;
  height: 14px;
  margin: 3px 3px 0px 0px;
}
</style>
