<template lang="pug">
.modal-light-config.vm-light-config
  .modal-body
    span.table-title(v-if="req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10") 모니터링
    .monitoring-area(v-if="req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10")
      .monitoring-item
        .monitoring-title AC인입
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(v-show="distributionBLACKOUT != 'HIDE'" :src="monitorDistributionImg(distributionBLACKOUT.length)")
          span.monitoring-resunt(v-show="distributionBLACKOUT != 'HIDE'") {{distributionBLACKOUT.length == 0 ? "정상":"오류"}}
          span.monitoring-resunt.distribution-result(v-show="distributionBLACKOUT != 'HIDE'") {{distributionBLACKOUT[0]}}
      .monitoring-item
        .monitoring-title 점멸기
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(v-show="distributionDEVICE != 'HIDE'" :src="monitorDistributionImg(distributionDEVICE.length)")
          span.monitoring-resunt(v-show="distributionDEVICE != 'HIDE'") {{distributionDEVICE.length == 0 ? "정상":"오류"}}
          span.monitoring-resunt.distribution-result(v-show="distributionDEVICE != 'HIDE'") {{distributionDEVICE[0]}}
      .monitoring-item
        .monitoring-title 마그네트
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(v-show="distributionMG != 'HIDE'" :src="monitorDistributionImg(distributionMG.length)")
          span.monitoring-resunt(v-show="distributionMG != 'HIDE'") {{distributionMG.length == 0 ? "정상":"오류"}}
          span.monitoring-resunt.distribution-result(v-show="distributionMG != 'HIDE'") {{distributionMG[0]}}
      .monitoring-item
        .monitoring-title ELB_A
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(v-show="distributionELBA != 'HIDE'" :src="monitorDistributionImg(distributionELBA.length)")
          span.monitoring-resunt(v-show="distributionELBA != 'HIDE'") {{distributionELBA.length == 0 ? "정상":"오류"}}
          span.monitoring-resunt.distribution-result(v-show="distributionELBA != 'HIDE'") {{distributionELBA[0]}}
      .monitoring-item
        .monitoring-title ELB_B
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(v-show="distributionELBB != 'HIDE'" :src="monitorDistributionImg(distributionELBB.length)")
          span.monitoring-resunt(v-show="distributionELBB != 'HIDE'") {{distributionELBB.length == 0 ? "정상":"오류"}}
          span.monitoring-resunt.distribution-result(v-show="distributionELBB != 'HIDE'") {{distributionELBB[0]}}
    br(v-if="req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10")
    .tab_menu(v-if="(req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10) && this.$store.getters.config_area == 'hygn'" style="margin-top:0px; margin-bottom:12px;")
      button.modal-button-color-black(type="button" class="btn btn-outline-primary" v-if="auth && !modifyLight" @click="[lightMode_Always_OFF = true]") 분전함 전체 소등
      button.modal-button-color-black(type="button" class="btn btn-outline-primary" v-if="auth && !modifyLight" @click="[lightMode_Always_ON = true]") 분전함 전체 점등
    table(v-if="req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10" :class="modifyLight ? 'table-modify' : ''" style="table-layout:fixed")
      colgroup
        col(style="width:25%")
        col(style="width:75%")
      tr.table-none-borer
        th.first-child  &nbsp;&nbsp;분기 구분
        td.has_child.last-child
          input.light-radio(type="radio" v-model="device" value="1" id="r1" name="rr" )
          label(for="r1") 
            span
              label.light-radio-label 1분기
          input.light-radio(type="radio" v-model="device" value="2" id="r2" name="rr" )
          label.light-radio-label-space(for="r2") 
            span
              label.light-radio-label 2분기
          input.light-radio(type="radio" v-model="device" value="3" id="r3" name="rr" )
          label.light-radio-label-space(for="r3") 
            span
              label.light-radio-label 3분기
          input.light-radio(type="radio" v-model="device" value="4" id="r4" name="rr" )
          label.light-radio-label-space(for="r4") 
            span
              label.light-radio-label 4분기
    span.table-title 편차 설정
    table(:class="modifyLight ? 'table-modify' : ''" style="table-layout:fixed")
      colgroup
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
      tr
        th.on-light-time.left-first-child(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;점등 편차 설정
        td.has_child(colspan=1)
          input.add-right-line(v-model="ON_BASIC_TIME" :disabled="true" :class="modifyLightMode()")
        td.has_child(colspan=1 tabindex="-1")
          .dropdown
            .dropdown__header(@click="toggleDropdown($event, req.setting.ON_DEVIATION)" :class="modifyLightMode()")
              span {{req.setting.ON_DEVIATION}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('ON_DEVIATION', value)" v-for="value in $_.range(-90, 91, 1)" :class="dropdownChoice(value, req.setting.ON_DEVIATION)" :data-val="value") {{value}}
                  .search-division-line
        th(:class="modifyLightMode()" colspan=2) &nbsp;&nbsp;점등 시간
        td.has_child.table-select-full-th(colspan=2)
          input.left-last-child(v-model="ON_TIME" :disabled="true" :class="modifyLightMode()")
      tr
        th.off-light-time.right-first-child(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;소등 편차 설정
        td.has_child.last-clear-bottom(colspan=1)
          input.add-right-line(v-model="OFF_BASIC_TIME" :disabled="true" :class="modifyLightMode()")
        td.has_child.last-clear-bottom(colspan=1 tabindex="-1")
          .dropdown
            .dropdown__header(@click="toggleDropdown($event, req.setting.OFF_DEVIATION)" :class="modifyLightMode()")
              span {{req.setting.OFF_DEVIATION}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('OFF_DEVIATION', value)" v-for="value in $_.range(-90, 91, 1)" :class="dropdownChoice(value, req.setting.OFF_DEVIATION)" :data-val="value") {{value}}
                  .search-division-line
        th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;소등 시간
        td.has_child.table-select-full-th.last-clear-bottom(colspan=2)
          input.right-last-child(v-model="OFF_TIME" :disabled="true" :class="modifyLightMode()")

    span.table-title 심야 설정
    table(:class="modifyLight ? 'table-modify' : ''" style="table-layout:fixed")
      colgroup
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
      tr
        th.left-first-child(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;설정 유무
        td.has_child.table-select-full-th(colspan=2 tabindex="-1")
          .dropdown
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{code.SPECIAL_TITLE_CONFIG[req.setting.SPECIAL_TITLE]}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content
              ul
                li(v-if="key != 'Always On' && key != 'Always Off'" @click="clickDropDownSetting('SPECIAL_TITLE', key)" v-for="value, key in code.SPECIAL_TITLE_CONFIG" :class="dropdownChoice(value, code.SPECIAL_TITLE_CONFIG[req.setting.SPECIAL_TITLE])") {{value}}
                  .search-division-line
                li(v-if="req.setting.SL_DATA_1 == 4" @click="clickDropDownSetting('SPECIAL_TITLE', 'Always On')" :class="dropdownChoice('Always On', code.SPECIAL_TITLE_CONFIG[req.setting.SPECIAL_TITLE])") Always On
                    .search-division-line
                li(v-if="req.setting.SL_DATA_1 == 4" @click="clickDropDownSetting('SPECIAL_TITLE', 'Always Off')" :class="dropdownChoice('Always Off', code.SPECIAL_TITLE_CONFIG[req.setting.SPECIAL_TITLE])") Always Off
                    .search-division-line
        th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;조도 설정
        td.has_child.table-select-full-th.left-last-child(colspan=2 tabindex="-1")
          input(v-model="req.setting.DIM_VALUE + '%'" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{req.setting.DIM_VALUE}}%
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content
              ul
                li(@click="clickDropDownSetting('DIM_VALUE', value)" v-for="value in $_.range(0, 110, 10)" :class="dropdownChoice(value, req.setting.DIM_VALUE)") {{value}}%
                  .search-division-line
      tr
        th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;시작 일자
        td.has_child(colspan=2 v-if="!modifyLight")
          span.config-td-span.light-datetime-text {{changeDateShape(req.setting.OFF_FROM_MONTH, req.setting.OFF_FROM_DAY)}}
        td.has_child.table-select-full-th(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_FROM_MONTH" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_FROM_MONTH, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content
              ul
                li(@click="clickDropDownSetting('OFF_FROM_MONTH', value)" v-for="value in 12" :class="dropdownChoice(value, req.setting.OFF_FROM_MONTH)") {{pad(value, 2)}}
                  .search-division-line
        td.has_child.table-select-full-th(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_FROM_DAY" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_FROM_DAY, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('OFF_FROM_DAY', value)" v-for="value in 31" :class="dropdownChoice(value, req.setting.OFF_FROM_DAY)") {{pad(value, 2)}}
                  .search-division-line
        th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;시작 시간
        td.has_child(colspan=2 v-if="!modifyLight")
          span.config-td-span.light-datetime-text {{changeDateShape(req.setting.OFF_FROM_HOUR,req.setting.OFF_FROM_MIN, 'time')}}
        td.has_child.table-select-full-th(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_FROM_HOUR" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_FROM_HOUR, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('OFF_FROM_HOUR', value)" v-for="(index, value) in 24" :class="dropdownChoice(value, req.setting.OFF_FROM_HOUR)") {{pad(value, 2)}}
                  .search-division-line
        td.has_child.table-select-full-th(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_FROM_MIN" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_FROM_MIN, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('OFF_FROM_MIN', value)" v-for="(index, value) in 60" :class="dropdownChoice(value, req.setting.OFF_FROM_MIN)") {{pad(value, 2)}}
                  .search-division-line
      tr
        th.right-first-child(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;종료 일자
        td.last-clear-bottom.has_child(colspan=2 v-if="!modifyLight")
          span.config-td-span.light-datetime-text {{changeDateShape(req.setting.OFF_TO_MONTH, req.setting.OFF_TO_DAY)}}
        td.last-clear-bottom.has_child.table-select-full-th(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_TO_MONTH" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_TO_MONTH, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content
              ul
                li(@click="clickDropDownSetting('OFF_TO_MONTH', value)" v-for="value in 12" :class="dropdownChoice(value, req.setting.OFF_TO_MONTH)") {{pad(value, 2)}}
                  .search-division-line
        td.has_child.table-select-full-th(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_TO_DAY" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_TO_DAY, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('OFF_TO_DAY', value)" v-for="value in 31" :class="dropdownChoice(value, req.setting.OFF_TO_DAY)") {{pad(value, 2)}}
                  .search-division-line
        th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;종료 시간
        td.last-clear-bottom.has_child(colspan=2 v-if="!modifyLight")
          span.config-td-span.light-datetime-text {{changeDateShape(req.setting.OFF_TO_HOUR, req.setting.OFF_TO_MIN, 'time')}}
        td.last-clear-bottom.has_child.table-select-full-th(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_TO_HOUR" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_TO_HOUR, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('OFF_TO_HOUR', value)" v-for="(index, value) in 24" :class="dropdownChoice(value, req.setting.OFF_TO_HOUR)") {{pad(value, 2)}}
                  .search-division-line
        td.last-clear-bottom.has_child.table-select-full-th.right-last-child(colspan=1 v-if="modifyLight" tabindex="-1")
          input(v-model="padOFF_TO_MIN" :disabled="true" :class="modifyLightMode()" v-if="req.setting.SPECIAL_TITLE =='Always On' || req.setting.SPECIAL_TITLE =='Always Off' || req.setting.SPECIAL_TITLE =='미설정'")
          .dropdown(v-else)
            .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
              span {{pad(req.setting.OFF_TO_MIN, 2)}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content.dropdown__longdata
              ul
                li(@click="clickDropDownSetting('OFF_TO_MIN', value)" v-for="(index, value) in 60" :class="dropdownChoice(value, req.setting.OFF_TO_MIN)") {{pad(value, 2)}}
                  .search-division-line
    .tab_menu
      button.modal-button-color-black(type="button" class="btn btn-outline-primary" v-if="auth && !modifyLight" @click="onClickModifyLight") 수정
      button.modal-button-color-black.modal-modify-btn(type="button" class="btn btn-outline-primary" v-if="auth && modifyLight" @click="onClickSaveLight") 저장
      button.modal-button-color-black.modal-cancel-btn(type="button" class="btn btn-outline-primary" v-if="auth && modifyLight" @click="cancelBtn") 취소
    .config-title
      span.table-title 제어
      span.table-title.sync-title 최종 동기화 {{error.updated_at}} 
    br
    span.rs-label(:id="id+'rs-bullet'") {{light_value}}
    input.rs-range-sub(type="range" value="100" min="0" max="100" step="10" style="background:linear-gradient(to right, #ff7147 0%, #ffeca6 100%)")
    input.rs-range(:id="id+'rs-range-line'" type="range" value="100" min="0" max="100" v-modal="light_value" step="10" style="background:rgba(220,221,223,1); position: absolute;left: 12px;width: 496px;")
    .tab_menu
      button.default-light-btn(@click="LightTest('syncsetting', 'config')") 설정점검
      button.default-light-btn(@click="LightTest('syncstatus', 'status')") 상태점검
      button.off-light-btn(@click="LightTest('off', 'off')") 소등
      button.on-light-btn(@click="LightTestDim()") 점등/디밍
      button.reset-light-btn.default-light-btn(@click="LightTest('reset', 'reset')") 리셋

    table(v-if="!(req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10)" :class="modifyLight ? 'table-modify' : ''" style="table-layout:fixed")
      colgroup
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")       
      tr
        th.left-first-child(colspan=2) &nbsp;&nbsp;램프
        td.has_child(colspan=2)
          span.error-span {{error.light_value}} {{error.light_test == 1? "(TEST)":""}}
        th(colspan=2) &nbsp;&nbsp;센서값1
        td.has_child.left-last-child(colspan=2)
          span.error-span {{error.sensor_value_1}}
        //- th(colspan=2) 정전 여부
        //- td.has_child(colspan=2)
        //-   span.error-span {{error.BLACKOUT_error}}
      tr
        th(colspan=2) &nbsp;&nbsp;센서값2
        td.has_child(colspan=2)
          span.error-span {{error.sensor_value_2}}
        th(colspan=2) &nbsp;&nbsp;AC_output_A
        td.has_child(colspan=2)
          span.error-span {{error.AC_output_A}}
      tr
        th(colspan=2) &nbsp;&nbsp;SMPS output A
        td.has_child.add-right-line(colspan=2)
          span.error-span {{error.SMPS_output_V}}
        td.has_child.add-right-line(colspan=2)
        td.has_child(colspan=2)
      tr
        th.right-first-child(colspan=2 style="font-size:13px") &nbsp;&nbsp;전력량(현재/일/월)
        td.has_child.add-right-line.last-clear-bottom(colspan=2)
          span.error-span {{error_1.Watt}}
          img.watt-img(v-show="error_1.Watt != ''" :src="require('@/assets/img/res/img/watt.png')" @click="openElectricEnergy('now')")
        td.has_child.add-right-line.last-clear-bottom(colspan=2)
          span.error-span {{error_1.SUM_MONTH_STORE_EST}}
          img.watt-img(v-show="error.SUM_MONTH_STORE_EST != ''" :src="require('@/assets/img/res/img/watt.png')" @click="openElectricEnergy('daily')")
        td.right-last-child.has_child.last-clear-bottom(colspan=2)
          span.error-span {{error_1.SUM_YEAR_STORE_EST}}
          img.watt-img(v-show="error.SUM_YEAR_STORE_EST != ''" :src="require('@/assets/img/res/img/watt.png')" @click="openElectricEnergy('monthly')")
    table(v-if="req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10" :class="modifyLight ? 'table-modify' : ''" style="table-layout:fixed")
      colgroup
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")       
      tr
        th.left-first-child(colspan=2 style="font-size:13px") &nbsp;&nbsp;현재 전류량
        td.has_child.add-right-line(colspan=2)
          span.error-span {{nowAmpere}}
        th(colspan=2 style="font-size:13px") &nbsp;&nbsp;현재 전력량
        td.left-last-child.has_child(colspan=2)
          span.error-span {{device == 1 ? error_1.Watt : error_2.Watt}}
          img.watt-img(v-show="error.Watt != ''" :src="require('@/assets/img/res/img/watt.png')" @click="openElectricEnergy('now')")
      tr
        th.right-first-child(colspan=2 style="font-size:13px") &nbsp;&nbsp;일별 전력량
        td.has_child.add-right-line.last-clear-bottom(colspan=2)
          span.error-span {{device == 1 ? error_1.SUM_MONTH_STORE_EST : error_2.SUM_MONTH_STORE_EST}}
          img.watt-img(v-show="error.SUM_MONTH_STORE_EST != ''" :src="require('@/assets/img/res/img/watt.png')" @click="openElectricEnergy('daily')")
        th(colspan=2 style="font-size:13px") &nbsp;&nbsp;월별 전력량
        td.right-last-child.has_child.last-clear-bottom(colspan=2)
          span.error-span {{error_1.SUM_YEAR_STORE_EST}}
          img.watt-img(v-show="error.SUM_YEAR_STORE_EST != ''" :src="require('@/assets/img/res/img/watt.png')" @click="openElectricEnergy('monthly')")
    span.table-title(v-if="!(req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10)") 모니터링
    .monitoring-area(v-if="!(req.setting.SL_DATA_1 == 4 ||req.setting.SL_DATA_1 == 8 ||req.setting.SL_DATA_1 == 9 ||req.setting.SL_DATA_1 == 10)")
      .monitoring-item
        .monitoring-title AC인입
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(:src="monitorImg('ACIN', error.BLACKOUT_error)")
          span.monitoring-resunt {{error.BLACKOUT_error}}
      .monitoring-item
        .monitoring-title ELB
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(:src="monitorImg('ELB', error.GFCI_error)")
          span.monitoring-resunt {{error.GFCI_error}}
      .monitoring-item
        .monitoring-title 점멸기
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(:src="monitorImg('AC_RELAY', error.AC_RELAY_error)")
          span.monitoring-resunt {{error.AC_RELAY_error}}
      .monitoring-item
        .monitoring-title(v-if="req.setting.SL_DATA_1 == 1 && req.LF_LAMP != 'LED'") 안정기
        .monitoring-title(v-else) SMPS
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(:src="monitorImg('SMPS', error.SMPS_error)")
          span.monitoring-resunt {{ lampSMPSError('SMPS', error.SMPS_error) }}
      .monitoring-item
        .monitoring-title 램프
        .monitoring-content
          .monitoring-content-img
            img.monitoring-resunt-img(:src="monitorImg('LAMP', error.LAMP_error)")
          span.monitoring-resunt {{ lampSMPSError('LAMP', error.LAMP_error) }}
    .tab_menu
      //- button(type="button" class="btn btn-outline-primary") 인쇄
      //- .tab_menu-area(style="height:35px" v-if="modifyLight")
      //- button(type="button" class="btn btn-outline-primary" v-if="auth && !modifyLight" @click="onClickLightRegister") 개통
  transition(name='modal' v-if="lightMode_Always_ON")
    .modal-background
      .modal-position
        span 현재 시설물을 전체 점등하시겠습니까?
        br        
        button.spinner-btn.spinner-left(@click="[lightMode_Always_ON = false]") 취소
        button.spinner-btn.spinner-right(@click="onClickChangeMode('ON')") 확인
  transition(name='modal' v-if="lightMode_Always_OFF")
    .modal-background
      .modal-position
        span 현재 시설물을 전체 소등하시겠습니까?
        br
        button.spinner-btn.spinner-left(@click="[lightMode_Always_OFF = false]") 취소
        button.spinner-btn.spinner-right(@click="onClickChangeMode('OFF')") 확인
  transition(name='modal' v-if="retry")
    .modal-background
      .modal-position
        .loader
        br
        .modal-success(v-if="modalCheck")
          | {{modalText}}
        .modal-fail(v-if="!modalCheck")
          | 일시적으로 데이터를 불러오지 못했습니다
          br
          | 다시 시도해주세요
          br
          button.spinner-btn(@click="initLightConfig") 다시 시도
  transition(name='modal' v-if="modalAlert")
    .modal-background
      .modal-position
        .loader
        br
        | {{alertText}}
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
  transition(name='modal' v-if="nonQRCode")
    .modal-alert-background.vm-alert
      .modal-alert
        .modal-content
          .modal-body
            .alert-modal-body(style="text-align:center")
              .modal-text 등록된 QRCode가 없습니다.
              .alert-tab_menu
              button.spinner-btn(@click="onClickNonQRCode") 확인  
  vm-alert(ref="alert" @event="alertEvent")
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
import deviceCode from "@/assets/json/deviceCode.json";

export default {
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    },
    auth: {
      type: Boolean,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "",
        menu: [],
        exitBtn: true
      },
      req: {
        SL_DATA_1: "01",
        LF_LAMP: "",
        setting: {
          SPECIAL_TITLE: "미설정",
          OFF_FROM_DAY: "01",
          OFF_FROM_HOUR: "00",
          OFF_FROM_MIN: "00",
          OFF_FROM_MONTH: "01",
          OFF_FROM_YEAR: "2019",
          OFF_TO_DAY: "31",
          OFF_TO_HOUR: "23",
          OFF_TO_MIN: "59",
          OFF_TO_MONTH: "12",
          OFF_TO_YEAR: "2019",
          ON_DEVIATION: "-30",
          OFF_DEVIATION: "15",
          DIM_VALUE: "0",
          ENABLE_SMPS_SENSOR: "0",
          GD_SERIAL: "set",
          light_val: ""
        },
        ON_Hour: 20,
        ON_Min: 15,
        OFF_Hour: 4,
        OFF_Min: 45
      },
      error: {
        BLACKOUT_error: "",
        GFCI_error: "",
        SMPS_error: "",
        AC_RELAY_error: "",
        LAMP_error: "",
        updated_at: "",
        light_value: "",
        light_test: "",
        AC_output_A: "",
        SMPS_output_V: "",
        sensor_value_1: "",
        sensor_value_2: "",
        SUM_MONTH_STORE_EST: "",
        SUM_YEAR_STORE_EST: "",
        Watt: "",
        MG_error: "",
        ELB_A_error: "",
        ELB_B_error: ""
      },
      error_1: {
        BLACKOUT_error: "",
        GFCI_error: "",
        SMPS_error: "",
        AC_RELAY_error: "",
        LAMP_error: "",
        updated_at: "",
        light_value: "",
        light_test: "",
        AC_output_A: "",
        SMPS_output_V: "",
        sensor_value_1: "",
        sensor_value_2: "",
        SUM_MONTH_STORE_EST: "",
        SUM_YEAR_STORE_EST: "",
        Watt: "",
        MG_error: "",
        ELB_A_error: "",
        ELB_B_error: ""
      },
      error_2: {
        BLACKOUT_error: "",
        GFCI_error: "",
        SMPS_error: "",
        AC_RELAY_error: "",
        LAMP_error: "",
        updated_at: "",
        light_value: "",
        light_test: "",
        AC_output_A: "",
        SMPS_output_V: "",
        sensor_value_1: "",
        sensor_value_2: "",
        SUM_MONTH_STORE_EST: "",
        SUM_YEAR_STORE_EST: "",
        Watt: "",
        MG_error: "",
        ELB_A_error: "",
        ELB_B_error: ""
      },
      updated_at: 0,
      modifyLight: false,
      light_value: 100,
      control_resource_id: null,
      control_expire_time: null,
      CONTROL_EXPIRE_DURATION: 60000,
      CONTROL_RESET_EXPIRE_DURATION: 60000,
      settingProcess: false,
      invalidateLight: false,
      control_type: null,
      statusUpdatesIn: 0,
      retry: false,
      tabChoice: "",
      repeat: "",
      modalText: "",
      modalCheck: false,
      alertText: "",
      modalAlert: false,
      device: 1,
      GD_SERIAL: "",
      GD_SERIAL_2: "",
      loadData: false,
      nonQRCode: false,
      code: "",
      controlType: "",
      lightMode_Always_OFF: false,
      lightMode_Always_ON: false
    };
  },
  watch: {
    device: function(newVal, oldVal) {
      console.log("device change : ", newVal, oldVal);
      if (newVal == 1) {
        this.req.setting.GD_SERIAL = this.GD_SERIAL;
      } else if (newVal == 2) {
        this.req.setting.GD_SERIAL = this.GD_SERIAL_2;
      }
      console.log("this.req.setting.GD_SERIAL", this.req.setting.GD_SERIAL);
      if (this.req.setting.GD_SERIAL == "") {
        // 시리얼 없음 처리
      }

      for (var key in this.error) {
        this.error[key] = "";
      }
      for (var key in this.error_1) {
        this.error_1[key] = "";
      }
      for (var key in this.error_2) {
        this.error_2[key] = "";
      }
      console.log("device change : ", this.req.setting.GD_SERIAL);
      this.getLightInfo();

      clearInterval(this.repeat);
      this.repeat = setInterval(() => {
        this.getLightStatus();
      }, 1000);
    },
    modifyLight: function(val) {
      console.log("watch modifyLight");
      if (val) {
        this.$emit("changeTitle", "수정중");
        $(".vm-light-config .form-control").css("pointer-events", "auto");
        $(".vm-light-config .form-control")
          .children()
          .css("pointer-events", "auto");
        $(".vm-light-config .dropdown__header").css("pointer-events", "auto");
        $(".vm-light-config .dropdown__header")
          .children()
          .css("pointer-events", "auto");
      } else {
        this.$emit("changeTitle", "");
        $(".vm-light-config .form-control").css("pointer-events", "none");
        $(".vm-light-config .form-control")
          .children()
          .css("pointer-events", "none");
        $(".vm-light-config .dropdown__header").css("pointer-events", "none");
        $(".vm-light-config .dropdown__header")
          .children()
          .css("pointer-events", "none");
      }
    }
  },
  computed: {
    ON_BASIC_TIME() {
      return this.moment({
        hour: this.req.ON_Hour,
        minute: this.req.ON_Min
      }).format("HH:mm");
    },
    OFF_BASIC_TIME() {
      return this.moment({
        hour: this.req.OFF_Hour,
        minute: this.req.OFF_Min
      }).format("HH:mm");
    },
    ON_TIME() {
      return this.moment({
        hour: this.req.ON_Hour,
        minute: this.req.ON_Min
      })
        .add(this.req.setting.ON_DEVIATION, "m")
        .format("HH:mm");
    },
    OFF_TIME() {
      return this.moment({
        hour: this.req.OFF_Hour,
        minute: this.req.OFF_Min
      })
        .add(this.req.setting.OFF_DEVIATION, "m")
        .format("HH:mm");
    },
    padOFF_FROM_MONTH() {
      return this.pad(this.req.setting.OFF_FROM_MONTH, 2);
    },
    padOFF_FROM_DAY() {
      return this.pad(this.req.setting.OFF_FROM_DAY, 2);
    },
    padOFF_FROM_HOUR() {
      return this.pad(this.req.setting.OFF_FROM_HOUR, 2);
    },
    padOFF_FROM_MIN() {
      return this.pad(this.req.setting.OFF_FROM_MIN, 2);
    },
    padOFF_TO_MONTH() {
      return this.pad(this.req.setting.OFF_TO_MONTH, 2);
    },
    padOFF_TO_DAY() {
      return this.pad(this.req.setting.OFF_TO_DAY, 2);
    },
    padOFF_TO_HOUR() {
      return this.pad(this.req.setting.OFF_TO_HOUR, 2);
    },
    padOFF_TO_MIN() {
      return this.pad(this.req.setting.OFF_TO_MIN, 2);
    },
    deviceError() {
      if (
        this.error.GFCI_error == "오류" ||
        this.error.AC_RELAY_error == "오류"
      ) {
        return "오류";
      } else if (
        this.error.GFCI_error == "" &&
        this.error.AC_RELAY_error == ""
      ) {
        return "";
      } else {
        return "정상";
      }
    },
    nowAmpere() {
      // NOTE :: 암페어로 변환
      if (this.error.AC_output_A == "") {
        return "";
      } else {
        return (
          (((this.error.AC_output_A * 5.0) / 1024) * 0.5128).toFixed(2) + "A"
        );
      }
    },
    distributionBLACKOUT() {
      var distribution_error = [];
      if (
        this.error_1.BLACKOUT_error == "" &&
        this.error_2.BLACKOUT_error == ""
      ) {
        return "HIDE";
      }

      if (this.error_1.BLACKOUT_error == "오류") {
        distribution_error.push(1);
      }
      if (this.error_2.BLACKOUT_error == "오류") {
        distribution_error.push(2);
      }
      if (distribution_error.length == 2) {
        distribution_error = ["all"];
      }
      return distribution_error;
    },
    distributionDEVICE() {
      var distribution_error = [];
      if (
        this.error_1.GFCI_error == "" &&
        this.error_1.AC_RELAY_error == "" &&
        this.error_2.GFCI_error == "" &&
        this.error_2.AC_RELAY_error == ""
      ) {
        return "HIDE";
      }

      if (
        this.error_1.GFCI_error == "오류" ||
        this.error_1.AC_RELAY_error == "오류"
      ) {
        distribution_error.push(1);
      }
      if (
        this.error_2.GFCI_error == "오류" ||
        this.error_2.AC_RELAY_error == "오류"
      ) {
        distribution_error.push(2);
      }
      if (distribution_error.length == 2) {
        distribution_error = ["all"];
      }
      return distribution_error;
    },
    distributionMG() {
      var distribution_error = [];
      if (this.error_1.MG_error == "" && this.error_2.MG_error == "") {
        return "HIDE";
      }

      if (this.error_1.MG_error == "오류") {
        distribution_error.push(1);
      }
      if (this.error_2.MG_error == "오류") {
        distribution_error.push(2);
      }
      if (distribution_error.length == 2) {
        distribution_error = ["all"];
      }
      return distribution_error;
    },
    distributionELBA() {
      var distribution_error = [];
      if (this.error_1.ELB_A_error == "" && this.error_2.ELB_A_error == "") {
        return "HIDE";
      }
      if (this.error_1.ELB_A_error == "오류") {
        distribution_error.push(1);
      }
      if (this.error_2.ELB_A_error == "오류") {
        distribution_error.push(2);
      }
      if (distribution_error.length == 2) {
        distribution_error = ["all"];
      }
      return distribution_error;
    },
    distributionELBB() {
      var distribution_error = [];
      if (this.error_1.ELB_B_error == "" && this.error_2.ELB_B_error == "") {
        return "HIDE";
      }

      if (this.error_1.ELB_B_error == "오류") {
        distribution_error.push(1);
      }
      if (this.error_2.ELB_B_error == "오류") {
        distribution_error.push(2);
      }
      if (distribution_error.length == 2) {
        distribution_error = ["all"];
      }
      return distribution_error;
    }
  },
  methods: {
    changeDateShape(month, day, type) {
      // TODO :: 일이나 월을 0을 하나 더 붙여주는건데, 이거 watch나 computed 로 바꾸고 싶다
      let month_word = "월";
      let day_word = "일";

      month = Number(month);
      day = Number(day);
      month = month >= 10 ? month : "0" + month;
      day = day >= 10 ? day : "0" + day;

      if (type) {
        month_word = "시";
        day_word = "분";
      }
      return "{0}{1} {2}{3}".format(month, month_word, day, day_word);
    },
    modifyBackground() {
      if (this.modifyLight) {
        return "background-padding-left";
      } else {
        return "background-none";
      }
    },
    modifyLightMode() {
      if (this.modifyLight) {
        return "modify-light-mode";
      } else {
        return "";
      }
    },
    onClickLightRegister() {
      // NOTE :: QRCode 개통 / info 쪽으로 이전된 기능
      console.log("GD_SERIAL", this.req.setting.GD_SERIAL);
      if (this.req.setting.GD_SERIAL == "") {
        this.$refs.alert.init(
          "black",
          null,
          "입력된 QRCode가 없습니다.",
          null,
          null,
          true,
          false
        );
      } else {
        this.modalAlert = true;
        this.alertText = "기기에 설정 값을 저장 중입니다.. (통신망 요청 중)";
        var vm = this;
        console.log("onClickLightRegister", this.req.setting);
        this.$_API_POST("pcfacilitysetting", this.req.setting)
          .then(function(res) {
            console.log(res);
            vm.alertText =
              "기기에 설정 값을 저장 중입니다.. (통신망 전달 완료)";
            vm.modalAlert = false;
          })
          .catch(function(err) {
            vm.modalAlert = false;
            vm.$refs.alert.init(
              "black",
              null,
              "개통 오류",
              null,
              null,
              true,
              false
            );
          });
      }
    },
    showModifyCaution(value) {
      this.$refs.alert.init(
        "white",
        null,
        "수정 중 이동할 경우 수정한 내용들이 사라질 수 있습니다",
        "수정을 취소하고 다른 작업을 진행하시겠습니까?",
        null,
        "caution",
        true
      );
      this.tabChoice = value;
    },
    cancelBtn() {
      this.modifyLight = false;
      this.getLightInfo();
    },
    moveTab() {
      this.$refs.alert.close();
      this.modifyLight = false;
      this.getLightInfo();
      this.$emit("clickTab", this.tabChoice);
    },
    getModifyStatus() {
      return this.modifyLight;
    },
    pad(n, width) {
      n = n + "";
      return n.length >= width
        ? n
        : new Array(width - n.length + 1).join("0") + n;
    },
    onClickClose(key) {
      this.$store.commit("modal_close", key);
    },
    getLightInfo() {
      // NOTE :: 시설물 정보 가져옴
      // TODO :: 모달이 켜지면 info/config의 component를 모두 살리고 데이터를 부모에서 가져와서 자식들이 활용하는 형태로 변경해야 좋음
      console.log("getLightInfo");
      console.log("getLightInfo", this.req.setting.GD_SERIAL);
      console.log("getLightInfo", this.device);
      var vm = this;
      this.$_API_GET("pc/facility/info", {
        slcode: this.id,
        gdserial: this.req.setting.GD_SERIAL,
        device: this.device
      })
        .then(function(res) {
          console.log("config", res);
          if (res.special_setting != null) {
            vm.req.setting = res.special_setting;
            vm.req.setting.ENABLE_SMPS_SENSOR = res.light.ENABLE_SMPS_SENSOR;
          }
          if (res.light.GD_SERIAL != null) {
            vm.GD_SERIAL = res.light.GD_SERIAL;
          }
          if (res.light.GD_SERIAL_2 != null) {
            vm.GD_SERIAL_2 = res.light.GD_SERIAL_2;
          }
          if (vm.device == 1) {
            vm.req.setting.GD_SERIAL = vm.GD_SERIAL;
          } else if (vm.device == 2) {
            vm.req.setting.GD_SERIAL = vm.GD_SERIAL_2;
          }
          vm.req.setting.SL_DATA_1 = res.light.SL_DATA_1;
          vm.req.setting.SL_SLCODE = vm.id;
          vm.req.LF_LAMP = res.light.LF_1_LAMP;
          vm.req.ON_Hour = res.light_time.ON_Hour;
          vm.req.ON_Min = res.light_time.ON_Min;
          vm.req.OFF_Hour = res.light_time.OFF_Hour;
          vm.req.OFF_Min = res.light_time.OFF_Min;

          if (res.special_setting != null) {
            vm.req.setting = res.special_setting;
          } else {
            vm.req.setting.SPECIAL_TITLE = "미설정";
            vm.req.setting.OFF_FROM_DAY = "01";
            vm.req.setting.OFF_FROM_HOUR = "00";
            vm.req.setting.OFF_FROM_MIN = "00";
            vm.req.setting.OFF_FROM_MONTH = "01";
            vm.req.setting.OFF_FROM_YEAR = "2019";
            vm.req.setting.OFF_TO_DAY = "31";
            vm.req.setting.OFF_TO_HOUR = "23";
            vm.req.setting.OFF_TO_MIN = "59";
            vm.req.setting.OFF_TO_MONTH = "12";
            vm.req.setting.OFF_TO_YEAR = "2019";
            if (vm.$store.getters.config_on_deviation != undefined) {
              vm.req.setting.ON_DEVIATION = vm.$store.getters.config_on_deviation;
            } else {
              vm.req.setting.ON_DEVIATION = "-30";
            }
            if (vm.$store.getters.config_off_deviation != undefined) {
              vm.req.setting.OFF_DEVIATION = vm.$store.getters.config_off_deviation;
            } else {
              vm.req.setting.OFF_DEVIATION = "15";
            }
            vm.req.setting.DIM_VALUE = "0";
            vm.req.setting.ENABLE_SMPS_SENSOR = "0";
            vm.req.setting.light_val = "";
          }
          vm.retry = false;
          vm.loadData = false;
          vm.lightMode_Always_OFF = false;
          vm.lightMode_Always_ON = false;
          console.log("vm.req.setting.GD_SERIAL", vm.req.setting.GD_SERIAL);
          if (vm.req.setting.GD_SERIAL == "") {
            vm.nonQRCode = true;
          } else {
            vm.nonQRCode = false;
          }
        })
        .catch(function() {
          vm.modalCheck = true;
          vm.retry = true;
        });
    },
    getLightStatus() {
      // NOTE :: 시설물 상태 가져옴
      var requestData = {
        slcode: this.id,
        updated_at: this.updated_at,
        today: new Date().toDateString(),
        device: this.device
      };

      if (this.req.setting.GD_SERIAL != "") {
        requestData.GD_SERIAL = this.req.setting.GD_SERIAL;
      }
      // console.log("requestData", requestData);
      var requestUrl = "facility/status";
      if (this.control_resource_id != null) {
        requestUrl = "teststatus";
        requestData = {
          resource_id: this.control_resource_id
        };
      }
      // console.log("requestUrl", requestUrl);
      var vm = this;
      this.$_API_GET(requestUrl, requestData).then(function(res) {
        vm.modalCheck = true;
        // console.log("requestUrl", requestUrl);
        // console.log("requestUrl", res);
        // console.log("window.UpdateStatus(res)", window.watt(res));
        console.log(res);
        console.log("data check", res.error_1 == undefined);
        console.log("data check", res["error_1"] == undefined);
        if (res.error_1 != undefined) {
          if (vm.device == 1) {
            res.SL_SLCODE = res["error_1"]["SL_SLCODE"];
          } else if (vm.device == 2) {
            res.SL_SLCODE = res["error_2"]["SL_SLCODE"];
          }
        }
        if (res.SL_SLCODE == null) {
          for (var key in vm.error) {
            vm.error[key] = "";
          }
          for (var key in vm.error_1) {
            vm.error_1[key] = "";
          }
          for (var key in vm.error_2) {
            vm.error_2[key] = "";
          }
          return;
        }
        if (res.error_1 != undefined) {
          res.error_1.SUM_MONTH_STORE_EST = res.SUM_MONTH_STORE_EST;
          res.error_1.SUM_MONTH_STORE_VAL = res.SUM_MONTH_STORE_VAL;
          res.error_1.SUM_YEAR_STORE_EST = res.SUM_YEAR_STORE_EST;
          res.error_1.SUM_YEAR_STORE_VAL = res.SUM_YEAR_STORE_VAL;
          res.error_2.SUM_MONTH_STORE_EST = res.SUM_MONTH_STORE_EST;
          res.error_2.SUM_MONTH_STORE_VAL = res.SUM_MONTH_STORE_VAL;
          res.error_2.SUM_YEAR_STORE_EST = res.SUM_YEAR_STORE_EST;
          res.error_2.SUM_YEAR_STORE_VAL = res.SUM_YEAR_STORE_VAL;
          if (vm.device == 1) {
            res.error_1 = window.watt(res.error_1);
          } else if (vm.device == 2) {
            res.error_2 = window.watt(res.error_2);
          }
        }
        if (vm.statusUpdatesIn > Date.now()) {
          return;
        }
        vm.statusUpdatesIn = Date.now() + 3000;
        if (vm.control_resource_id != null) {
          if (res.success == false) {
            vm.control_resource_id = null;
            vm.retry = false;
            vm.$refs.alert.init(
              "black",
              null,
              "LoRa의 신호 세기가 미약합니다.",
              null,
              null,
              true,
              false
            );
          } else if (vm.control_expire_time < Date.now()) {
            vm.control_resource_id = null;
            vm.settingProcess = false;
            vm.retry = false;
            vm.$refs.alert.init(
              "black",
              null,
              "LoRa의 신호 세기가 미약합니다.",
              null,
              null,
              true,
              false
            );
          } else if (res.received_at != null) {
            vm.control_resource_id = null;
            vm.statusUpdatesIn = Date.now();
            vm.retry = false;
            if (res.received_at)
              if (vm.settingProcess) {
                if (
                  vm.controlType == "on" ||
                  vm.controlType == "off" ||
                  vm.controlType == "dim" ||
                  vm.controlType == "reset"
                ) {
                  vm.$refs.alert.init(
                    "black",
                    null,
                    "제어 명령이 완료되었습니다.",
                    null,
                    null,
                    true,
                    false
                  );
                } else if (
                  vm.controlType == "config" ||
                  vm.controlType == "status"
                ) {
                  vm.$refs.alert.init(
                    "black",
                    null,
                    "데이터 동기화가 완료되었습니다.",
                    null,
                    null,
                    true,
                    false
                  );
                }
                // $("#modal-info").modal("hide");
                vm.settingProcess = false;
                vm.invalidateLight = true;
              } else {
                if (vm.control_type == "syncsetting") {
                  if (vm.device == 1) {
                    res.updated_at = res["error_1"]["updated_at"];
                  } else if (vm.device == 2) {
                    res.updated_at = res["error_2"]["updated_at"];
                  }
                  if (res.updated_at != undefined) {
                    for (var key in vm.error_1) {
                      if (
                        key == "SUM_MONTH_STORE_EST" ||
                        key == "SUM_YEAR_STORE_EST"
                      ) {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "Watt") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "updated_at") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "light_value") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "light_test") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "AC_output_A") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "SMPS_output_V") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "sensor_value_1") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (key == "sensor_value_2") {
                        vm.error_1[key] = res["error_1"][key];
                      } else if (res["error_1"][key] == null) {
                        vm.error_1[key] = "정상";
                      } else if (res["error_1"][key] != null) {
                        vm.error_1[key] = "오류";
                      }
                    }
                    for (var key in vm.error_2) {
                      if (
                        key == "SUM_MONTH_STORE_EST" ||
                        key == "SUM_YEAR_STORE_EST"
                      ) {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "Watt") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "updated_at") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "light_value") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "light_test") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "AC_output_A") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "SMPS_output_V") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "sensor_value_1") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (key == "sensor_value_2") {
                        vm.error_2[key] = res["error_2"][key];
                      } else if (res["error_2"][key] == null) {
                        vm.error_2[key] = "정상";
                      } else if (res["error_2"][key] != null) {
                        vm.error_2[key] = "오류";
                      }
                    }
                    if (vm.device == 1) {
                      vm.error = vm.error_1;
                    } else if (vm.device == 2) {
                      vm.error = vm.error_2;
                    }
                    // console.log("vm.error", vm.error);
                    // console.log("vm.error_1", vm.error_1);
                    // console.log("vm.error_2", vm.error_2);
                  }
                }
                vm.$refs.alert.init(
                  "black",
                  null,
                  "제어가 성공적으로 완료됐습니다.",
                  null,
                  null,
                  true,
                  false
                );
              }
          } else if (res.delivered_at != null) {
            if (vm.settingProcess) {
              vm.modalText =
                "기기에 설정 값을 저장 중입니다.. (단말기 전달 완료)";
            } else {
              vm.modalText = "제어 요청 중입니다.. (단말기 전달 완료)";
            }
          }
        } else {
          if (vm.device == 1) {
            res.updated_at = res["error_1"]["updated_at"];
          } else if (vm.device == 2) {
            res.updated_at = res["error_2"]["updated_at"];
          }
          if (res.updated_at != undefined) {
            for (var key in vm.error_1) {
              if (key == "SUM_MONTH_STORE_EST" || key == "SUM_YEAR_STORE_EST") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "Watt") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "updated_at") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "light_value") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "light_test") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "AC_output_A") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "SMPS_output_V") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "sensor_value_1") {
                vm.error_1[key] = res["error_1"][key];
              } else if (key == "sensor_value_2") {
                vm.error_1[key] = res["error_1"][key];
              } else if (res["error_1"][key] == null) {
                vm.error_1[key] = "정상";
              } else if (res["error_1"][key] != null) {
                vm.error_1[key] = "오류";
              }
            }
            for (var key in vm.error_2) {
              if (key == "SUM_MONTH_STORE_EST" || key == "SUM_YEAR_STORE_EST") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "Watt") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "updated_at") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "light_value") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "light_test") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "AC_output_A") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "SMPS_output_V") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "sensor_value_1") {
                vm.error_2[key] = res["error_2"][key];
              } else if (key == "sensor_value_2") {
                vm.error_2[key] = res["error_2"][key];
              } else if (res["error_2"][key] == null) {
                vm.error_2[key] = "정상";
              } else if (res["error_2"][key] != null) {
                vm.error_2[key] = "오류";
              }
            }
            if (vm.device == 1) {
              vm.error = vm.error_1;
            } else if (vm.device == 2) {
              vm.error = vm.error_2;
            }
          }
          if (!Object.keys(res).length) {
            for (var key in vm.error) {
              vm.error[key] = "";
            }
            for (var key in vm.error_1) {
              vm.error_1[key] = "";
            }
            for (var key in vm.error_2) {
              vm.error_2[key] = "";
            }
          }
        }
      });
    },
    onClickModifyLight() {
      if (this.req.setting.GD_SERIAL == "") {
        this.nonQRCode = true;
      }
      if (this.auth) {
        this.modifyLight = true;
      }
    },
    onClickSaveLight() {
      // NOTE :: 시설물 세팅 저장
      console.log("onClickSaveLight", this.req.setting);
      if (this.req.setting.GD_SERIAL == "") {
        this.nonQRCode = true;
        this.modifyLight = false;
        return;
      }
      this.req.setting.QRCODE = this.device;
      if (this.device == 1) {
        this.req.setting.GD_SERIAL = this.GD_SERIAL;
      } else if (this.device == 2) {
        this.req.setting.GD_SERIAL = this.GD_SERIAL_2;
      }
      this.modalText = "기기에 설정 값을 저장 중입니다.. (통신망 요청 중)";
      this.retry = true;
      var vm = this;
      this.$_API_POST("pcfacilitysetting", this.req.setting).then(function(
        res
      ) {
        vm.modalText = "기기에 설정 값을 저장 중입니다.. (통신망 전달 완료)";
        console.log(res);
        vm.control_resource_id = res.data.special_setting[0].mgc.exin[0].ri;
        vm.control_expire_time = Date.now() + vm.CONTROL_EXPIRE_DURATION;
        console.log("vm.control_resource_id", vm.control_resource_id);
        console.log("vm.control_expire_time", vm.control_expire_time);
      });
      this.modifyLight = false;
    },
    onClickChangeMode(mode) {
      console.log("onClickChangeMode", this.req.setting);
      console.log(this.$store.getters.config_area);
      if (this.req.setting.GD_SERIAL == "") {
        this.nonQRCode = true;
        this.lightMode_Always_ON = false;
        this.lightMode_Always_OFF = false;
        return;
      }
      this.modalText = "기기에 설정 값을 저장 중입니다.. (통신망 요청 중)";
      this.retry = true;
      var vm = this;
      var funName = "";
      if (mode == "ON") {
        funName = "Distributon_Box_Manual_On";
      } else if (mode == "OFF") {
        funName = "Distributon_Box_Manual_Off";
      }
      this.$_API_POST(funName, this.req.setting).then(function(res) {
        vm.modalText = "기기에 설정 값을 저장 중입니다.. (통신망 전달 완료)";
        console.log(res);
        vm.control_resource_id = res.data.resource_ids[0];
        vm.control_expire_time = Date.now() + vm.CONTROL_EXPIRE_DURATION;
        console.log("vm.control_resource_id", vm.control_resource_id);
        console.log("vm.control_expire_time", vm.control_expire_time);
      });
      this.modifyLight = false;
      this.lightMode_Always_OFF = false;
      this.lightMode_Always_ON = false;
    },
    LightTest(type, btnType) {
      // NOTE :: 시설물 점등, 소등, 리셋 등 제어 테스트, 상태점검, 설정점검 기능
      this.controlType = btnType;
      if (this.req.setting.GD_SERIAL == "") {
        this.nonQRCode = true;
        return;
      }
      var data = {
        GD_SERIAL: this.req.setting.GD_SERIAL,
        light_val: this.light_value,
        QRCODE: this.device
      };
      console.log(data);
      console.log("LightTesttype", type);
      this.control_type = type;
      this.retry = true;
      this.settingProcess = true;
      var vm = this;
      this.modalCheck = true;
      this.modalText = "제어 요청 중입니다.. (통신망 요청 중)";
      this.$_API_POST("test" + type, data)
        .then(function(res) {
          vm.modalText = "제어 요청 중입니다.. (통신망 전달 완료)";
          console.log("API_POSTLightTest", res);
          try {
            // for command
            vm.control_resource_id = res.data[0].mgc.exin[0].ri;
          } catch (err) {
            // for reset
            console.log(err);
            vm.control_resource_id = res.data.mgc.exin[0].ri;
          }
          if (vm.control_type == "reset") {
            // NOTE reset은 처리시간이 오ㄹ
            vm.control_expire_time =
              Date.now() + vm.CONTROL_RESET_EXPIRE_DURATION;
          } else {
            vm.control_expire_time = Date.now() + vm.CONTROL_EXPIRE_DURATION;
          }
        })
        .catch(function(err) {
          vm.settingProcess = false;
          vm.retry = false;
        });
    },
    LightTestDim() {
      // NOTE :: 시설물 점/소등
      console.log("LightTestDim", this.light_value);
      if (this.light_value == 100) {
        this.LightTest("on", "on");
      } else {
        this.LightTest("dim", "dim");
      }
    },
    initLightConfig() {
      this.loadData = true;
      if (this.error.updated_at == "") {
        // 정보 동기화 실패
        console.log("initLightConfig start");
        this.getLightInfo();
      } else {
        this.loadData = false;
      }
      this.repeat = setInterval(() => {
        this.getLightStatus();
        // console.log("vm.error", this.error);
      }, 1000);
      this.device = 1;
    },
    clearInterval() {
      clearInterval(this.repeat);
    },
    showSliderValue() {},
    closeModal() {
      this.$store.commit("modal_all_close", this.key.split(":")[0]);
    },
    toggleDropdown(event, index) {
      event.currentTarget.classList.toggle("is-active");
      console.log(index);
      if (index != undefined) {
        console.log(
          $(
            ".vm-light-config .dropdown__content li[data-val='" + index + "']"
          ).index()
        );
        var liIndex =
          $(
            ".vm-light-config .dropdown__content li[data-val='" + index + "']"
          ).index() + 1;
        $(".vm-light-config .dropdown__content").scrollTop(
          $(
            ".vm-light-config .dropdown__content li:nth-child(" + liIndex + ")"
          ).position().top
        );
      }
    },
    clickDropDownSetting(type, data) {
      this.req.setting[type] = data;
      $(".vm-light-config .dropdown__header").removeClass("is-active");
      if (type == "SPECIAL_TITLE") {
        if (data == "Always On") {
          this.req.setting.DIM_VALUE = 100;
        } else if (data == "Always Off") {
          this.req.setting.DIM_VALUE = 0;
        }
      }
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    monitorDistributionImg(value) {
      if (value == 0) {
        return require("@/assets/img/res/img/monitor-true.png");
      } else if (value == undefined) {
        return require("@/assets/img/res/img/check-blank.png");
      } else {
        return require("@/assets/img/res/img/monitor-false.png");
      }
    },
    monitorImg(name, error) {
      // NOTE :: Error Image 처리
      if (this.req.setting.SL_DATA_1 == 1 && this.req.LF_LAMP != "LED") {
        if (name == "SMPS") {
          if (error == "오류") {
            return require("@/assets/img/res/img/monitor-false.png");
          } else if (this.error.LAMP_error == "오류") {
            return require("@/assets/img/res/img/monitor-check.png");
          } else if (error == "") {
            return require("@/assets/img/res/img/check-blank.png");
          } else {
            return require("@/assets/img/res/img/monitor-true.png");
          }
        } else if (name == "LAMP") {
          if (error == "오류") {
            return require("@/assets/img/res/img/monitor-false.png");
          } else if (this.error.SMPS_error == "오류") {
            return require("@/assets/img/res/img/monitor-check.png");
          } else if (error == "") {
            return require("@/assets/img/res/img/check-blank.png");
          } else {
            return require("@/assets/img/res/img/monitor-true.png");
          }
        }
      }
      if (error == "정상") {
        return require("@/assets/img/res/img/monitor-true.png");
      } else if (error == "오류") {
        return require("@/assets/img/res/img/monitor-false.png");
      } else {
        return require("@/assets/img/res/img/check-blank.png");
      }
    },
    openElectricEnergy(type) {
      // NOTE :: 전력량 모달 연결
      let dataObj = {
        slcode: this.id,
        dataType: type
      };
      console.log("data", dataObj);
      this.$emit("clickElectricEnergy", dataObj);
    },
    onClickNonQRCode() {
      var vm = this;
      Vue.nextTick(function() {
        EventBus.$emit("modalOpenParam" + vm.id, vm.id, "VMLightInfo", {
          choiceTab: "상세"
        });
      });
    },
    lampSMPSError(name, error) {
      if (this.req.setting.SL_DATA_1 == 1 && this.req.LF_LAMP != "LED") {
        if (name == "SMPS") {
          if (error == "오류") {
            return "오류";
          } else if (this.error.LAMP_error == "오류") {
            return "점검";
          } else if (error == "") {
            return "";
          } else {
            return "정상";
          }
        } else if (name == "LAMP") {
          if (error == "오류") {
            // NOTE :: 오류/정상 애매함. 펌웨어 이슈 있음.
          } else if (this.error.SMPS_error == "오류") {
            return "점검";
          } else if (error == "") {
            return "";
          } else {
            return "정상";
          }
        }
      }
      if (error == "정상") {
        return "정상";
      } else if (error == "오류") {
        return "오류";
      } else {
        return "";
      }
    },
    alertEvent(key, inputData) {
      switch (key) {
        case "caution":
          this.moveTab();
          break;
        case "closeModal":
          this.closeModal();
          break;
      }
    }
  },
  created() {},
  mounted() {
    console.log("config mounted");

    this.code = JSON.parse(JSON.stringify(deviceCode));

    console.log(this.id + "lightModifyStatus");
    var vm = this;
    EventBus.$on(this.id + "lightModifyStatusConfig", function() {
      console.log("aaaa", vm.modifyLight);
      if (vm.modifyLight) {
        vm.$refs.alert.init(
          "white",
          null,
          "수정 중인 내용들이 사라질 수 있습니다",
          "수정을 취소하고 종료를 진행하시겠습니까?",
          null,
          "closeModal",
          true
        );
      } else {
        vm.$store.commit("modal_all_close", vm.key.split(":")[0]);
      }
    });

    Vue.nextTick(function() {
      $(".vm-light-config .has_child").focusout(function(e) {
        $(".vm-light-config .dropdown__header").removeClass("is-active");
      });

      $(".vm-light-config .form-control").css("pointer-events", "none");
      $(".vm-light-config .form-control")
        .children()
        .css("pointer-events", "none");

      $(".vm-light-config .dropdown__header").css("pointer-events", "none");
      $(".vm-light-config .dropdown__header")
        .children()
        .css("pointer-events", "none");

      // NOTE :: 점소등 Value에 사용되는 ProgressBar
      var rangeSlider = document.getElementById(vm.id + "rs-range-line");
      var rangeBullet = document.getElementById(vm.id + "rs-bullet");

      function showSliderValue() {
        vm.light_value = rangeSlider.value;
        rangeBullet.innerHTML = rangeSlider.value;
        var bulletPosition = rangeSlider.value / rangeSlider.max;
        console.log("rangeSlider.value", rangeSlider.value);
        // rangeBullet.style.left = 458 + "px";
        if (rangeSlider.value == 0) {
          rangeBullet.style.left = 0 + "px";
        } else if (rangeSlider.value == 10) {
          rangeBullet.style.left = 45.5 + "px";
        } else if (rangeSlider.value == 20) {
          rangeBullet.style.left = 93 + "px";
        } else if (rangeSlider.value == 30) {
          rangeBullet.style.left = 139 + "px";
        } else if (rangeSlider.value == 40) {
          rangeBullet.style.left = 186 + "px";
        } else if (rangeSlider.value == 50) {
          rangeBullet.style.left = 232 + "px";
        } else if (rangeSlider.value == 60) {
          rangeBullet.style.left = 278 + "px";
        } else if (rangeSlider.value == 70) {
          rangeBullet.style.left = 324.7 + "px";
        } else if (rangeSlider.value == 80) {
          rangeBullet.style.left = 371 + "px";
        } else if (rangeSlider.value == 90) {
          rangeBullet.style.left = 418 + "px";
        } else if (rangeSlider.value == 100) {
          rangeBullet.style.left = 462 + "px";
        }

        $("#" + vm.id + "rs-range-line").bind("change mousemove", function() {
          var val = $(this).val();
          var buf = (100 - val) / 4 + parseInt(val);
          $(this).css(
            "background",
            "linear-gradient(to right, rgba(220,221,223,0) 0%, rgba(220,221,223,0) " +
              val +
              "%, #dadada " +
              val +
              "% 100%)"
          );
        });
      }

      rangeSlider.addEventListener("input", showSliderValue, false);
      showSliderValue();
    });
  },
  updated() {
    $(".vm-light-config .has_child").focusout(function(e) {
      $(".vm-light-config .dropdown__header").removeClass("is-active");
    });
    if (this.modifyLight) {
      this.$emit("changeTitle", "수정중");
      $(".vm-light-config .form-control").css("pointer-events", "auto");
      $(".vm-light-config .form-control")
        .children()
        .css("pointer-events", "auto");
      $(".vm-light-config .dropdown__header").css("pointer-events", "auto");
      $(".vm-light-config .dropdown__header")
        .children()
        .css("pointer-events", "auto");
    } else {
      this.$emit("changeTitle", "");
      $(".vm-light-config .form-control").css("pointer-events", "none");
      $(".vm-light-config .form-control")
        .children()
        .css("pointer-events", "none");
      $(".vm-light-config .dropdown__header").css("pointer-events", "none");
      $(".vm-light-config .dropdown__header")
        .children()
        .css("pointer-events", "none");
    }
  },
  beforeDestroy() {
    clearInterval(this.repeat);
    EventBus.$off(this.id + "lightModifyStatusConfig");
  }
};
</script>

<style>
.modal-light-config.vm-light-config {
  min-width: 518px;
}
.vm-light-config .vm-alert .modal-alert .modal-content {
  min-width: 200px;
}
.on-light-time {
  background-color: rgb(255, 192, 1);
}
.off-light-time {
  background-color: rgb(51, 51, 51);
}
.light-datetime-text {
  color: #8d8d8d;
  color: black;
}
.modify-light-config {
  margin-top: 10px;
  margin-bottom: 10px;
  float: right;
}
.modify-light-config > * {
  margin: 2px;
  font-size: 14px;
  font-weight: bold;
  border-radius: 1rem;
}
.hr-line {
  margin-top: 60px;
}
.config-control-btn {
  text-align: center;
}
.config-control-btn > * {
  border: 1px solid lightgray;
  border-radius: 15px;
  width: 66px;
  padding-top: 4px;
  padding-bottom: 4px;
  margin-left: 3px;
  margin-top: 3px;
  margin-bottom: 3px;
}

.vm-light-config .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
}

.vm-light-config .tab_menu > button.modal-remove-btn {
  float: left;
}
.vm-light-config .tab_menu button:hover {
  background: #016aae;
}
.vm-light-config .tab_menu button.modal-remove-btn {
  background: rgb(181, 181, 181);
}
.vm-light-config .tab_menu button.modal-remove-btn:hover {
  background: #a0a0a0;
}

.vm-light-config .tab_menu button.on-light-btn {
  background: #f47e00;
  width: 80px;
}
.vm-light-config .tab_menu button.on-light-btn:hover {
  background: #f3a600;
}
.off-light-btn {
  border-color: rgb(51, 51, 51);
  width: 55px;
}
.vm-light-config .tab_menu .reset-light-btn {
  background: #b5b5b5;
  width: 55px;
  float: left;
  margin-bottom: 12px;
}
.vm-light-config .tab_menu .reset-light-btn:hover {
  background: #a0a0a0;
  width: 55px;
}
.on-light-btn:hover {
  background-color: rgb(255, 192, 1);
  color: white;
}
.off-light-btn:hover {
  background-color: rgb(51, 51, 51);
  color: white;
}
.default-light-btn:hover {
  background-color: lightgray;
  color: white;
}
.test-th {
  vertical-align: middle;
}

.modal-light-config input[type="radio"] {
  display: none;
}

.modal-light-config input[type="radio"] + label {
  color: #000;
  margin-bottom: 0px;
}

.modal-light-config input[type="radio"] + label span {
  display: inline-block;
  width: 19px;
  height: 19px;
  margin: 0px 10px 0 0;
  vertical-align: middle;
  background: url("../../assets/img/res/img/radio-btn-bg.png") top no-repeat;
  background-size: 11px;
  cursor: pointer;
  line-height: 11px;
  margin-top: 5px;
}

.modal-light-config input[type="radio"]:checked + label span {
  background: url("../../assets/img/res/img/radio-btn.png") top no-repeat;
  background-size: 11px;
}
.light-radio {
  height: 10px;
  width: 10px;
}
.light-radio-label {
  width: 50px;
  margin-left: 14px;
}
.light-radio-label-space {
  margin-left: 33px;
}
.vm-light-config .watt-img {
  margin-left: 10px;
  height: 17px;
  cursor: pointer;
}
</style>

<style lang="scss">
.vm-light-config {
  & * {
    font-size: 12px;
  }
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.modify-light-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        & span {
          padding-left: 7px;
        }
        & > input.modify-light-mode {
          background: #d3d3d3;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }

      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0;
      -webkit-border-radius: 10px 0 0 0;
      border-radius: 10px 0 0 0;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0 0;
      -webkit-border-radius: 0 10px 0 0;
      border-radius: 0 10px 0 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .first-child {
      -moz-border-radius: 10px 0 0 10px;
      -webkit-border-radius: 10px 0 0 10px;
      border-radius: 10px 0 0 10px;
    }

    & .last-child {
      -moz-border-radius: 0 10px 10px 0;
      -webkit-border-radius: 0 10px 10px 0;
      border-radius: 0 10px 10px 0;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>

<style lang="scss">
// NOTE :: DropDown CSS
.vm-light-config {
  & .dropdown {
    width: 100%;
    &__header {
      background: #fff;
      font-size: 12px;
      cursor: pointer;
      line-height: 20px;
      position: relative;
      text-overflow: ellipsis;
      color: #000;
      width: 100%;
      height: 21px;
      i.fas {
        position: absolute;
        right: 4px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 10px !important;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &:not(.modify-light-mode) {
        i {
          opacity: 0;
        }
      }
      &.is-active {
        outline: -webkit-focus-ring-color auto 1px;
        outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
        }
        + .dropdown__content.dropdown__longdata {
          height: 220px;
          overflow: scroll;
        }
      }
      & span {
        padding-left: 7px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #fff;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #000;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>

<style>
.vm-light-config .table-title {
  font-size: 12px;
  color: #000;
  font-weight: 500;
  padding-left: 8px;
  display: block;
  margin-bottom: 5px;
  margin-top: 10px;
}
.vm-light-config .modal-body > .table-title:first-child {
  margin-top: 5px;
}
.vm-light-config .sync-title {
  color: #8d8d8d;
}
.vm-light-config .config-title {
  display: inline-flex;
}
.vm-light-config .add-right-line {
  border-right: 0.6px solid rgba(195, 195, 195, 0.3);
}
.vm-light-config .monitoring-area {
  display: flex;
  justify-content: space-between;
}
.vm-light-config .monitoring-item {
  height: 90px;
  width: 70px;
  display: flex;
  flex-direction: column;
}
.vm-light-config .monitoring-item .monitoring-title {
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  background: #424242;
  color: #fff;
  height: 25px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.vm-light-config .monitoring-item .monitoring-content {
  border-left: 0.6px solid rgba(195, 195, 195, 0.3);
  border-right: 0.6px solid rgba(195, 195, 195, 0.3);
  border-bottom: 0.6px solid rgba(195, 195, 195, 0.3);
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  min-height: 65px;
  min-width: 65px;
}
.vm-light-config .monitoring-item .monitoring-content .monitoring-content-img {
  height: 100%;
  width: 100%;
  flex: 1;
  display: grid;
  justify-content: center;
  align-items: baseline;
  padding: 4px 4px 0px 4px;
}
.vm-light-config .monitoring-item .monitoring-content .distribution-result {
  background: #595959;
  padding: 0px 5px 0px 5px;
  border-radius: 20px;
  color: white;
}
.vm-light-config .monitoring-item .monitoring-content .monitoring-resunt-img {
  display: block;
  margin: auto;
  width: 60%;
  /* margin: 4px 10px 4px 10px; */
}
</style>

<style lang="scss">
.rs-range {
  margin-top: 29px;
  width: 100%;
  -webkit-appearance: none;
  border-radius: 10px;
  &:focus {
    outline: none;
  }
  &::-webkit-slider-runnable-track {
    width: 100%;
    height: 6px;
    cursor: pointer;
    box-shadow: none;
    // background: #dbdbdb;
    border-radius: 0px;
    border: 0px solid #010101;
  }
  &::-moz-range-track {
    width: 100%;
    height: 1px;
    cursor: pointer;
    box-shadow: none;
    background: #ffffff;
    border-radius: 0px;
    border: 0px solid #010101;
  }

  &::-webkit-slider-thumb {
    box-shadow: none;
    border: 0px solid #ffffff;
    // box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.25);
    height: 52px;
    width: 32px;
    background: url("../../assets/img/res/img/range-icon.png") top no-repeat;
    // background-color: white;
    // background: rgba(251, 215, 25, 1);
    cursor: pointer;
    -webkit-appearance: none;
    margin-top: -35px;
    // transform: translateX(-50%);
  }
  &::-moz-range-thumb {
    box-shadow: none;
    border: 0px solid #ffffff;
    box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.25);
    height: 42px;
    width: 22px;
    border-radius: 22px;
    background: rgba(255, 255, 255, 1);
    cursor: pointer;
    -webkit-appearance: none;
    margin-top: -20px;
  }
  &::-moz-focus-outer {
    border: 0;
  }
}
.rs-label {
  position: relative;
  transform-origin: center center;
  display: block;
  width: 20px;
  height: 20px;
  background: transparent;
  border-radius: 50%;
  line-height: 30px;
  text-align: center;
  font-weight: bold;
  padding-top: 20px;
  box-sizing: border-box;
  margin-top: 0px;
  margin-left: 6.5px;
  left: attr(value);
  color: #fff;
  font-style: normal;
  font-weight: normal;
  line-height: normal;
  font-size: 14px;
  pointer-events: none;
  z-index: 1;
  &::after {
    display: block;
    font-size: 14px;
    letter-spacing: 0.07em;
    margin-top: -2px;
  }
}
</style>

<style lang="scss">
.rs-range-sub {
  margin-top: 29px;
  width: 100%;
  -webkit-appearance: none;
  border-radius: 10px;
  &:focus {
    outline: none;
  }
  &::-webkit-slider-runnable-track {
    width: 100%;
    height: 6px;
    cursor: pointer;
    box-shadow: none;
    // background: #dbdbdb;
    border-radius: 0px;
    border: 0px solid #010101;
  }
  &::-moz-range-track {
    width: 100%;
    height: 1px;
    cursor: pointer;
    box-shadow: none;
    background: #ffffff;
    border-radius: 0px;
    border: 0px solid #010101;
  }

  &::-webkit-slider-thumb {
    box-shadow: none;
    border: 0px solid #ffffff;
    // box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.25);
    height: 52px;
    width: 32px;
    // background: url("../../assets/img/res/img/range-icon.png") top no-repeat;
    // background-color: white;
    // background: rgba(251, 215, 25, 1);
    cursor: pointer;
    -webkit-appearance: none;
    margin-top: -35px;
    // transform: translateX(-50%);
  }
  &::-moz-range-thumb {
    box-shadow: none;
    border: 0px solid #ffffff;
    box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.25);
    height: 42px;
    width: 22px;
    border-radius: 22px;
    background: rgba(255, 255, 255, 1);
    cursor: pointer;
    -webkit-appearance: none;
    margin-top: -20px;
  }
  &::-moz-focus-outer {
    border: 0;
  }
}
</style>
