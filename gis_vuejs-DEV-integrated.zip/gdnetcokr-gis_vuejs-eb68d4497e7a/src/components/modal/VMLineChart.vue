<script>
//Exporting this so it can be used in other components
import { Line } from "vue-chartjs";
export default {
  mixins: [Line],
  props: ["chartdata", "options"],
  data() {
    return {};
  },
  mounted() {
    console.log(">>>>>>>>>>.", this.chartdata, this.options);
    this.renderChart(this.chartdata, this.options);
  }
};
</script>
