<template lang="pug">
.modal-content.vm-light-remove(:id="key")
  .modal-header
    VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key")
  .modal-body
    table
      colgroup
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
        col(style="width:12.5%")
      tr.tr-item
        td.td-item(colspan=6) 
          select.tb-select(v-model="req.addr1")
            option(v-for="(vaule, key) in res" :value="key") {{key}}
      tr.tr-item
        td.td-item(colspan=6) 
          select.tb-select(v-model="req.addr2")
            option(:value="addrSub") {{addrSub}}
    .tab_menu
      button(type="button" class="btn btn-outline-primary" @click="onClickClose(key)") 취소
      button(type="button" class="btn btn-outline-primary" @click="onClickLightChoice(key)") 확인
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
export default {
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "주소",
        menu: [],
        exitBtn: true
      },
      res: {},
      req: {
        addr1: "거제면",
        addr2: "거제"
      }
    };
  },
  computed: {
    addrSub() {
      if (this.res[this.req.addr1] == null) {
        return "거제";
      } else {
        return this.res[this.req.addr1];
      }
    }
  },
  methods: {
    onClickClose(key) {
      console.log(key);
      this.$store.commit("modal_close", key);
    },
    onClickLightChoice(key) {
      EventBus.$emit(
        this.id + "addr",
        this.req.addr1 + " " + this.req.addr2 + " " + this.req.addr2
      );
      this.$store.commit("modal_close", key);
    },
    GetFacilityInfoAPI() {
      var vm = this;
      this.$_API_GET("postcode", {}, 24 * 7)
        .then(function(res) {
          console.log("GetFacilityInfoAPI", res);
          for (var key in res) {
            // console.log(key.split(":")[0]);
            for (var value in res[key]) {
              //   console.log(value.split(":")[0]);
              if (key != "SIDOSGG_CD") {
                vm.res[key.split(":")[0]] = value.split(":")[0];
              }
            }
          }
          console.log("vm.res", vm.res);
        })
        .then(() => {
          vm.$forceUpdate();
        })
        .catch(function() {
          alert("주소 가져오기 실패");
        });
    }
  },
  created() {},
  mounted() {
    $(".modal").modal({
      backdrop: false
    });
    $(".modal-content").draggable({
      handle: ".modal-header, .modal-body",
      containment: "#modal_area"
    });
    console.log("this.id", this.id);
    this.GetFacilityInfoAPI();
  },
  updated() {
    console.log("updated base modal");
  }
};
</script>

<style>
.vm-light-remove {
  max-width: 530px; /* NOTE :: dialog에 따라 width 사이즈 다르게 설정 */
}
.th-item,
.td-item {
  text-align: center;
}
.input-padding {
  padding: 0px;
}
.tb-textarea {
  border: 0px;
  width: 100%;
  height: 150px;
}
</style>
