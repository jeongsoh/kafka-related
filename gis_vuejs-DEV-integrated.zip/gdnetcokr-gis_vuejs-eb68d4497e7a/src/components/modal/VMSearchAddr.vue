<template lang="pug">
.modal-alert-background.vm-search-addr
  .modal-content.sub-modal-position(:id="key")
    .modal-header
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-on:clickClose="onClickClose")
    .modal-body
      vm-alert(ref="alert" @event="alertEvent")
      #search_condition.result-area(style="height:100%" v-show="true")
        #search_result
          table.result-table
            colgroup
              col(style="width:25%")
              col(style="width:60%")
              col(style="width:15%")
            thead
              tr
                th.result-th-default
                  .result-th 시설물 이름
                th.result-th-default
                  .result-th 주소
                th.result-th-default
                  .result-th 이동
            tbody
              tr.result-body-tr(v-for="value in res" )
                td(@click="onClickAddr(value)") {{value.SL_SLNAME}}
                td(@click="onClickAddr(value)") 
                  p.addr-blank {{value.SL_ADDR}}
                  p.addr-blank.sub-addr {{value.ADDRESS_OLD}}
                  p.addr-blank.sub-addr {{value.ADDRESS_NEW}}
                td(@click="onClickMove(value)")
                  button.addr-search-btn 이동
    .modal-page
      font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-double-left' @click="movePage('first')")
      font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-left' @click="movePage('down')")
      span.result-page(v-for="page in getNumbers(paging[0],paging[1])" @click="pageSelect(page)" :class="pageChoice(page)") {{page}}
      font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-right' @click="movePage('up')")
      font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-double-right' @click="movePage('end')")
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";

export default {
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}ComplainAddr".format(this.id, this.type),
      header: {
        icon: "",
        title: "민원 시설물 검색",
        menu: [],
        exitBtn: true
      },
      req: {
        PAGE: 1
      },
      res: {},
      paging: [1, 1, false, false, 1],
      loadData: false
    };
  },
  methods: {
    pageChoice(page) {
      if (page == this.req.PAGE) {
        return "result-page-choice";
      } else {
        return "";
      }
    },
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    onClickClose(key) {
      this.$emit("clickAddrClose");
    },
    setComplain() {
      this.GetPcaddress(this.req);
    },
    GetPcaddress(data) {
      // NOTE :: 주소 검색
      var vm = this;
      this.$_API_GET("pcaddress", data)
        .then(function(res) {
          console.log(res);
          vm.res = res.content;
          vm.paging = res.paging;
          if (vm.paging[4] > 5) {
            vm.paging[1] = 5;
            vm.paging[3] = false;
            vm.paging[4] = 5;
          }
          console.log(vm.paging[4]);
          vm.loadData = false;
        })
        .catch(() => {
          console.log("주소 검색 에러");
        });
    },
    pageSelect(page) {
      this.req.PAGE = page;
      this.GetPcaddress(this.req);
    },
    movePage(check) {
      if (check == "down") {
        if (this.paging[2]) {
          this.req.PAGE = this.paging[0] - 5 > 0 ? this.paging[0] - 5 : 1;
        }
      } else if (check == "up") {
        if (this.paging[3]) {
          this.req.PAGE = this.paging[0] + 5;
        }
      } else if (check == "first") {
        this.req.PAGE = 1;
      } else if (check == "end") {
        this.req.PAGE = this.paging[4];
      }
      this.GetPcaddress(this.req);
    },
    onClickAddr(data) {
      EventBus.$emit(
        "setComplainAddr" + this.id,
        data.SL_SLNAME,
        data.SL_SLCODE,
        data.SL_MAP_X,
        data.SL_MAP_Y
      );
      this.onClickClose(this.key);
    },
    onClickMove(data) {
      var point = window.setCoordsFromPoint(
        data.SL_MAP_X,
        data.SL_MAP_Y,
        this.$store.getters.panel_location_name
      );
      window.SetPositionLevel(point.getLng(), point.getLat(), 1);
    }
  },
  created() {},
  mounted() {
    var vm = this;
    EventBus.$on("setAddr", function(name) {
      vm.req.SL_SLNAME = name;
      vm.loadData = true;
      vm.setComplain();
    });
  },
  updated() {
    console.log("updated base modal");
  },
  beforeDestroy() {
    EventBus.$off("setAddr");
  }
};
</script>

<style>
.td-vertical-allign {
  vertical-align: middle;
}
.sub-addr {
  font-size: 11px;
}
.addr-blank {
  padding: 0px;
  margin: 0px;
}

.modal-page {
  text-align: center;
  margin-bottom: 20px;
}
.addr-search-btn {
  border-radius: 5px;
  width: 100%;
  color: white;
  height: 100%;
  background-color: rgb(0, 160, 234);
}
</style>
