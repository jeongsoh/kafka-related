<template lang="pug">
.modal-alert-background.vm-alert
  .modal-alert
    .modal-content
      .modal-body
        .alert-modal-body
          .modal-text(v-for="value in content") {{value}}
          .alert-tab_menu
            button.spinner-btn(type="button" @click="onClickChoice") 확인
      //-   .modal-header
          //- VMHeader(v-bind:icon="header.icon", v-bind:title="title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-on:clickClose="onClickClose")
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
export default {
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    },
    title: {
      type: String,
      requied: false
    },
    content: {
      type: Array,
      required: false
    }
  },
  data() {
    return {
      key: "{0}:{1}LightAddr".format(this.id, this.type),
      header: {
        icon: "",
        title: "",
        menu: [],
        exitBtn: true
      }
    };
  },
  methods: {
    onClickChoice() {
      this.$emit("exitAlert");
    },
    onClickClose(key) {
      console.log(key);
      this.$emit("clickAddrClose");
    }
  },
  created() {},
  mounted() {
    this.header.title = this.title;
  },
  updated() {}
};
</script>

<style>
.vm-alert {
  z-index: 3000;
}
.vm-alert .modal-text {
  text-align: center;
  font-size: 12px;
}
.vm-alert .alert-tab_menu {
  width: 100%;
  text-align: center;
  margin-top: 12px;
}
.vm-alert .alert-tab_menu button {
  font-size: 12px;
  outline: none;
}
.vm-alert .alert-modal-body {
  padding: 10px;
}
</style>
