<script>
//Exporting this so it can be used in other components
import { Bar } from "vue-chartjs";
export default {
  mixins: [Bar],
  props: ["chartdata", "options"],
  data() {
    return {};
  },
  // computed:{
  //   chartdata: function() {
  //     console.log("????computed 에헤라 디야")
  //     return this.chartdata;
  //   }
  // },
  watch: {
    chartdata: function(newData, oldData) {
      console.log("????watch 에헤라 디야", newData, oldData);
      this._chart.destroy();
      //this.renderChart(this.data, this.options);
      this.renderBarChart();
    }
  },
  methods: {
    renderBarChart: function() {
      console.log(">>>에헤라>>>", this.chartdata);
      this.renderChart(this.chartdata, this.options);
    }
  },
  mounted() {
    // console.log(">>>>>>>>>>>>", this.chartdata, this.options)
    // this.renderChart(this.chartdata, this.options)
    this.renderBarChart();
  }
};
</script>
