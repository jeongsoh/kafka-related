<template lang="pug">
.modal-light-add.vm-light-add
  .modal-content(:id="key")
    .modal-header
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-bind:subTitle="subTitle")
    .modal-body
      vm-alert(ref="alert" @event="alertEvent")
      table(:class="modifyLight ? 'table-modify' : ''" style="table-layout:fixed")
        colgroup
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
          col(style="width:10%")
        tr
          th.left-first-child.lowast-span(colspan=2 :class="modifyLightMode()") 
            span &nbsp;&nbsp;도로조명 구분
            img.lowast(:src="require('@/assets/img/res/img/essential.png')")
          td.has_child.table-select-full-th.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_DATA_1[req.SL_DATA_1]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  //- li(@click="clickDropDown('SL_DATA_1', '0')" :class="dropdownChoice('가로등', code.SL_DATA_1[req.SL_DATA_1])") 가로등
                  //-   .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_DATA_1', key)" v-for="value, key in code.SL_DATA_1" :class="dropdownChoice(value, code.SL_DATA_1[req.SL_DATA_1])") {{value}}
                    .search-division-line
          td.img-td.left-last-child(colspan=6 rowspan=10 style="vertical-align:middle;" v-if="isAddrStep == 2")
            .picture_area.left-last-child
              //- img#first-picture.img-position(src="../../assets/img/bg/map.jpg" )
              .owl-carousel.owl-theme.img-position
                .item(v-for="(val, index) in pictureData" :key="val")
                  .owl-content
                    img(:src="val" :id="pictureNameInfo[index]" :class="owlImageClass(pictureNameInfo[index])" @click="onClickImage(pictureSLCODE[index])")
                    span.picture-date {{pictureDateInfo[index]}}
                    span.picture-page {{index + 1}} / {{pictureData.length}}
              img.non-picture(:src="require('@/assets/img/res/img/non-picture.png')")
          td.img-td.left-last-child(colspan=6 rowspan=12 style="vertical-align:middle;" v-if="isAddrStep == 3")
            .picture_area.left-last-child
              //- img#first-picture.img-position(src="../../assets/img/bg/map.jpg" )
              .owl-carousel.owl-theme.img-position
                .item(v-for="(val, index) in pictureData" :key="val")
                  .owl-content
                    img(:src="val" :id="pictureNameInfo[index]" :class="owlImageClass(pictureNameInfo[index])" @click="onClickImage(pictureSLCODE[index])")
                    span.picture-date {{pictureDateInfo[index]}}
                    span.picture-page {{index + 1}} / {{pictureData.length}}
              img.non-picture(:src="require('@/assets/img/res/img/non-picture.png')")
              //- button.add-picture(v-show="auth && modifyLight && pictureData.length != 5" :class="id" style="z-index:1") 사진 추가
              //- input.add-picture-input#web-fileUpload(type="file" :class="id" @change="loadImg" accept="image/*" v-show="false" )
        tr
          th.lowast-span(colspan=2 :class="modifyLightMode()") 
            span &nbsp;&nbsp;관리(표찰) 번호
            img.lowast(:src="require('@/assets/img/res/img/essential.png')")
          td.has_child.add-right-line(colspan=2)
            input.focus-set(v-model="req.SL_SLNAME" :disabled="!modifyLight")
        tr
          th.lowast-span(colspan=2 :class="modifyLightMode()")
            span &nbsp;&nbsp;주소1
            img.lowast(:src="require('@/assets/img/res/img/essential.png')")
          td.has_child.add-right-line(colspan=2 tabindex="-1")
            //- .text-align-end.light-addr-text(v-model="req.SL_ADDR" :disabled="!modifyLight" @click="onClickAddr") {{req.SL_ADDR}}
            .dropdown
              .dropdown__header(@click="toggleDropdown($event, req.SL_ADDR_1)")
                span {{req.SL_ADDR_1.split(":")[0]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(@click="clickDropDown('addr1', key)" v-for="value, key in addrCode" :class="dropdownChoice(key, req.SL_ADDR_1)" :data-val="value") {{key.toString().split(":")[0]}}
                    .search-division-line
        tr
          th.lowast-span(colspan=2 :class="modifyLightMode()")
            span &nbsp;&nbsp;주소2
            img.lowast(:src="require('@/assets/img/res/img/essential.png')")
          td.has_child.add-right-line(colspan=2 tabindex="-1")
            //- .text-align-end.light-addr-text(v-model="req.SL_ADDR" :disabled="!modifyLight" @click="onClickAddr") {{req.SL_ADDR}}
            .dropdown
              .dropdown__header(@click="toggleDropdown($event, req.SL_ADDR_2)")
                span {{req.SL_ADDR_2.split(":")[0]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(@click="clickDropDown('addr2', key)" v-for="value, key in addrCode[req.SL_ADDR_1]" :class="dropdownChoice(key, req.SL_ADDR_2)" :data-val="value") {{key.toString().split(":")[0]}}
                    .search-division-line
        tr(v-show="isAddrStep == 3")
          th.lowast-span(colspan=2 :class="modifyLightMode()")
            span &nbsp;&nbsp;주소3
            img.lowast(:src="require('@/assets/img/res/img/essential.png')")
          td.has_child.add-right-line(colspan=2 tabindex="-1")
            //- .text-align-end.light-addr-text(v-model="req.SL_ADDR" :disabled="!modifyLight" @click="onClickAddr") {{req.SL_ADDR}}
            .dropdown
              .dropdown__header(@click="toggleDropdown($event, req.SL_ADDR_3)")
                span {{req.SL_ADDR_3.toString().split(":")[0]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(@click="clickDropDown('addr3', value)" v-for="value, key in  (addrCode[req.SL_ADDR_1] != undefined ? addrCode[req.SL_ADDR_1][req.SL_ADDR_2] : [])" :class="dropdownChoice(value, req.SL_ADDR_3)" :data-val="value") {{value.toString().split(":")[0]}}
                    .search-division-line
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;관리 부서
          td.has_child.add-right-line(colspan=2)
            input(v-model="req.MANAGE_DEPT" :disabled="!modifyLight")
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;설치 부서(기관)
          td.has_child.add-right-line(colspan=2)
            input(v-model="req.INSTALL_DEPT" :disabled="!modifyLight")
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;전기요금
          td.has_child.table-select-full-th.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_DATA_2[req.SL_DATA_2]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all'" @click="clickDropDown('SL_DATA_2', key)" v-for="value, key in code.SL_DATA_2" :class="dropdownChoice(value, code.SL_DATA_2[req.SL_DATA_2])") {{value}}
                    .search-division-line        
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;고객 번호
          td.has_child.add-right-line(colspan=2)
            input(v-model="req.KEPCO_NUM" :disabled="!modifyLight")
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;전주 번호
          td.has_child.add-right-line(colspan=2)
            input(v-model="req.SL_SLNO" :disabled="!modifyLight")
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;빛 공해
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)" :class="modifyLightMode()")
                span {{req.POLLUTION_LIGHT}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('POLLUTION_LIGHT', value)" v-for="value, key in code.POLLUTION_LIGHT" :class="dropdownChoice(value, req.POLLUTION_LIGHT)") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('POLLUTION_LIGHT', '없음')" :class="dropdownChoice('없음', code.POLLUTION_LIGHT[req.POLLUTION_LIGHT])") 없음
                  //-   .search-division-line
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;설치 업체
          td.has_child.add-right-line(colspan=4)
            input(v-model="req.PT_INSTALL" :disabled="!modifyLight")
          td.has_child.add-right-line(colspan=2)
            input(type="text" v-model="req.PT_INSTALL_TEL" :disabled="!modifyLight" @keyup="getPhoneMask(req.PT_INSTALL_TEL, 'PT_INSTALL_TEL', $event)")
          td.has_child(colspan=2)
            input(type="text" v-model="req.PT_INSTALL_HAND" :disabled="!modifyLight" @keyup="getPhoneMask(req.PT_INSTALL_HAND, 'PT_INSTALL_HAND', $event)")
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;설치(준공) 일자
          td.has_child(colspan=2)
            date-range-picker(:singleDatePicker="true" :ranges="false" :startDate="startDate" :endDate="endDate" @update="updateDatepicker" :locale-data="locale" :opens="'right'" autoApply v-model="dataRange" style="width:100%; height:100%;" :show-dropdowns="true")
            //- input(v-model="req.INSTALL_DATE" :disabled="!modifyLight")
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;주소
          td.has_child(colspan=4)
            input.add-right-line(v-model="req.ADDRESS_OLD" :disabled="!modifyLight")
            //- .text-align-end.light-addr-text(v-if="!modifyLight") {{req.ADDRESS_OLD}}
          //- td.has_child(colspan=4)
          //-   .light-addr-text.text-align-end(v-if="!modifyLight") {{req.ADDRESS_NEW}}
          //-   input(v-model="req.ADDRESS_NEW" :disabled="!modifyLight" v-else)
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;하자완료일
          td.has_child(colspan=2)
            date-range-picker(:singleDatePicker="true" :ranges="false" :startDate="startDateFinish" :endDate="endDateFinish" @update="updateDatepicker" :locale-data="localeFinish" :opens="'right'" autoApply v-model="dataRangeFinish" style="width:100%; height:100%;"  :show-dropdowns="true")
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;{{$store.getters.filter['filter_1']}} / {{$store.getters.filter['filter_2']}}
          td.has_child.add-right-line(colspan=2)
            input(v-model="req.FILTER_STREET" :disabled="!modifyLight")
          td.has_child(colspan=2)
            input(v-model="req.FILTER_VILLAGE" :disabled="!modifyLight")
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;등주 형식
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_DATA_5[req.SL_DATA_5]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all'" @click="clickDropDown('SL_DATA_5', key)" v-for="value, key in code.SL_DATA_5" :class="dropdownChoice(value, code.SL_DATA_5[req.SL_DATA_5])") {{value}}
                    .search-division-line        
          td.has_child.table-select-full-th.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.POLES_DIRECTION[req.POLES_DIRECTION]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('POLES_DIRECTION', key)" v-for="value, key in code.POLES_DIRECTION" :class="dropdownChoice(value, code.POLES_DIRECTION[req.POLES_DIRECTION])") {{value}}
                    .search-division-line
                  li(@click="clickDropDown('POLES_DIRECTION', '없음')" :class="dropdownChoice('없음', code.POLES_DIRECTION[req.POLES_DIRECTION])") 없음
                    .search-division-line        
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.PED_LIGHTING[req.PED_LIGHTING]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('PED_LIGHTING', key)" v-for="value, key in code.PED_LIGHTING" :class="dropdownChoice(value, code.PED_LIGHTING[req.PED_LIGHTING])") {{value}}
                    .search-division-line   
                  li(@click="clickDropDown('PED_LIGHTING', '없음')" :class="dropdownChoice('없음', code.PED_LIGHTING[req.PED_LIGHTING])") 없음
                    .search-division-line     
          td.has_child.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.POLES_HEIGHT[req.POLES_HEIGHT]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('POLES_HEIGHT', key)" v-for="value, key in code.POLES_HEIGHT" :class="dropdownChoice(value, code.POLES_HEIGHT[req.POLES_HEIGHT])") {{value}}
                    .search-division-line      
                  li(@click="clickDropDown('POLES_HEIGHT', '없음')" :class="dropdownChoice('없음', code.POLES_HEIGHT[req.POLES_HEIGHT])") 없음
                    .search-division-line  
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;등기구1(단방향)
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{req.LF_1_LAMP}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_1_LAMP', value)" v-for="value, key in code.LF_LAMP" :class="dropdownChoice(value, req.LF_1_LAMP)") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_1_LAMP', '없음')" :class="dropdownChoice('없음', code.LF_LAMP[req.LF_1_LAMP])") 없음
                  //-   .search-division-line
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{req.LF_1_POWER}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_1_POWER', value)" v-for="value, key in code.LF_POWER" :class="dropdownChoice(value, req.LF_1_POWER)") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_1_POWER', '없음')" :class="dropdownChoice('없음', code.LF_POWER[req.LF_1_POWER])") 없음
                  //-   .search-division-line
          td.has_child.table-select-full-th.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.LF_TYPE[req.LF_1_TYPE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_1_TYPE', key)" v-for="value, key in code.LF_TYPE" :class="dropdownChoice(value, code.LF_TYPE[req.LF_1_TYPE])") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_1_TYPE', '없음')" :class="dropdownChoice('없음', code.LF_TYPE[req.LF_1_TYPE])") 없음
                  //-   .search-division-line
          td.has_child.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.LF_FORM[req.LF_1_FORM]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_1_FORM', key)" v-for="value, key in code.LF_FORM" :class="dropdownChoice(value, code.LF_FORM[req.LF_1_FORM])") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_1_FORM', '없음')" :class="dropdownChoice('없음', code.LF_FORM[req.LF_1_FORM])") 없음
                  //-   .search-division-line
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;등기구2(양방향)
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{req.LF_2_LAMP}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_2_LAMP', value)" v-for="value, key in code.LF_LAMP" :class="dropdownChoice(value, req.LF_2_LAMP)") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_2_LAMP', '없음')" :class="dropdownChoice('없음', code.LF_LAMP[req.LF_2_LAMP])") 없음
                  //-   .search-division-line
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{req.LF_2_POWER}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_2_POWER', value)" v-for="value, key in code.LF_POWER" :class="dropdownChoice(value, req.LF_2_POWER)") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_2_POWER', '없음')" :class="dropdownChoice('없음', code.LF_POWER[req.LF_2_POWER])") 없음
                  //-   .search-division-line
          td.has_child.table-select-full-th.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.LF_TYPE[req.LF_2_TYPE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_2_TYPE', key)" v-for="value, key in code.LF_TYPE" :class="dropdownChoice(value, code.LF_TYPE[req.LF_2_TYPE])") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_2_TYPE', '없음')" :class="dropdownChoice('없음', code.LF_TYPE[req.LF_2_TYPE])") 없음
                  //-   .search-division-line
          td.has_child.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.LF_FORM[req.LF_2_FORM]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_2_FORM', key)" v-for="value, key in code.LF_FORM" :class="dropdownChoice(value, code.LF_FORM[req.LF_2_FORM])") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_2_FORM', '없음')" :class="dropdownChoice('없음', code.LF_FORM[req.LF_2_FORM])") 없음
                  //-   .search-division-line
        tr
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;등기구3(보행자)
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{req.LF_3_LAMP}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_3_LAMP', value)" v-for="value, key in code.LF_LAMP" :class="dropdownChoice(value, req.LF_3_LAMP)") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_3_LAMP', '없음')" :class="dropdownChoice('없음', code.LF_LAMP[req.LF_3_LAMP])") 없음
                  //-   .search-division-line
          td.has_child.add-right-line.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{req.LF_3_POWER}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_3_POWER', value)" v-for="value, key in code.LF_POWER" :class="dropdownChoice(value, req.LF_3_POWER)") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_3_POWER', '없음')" :class="dropdownChoice('없음', code.LF_POWER[req.LF_3_POWER])") 없음
                  //-   .search-division-line
          td.has_child.table-select-full-th.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.LF_TYPE[req.LF_3_TYPE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_3_TYPE', key)" v-for="value, key in code.LF_TYPE" :class="dropdownChoice(value, code.LF_TYPE[req.LF_3_TYPE])") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_3_TYPE', '없음')" :class="dropdownChoice('없음', code.LF_TYPE[req.LF_3_TYPE])") 없음
                  //-   .search-division-line
          td.has_child.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.LF_FORM[req.LF_3_FORM]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('LF_3_FORM', key)" v-for="value, key in code.LF_FORM" :class="dropdownChoice(value, code.LF_FORM[req.LF_3_FORM])") {{value}}
                    .search-division-line
                  //- li(@click="clickDropDown('LF_3_FORM', '없음')" :class="dropdownChoice('없음', code.LF_FORM[req.LF_3_FORM])") 없음
                  //-   .search-division-line
        tr
          th(colspan=2 :class="modifyLightMode()" v-if="req.SL_DATA_1 == 4 || req.SL_DATA_1 == 1") &nbsp;&nbsp;점멸기
          th(colspan=2 :class="modifyLightMode()" v-else) &nbsp;&nbsp;등주감시기
          td.has_child.table-select-full-th(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.WORK_TYPE[req.WORK_TYPE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('WORK_TYPE', '-1')" :class="dropdownChoice('양방향(LoRa)', code.WORK_TYPE[req.WORK_TYPE])") 양방향(LoRa)
                    .search-division-line
                  li(v-if="key != 'all' && key != '99' && key != '-1'" @click="clickDropDown('WORK_TYPE', key)" v-for="value, key in code.WORK_TYPE" :class="dropdownChoice(value, code.WORK_TYPE[req.WORK_TYPE])") {{value}}
                    .search-division-line
                  li(@click="clickDropDown('WORK_TYPE', '99')" :class="dropdownChoice('99', code.WORK_TYPE[req.WORK_TYPE])") 없음
                    .search-division-line
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;QR Code
          td.has_child.add-right-line(colspan=2 :class="serialTdClass('serial1')")
            input.serial(v-model="req.GD_SERIAL" :disabled="false" :class="serialClass('serial1')" @keyup="errRest()")
          td.has_child(colspan=2 v-if="req.SL_DATA_1 == 4 || req.SL_DATA_1 == 8 || req.SL_DATA_1 == 9 || req.SL_DATA_1 == 10" :class="serialTdClass('serial2')")
            input.serial(v-model="req.GD_SERIAL_2" :disabled="req.SL_DATA_1 != 4" :class="serialClass('serial2')" @keyup="errRest()")
          td.has_child(colspan=2 v-else)
        tr(v-if="req.SL_DATA_1 == 0")
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;분전함번호
          td.has_child(colspan=2)
            input(v-model="req.DISTRIBUTION_NUM" :disabled="!modifyLight")
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;등주감시기 위치
          td.has_child.add-right-line(colspan=1 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.MONITOR_LINE[req.MONITOR_LINE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('MONITOR_LINE', key)" v-for="value, key in code.MONITOR_LINE" :class="dropdownChoice(value, code.MONITOR_LINE[req.MONITOR_LINE])") {{value}}
                    .search-division-line
                  li(@click="clickDropDown('MONITOR_LINE', '없음')" :class="dropdownChoice('없음', code.MONITOR_LINE[req.MONITOR_LINE])") 없음
                    .search-division-line
          td.has_child.add-right-line(colspan=1 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.MONITOR_CIRCUIT[req.MONITOR_CIRCUIT]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('MONITOR_CIRCUIT', key)" v-for="value, key in code.MONITOR_CIRCUIT" :class="dropdownChoice(value, code.MONITOR_CIRCUIT[req.MONITOR_CIRCUIT])") {{value}}
                    .search-division-line
                  li(@click="clickDropDown('MONITOR_CIRCUIT', '없음')" :class="dropdownChoice('없음', code.MONITOR_CIRCUIT[req.MONITOR_CIRCUIT])") 없음
                    .search-division-line
          td.has_child(colspan=2)
            input(v-model="req.MONITOR_POSITION" :disabled="!modifyLight")
        tr(v-if="req.SL_DATA_1 == 0")
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;설치 형태
          td.has_child.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.INSTALL_TYPE[req.INSTALL_TYPE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('INSTALL_TYPE', key)" v-for="value, key in code.INSTALL_TYPE" :class="dropdownChoice(value, code.INSTALL_TYPE[req.INSTALL_TYPE])") {{value}}
                    .search-division-line
                  li(@click="clickDropDown('INSTALL_TYPE', '없음')" :class="dropdownChoice('없음', code.INSTALL_TYPE[req.INSTALL_TYPE])") 없음
                    .search-division-line
          td.has_child(colspan=6)
        tr(v-if="req.SL_DATA_1 == 4")
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;(총) 등 개수
          td.has_child(colspan=2)
            input(v-model="req.DISTRIBUTION_TOTAL + '개'" :disabled="true")
          th(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;분전함 총 회로수
          td.has_child.add-right-line(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.DISTRIBUTION_LINE[req.DISTRIBUTION_LINE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('DISTRIBUTION_LINE', key)" v-for="value, key in code.DISTRIBUTION_LINE" :class="dropdownChoice(value, code.DISTRIBUTION_LINE[req.DISTRIBUTION_LINE])") {{value}}
                    .search-division-line
                  li(@click="clickDropDown('DISTRIBUTION_LINE', '없음')" :class="dropdownChoice('없음', code.DISTRIBUTION_LINE[req.DISTRIBUTION_LINE])") 없음
                    .search-division-line
          td.has_child(colspan=2 tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.DISTRIBUTION_CIRCUIT[req.DISTRIBUTION_CIRCUIT]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(v-if="key != 'all' && key != '없음'" @click="clickDropDown('DISTRIBUTION_CIRCUIT', key)" v-for="value, key in code.DISTRIBUTION_CIRCUIT" :class="dropdownChoice(value, code.DISTRIBUTION_CIRCUIT[req.DISTRIBUTION_CIRCUIT])") {{value}}
                    .search-division-line
                  li(@click="clickDropDown('DISTRIBUTION_CIRCUIT', '없음')" :class="dropdownChoice('없음', code.DISTRIBUTION_CIRCUIT[req.DISTRIBUTION_CIRCUIT])") 없음
                    .search-division-line
        tr(v-if="req.SL_DATA_1 == 4")
          th(colspan=2 rowspan=2 :class="modifyLightMode()") &nbsp;&nbsp;(회로) 등 개수
          td.has_child(colspan=1 v-for="val in 8" :class="val != 8? 'add-right-line': ''")
            input(:value="val+'분기'" :disabled="true")
        tr(v-if="req.SL_DATA_1 == 4")
          td.has_child.add-right-line(colspan=1 v-for="val in $_.range(1, 9, 1)")
            input(:value="'0개'" :disabled="true")
        tr
          th.memo-middle.th-item.right-first-child(colspan=2 :class="modifyLightMode()") &nbsp;&nbsp;메모
          td.has_child.textarea-td.last-clear-bottom(colspan=8)
            textarea(v-model="req.SL_ETC" :disabled="!modifyLight")
      .tab_menu
        span.err_content {{errContent}}
        button.modal-modify-btn(type="button" class="btn btn-outline-primary" v-if="modifyLight" @click="getSlnameOverlapAPI") 저장
  transition(name='modal' v-if="name")
    .modal-background(style="pointer-events: auto;")
      .modal-position
        | 중복되는 이름의 시설물이 {{nameCheck["data"].length}}개 있습니다. 변경하시겠습니까?
        br
        div(v-for="value in nameCheck['data']")
          | * {{value.SL_SLNAME}} {{value.SL_ADDR}}
          br
        | 수정을 취소하고 다른 작업을 진행하시겠습니까?
        br
        button.spinner-btn.spinner-left(@click="name = false") 취소
        button.spinner-btn.spinner-right(@click="onClickSaveLight") 확인
  VM-light-addr(:id="id" :type="type" :key="key" v-on:clickAddrClose="onClickAddrClose" v-if="modalLightAddr")
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
import VMLightAddr from "@/components/modal/VMLightAddr";
import deviceCode from "@/assets/json/deviceCode.json";
import DateRangePicker from "vue2-daterange-picker";

export default {
  components: {
    VMLightAddr,
    DateRangePicker
  },
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    },
    auth: {
      type: Boolean,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "신규 시설물 설치",
        menu: [],
        exitBtn: true
      },
      subTitle: "작성중",
      req: {
        SL_DATA_6: "",
        SL_DATA_7: "",
        SL_DATA_1: "",
        SL_SLNAME: "",
        SL_ADDR: "",
        SL_ADDR_1: "",
        SL_ADDR_2: "",
        SL_ADDR_3: "",
        MANAGE_DEPT: "",
        INSTALL_DEPT: "",
        SL_DATA_2: "",
        KEPCO_NUM: "",
        METER_NUM: "",
        SL_SLNO: "",
        POLLUTION_LIGHT: "",
        PT_INSTALL: "",
        PT_INSTALL_TEL: "",
        PT_INSTALL_HAND: "",
        INSTALL_DATE: "",
        ADDRESS_OLD: "",
        ADDRESS_NEW: "",
        REPAIRED_DATE: "",
        FILTER_STREET: "",
        FILTER_VILLAGE: "",
        SL_DATA_5: "",
        POLES_DIRECTION: "",
        PED_LIGHTING: "",
        POLES_HEIGHT: "",
        LF_1_LAMP: "",
        LF_1_POWER: "",
        LF_1_TYPE: "",
        LF_1_FORM: "",
        LF_2_LAMP: "",
        LF_2_POWER: "",
        LF_2_TYPE: "",
        LF_2_FORM: "",
        LF_3_LAMP: "",
        LF_3_POWER: "",
        LF_3_TYPE: "",
        LF_3_FORM: "",
        WORK_TYPE: "",
        GD_SERIAL: "",
        GD_SERIAL_2: "",
        special_setting: {
          SPECIAL_TITLE: ""
        },
        SL_ETC: "",
        DISTRIBUTION_NUM: "",
        DISTRIBUTION_LINE: "",
        DISTRIBUTION_CIRCUIT: "",
        MONITOR_LINE: "",
        MONITOR_POSITION: "",
        INSTALL_TYPE: "",
        ESCO: "",
        PARENT_CIRCUIT_INFO: "",
        SL_MAN: "",
        SL_MAN2: "",
        SL_HAND: "",
        SL_HAND2: "",
        ENABLE_SMPS_SENSOR: "0",
        MONITOR_0: 0,
        MONITOR_1: 0,
        MONITOR_2: 0,
        MONITOR_3: 0,
        MONITOR_4: 0,
        MONITOR_5: 0,
        MONITOR_6: 0,
        MONITOR_7: 0,
        DISTRIBUTION_TOTAL: 0,
        MONITOR_CIRCUIT: ""
      },
      res: {},
      dataRange: {
        startDate: new Date(),
        endDate: new Date()
      },
      startDate: new Date(),
      endDate: new Date(),
      dataRangeFinish: {
        startDate: new Date(),
        endDate: new Date()
      },
      startDateFinish: new Date(),
      endDateFinish: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      localeFinish: {},
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      modifyLight: true,
      modalLightAddr: false,
      name: false,
      code: "",
      nameCheck: {},
      imgPreview: false,
      uploadData: false,
      pictureData: [],
      pictureNameInfo: [],
      pictureSLCODE: [],
      pictureDateInfo: [],
      pictureIndex: 0,
      specialTitle: "",
      errCheck: "",
      errContent: "",
      addrCode: {}
    };
  },
  computed: {
    isAddrStep() {
      return window.addrStep;
    }
  },
  methods: {
    ADDR() {
      return this.req.SL_ADDR.split(" ")[0];
    },
    getSlnameOverlapAPI() {
      // NOTE :: 입력 데이터 검증
      while (
        this.req.SL_SLNAME.search(
          /^[~!@#$%^&*()_+|<>?:{}가-힣ㄱ-ㅎㅏ-ㅣa-zA-Z0-9-]{0,16}$/
        ) == -1
      ) {
        this.$refs.alert.init(
          "black",
          null,
          "시설물의 이름을 다시 입력해주세요. ",
          "(공백,스페이스바는 입력할수 없습니다.) (최대 16글자)",
          null,
          true,
          false
        );
        return;
      }
      if (this.isAddrStep == 2) {
        if (this.req.SL_ADDR_1 == "" || this.req.SL_ADDR_2 == "") {
          this.$refs.alert.init(
            "black",
            null,
            "주소를 입력해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      } else {
        if (
          this.req.SL_ADDR_1 == "" ||
          this.req.SL_ADDR_2 == "" ||
          this.req.SL_ADDR_3 == ""
        ) {
          this.$refs.alert.init(
            "black",
            null,
            "주소를 입력해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      }
      if (this.req.DISTRIBUTION_NUM != null) {
        while (
          this.req.DISTRIBUTION_NUM.search(
            /^[~!@#$%^&*()_+|<>?:{}가-힣ㄱ-ㅎㅏ-ㅣa-zA-Z0-9-]{0,16}$/
          ) == -1
        ) {
          this.$refs.alert.init(
            "black",
            null,
            "분전함 번호를 다시 확인 바랍니다.",
            "(공백,스페이스바는 입력할수 없습니다.) (최대 16글자)",
            null,
            true,
            false
          );
          return;
        }
      }
      var requestData = {
        slname: this.req.SL_SLNAME
      };
      var vm = this;
      API_GET("slname/overlap", requestData).done(function(res) {
        if (res["data"].length > 0) {
          vm.nameCheck = res;
          vm.name = true;
        } else {
          vm.onClickSaveLight();
        }
      });
    },
    onClickAddrClose() {
      this.modalLightAddr = false;
    },
    onClickAddr(name, data, type) {
      if (this.modifyLight) {
        EventBus.$emit(name, data, type);
      }
    },
    onClickClose(key) {
      console.log(key);
      this.$store.commit("modal_close", key);
      EventBus.$off("postFacilityAPI");
    },
    onClickSaveLight() {
      // NOTE :: 시설물 저장 클릭하여 위치 지정하는 단계로 이동
      this.$store.commit("panel_class", "hidden");
      $("#modal_area").addClass("hidden");
      let panel_level = this.$store.getters.panel_location_name;
      window.facilityInstall(panel_level);
    },
    postFacilityAPI() {
      // NOTE :: 시설물 신규 설치
      if (this.req.GD_SERIAL == null) {
        this.req.GD_SERIAL = "";
      }
      if (this.req.GD_SERIAL_2 == null) {
        this.req.GD_SERIAL_2 = "";
      }
      if (this.req.SL_SLNAME == "") {
        this.req.SL_SLNAME = "시설물";
      }
      this.req.SL_TEL = null;
      this.req.latitude = window.installObj.MAP_Y;
      this.req.longitute = window.installObj.MAP_X;
      if (this.isAddrStep == 2) {
        this.req.SL_ADDR =
          this.req.SL_ADDR_1.toString().split(":")[0] +
          " " +
          this.req.SL_ADDR_2.toString().split(":")[0] +
          " " +
          this.req.SL_ADDR_2.toString().split(":")[0];
      } else {
        this.req.SL_ADDR =
          this.req.SL_ADDR_1.toString().split(":")[0] +
          " " +
          this.req.SL_ADDR_2.toString().split(":")[0] +
          " " +
          this.req.SL_ADDR_3.toString().split(":")[0];
      }
      for (var key in this.req) {
        if (this.req[key] == "" && key != "GD_SERIAL" && key != "GD_SERIAL_2") {
          this.req[key] = null;
        }
      }
      this.req.INSTALL_DATE = this.moment(this.dataRange.endDate).format(
        "YYYY-MM-DD"
      );
      this.req.REPAIRED_DATE = this.moment(this.dataRangeFinish.endDate).format(
        "YYYY-MM-DD"
      );
      console.log("postFacilityAPI", this.req);
      window.installMoveStatus = false;
      window.installMoveSLCODE = false;
      window.overlayObjects[window.overlayObjects.length - 1]["Object"].setMap(
        null
      );
      var vm = this;
      this.$_API_POST("facility", this.req)
        .then(function(res) {
          console.log("postFacilityAPI facility", res);
          $("#sidebar > *").removeClass("pointer-events-none");
          $("#sidebar").unbind("click");
          vm.$store.commit("status", "");
          vm.onClickClose(vm.key);
          $("#modal_area").removeClass("hidden");
          window.invalidateLight = true;
          window.WatchPosition();
        })
        .catch(function(err) {
          console.log("testsetsetset", err);
          if (err == "Error: 정확한 Serial1을 입력해 주세요") {
            vm.errCheck = "serial1";
            vm.errContent = "QR Code 1번이 올바르지 않은 번호입니다.";
          } else if (err == "Error: 정확한 Serial2를 입력해 주세요") {
            vm.errCheck = "serial2";
            vm.errContent = "QR Code 2번이 올바르지 않은 번호입니다.";
          } else {
            vm.$refs.alert.init(
              "black",
              null,
              "설치 오류",
              null,
              null,
              true,
              false
            );
          }
          vm.name = false;
          window.installFlag = true;
          window.cancelMoving(false);
          $("#modal_area").removeClass("hidden");
          vm.req.SL_ADDR = vm.req.SL_ADDR.split(" ")[0];
        });
    },
    modifyLightMode() {
      if (this.modifyLight) {
        return "modify-light-mode";
      } else {
        return "";
      }
    },
    memoHeight() {
      if (this.req.SL_DATA_1 != "1") {
        return "memo";
      } else {
        return "memo-double";
      }
    },
    closeModal() {
      this.$store.commit("modal_all_close", this.key.split(":")[0]);
    },
    toggleDropdown(event, index) {
      event.currentTarget.classList.toggle("is-active");
      console.log(index);
      if (index != undefined) {
        console.log(
          $(
            ".vm-light-add .dropdown__content li[data-val='" + index + "']"
          ).index()
        );
        var liIndex =
          $(
            ".vm-light-add .dropdown__content li[data-val='" + index + "']"
          ).index() + 1;
        $(".vm-light-add .dropdown__content").scrollTop(
          $(
            ".vm-light-add .dropdown__content li:nth-child(" + liIndex + ")"
          ).position().top
        );
      }
    },
    clickDropDown(type, data) {
      if (type == "addr1") {
        this.req.SL_ADDR_1 = data;
        this.req.SL_ADDR_2 = Object.keys(this.addrCode[this.req.SL_ADDR_1])[0];
        this.req.SL_ADDR_3 = this.addrCode[this.req.SL_ADDR_1][
          this.req.SL_ADDR_2
        ][0];
      } else if (type == "addr2") {
        this.req.SL_ADDR_2 = data;
        this.req.SL_ADDR_3 = this.addrCode[this.req.SL_ADDR_1][
          this.req.SL_ADDR_2
        ][0];
      } else if (type == "addr3") {
        this.req.SL_ADDR_3 = data;
      } else {
        this.req[type] = data;
      }
      $(".vm-light-add .dropdown__header").removeClass("is-active");
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    updateDatepicker(value) {},
    GetFacilityInfoAPI() {
      var vm = this;
      this.$_API_GET("postcode", {}, 24 * 7)
        .then(function(res) {
          console.log("postcode", res);
          for (var key in res) {
            for (var value in res[key]) {
              if (key != "SIDOSGG_CD") {
                vm.res[key.split(":")[0]] = value.split(":")[0];
                // vm.res[key.split(":")[0]] += value.split(":")[0];
              }
            }
          }
          if (Object.keys(vm.res).length == 1) {
            vm.req.SL_ADDR = vm.res[Object.keys(vm.res)[0]];
          }
        })
        .then(() => {
          vm.$forceUpdate();
        })
        .catch(function() {
          vm.$refs.alert.init(
            "black",
            null,
            "주소 가져오기 실패",
            null,
            null,
            true,
            false
          );
        });
    },
    getPhoneMask(val, key, event) {
      if (event.keyCode >= 48 && event.keyCode <= 57) {
        let res = this.getMask(val);
        this.req[key] = res;
      } else {
        // $(event.path)
        //   .eq(0)
        //   .val(val.replace(/[^0-9]/gi, ""));
      }
    },
    getMask(phoneNumber) {
      var number = phoneNumber.replace(/[^0-9]/gi, "");
      var tel = "";

      // 서울 지역번호(02)가 들어오는 경우
      if (number.substring(0, 2).indexOf("02") == 0) {
        if (number.length < 3) {
          return number;
        } else if (number.length < 6) {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2);
        } else if (number.length < 10) {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2, 3);
          tel += "-";
          tel += number.substr(5);
        } else {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2, 4);
          tel += "-";
          tel += number.substr(6);
        }

        // 서울 지역번호(02)가 아닌경우
      } else {
        if (number.length < 4) {
          return number;
        } else if (number.length < 7) {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3);
        } else if (number.length < 11) {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3, 3);
          tel += "-";
          tel += number.substr(6);
        } else {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3, 4);
          tel += "-";
          tel += number.substr(7);
        }
      }

      return tel;
    },
    serialClass(data) {
      if (this.errCheck == data) {
        return "err_serial";
      } else {
        return "";
      }
    },
    serialTdClass(data) {
      if (this.errCheck == data) {
        return "err_serial_td";
      } else {
        return "";
      }
    },
    errRest() {
      this.errCheck = "";
      this.errContent = "";
    },
    alertEvent(key, inputData) {
      switch (key) {
        case "closeModal":
          this.closeModal();
          break;
      }
    },
    getDataCode() {
      var vm = this;
      this.$_API_GET("datacode", undefined, 1)
        .then(function(res) {
          datacode = {};
          res.forEach(function(value) {
            if (!(value.SL_GRP in datacode)) {
              datacode[value.SL_GRP] = [value];
            } else {
              datacode[value.SL_GRP].push(value);
            }
          });
          var TYPES_IDS = [0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
          // 시설물 종류
          datacode["D1"].forEach(function(val) {
            if ($.inArray(val.SL_VALUE, TYPES_IDS) >= 0) {
              if (
                $.inArray(val.SL_VALUE, [
                  TYPE_BOX_DISTRIBUTION_SUB_MODULE_A,
                  TYPE_BOX_DISTRIBUTION_SUB_MODULE_B
                ]) >= 0
              ) {
                // $('#light_type').append('<option value=' + val.SL_VALUE + ' style="display: none;">' + val.SL_DESC + '</option>');
              } else {
                // $('#light_type').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
                vm.code["SL_DATA_1"][val.SL_VALUE] = val.SL_DESC;
              }
            }
          });
          // 요금형태
          datacode["D2"].forEach(function(val) {
            vm.code["SL_DATA_2"][val.SL_VALUE] = val.SL_DESC;
          });
          // 등기구 형태
          datacode["D5"].forEach(function(val) {
            vm.code["SL_DATA_5"][val.SL_VALUE] = val.SL_DESC;
          });
          // 운영방식
          datacode["D8"].sort(function(a, b) {
            return a.SL_VALUE > b.SL_VALUE;
          });
          datacode["D8"].forEach(function(val) {
            vm.code["WORK_TYPE"][val.SL_VALUE] = val.SL_DESC;
          });
          // 램프종류
          datacode["D6"].forEach(function(val) {
            vm.code["LF_LAMP"][val.SL_VALUE] = val.SL_DESC;
          });
          // 소비전력
          datacode["D7"].forEach(function(val) {
            vm.code["LF_POWER"][val.SL_VALUE] = val.SL_DESC;
          });
        })
        .then(() => {
          vm.$forceUpdate();
        })
        .catch(function() {
          vm.$refs.alert.init(
            "black",
            null,
            "데이터 코드 가져오기 실패",
            null,
            null,
            true,
            false
          );
        });
    }
  },
  created() {},
  mounted() {
    this.code = JSON.parse(JSON.stringify(deviceCode));
    this.localeFinish = JSON.parse(JSON.stringify(this.locale));
    this.GetFacilityInfoAPI();
    this.getDataCode();
    this.addrCode = postcode;
    this.clickDropDown("addr1", Object.keys(this.addrCode)[0]);
    var vm = this;
    EventBus.$on("postFacilityAPI", function() {
      vm.postFacilityAPI();
    });

    EventBus.$on(this.id + "addr", function(addr) {
      vm.req.SL_ADDR = addr;
    });

    EventBus.$on(this.id + "lightModifyStatus", function() {
      if (vm.modifyLight) {
        vm.$refs.alert.init(
          "white",
          null,
          "신규 시설물 설치 중입니다",
          "설치를 취소하고 종료하시겠습니까?",
          null,
          "closeModal",
          true
        );
      } else {
        vm.$store.commit("modal_all_close", vm.key.split(":")[0]);
      }
    });

    Vue.nextTick(function() {
      $(".vm-light-add .has_child").focusout(function(e) {
        $(".vm-light-add .dropdown__header").removeClass("is-active");
      });
      setTimeout(function() {
        $(".vm-light-add .focus-set").focus();
      }, 0);
    });
  },
  updated() {
    console.log("updated base modal");
  },
  beforeDestroy() {
    EventBus.$off("postFacilityAPI");
    EventBus.$off(this.id + "addr");
    EventBus.$off(this.id + "lightModifyStatus");
  }
};
</script>

<style>
.modal-light-add.vm-light-add {
  min-width: 520px; /* NOTE: dialog에 따라 width 사이즈 다르게 설정 */
}
.vm-light-add .form-control {
  padding: 3px 12px 6px 3px;
  height: 21px;
}
.vm-light-add .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
}

.vm-light-add .tab_menu > button.modal-remove-btn {
  float: left;
}
.vm-light-add .tab_menu button:hover {
  background: #016aae;
}
.vm-light-add .tab_menu button.modal-remove-btn {
  background: rgb(181, 181, 181);
}
.vm-light-add .tab_menu button.modal-remove-btn:hover {
  background: #a0a0a0;
}
.vm-light-add .add-right-line {
  border-right: 0.6px solid rgba(195, 195, 195, 0.3);
}

.vm-light-add .lowast-span {
  vertical-align: bottom;
}
.vm-light-add .err_serial {
  background: #ffd7d7;
  color: #f15858;
}
.vm-light-add .err_serial_td {
  border-bottom: 1px solid #ffd7d7;
}
.vm-light-add .err_content {
  font-weight: normal;
  font-size: 12px;
  line-height: 30px;
  color: #f15858;
}
</style>

<style lang="scss">
.vm-light-add {
  & * {
    font-size: 12px;
  }
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.modify-light-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0;
      -webkit-border-radius: 10px 0 0 0;
      border-radius: 10px 0 0 0;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0 0;
      -webkit-border-radius: 0 10px 0 0;
      border-radius: 0 10px 0 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>

<style lang="scss">
// NOTE :: DropDown CSS
.vm-light-add {
  & .dropdown {
    width: 100%;
    &__header {
      background: #fff;
      font-size: 12px;
      cursor: pointer;
      line-height: 20px;
      position: relative;
      text-overflow: ellipsis;
      color: #000;
      width: 100%;
      height: 21px;
      i.fas {
        position: absolute;
        right: 4px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 10px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &.is-active {
        outline: -webkit-focus-ring-color auto 1px;
        outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
        }
        + .dropdown__content.dropdown__longdata {
          max-height: 220px;
          overflow: scroll;
        }
      }
      & span {
        padding-left: 7px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #fff;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #000;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>
