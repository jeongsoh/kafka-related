<template lang="pug">
.vm-header(:class="modalKey")
  .modal-icon
    img.icon(v-if="icon != ''" :src="require('@/assets/img/res/img/' + icon)")
  .modal-title
    .main-title
      h6
        b(style="font-size:13px;") {{title}}
    .sub-title(v-if="subTitle != undefined && subTitle != ''")
      span {{subTitle}}
  .modal-exit
    .close(v-if="exitBtn" @click="onClickClose(modalKey)") &times;
  .modal-tabs
    .tabs(v-for="value in tab" :class="tabWidth()")
      .tab( @click="onClickTab(value)" :class="checkTab(value)")
        //- img.extend-icon(:src="require('@/assets/img/res/img/modal_out.png')")
        span {{value}}
</template>

<script>
// NOTE :: 모달 공통 헤더
import Vue from "vue";
import { EventBus } from "@/main";

export default {
  props: {
    icon: {
      type: String,
      required: false
    },
    title: {
      type: String,
      requied: false
    },
    menu: {
      type: Array,
      requied: false
    },
    exitBtn: {
      type: Boolean,
      required: false
    },
    modalKey: {
      type: String,
      required: false
    },
    tab: {
      type: Array,
      requied: false
    },
    choiceTab: {
      type: String,
      requied: false
    },
    id: {
      type: String, // Number
      required: false
    },
    subTitle: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      icn_blink: ""
    };
  },
  methods: {
    checkTab(value) {
      if (value == this.choiceTab) {
        return "enable-tab";
      } else {
        return "disable-tab";
      }
    },
    onClickClose(modalKey) {
      // NOTE :: 모달 종료 처리
      console.log("modalKey", modalKey);
      // this.$store.commit("modal_all_close", modalKey.split(":")[0]);
      if (modalKey != undefined) {
        if (
          modalKey.split(":")[1] == "VMLight" ||
          modalKey.split(":")[1] == "VMLightAdd" ||
          modalKey.split(":")[1] == "VMComplainRegister" ||
          modalKey.split(":")[1] == "VMComplainInfo" ||
          modalKey.split(":")[1] == "VMComplaintList"
        ) {
          if (modalKey.split(":")[1] == "VMLight") {
            console.log(modalKey.split(":")[0] + "lightModifyStatus");
            if (this.choiceTab == "상세") {
              EventBus.$emit(modalKey.split(":")[0] + "lightModifyStatusLight");
            } else {
              console.log(modalKey.split(":")[0] + "lightModifyStatus");
              EventBus.$emit(
                modalKey.split(":")[0] + "lightModifyStatusConfig"
              );
            }
          } else if (modalKey.split(":")[1] == "VMComplaintList") {
            EventBus.$emit(modalKey.split(":")[0] + "ComplaintListModalClose");
          } else {
            EventBus.$emit(modalKey.split(":")[0] + "lightModifyStatus");
          }
          // this.$store.commit("modal_all_close", modalKey.split(":")[0]);
        } else {
          console.log("click Close");
          this.$emit("clickClose");
        }
      } else {
        this.$emit("clickClose");
      }
    },
    tabWidth() {
      if (this.title == undefined) {
        return "tabs-light";
      }
      if (this.title.indexOf("민원 처리") == 0) {
        return "tabs-complain";
      } else {
        return "tabs-light";
      }
    },
    onClickTab(value) {
      this.$emit("clickTab", value);
    }
  },
  mounted() {
    console.log("icon", this.icon);
    console.log("title", this.title);
    console.log("menu", this.menu);
    console.log("exitBtn", this.exitBtn);
    console.log("key", this.modalKey);
    console.log("tab", this.tab);
    console.log("choiceTab", this.choiceTab);
    console.log("subTitle", this.subTitle);
    $(".vm-header .tabs").focusout(function(e) {});
    $(".vm-header .tab").focusout(function(e) {});
    if (this.modalKey != undefined) {
      this.icn_blink = setInterval(() => {
        $("." + this.modalKey.replace(/:/g, "\\:") + " .sub-title span")
          .fadeOut("fast")
          .fadeIn("fast");
      }, 1000);
    }
  },
  beforeDestroy() {
    clearInterval(this.icn_blink);
  }
};
</script>

<style>
.tabs {
  float: left;
  text-align: center;
}
.enable-tab {
  background: #016aae;
  color: #fff;
  /* border: 1px solid #eee; */
}
.extend-icon {
  width: 17px;
  height: 15px;
}
.tabs-light {
  cursor: pointer;
  height: 40px;
}
.tabs-complain {
  width: 80px;
}
</style>

<style>
.vm-header .modal-title,
.vm-header .modal-exit {
  padding-top: 12px;
}
.vm-header .modal-exit {
  position: absolute;
  right: 0px;
}
.vm-header .modal-icon {
  padding-top: 6px;
  margin-left: 11px;
  float: left;
}
.vm-header .modal-title {
  display: flex;
  align-items: center;
  padding-bottom: 11px;
  font-size: 13px;
  width: 81%;
}
.vm-header .close {
  margin-left: 19px;
  margin-right: 15px;
  padding: 0.7rem 0rem 0.7rem 0rem;
  font-size: 25px;
}
.vm-header .modal-tabs {
  position: absolute;
  right: 50px;
}
.vm-header .modal-tabs .tab {
  padding-top: 8px;
  padding-bottom: 8px;
}
.vm-header .modal-tabs .tab span {
  margin-left: 11px;
  margin-right: 11px;
  font-weight: 600;
  font-size: 14px;
}
.vm-header .modal-icon img {
  width: 22px;
  height: 22px;
  vertical-align: middle;
  border-style: none;
}
.vm-header .main-title {
  line-height: 10px;
  padding-bottom: 1px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 77%;
}
.vm-header .sub-title {
  background: #00a0ea;
  border-radius: 10px;
  color: #fff;
  padding: 0px 5px 2px 5px;
  margin: 1px 0px 0px 5px;
  line-height: 13px;
}
.vm-header .sub-title span {
  font-size: 11px;
}
</style>
