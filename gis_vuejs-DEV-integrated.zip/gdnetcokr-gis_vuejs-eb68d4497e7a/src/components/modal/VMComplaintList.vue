<template lang="pug">
.modal-content(:id="key")
  .modal-header
    VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key")
  .modal-body
    #search_list.table-content
      #search_condition
        #table-all
          #table-border-radius
          table.parent-table#panel-table
            tr.group-condition
              th.item-th
                span 민원접수일
              td.item-td
                date-range-picker(:startDate="startDate" :endDate="endDate" @update="updateDatepicker" :locale-data="locale" :opens="openPosition" autoApply v-model="dataRange" style="width:100%; height:100%;" :show-dropdowns="true")
            tr.group-condition
              th.item-th
                span 표찰번호
              td.item-td.td-input
                input.condition-input(v-model="req.SL_SLNAME")
            tr.group-condition
              th.item-th
                span 처리상태
              td.item-td
                select.item-select(v-model="req.SL_NTRES")
                  option(value="all") 전체
                  option(value="N") 미처리
                  option(value="Y") 처리
            tr.group-condition
              th.item-th
                span 회신 방법
              td.item-td
                select.item-select(v-model="req.SL_REPLY")
                  option(value="all") 전체
                  option(value="NONE") 회신 받지 않음
                  option(value="SMS") 문자
                  option(value="TEL") 전화
            tr.group-condition
              th.item-th
                span 신고 내용
              td.item-td
                select.item-select(v-model="req.SL_CONTENT")
                  option(value="all") 전체
                  option(value="불이 안들어와요") 불이 안들어와요
                  option(value="기타") 기타
            tr.group-condition(id="blank-1")
              th.item-th.blank-th
            tr.group-condition(id="blank-2")
              th.item-th.blank-th
            tr.group-condition(id="blank-3")
              th.item-th.blank-th
            tr.group-condition(id="blank-4")
              th.item-th.blank-th
        button.search-btn(@click="searchComplaint") 검색
        //- b-table#search-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
      #search_condition.result-area.search-margin-top(style="height:100%" v-show="resultTable")
        #search_result
          //- b-table#search-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
          table.result-table
            thead
              tr
                th.result-th-default
                  .result-th 작업 상태
                th.result-th-default
                  .result-th 표찰번호
                th.result-th-default
                  .result-th 민원 접수일
                th.result-th-default
                  .result-th 처리 상태
                th.result-th-default
                  .result-th 회신 방법
                th.result-th-default
                  .result-th 신고 내용
            tbody
              tr.result-body-tr(v-for="result in items")
                td(@click="complainMaintenance(result)")
                  button.maintenance-button(:class="maintenance(result.SL_MAINTENANCE)") {{MAINTENANCE[result.SL_MAINTENANCE]}}
                td(@click="rowSelected(result)") {{result.SL_SLNAME}}
                td(@click="rowSelected(result)") {{result.SL_NTDATE}}
                td(@click="rowSelected(result)") {{NTRES[result.SL_NTRES]}}
                td(@click="rowSelected(result)") {{REPLY[result.SL_REPLY]}}
                td(@click="rowSelected(result)") {{result.SL_CONTENT}}
        br
        #search_page
          font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-double-left' @click="movePage('first')")
          font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-left' @click="movePage('down')")
          span.result-page(v-for="page in getNumbers(paging[0],paging[1])" @click="pageSelect(page)" :class="pageChoice(page)") {{page}}
          font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-right' @click="movePage('up')")
          font-awesome-icon.result-awssome(style="width:20px; height:20px;" icon='angle-double-right' @click="movePage('end')")
    transition(name='modal' v-if="loadData")
      .modal-background(style="display:flex; justify-content: center; align-items: center; pointer-events: auto; top:0px; left:0px; height:100%")
        .modal-position
          .loader
          br
          | 데이터를 불러오는 중입니다
          br
          | 잠시만 기다려주세요
</template>

<script>
import { EventBus } from "@/main";
import Vue from "vue";
import DateRangePicker from "vue2-daterange-picker";

export default {
  components: { DateRangePicker },
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "민원 목록",
        menu: [],
        exitBtn: true
      },
      fields: [],
      items: [],
      parentEl: "#content",
      // NOTE :: 장훈님 오면 DB 추가사항 관련 문의하여 추가작업 필요
      req: {
        SL_NTDATE_START: new Date(), // 민원 접수일
        SL_NTDATE_END: new Date(), // 민원 접수일
        SL_SLNAME: "", // 표찰번호
        SL_NTRES: "N", // 처리상태
        SL_REPLY: "all", // 회신 방법
        SL_CONTENT: "all", // 신고 내용
        PAGE: 1
      },
      paging: [1, 1, false, false, 1],
      dataRange: {
        startDate: new Date().setMonth(new Date().getMonth() - 1),
        endDate: new Date()
      },
      startDate: new Date().setMonth(new Date().getMonth() - 1),
      endDate: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      resultTable: false,
      loadData: false,
      MAINTENANCE: {
        READY: "작업처리",
        INPROGRESS: "작업지시 취소",
        DONE: "재작업처리"
      },
      REPLY: {
        NONE: "회신 받지 않음",
        SMS: "문자",
        TEL: "전화"
      },
      NTRES: {
        Y: "처리",
        N: "미처리"
      }
    };
  },
  computed: {
    openPosition() {
      if (this.$store.getters.panel_location_name == "right") {
        return "left";
      } else {
        return "right";
      }
    }
  },
  methods: {
    complainMaintenance(items) {
      console.log(items);
      EventBus.$emit("modalOpen", items.SL_NT_NO, "VMComplainHandle");
    },
    maintenance(type) {
      if (type == "READY") {
        return "maintenance-ready";
      } else if (type == "INPROGRESS") {
        return "maintenance-inprogress";
      } else if (type == "DONE") {
        return "maintenance-done";
      }
    },
    pageChoice(page) {
      if (page == this.req.PAGE) {
        return "result-page-choice";
      } else {
        return "";
      }
    },
    pageSelect(page) {
      this.req.PAGE = page;
      this.searchComplaint();
    },
    movePage(check) {
      if (check == "down") {
        if (this.paging[2]) {
          this.req.PAGE = this.paging[0] - 5 > 0 ? this.paging[0] - 5 : 1;
        }
      } else if (check == "up") {
        if (this.paging[3]) {
          this.req.PAGE = this.paging[0] + 5;
        }
      } else if (check == "first") {
        this.req.PAGE = 1;
      } else if (check == "end") {
        this.req.PAGE = this.paging[4];
      }
      this.searchComplaint();
    },
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    rowSelected(items) {
      console.log("items", items);
      EventBus.$emit("modalOpen", items.SL_NT_NO, "VMComplainInfo");
      Vue.nextTick(function() {
        EventBus.$emit(items.SL_NT_NO + "setComplainInfo", items.SL_NT_NO);
      });
    },
    searchComplaint() {
      this.loadData = true;
      this.req.SL_NTDATE_START = this.datepickerFormatter(
        this.dataRange.startDate
      );
      this.req.SL_NTDATE_END = this.datepickerFormatter(this.dataRange.endDate);
      this.getPccomplainAPI(this.req);
    },
    getPccomplainAPI(data, path) {
      var vm = this;
      this.$_API_GET("pccomplain", data).then(function(res) {
        console.log(res);
        if (res.content.length == 0) {
          vm.loadData = false;
          vm.$emit(
            "onAlert",
            "black",
            null,
            "검색된 결과가 없습니다",
            null,
            null,
            true,
            false
          );
          vm.resultTable = false;
        } else {
          vm.items = [];
          for (var value in res.content) {
            if (value != "contains") {
              vm.items.push(res.content[value]);
            }
          }
          vm.paging = res.paging;
          $("#search_page").css("display", "flex");
          console.log(vm.items);
          vm.resultTable = true;
          vm.loadData = false;
        }
      });
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    updateDatepicker(value) {}
  },
  mounted() {
    var vm = this;
    this.searchComplaint();
    EventBus.$on("getPccomplainAPI", function(data) {
      vm.getPccomplainAPI(data);
    });
    EventBus.$on("searchComplaint", function() {
      vm.searchComplaint();
    });
    EventBus.$on(this.id + "ComplaintListModalClose", function() {
      console.log("aaaa", vm.modifyLight);
      vm.$store.commit("modal_all_close", vm.key.split(":")[0]);
    });
  },
  beforeDestroy() {
    EventBus.$off("getPccomplainAPI");
    EventBus.$off("searchComplaint");
    EventBus.$off(this.id + "ComplaintListModalClose");
  }
};
</script>

<style>
.rm-white-space {
  white-space: normal;
}
.show-calendar {
  display: block;
}

th.month {
  color: black;
}
.item-td .form-control {
  height: 100%;
  padding: 0px 0px 0px 4px;
  border: 0px;
}

.item-td .form-control * {
  font-size: 12px;
}

.maintenance-button {
  border-radius: 5px;
  width: 100%;
  color: white;
  height: 100%;
}
.maintenance-ready {
  background-color: rgb(0, 160, 234);
  border: 1px solid rgb(0, 160, 234);
}
.maintenance-ready:hover {
  border: 1px solid rgb(0, 160, 234);
  background-color: white;
  color: black;
}
.maintenance-inprogress {
  background-color: rgb(243, 152, 0);
  border: 1px solid rgb(243, 152, 0);
}
.maintenance-inprogress:hover {
  border: 1px solid rgb(243, 152, 0);
  background-color: white;
  color: black;
}
.maintenance-done {
  background-color: rgb(33, 172, 55);
  border: 1px solid rgb(33, 172, 55);
}
.maintenance-done:hover {
  border: 1px solid rgb(33, 172, 55);
  background-color: white;
  color: black;
}

.search-margin-top {
  margin-top: 10px;
}
</style>
