<template lang="pug">
.modal-alert-background
  .modal-content.sub-modal-position
    .modal-header
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-on:clickClose="onClickClose")
    .modal-body
      vm-alert(ref="alert" @event="alertEvent")
      table.search-addr.table-modify
        colgroup
          col(style="width:47%")
          col(style="width:47%")
        tr.tr-item
          td.td-item.table-select-full-th(colspan=1) 
            select.tb-select.table-select-full-td(v-model="req.addr1")
              option(v-for="(vaule, key) in res" :value="key") {{key}}
          td.td-item.table-select-full-th(colspan=1) 
            select.tb-select.table-select-full-td(v-model="req.addr2")
              option(:value="addrSub") {{addrSub}}
      .tab_menu
        button.modal-cancel-btn(type="button" class="btn btn-outline-primary" @click="onClickClose(key)") 취소
        button.modal-modify-btn(type="button" class="btn btn-outline-primary" @click="onClickLightChoice(key)") 확인
    transition(name='modal' v-if="loadData")
      .modal-background
        .modal-position
          .loader
          br
          | 데이터를 불러오는 중입니다
          br
          | 잠시만 기다려주세요
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
export default {
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    },
    modalDrag: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}LightAddr".format(this.id, this.type),
      header: {
        icon: "",
        title: "시설물 정보 입력",
        menu: [],
        exitBtn: true
      },
      res: {},
      req: {
        addr1: "거제면",
        addr2: "거제"
      },
      loadData: true
    };
  },
  computed: {
    addrSub() {
      if (this.res[this.req.addr1] == null) {
        return "거제";
      } else {
        return this.res[this.req.addr1];
      }
    }
  },
  methods: {
    onClickClose(key) {
      this.$emit("clickAddrClose");
    },
    onClickLightChoice(key) {
      EventBus.$emit(
        this.id + "addr",
        this.req.addr1 + " " + this.req.addr2 + " " + this.req.addr2
      );
      this.$emit("clickAddrClose");
    },
    GetFacilityInfoAPI() {
      var vm = this;
      this.$_API_GET("postcode", {}, 24 * 7)
        .then(function(res) {
          console.log("GetFacilityInfoAPI", res);
          for (var key in res) {
            // console.log(key.split(":")[0]);
            for (var value in res[key]) {
              //   console.log(value.split(":")[0]);
              if (key != "SIDOSGG_CD") {
                vm.res[key.split(":")[0]] = value.split(":")[0];
              }
            }
          }
          vm.loadData = false;
          console.log("vm.res", vm.res);
        })
        .then(() => {
          vm.$forceUpdate();
        })
        .catch(function() {
          vm.$refs.alert.init(
            "black",
            null,
            "주소 가져오기 실패",
            null,
            null,
            true,
            false
          );
        });
    }
  },
  created() {},
  mounted() {
    console.log("this.id", this.id);
    this.loadData = true;
    this.GetFacilityInfoAPI();
  },
  updated() {
    console.log("updated base modal");
  }
};
</script>

<style>
.th-item,
.td-item {
  text-align: center;
}
.input-padding {
  padding: 0px;
}
.tb-textarea {
  border: 0px;
  width: 100%;
  height: 150px;
}
.search-addr {
  border: 1.2px solid rgba(195, 195, 195, 0.3);
}
</style>
