<template lang="pug">
.modal-complain-info.vm-complain-info
  .modal-content(:id="key")
    .modal-complain-info
    .modal-header
      VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key" v-bind:subTitle="header.subTitle")
    .modal-complain-info
      .modal-body
        vm-alert(ref="alert" @event="alertEvent")
        .main-area
          .left-main-area
            table(:class="modifyComplain ? 'table-modify' : ''")
              colgroup
                col(style="width:33%")
                col(style="width:66%")
              tr.tr-item.compalin-table
                th.th-item.left-first-child.lowast-span(:class="modifyComplainMode()")
                  span &nbsp;&nbsp;접수 구분
                  img.lowast(:src="require('@/assets/img/res/img/essential.png')")
                td.td-item.input-padding.table-vertical-top.left-last-child
                  input.light-radio(type="radio" v-model="registerType" value="1" :id="'registerTypeSLCODEinfo' + key" :name="key" :disabled="!modifyComplain")
                  label.radio-label(:for="'registerTypeSLCODEinfo' + key") 
                    span
                      label.light-radio-label 표찰번호
                  input.light-radio(type="radio" v-model="registerType" value="2" :id="'registerTypeAddrinfo' + key" :name="key" :disabled="!modifyComplain")
                  label.radio-label.light-radio-label-space(:for="'registerTypeAddrinfo' + key") 
                    span
                      label.light-radio-label 주소
              tr.tr-item(v-if="registerType!=2")
                th.th-item(:class="modifyComplainMode()") 
                  span &nbsp;&nbsp;표찰번호
                  img.lowast(:src="require('@/assets/img/res/img/essential.png')")
                td.td-item.input-padding
                  input.complain-check-sn.focus-set(type="text" v-model="req.SL_SLNAME" :disabled="!modifyComplain" v-on:keyup="searchEnter($event)")
                  .complain-check-sn-img
                    span(v-if="snCheck == 1" style="color:#00a0ea") 존재
                    span(v-if="snCheck == -1" style="color:#f63f3f") 미존재
                    img(:src="require('@/assets/img/res/img/' + snCheckImg() + '.png')")
                  button.complain-control-btn(@click="onClickSearchAddr" v-if="modifyComplain") 확인
                  button.complain-control-btn(@click="onClickMove") 지도
                  button.complain-control-btn(@click="onClickShowLight") 상세
                  button.complain-control-btn(@click="onClickHistory") 이력
              tr.tr-item
                th.th-item(:class="[modifyComplainMode(), registerType == 1 ? 'lowast-span' : '']") 
                  span &nbsp;&nbsp;주소
                  img.lowast(:src="require('@/assets/img/res/img/essential.png')")
                td.td-item.input-padding
                  input.complain-check-addr(type="text" v-model="req.user_addr" :disabled="registerType == 1 || !modifyComplain" :class="registerType == 1 ? 'modify-disabled': ''")
                  button.complain-control-btn(v-if="registerType != 1" @click="onClickAddrMove") 지도
              tr.tr-item
                th.th-item(:class="modifyComplainMode()") &nbsp;&nbsp;민원 일자
                td.td-item.input-padding 
                  date-range-picker(:startDate="startDate" :endDate="endDate" :locale-data="locale" opens="right" autoApply v-model="dataRange" style="width:100%; height:100%;" :singleDatePicker="true" :ranges="false" :show-dropdowns="true")
                  //- input(type="text" v-model="req.user_addr")
              tr.tr-item
                th.th-item(:class="modifyComplainMode()") &nbsp;&nbsp;접수 일자
                td.td-item.input-padding 
                  input(type="text" v-model="nowDate" :disabled="true" style="background:#d3d3d3")
              tr.tr-item
                th.th-item(:class="modifyComplainMode()") &nbsp;&nbsp;신고인
                td.td-item.input-padding() 
                  input(type="text" v-model="req.repoter" :disabled="!modifyComplain")
              tr.tr-item
                th.th-item(:class="modifyComplainMode()") &nbsp;&nbsp;전화번호
                td.td-item.input-padding() 
                  input(type='text' v-model="req.tel" :disabled="!modifyComplain" @keyup="getPhoneMask(req.tel, 'tel', $event)")
              tr.tr-item
                th.th-item(:class="modifyComplainMode()") &nbsp;&nbsp;휴대전화
                td.td-item.input-padding() 
                  input(type="text" v-model="req.phone" :disabled="!modifyComplain" @keyup="getPhoneMask(req.phone, 'phone', $event)")
              tr.tr-item
                th.th-item.lowast-span(:class="modifyComplainMode()") 
                  span &nbsp;&nbsp;회신 여부
                  img.lowast(:src="require('@/assets/img/res/img/essential.png')")
                td.item-td.input-padding(tabindex="-1")
                  input.light-radio(type="radio" v-model="req.reply" value="SMS" :id="'replySMS'+key" :name="'reply'+key" :disabled="!modifyComplain")
                  label.radio-label(:for="'replySMS'+key")
                    span
                      label(:class="registerType == 1 ? 'radio-reply' : 'radio-reply-addr'") SMS
                  input.light-radio(type="radio" v-model="req.reply" value="TEL" :id="'replyTEL' + key" :name="'reply'+key" :disabled="!modifyComplain")
                  label.radio-label.radio-reply-space(:for="'replyTEL' + key")
                    span
                      label(:class="registerType == 1 ? 'radio-reply' : 'radio-reply-addr'") 전화
                  input.light-radio(type="radio" v-model="req.reply" value="NONE" :id="'replyNONE' + key" :name="'reply'+key" :disabled="!modifyComplain")
                  label.radio-label.radio-reply-space(:for="'replyNONE' + key")
                    span
                      label(:class="registerType == 1 ? 'radio-reply' : 'radio-reply-addr'" style="width:70px;") 회신받지않음
              tr.tr-item
                th.th-item.lowast-span(:class="modifyComplainMode()") 
                  span &nbsp;&nbsp;표찰 상태
                  img.lowast(:src="require('@/assets/img/res/img/essential.png')")
                td.item-td.input-padding(tabindex="-1")
                  input.light-radio(type="radio" v-model="req.status" value="NORMAL" :id="'statusSMS'+key" :name="'status'+key" :disabled="!modifyComplain")
                  label.radio-label(:for="'statusSMS'+key")
                    span
                      label(:class="registerType == 1 ? 'radio-status' : 'radio-status-addr'") 정상
                  input.light-radio(type="radio" v-model="req.status" value="WORNOUT" :id="'statusTEL' + key" :name="'status'+key" :disabled="!modifyComplain")
                  label.radio-label.radio-status-space(:for="'statusTEL' + key")
                    span
                      label(:class="registerType == 1 ? 'radio-status' : 'radio-status-addr'") 노후
                  input.light-radio(type="radio" v-model="req.status" value="NONE" :id="'statusNONE' + key" :name="'status'+key" :disabled="!modifyComplain")
                  label.radio-label.radio-status-space(:for="'statusNONE' + key")
                    span
                      label(:class="registerType == 1 ? 'radio-status' : 'radio-status-addr'") 없음
              tr.tr-item
                th.th-item.lowast-span(:class="modifyComplainMode()") 
                  span &nbsp;&nbsp;고장 종류
                  img.lowast(:src="require('@/assets/img/res/img/essential.png')")
                td.item-td.input-padding(tabindex="-1")
                  .dropdown
                    .dropdown__header(@click="toggleDropdown($event)" :class="modifyComplainMode()")
                      span {{code.SL_CONTENT[req.content]}}
                      i.fas.fa-chevron-down
                      i.fas.fa-chevron-up
                    .dropdown__content
                      ul
                        li(v-if="key != 'all'" @click="clickDropDown('content', key)" v-for="value, key in code.SL_CONTENT"  :class="dropdownChoice(value, code.SL_CONTENT[req.content])") {{value}}
                          .search-division-line   
              tr.tr-item
                th.th-item.right-first-child(:class="modifyComplainMode()") &nbsp;&nbsp;상태 설명
                td.complain-control.last-clear-bottom
                  textarea.tb-textarea(row='6' v-model="req.comment" :disabled="!modifyComplain"  :class="registerType == 2 ? 'registerTypeAddr' : ''")
            .tab_menu(style="margin: 10px 0px 2px 0px;" v-if="isLightData")
              button.modal-remove-btn(type="button" class="btn btn-outline-primary" @click="deleteModal = true" v-if="modifyAuth && !modifyComplain") 민원 삭제
              button(type="button" class="btn btn-outline-primary" @click="onClickComplainModify()" v-if="modifyAuth && !modifyComplain") 민원 수정
              button.modal-modify-btn(type="button" class="btn btn-outline-primary" @click="onClickModify" v-if="modifyAuth && modifyComplain") 저장
              button.modal-cancel-btn(type="button" class="btn btn-outline-primary" @click="onClickCancel" v-if="modifyAuth && modifyComplain") 취소
            .tab_menu(style="margin: 10px 0px 2px 0px;" v-if="!isLightData")
              span(style="color:#f24e4e;font-size:12px;font-weight:400;") 삭제된 시설물입니다.
          .right-main-area
            //- table.table-top-margin(v-if="maintenance != 'READY'")
            table.table-top-margin
              colgroup
                col(style="width:33%")
                col(style="width:66%")
              tr.tr-item
                th.th-item.left-first-child &nbsp;&nbsp; 지시 일자
                td.item-td
                  input.left-last-child(type="text" v-model="handling.SL_DRDATE" :disabled="true" )
              tr.tr-item
                th.th-item &nbsp;&nbsp; 지시 업체
                td.item-td
                  input(type="text" v-model="handling.SL_ASSIGNED_ID" :disabled="true" )
              tr.tr-item
                th.th-item.right-first-child &nbsp;&nbsp; 지시 내용
                td.item-td.last-clear-bottom
                  input.right-last-child(type="text" v-model="handling.SL_DRWORK" :disabled="true" )
            //- table.table-top-margin(v-if="maintenance != 'READY'")
            table.table-top-margin
              colgroup
                col(style="width:33%")
                col(style="width:66%")
              tr.tr-item
                th.th-item.left-first-child &nbsp;&nbsp; 보수 일자
                td.item-td
                  input.left-last-child(type="text" v-model="handling.SL_DODATE" :disabled="true" )
              tr.tr-item
                th.th-item &nbsp;&nbsp; 보수 업체
                td.item-td
                  input(type="text" v-model="handling.SL_DO_ASSIGNED" :disabled="true" )
              tr.tr-item
                th.th-item &nbsp;&nbsp; 보수 종류
                td.item-td
                  input(type="text" v-model="handling.SL_WORKTYPE" :disabled="true" )
              tr.tr-item
                th.th-item.right-first-child &nbsp;&nbsp; 보수 내용
                td.item-td.last-clear-bottom
                  input.right-last-child(type="text" v-model="handling.SL_WORK" :disabled="true" )
            .jaje-list-area
              table(style="border:0px;")
                tr
                  th.th-item.left-first-child.td-center 분류
                  th.th-item.td-center 자재명
                  th.th-item.td-center 수량
                  th.th-item.left-last-child.td-center 날짜
                tr(v-for="jaje in jajeList" v-if="jajeList != undefined" v-show="jaje.jaje!=undefined")
                  td.td-center(style="width:40px")
                    span {{jaje.jaje != undefined ? jaje.jaje.SL_JJ_TYPE == "I"?"입고":"출고":""}}
                  td.td-center
                    span {{jaje.code != undefined ? jaje.code.SL_JJ_NAME:""}}
                  td.td-center
                    span {{jaje.jaje != undefined ? jaje.jaje.SL_JJ_COUNT:""}}
                  td.td-center
                    span {{datepickerFormatter(jaje.jaje != undefined ? jaje.jaje.SL_JJ_DATE:"")}}
                tr(v-if="jajeList == undefined")
                  td.td-center(colspan=4) 자재 이력이 없습니다.
            .tab_menu(style="margin: 10px 0px 2px 0px;" v-if="isLightData")
              //- button.modal-remove-btn(type="button" class="btn btn-outline-primary" @click="deleteModal = true" v-if="modifyAuth && !modifyComplain && maintenance == 'READY'") 삭제
              button(type="button" class="btn btn-outline-primary" @click="complainHandle('VMComplainMaintenance')" v-if="modifyAuth && !modifyComplain && maintenance == 'READY'") 작업 처리
              //- button(type="button" class="btn btn-outline-primary" @click="onClickComplainModify()" v-if="modifyAuth && !modifyComplain && maintenance == 'READY'") 수정
              button(type="button" class="btn btn-outline-primary" @click="complainHandle('VMComplainDirection')" v-if="modifyAuth && !modifyComplain && maintenance == 'READY'") 작업 지시
              button(type="button" class="btn btn-outline-primary" @click="complainHandle('VMComplainMaintenance')" v-if="!modifyAuth && !modifyComplain && maintenance == 'INPROGRESS'") 작업 처리
              button(type="button" class="btn btn-outline-primary" @click="complainHandle('VMComplainChangeDirection')" v-if="modifyAuth && !modifyComplain && maintenance == 'INPROGRESS'") 지시 수정
              button(type="button" class="btn btn-outline-primary" @click="deleteDirection = true" v-if="modifyAuth && !modifyComplain && maintenance == 'INPROGRESS'") 지시 취소
              button(type="button" class="btn btn-outline-primary" @click="complainHandle('VMComplainReMaintenance')" v-if="!modifyComplain && maintenance == 'DONE'") 재작업 처리
              button(type="button" class="btn btn-outline-primary" @click="complainHandle('VMComplainReDirection')" v-if="modifyAuth && !modifyComplain && maintenance == 'DONE'") 재작업 지시
              //- button.modal-modify-btn(type="button" class="btn btn-outline-primary" @click="onClickModify" v-if="modifyAuth && modifyComplain && maintenance == 'READY'") 저장
              //- button.modal-cancel-btn(type="button" class="btn btn-outline-primary" @click="onClickCancel" v-if="modifyAuth && modifyComplain && maintenance == 'READY'") 취소
      transition(name='modal' v-if="retry")
        .modal-background
          .modal-position
            | 일시적으로 데이터를 불러오지 못했습니다
            br
            | 다시 시도해주세요
            br
            button.spinner-btn(@click="GetPccoordinatesAPI") 다시 시도
      transition(name='modal' v-if="loadData")
        .modal-background
          .modal-position
            .loader
            br
            | 데이터를 불러오는 중입니다
            br
            | 잠시만 기다려주세요
      transition(name='modal' v-if="deleteModal")
        .modal-background(style="pointer-events: auto;")
          .modal-position
            span [ 
            span.alert-delete-red(v-if="registerType==1") {{req.SL_SLNAME}}
            span.alert-delete-red(v-if="registerType==2") 민원 삭제
            span  ] 민원 정보를 삭제하시겠습니까?
            br
            | 삭제하시려면 위 괄호 안의 정보를 입력해주세요
            br
            | (민원 정보를 삭제하면 민원 목록에서 제외됩니다)
            br
            input.remove-input(v-if="registerType==1" type="text" v-model="removeName" :placeholder="req.SL_SLNAME")
            input.remove-input(v-if="registerType==2" type="text" v-model="removeName" :placeholder="'민원 삭제'")
            br
            button.spinner-btn.spinner-left(@click="deleteModal = false, removeName = ''") 취소
            button.spinner-btn.spinner-right(@click="onClickRemove") 확인
      transition(name='modal' v-if="deleteDirection")
        .modal-background(style="pointer-events: auto;")
          .modal-position
            //- span [ 
            //- span.alert-delete-red(v-if="registerType==1") {{req.SL_SLNAME}}
            //- span.alert-delete-red(v-if="registerType==2") 지시 취소
            //- span  ] 작업 지시를 취소하시겠습니까?
            | 작업 지시를 취소하시겠습니까?
            br
            //- | 취소하시려면 위 괄호 안의 정보를 입력해주세요
            //- br
            | (작업지시 내역을 취소하면 미처리 상태로 변경됩니다)
            //- br
            //- input.remove-input(v-if="registerType==1" type="text" v-model="removeDirectionName" :placeholder="req.SL_SLNAME")
            //- input.remove-input(v-if="registerType==2" type="text" v-model="removeDirectionName" :placeholder="'지시 취소'")
            br
            button.spinner-btn.spinner-left(@click="deleteDirection = false, removeDirectionName = ''") 취소
            button.spinner-btn.spinner-right(@click="onClickRemoveDirection") 확인
  VM-complain-handle(:id="id" :type="type" :showComponent="showComponent" :key="key" v-on:clickHandleClose="onClickHandleClose" v-if="modalComplainHandle" v-bind:subTitle="subTitle")
  VM-complain-history(:id="id" :type="type" :key="key" v-on:clickAddrClose="onClickAddrClose" :slcode="req.SL_SLCODE" v-if="modalComplainHistory")
</template>

<script>
/*
  TODO :: 민원 정보를 가져오는게 중간에 계속 추가/삭제되면서 API가 나뉘어짐. 이것들 하나로 통합 작업이 필요.
          현재 처리,지시,재작업의 모달이 다 제각각 돌고 있는데 지시와 처리 2가지 또는 아예 하나로 통합해야 좋음.
*/
import Vue from "vue";
import { EventBus } from "@/main";
import VMComplainHandle from "@/components/modal/VMComplainHandle";
import VMComplainHistory from "@/components/modal/VMComplainHistory";
import complainCode from "@/assets/json/complainCode.json";
import DateRangePicker from "vue2-daterange-picker";

export default {
  components: {
    VMComplainHandle,
    DateRangePicker,
    VMComplainHistory
  },
  props: {
    id: {
      type: String, // Number
      required: false
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "민원 정보",
        menu: [],
        exitBtn: true,
        subTitle: ""
      },
      req: {
        SL_SLCODE: "",
        SL_SLNAME: "",
        user_addr: "",
        writer: "",
        repoter: "",
        tel: "",
        phone: "",
        reply: "NONE",
        content: "미점등",
        comment: "",
        relocation: "N",
        cp_date: "",
        status: "NORMAL",
        SL_ISUL: "N"
      },
      jajeList: [],
      reqBnk: {},
      SL_MAP_X: "",
      SL_MAP_Y: "",
      deleteModal: false,
      retry: false,
      modifyAuth: false,
      modifyComplain: false,
      modalComplainHandle: false,
      modalComplainHistory: false,
      loadData: false,
      registerType: "1",
      dataRange: {
        startDate: new Date(),
        endDate: new Date()
      },
      startDate: new Date(),
      endDate: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      returnData: 0,
      snCheck: 0,
      code: {},
      maintenance: "",
      handling: {
        SL_DRDATE: "",
        SL_ASSIGNED_ID: "",
        SL_DRWORK: "",
        SL_DODATE: "",
        SL_DO_ASSIGNED: "",
        SL_WORKTYPE: "",
        SL_WORK: ""
      },
      SL_NT_NO: "",
      removeName: "",
      showComponent: "",
      deleteDirection: false,
      removeDirectionName: "",
      sl_nt: "",
      SL_NTDATE: "",
      removeDirectionCheck: false,
      registerTypeBnk: "1",
      isLightData: false
    };
  },
  watch: {
    modifyComplain: function(val) {
      if (val) {
        $(".vm-complain-info .form-control").css("pointer-events", "auto");
        $(".vm-complain-info .form-control")
          .children()
          .css("pointer-events", "auto");
        $(".vm-complain-info .dropdown__header").css("pointer-events", "auto");
        $(".vm-complain-info .dropdown__header")
          .children()
          .css("pointer-events", "auto");
      } else {
        $(".vm-complain-info .form-control").css("pointer-events", "none");
        $(".vm-complain-info .form-control")
          .children()
          .css("pointer-events", "none");
        $(".vm-complain-info .dropdown__header").css("pointer-events", "none");
        $(".vm-complain-info .dropdown__header")
          .children()
          .css("pointer-events", "none");
      }
    },
    registerType: function(val) {
      console.log("change registerType");
      this.snCheck = 0;
      // this.req.user_addr = "";
      // this.req.SL_SLNAME = "";
      if (val == 1) {
        setTimeout(function() {
          $(".vm-complain-info .complain-check-sn").focus();
        }, 0);
      } else if (val == 2) {
        setTimeout(function() {
          $(".vm-complain-info .complain-check-addr").focus();
        }, 0);
      }
    },
    "dataRange.endDate": function(val) {
      console.log(val >= new Date());
      if (val >= new Date()) {
        this.$refs.alert.init(
          "black",
          null,
          "민원 일자는 최대 당일까지 선택이 가능합니다.",
          null,
          null,
          true,
          false
        );
        this.dataRange.startDate = new Date();
        this.dataRange.endDate = new Date();
      }
    }
  },
  computed: {
    nowDate() {
      return this.moment(this.SL_NTDATE).format("YY.MM.DD HH:mm");
    }
  },
  methods: {
    dataValueCheck(data, value) {
      return data == undefined ? "" : data[value];
    },
    modifyBackground() {
      if (this.modifyComplain) {
        return "background-padding-left";
      } else {
        return "background-none";
      }
    },
    modifyComplainMode() {
      if (this.modifyComplain) {
        return "complain-modify-mode";
      } else {
        return "";
      }
    },
    onClickCancel() {
      console.log(this.reqBnk);
      console.log(this.registerTypeBnk);
      this.req = JSON.parse(JSON.stringify(this.reqBnk));
      this.registerType = this.registerTypeBnk;
      this.modifyComplain = false;
      this.header.subTitle = "";
    },
    onClickHandleClose() {
      this.modalComplainHandle = false;
    },
    onClickAddrClose() {
      this.modalComplainHistory = false;
    },
    onClickModify() {
      // NOTE :: 입력 데이터 검증 및 민원 수정
      if (this.registerType == "1") {
        if (
          (this.SL_SLCODE == "" && this.registerType == "1") ||
          this.snCheck != 1
        ) {
          this.$refs.alert.init(
            "black",
            null,
            "표찰번호를 입력 후 확인 버튼을 클릭 해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      } else if (this.registerType == "2") {
        if (this.req.user_addr == "" && this.registerType == "2") {
          this.$refs.alert.init(
            "black",
            null,
            "주소를 확인해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      }
      if (this.req.reply == "SMS" || this.req.reply == "TEL") {
        if (
          this.req.phone.length != 13 ||
          this.req.phone.split("-")[0] != "010"
        ) {
          this.$refs.alert.init(
            "black",
            null,
            "휴대전화를 확인해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      }
      if (this.registerType == "2") {
        this.req.SL_SLNAME = "";
      }
      this.loadData = true;
      var vm = this;
      this.req.cp_date = this.moment(this.dataRange.endDate).format(
        "YYYY-MM-DD"
      );
      this.$_API_POST("pc/modify/notice", this.req).then(function(res) {
        console.log(res);
        vm.modifyComplain = false;
        vm.loadData = false;
        vm.header.subTitle = "";
        vm.reqBnk = JSON.parse(JSON.stringify(vm.req));
        EventBus.$emit("searchComplaint");
      });
    },
    onClickRemove() {
      // NOTE :: 민원 삭제
      if (
        (this.registerType == 1 && this.removeName == this.req.SL_SLNAME) ||
        (this.registerType == 2 && this.removeName == "민원 삭제")
      ) {
        var vm = this;
        this.loadData = true;
        this.$_API_POST("pc/remove/notice", this.req).then(function(res) {
          console.log(res);
          vm.loadData = false;
          vm.onClickClose(vm.key);
          EventBus.$emit("searchComplaint");
          this.deleteModal = false;
        });
      } else {
        this.deleteModal = false;
        this.$refs.alert.init(
          "black",
          null,
          "입력한 내용이 맞지 않습니다",
          null,
          null,
          true,
          false
        );
      }
      this.removeName = "";
    },
    onClickRemoveDirection() {
      var data = {
        SL_NT_NO: this.id
      };
      this.postPcRemoveDirectionAPI(data);
      this.deleteDirection = false;
      // if (
      //   (this.registerType == 1 &&
      //     this.removeDirectionName == this.req.SL_SLNAME) ||
      //   (this.registerType == 2 && this.removeDirectionName == "지시 취소")
      // ) {
      //   var data = {
      //     SL_NT_NO: this.id
      //   };
      //   this.postPcRemoveDirectionAPI(data);
      //   this.deleteDirection = false;
      // } else {
      //   this.showAlert(true, "", ["입력한 내용이 맞지 않습니다"]);
      //   this.deleteDirection = false;
      // }
      // this.removeDirectionName = "";
    },
    postPcRemoveDirectionAPI(data) {
      // NOTE :: 민원 지시 삭제
      var vm = this;
      this.$_API_POST("pc/remove/direction", data).then(function(res) {
        EventBus.$emit("searchComplaint");
        EventBus.$emit(vm.id + "setComplainInfo", vm.id);
        vm.onClickClose();
        vm.removeDirectionCheck = true;
      });
    },
    onClickMove() {
      // NOTE :: 민원 위치로 지도 이동
      if (this.isLightData == false) {
        this.$refs.alert.init(
          "black",
          null,
          "삭제된 시설물입니다.",
          null,
          null,
          true,
          false
        );
      } else if (this.SL_MAP_X == "") {
        this.$refs.alert.init(
          "black",
          null,
          "표찰번호를 입력 후 확인 버튼을 클릭 해주세요",
          null,
          null,
          true,
          false
        );
      } else {
        var point = window.setCoordsFromPoint(
          this.SL_MAP_X,
          this.SL_MAP_Y,
          this.$store.getters.panel_location_name
        );
        window.SetPositionLevel(point.getLng(), point.getLat(), 1);
      }
    },
    onClickClose(key) {
      this.$store.commit("modal_close", key);
    },
    // onClickSearchAddr() {
    //   console.log("onClickSearchAddr", this.req.SL_SLCODE);
    //   EventBus.$emit("modalOpen", this.req.SL_SLCODE, "VMSearchAddr");
    // },
    onClickHistory() {
      // NOTE :: 민원 유지보수 이력 확인
      if (this.modifyComplain) {
        if (this.snCheck != 1) {
          this.$refs.alert.init(
            "black",
            null,
            "표찰번호 중복체크해주세요",
            null,
            null,
            true,
            false
          );
        } else if (this.req.SL_SLNAME.length >= 2) {
          if (this.sl_nt == "") {
            this.$refs.alert.init(
              "black",
              null,
              "해당 시설물의 민원 이력이 없습니다",
              null,
              null,
              true,
              false
            );
          } else {
            this.modalComplainHistory = true;
          }
        } else {
          this.$refs.alert.init(
            "black",
            null,
            "표찰번호를 2글자 이상 작성 바랍니다",
            null,
            null,
            true,
            false
          );
        }
      } else {
        if (this.req.SL_SLNAME.length >= 2) {
          if (this.sl_nt == "") {
            this.$refs.alert.init(
              "black",
              null,
              "해당 시설물의 민원 이력이 없습니다",
              null,
              null,
              true,
              false
            );
          } else {
            this.modalComplainHistory = true;
          }
        } else {
          this.$refs.alert.init(
            "black",
            null,
            "표찰번호를 2글자 이상 작성 바랍니다",
            null,
            null,
            true,
            false
          );
        }
      }
    },
    complainHandle(value) {
      this.showComponent = value;
      this.modalComplainHandle = true;
    },
    GetPccoordinatesAPI() {
      // NOTE :: 시설물 좌표 가져옴
      var vm = this;
      this.$_API_GET("pccoordinates", { SL_SLCODE: this.req.SL_SLCODE })
        .then(function(res) {
          console.log("GetPccoordinatesAPI", res);
          console.log("GetPccoordinatesAPI res", res.SL_MAP_X);
          if (res.SL_MAP_X == undefined) {
            vm.isLightData = false;
          } else {
            vm.isLightData = true;
          }
          vm.SL_MAP_X = res.SL_MAP_X;
          vm.SL_MAP_Y = res.SL_MAP_Y;
          vm.retry = false;
          vm.loadData = false;
        })
        .catch(function() {
          vm.retry = true;
        });
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        if (
          res.grade.substring(0, 1) == "S" ||
          res.grade.substring(0, 1) == "A" ||
          res.grade.substring(0, 1) == "B"
        ) {
          vm.modifyAuth = true;
        } else {
          vm.modifyAuth = false;
        }
      });
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    onClickShowLight() {
      if (this.isLightData == false) {
        this.$refs.alert.init(
          "black",
          null,
          "삭제된 시설물입니다.",
          null,
          null,
          true,
          false
        );
      } else {
        EventBus.$emit("modalOpen", this.req.SL_SLCODE, "VMLight");
      }
    },
    closeModal() {
      this.$store.commit("modal_all_close", this.key.split(":")[0]);
    },
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      this.req[type] = data;
      $(".vm-complain-info .dropdown__header").removeClass("is-active");
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    snCheckImg() {
      // NOTE :: 시설물 중복체크 상태
      if (this.snCheck == 0) {
        return "check-blank";
      } else if (this.snCheck == 1) {
        return "check-true";
      } else if (this.snCheck == -1) {
        return "check-false";
      }
    },
    onClickSearchAddr() {
      // NOTE :: 주소 검증
      if (this.req.SL_SLNAME.length >= 2) {
        this.GetPcaddress(this.req.SL_SLNAME);
      } else {
        this.$refs.alert.init(
          "black",
          null,
          "표찰번호를 2글자 이상 작성 바랍니다",
          null,
          null,
          true,
          false
        );
      }
    },
    GetPcaddress(data) {
      // NOTE :: 주소 데이터 확인
      var addrData = {
        SL_SLNAME: data,
        PAGE: 1
      };
      var vm = this;
      this.$_API_GET("pcaddress", addrData)
        .then(function(res) {
          console.log("pcaddress", res);
          vm.returnData = res.content.length;
          if (res.content.length == 0) {
            vm.snCheck = -1;
            vm.req.user_addr = "";
          } else if (res.content.length == 1) {
            vm.req.SL_SLNAME = res.content[0].SL_SLNAME;
            vm.SL_SLCODE = res.content[0].SL_SLCODE;
            vm.SL_MAP_X = res.content[0].SL_MAP_X;
            vm.SL_MAP_Y = res.content[0].SL_MAP_Y;
            vm.req.user_addr = res.content[0].ADDRESS_OLD;
            if (res.notice.length == 0) {
              vm.sl_nt = "";
            } else {
              vm.sl_nt = res.notice[res.notice.length - 1].SL_NT_NO;
            }
            vm.snCheck = 1;
          } else if (res.content.length > 1) {
            // NOTE :: 환경설정으로 넘겨야 하는 부분
            // vm.modalComplainAddr = true;
            // Vue.nextTick(function() {
            //   EventBus.$emit("setAddr", vm.req.SL_SLNAME);
            // });

            // NOTE :: alert은 어떻게?
            // vm.showAlert(true, "", ["결과가 2개 이상"]);
            vm.snCheck = -1;
            vm.req.user_addr = "";
          }
        })
        .catch(e => {
          console.log("주소 검색 에러", e);
        });
    },
    onClickComplainModify() {
      this.modifyComplain = true;
      this.header.subTitle = "수정중";
      // $(".vm-complain-info .focus-set").focus();
      setTimeout(function() {
        $(".vm-complain-info .focus-set").focus();
      }, 0);
    },
    onClickAddrMove() {
      // NOTE :: 주소 위치로 지도 이동
      if (this.req.user_addr == "") {
        this.$refs.alert.init(
          "black",
          null,
          "주소를 입력해주세요",
          null,
          null,
          true,
          false
        );
      } else {
        // window.getValue(this.req.user_addr);
        var vm = this;
        var geocoder = new kakao.maps.services.Geocoder();
        geocoder.addressSearch(this.req.user_addr, function(result, status) {
          if (status === window.kakao.maps.services.Status.OK) {
            window.map.setCenter(
              window.setCoordsFromPoint(
                result[0].x,
                result[0].y,
                window.panelPosition
              )
            );
            if (window.isRvOn) {
              window.isToggleRvJustNow = true;
              window.evtRvPositionChanged();
            }
          } else {
            vm.$refs.alert.init(
              "black",
              null,
              "잘못된 주소를 입력하셨습니다",
              null,
              null,
              true,
              false
            );
          }
        });
      }
    },
    getComplainInfo(data) {
      // NOTE :: 민원 정보 가져옴
      var vm = this;
      this.$_API_GET("pc/complain/name", { SL_NT_NO: data }).then(function(
        items
      ) {
        console.log("getComplainInfo", items);
        vm.loadData = true;
        vm.req.SL_SLNAME = items.info.SL_SLNAME;
        vm.req.user_addr = items.info.SL_USR_ADDR;
        vm.req.writer = items.info.SL_INMAN;
        vm.req.repoter = items.info.SL_MAN;
        vm.req.tel = items.info.SL_TEL_2;
        vm.req.phone = items.info.SL_TEL;
        vm.req.reply = items.info.SL_REPLY;
        vm.req.content = items.info.SL_CONTENT;
        vm.req.comment = items.info.SL_BIGO;
        vm.req.SL_NT_NO = items.info.SL_NT_NO;
        vm.req.SL_SLCODE = items.info.SL_SLCODE;
        vm.req.status = items.info.SL_STATUS;
        vm.SL_NTDATE = items.info.SL_NTDATE;
        vm.handling.SL_DRDATE = items.info.SL_DRDATE;
        vm.handling.SL_ASSIGNED_ID = items.info.SL_ASSIGNED_ID;
        vm.handling.SL_DRWORK = items.info.SL_DRWORK;
        vm.handling.SL_DODATE = items.info.SL_DODATE;
        vm.handling.SL_DO_ASSIGNED = items.info.SL_DO_ASSIGNED;
        vm.handling.SL_WORKTYPE = items.info.SL_WORKTYPE;
        vm.handling.SL_WORK = items.info.SL_WORK;
        if (items.info.SL_MAINTENANCE == "READY") {
          vm.header.title = "민원 정보 - 미처리";
        } else if (items.info.SL_MAINTENANCE == "INPROGRESS") {
          vm.header.title = "민원 정보 - 작업중";
        } else if (items.info.SL_MAINTENANCE == "DONE") {
          vm.header.title = "민원 정보 - 처리 완료";
        }
        vm.maintenance = items.info.SL_MAINTENANCE;

        if (items.info.SL_SLNAME == "") {
          vm.registerType = 2;
          vm.registerTypeBnk = 2;
        }

        console.log("items.info.SL_CPDATE", items.info.SL_CPDATE);
        vm.dataRange.startDate = items.info.SL_CPDATE;
        vm.dataRange.endDate = items.info.SL_CPDATE;
        vm.startDate = items.info.SL_CPDATE;
        vm.endDate = items.info.SL_CPDATE;

        vm.sl_nt = items.info.SL_NT_NO;

        if (items.jaje.length == 0) {
          vm.jajeList = undefined;
        } else {
          vm.jajeList = items.jaje;
        }
        console.log("vm.jajeList", items.jaje);
        console.log("vm.jajeList", vm.jajeList);
        console.log("items.info.SL_CPDATE dataRange", vm.dataRange);
        console.log("items.info.sl_nt sl_nt", vm.sl_nt);

        console.log("complain info items", items);
        console.log(vm.reqBnk);
        vm.reqBnk = JSON.parse(JSON.stringify(vm.req));
        vm.GetPccoordinatesAPI();
        vm.getPcauthAPI();
        if (vm.removeDirectionCheck) {
          vm.removeDirectionCheck = false;
          vm.$refs.alert.init(
            "black",
            null,
            "작업 지시가 삭제되었습니다.",
            null,
            null,
            true,
            false
          );
        }
      });
    },
    getPhoneMask(val, key, event) {
      if (event.keyCode >= 48 && event.keyCode <= 57) {
        let res = this.getMask(val);
        this.req[key] = res;
      } else {
        // $(event.path)
        //   .eq(0)
        //   .val(val.replace(/[^0-9]/gi, ""));
      }
    },
    getMask(phoneNumber) {
      var number = phoneNumber.replace(/[^0-9]/gi, "");
      var tel = "";

      // 서울 지역번호(02)가 들어오는 경우
      if (number.substring(0, 2).indexOf("02") == 0) {
        if (number.length < 3) {
          return number;
        } else if (number.length < 6) {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2);
        } else if (number.length < 10) {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2, 3);
          tel += "-";
          tel += number.substr(5);
        } else {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2, 4);
          tel += "-";
          tel += number.substr(6);
        }

        // 서울 지역번호(02)가 아닌경우
      } else {
        if (number.length < 4) {
          return number;
        } else if (number.length < 7) {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3);
        } else if (number.length < 11) {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3, 3);
          tel += "-";
          tel += number.substr(6);
        } else {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3, 4);
          tel += "-";
          tel += number.substr(7);
        }
      }

      return tel;
    },
    searchEnter(e) {
      if (e.key == "Enter") {
        this.onClickSearchAddr();
      }
    },
    alertEvent(key, inputData) {
      switch (key) {
        case "closeModal":
          this.closeModal();
          break;
      }
    }
  },
  created() {},
  mounted() {
    this.code = JSON.parse(JSON.stringify(complainCode));

    var vm = this;
    EventBus.$on(this.id + "setComplainInfo", function(data) {
      console.log("eventbus setcomplaininfo : ", data);
      vm.getComplainInfo(data);
    });

    EventBus.$on(this.id + "lightModifyStatus", function() {
      if (vm.modifyComplain) {
        vm.$refs.alert.init(
          "white",
          null,
          "수정 중인 내용들이 사라질 수 있습니다",
          "수정을 취소하고 종료를 진행하시겠습니까?",
          null,
          "closeModal",
          true
        );
      } else {
        vm.$store.commit("modal_all_close", vm.key.split(":")[0]);
      }
    });
    Vue.nextTick(function() {
      $(".vm-complain-info .item-td").focusout(function(e) {
        $(".vm-complain-info .dropdown__header").removeClass("is-active");
      });
      $(".vm-complain-info .complain-check-sn").on(
        "propertychange change keyup paste input",
        function() {
          vm.snCheck = 0;
          vm.req.user_addr = "";
          vm.SL_SLCODE = "";
          vm.SL_MAP_X = "";
          vm.SL_MAP_Y = "";
        }
      );
      $(".vm-complain-info .form-control").css("pointer-events", "none");
      $(".vm-complain-info .form-control")
        .children()
        .css("pointer-events", "none");

      $(".vm-complain-info .dropdown__header").css("pointer-events", "none");
      $(".vm-complain-info .dropdown__header")
        .children()
        .css("pointer-events", "none");
    });
  },
  updated() {
    console.log("updated base modal");
  },
  beforeDestroy() {
    EventBus.$off(this.id + "setComplainInfo");
    EventBus.$off(this.id + "lightModifyStatus");
  }
};
</script>

<style>
.vm-complain-info {
  max-width: 600px; /* NOTE: dialog에 따라 width 사이즈 다르게 설정 */
}
.vm-complain-info .input-padding {
  padding: 0px;
}
.vm-complain-info .tb-textarea {
  border: 0px;
  width: 100%;
  resize: none;
}
.vm-complain-info .complain-control {
  padding: 0px;
  text-align: center;
}
.vm-complain-info .complain-control-btn {
  /* border: 1px solid rgba(25, 128, 223, 0.5); */
  background: #7d7d7d;
  color: #fff;
  padding: 1px 7px 1px 7px;
  border-radius: 15px;
  margin: 2px 0px 2px 7px;
  outline: none;
  line-height: 17px;
}
.vm-complain-info .complain-check-sn {
  padding: 3px 20px 3px 7px;
}
.vm-complain-info .complain-check-sn-img {
  position: absolute;
  margin: 4px 4px 0px 0px;
  height: 21px;
  width: 50px;
  left: 235px;
  top: 27px;
}
.vm-complain-info .complain-check-sn-img img {
  height: 10px;
  width: 10px;
  float: right;
  margin-top: 2px;
  margin-right: 2px;
}
.vm-complain-info .complain-check-sn-img span {
  float: right;
  line-height: 13px;
}
.vm-complain-info input[type="radio"] {
  display: none;
}

.vm-complain-info input[type="radio"] + label {
  color: #000;
}

.vm-complain-info input[type="radio"] + label span {
  display: inline-block;
  width: 11px;
  height: 11px;
  /* margin: -3px 10px 0 0; */
  vertical-align: middle;
  background: url("../../assets/img/res/img/radio-btn-bg.png") top no-repeat;
  background-size: 11px;
  cursor: pointer;
}

.vm-complain-info input[type="radio"]:checked + label span {
  background: url("../../assets/img/res/img/radio-btn.png") top no-repeat;
  background-size: 11px;
}
.vm-complain-info .light-radio {
  height: 10px;
  width: 10px;
  margin-bottom: 0px;
}
.vm-complain-info .light-radio-label {
  width: 50px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 3px;
}
.vm-complain-info .radio-label > span {
  margin-top: 18x;
}
.vm-complain-info .radio-label {
  margin-bottom: 0px;
  margin-left: 7px;
}
.vm-complain-info .light-radio-label-space {
  margin-left: 56px;
}
.vm-complain-info .radio-reply-space {
  margin-left: 32px;
}
.vm-complain-info .radio-status-space {
  margin-left: 32px;
}
.vm-complain-info .radio-status {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 255px;
}
.vm-complain-info .radio-status-addr {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 230px;
}
.vm-complain-info .radio-reply {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 230px;
}
.vm-complain-info .radio-reply-addr {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 205px;
}
.jaje-list-area {
  height: 188px;
  border: 1px solid #eeeeee;
  margin-top: 12px;
  border-radius: 10px;
  overflow: auto;
}

.vm-complain-info .tab_menu {
  margin-top: 7px;
}
.vm-complain-info .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
}

.vm-complain-info .tab_menu > button.modal-remove-btn {
  float: left;
}
.vm-complain-info .tab_menu button:hover {
  background: #016aae;
}
.vm-complain-info .tab_menu button.modal-remove-btn {
  background: rgb(181, 181, 181);
}
.vm-complain-info .tab_menu button.modal-remove-btn:hover {
  background: #a0a0a0;
}
.vm-complain-info .form-control {
  padding: 3px 12px 6px 3px;
  height: 22px;
}
.vm-complain-info .lowast-span {
  vertical-align: bottom;
}
.vm-complain-info .modal-alert {
  width: 280px;
}
.vm-complain-info .main-area {
  display: flex;
}
.vm-complain-info .left-main-area,
.vm-complain-info .right-main-area {
  flex: 1;
}
.left-main-area {
  margin-right: 6px;
}
.right-main-area {
  margin-left: 6px;
}
</style>

<style lang="scss">
.vm-complain-info {
  & * {
    font-size: 12px;
  }
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th.td-center {
        text-align: center;
      }
      & > th {
        // min-width: 92px;
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.complain-modify-mode {
        background: #7d7d7d;
      }

      & > td.td-center {
        text-align: center;
      }
      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0;
      -webkit-border-radius: 10px 0 0 0;
      border-radius: 10px 0 0 0;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0 0;
      -webkit-border-radius: 0 10px 0 0;
      border-radius: 0 10px 0 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>

<style lang="scss">
// NOTE :: DropDown CSS
.vm-complain-info {
  & .dropdown {
    width: 100%;
    &__header {
      background: #fff;
      font-size: 12px;
      cursor: pointer;
      line-height: 20px;
      position: relative;
      text-overflow: ellipsis;
      color: #000;
      width: 100%;
      height: 21px;
      i.fas {
        position: absolute;
        right: 4px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 10px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &:not(.complain-modify-mode) {
        i {
          opacity: 0;
        }
      }
      &.is-active {
        outline: -webkit-focus-ring-color auto 1px;
        outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
        }
      }
      & span {
        padding-left: 7px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #fff;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #000;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>
