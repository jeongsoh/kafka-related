<template lang="pug">
.modal-content.vm-complain-register(:id="key")
  .modal-header
    VMHeader(v-bind:icon="header.icon", v-bind:title="header.title", v-bind:menu="header.menu", v-bind:exitBtn="header.exitBtn", v-bind:modalKey="key", v-bind:subTitle="subTitle")
  .modal-body
    vm-alert(ref="alert" @event="alertEvent")
    table.modal-main-table(:class="modifyLight ? 'table-modify' : ''")
      colgroup
        col(style="width:33%")
        col(style="width:66%")
      tr.tr-item.compalin-table
        th.th-item.left-first-child.lowast-span(:class="modifyLightMode()")
          span &nbsp;&nbsp;접수 구분
          img.lowast(:src="require('@/assets/img/res/img/essential.png')")
        td.td-item.input-padding.table-vertical-top.left-last-child
          input.light-radio(type="radio" v-model="registerType" value="1" :id="'registerTypeSLCODE'+key" :name="key" )
          label.radio-label(:for="'registerTypeSLCODE'+key")
            span
              label.light-radio-label 표찰번호
          input.light-radio(type="radio" v-model="registerType" value="2" :id="'registerTypeAddr' + key" :name="key" )
          label.radio-label.light-radio-label-space(:for="'registerTypeAddr' + key")
            span
              label.light-radio-label 주소
      tr.tr-item(v-if="registerType!=2")
        th.th-item(:class="modifyLightMode()") 
          span &nbsp;&nbsp;표찰번호
          img.lowast(:src="require('@/assets/img/res/img/essential.png')")
        td.td-item.input-padding 
          input.complain-check-sn(type="text" v-model="req.SL_SLNAME" v-on:keyup="searchEnter($event)")
          .complain-check-sn-img
            span(v-if="snCheck == 1" style="color:#00a0ea") 존재
            span(v-if="snCheck == -1" style="color:#f63f3f") 미존재
            span(v-if="snCheck == 2" style="color:#ffbc08") 중복
            img(:src="require('@/assets/img/res/img/' + snCheckImg() + '.png')")
          button.complain-control-btn(@click="onClickSearchAddr" style="outline:none") 확인
          button.complain-control-btn(@click="onClickMove" style="outline:none" :disabled="snCheck == 1 ? false : true") 지도
          button.complain-control-btn(@click="onClickShowLight" style="outline:none" :disabled="snCheck == 1 ? false : true") 상세
          button.complain-control-btn(@click="onClickHistory" style="outline:none" :disabled="snCheck == 1 ? false : true") 이력
      tr.tr-item
        th.th-item(:class="[modifyLightMode(), registerType == 1 ? 'lowast-span' : '']")
          span &nbsp;&nbsp;주소
          img.lowast(:src="require('@/assets/img/res/img/essential.png')")
        td.td-item.input-padding 
          input.complain-check-addr(type="text" v-model="req.user_addr" :disabled="registerType == 1")
          button.complain-control-btn(v-if="registerType != 1" @click="onClickAddrMove" style="outline:none") 지도
      tr.tr-item
        th.th-item(:class="modifyLightMode()") &nbsp;&nbsp;민원 일자
        td.td-item.input-padding 
          date-range-picker(:startDate="startDate" :endDate="endDate" :locale-data="locale" opens="right" autoApply v-model="dataRange" style="width:100%; height:100%;" :singleDatePicker="true" :ranges="false" :show-dropdowns="true")
          //- input(type="text" v-model="req.user_addr")
      tr.tr-item
        th.th-item(:class="modifyLightMode()") &nbsp;&nbsp;접수 일자
        td.td-item.input-padding 
          input(type="text" v-model="nowDate" :disabled="true")
      tr.tr-item
        th.th-item(:class="modifyLightMode()") &nbsp;&nbsp;신고인
        td.td-item.input-padding 
          input(type="text" v-model="req.repoter")
      tr.tr-item
        th.th-item(:class="modifyLightMode()") &nbsp;&nbsp;전화번호
        td.td-item.input-padding
          input(type="text" v-model="req.tel" @keyup="getPhoneMask(req.tel, 'tel', $event)")
      tr.tr-item
        th.th-item(:class="modifyLightMode()") &nbsp;&nbsp;휴대전화
        td.td-item.input-padding
          input(type="text" v-model="req.phone" @keyup="getPhoneMask(req.phone, 'phone', $event)")
      tr.tr-item
        th.th-item.lowast-span(:class="modifyLightMode()") 
          span &nbsp;&nbsp;회신 여부
          img.lowast(:src="require('@/assets/img/res/img/essential.png')")
        td.item-td.input-padding(tabindex="-1")
          input.light-radio(type="radio" v-model="req.reply" value="SMS" :id="'replySMS'+key" :name="'reply'+key" )
          label.radio-label(:for="'replySMS'+key")
            span
              label(:class="registerType == 1 ? 'radio-reply' : 'radio-reply-addr'") SMS
          input.light-radio(type="radio" v-model="req.reply" value="TEL" :id="'replyTEL' + key" :name="'reply'+key" )
          label.radio-label.radio-reply-space(:for="'replyTEL' + key")
            span
              label(:class="registerType == 1 ? 'radio-reply' : 'radio-reply-addr'") 전화
          input.light-radio(type="radio" v-model="req.reply" value="NONE" :id="'replyNONE' + key" :name="'reply'+key")
          label.radio-label.radio-reply-space(:for="'replyNONE' + key")
            span
              label(:class="registerType == 1 ? 'radio-reply' : 'radio-reply-addr'" style="width:70px;") 회신받지않음
      tr.tr-item
        th.th-item.lowast-span(:class="modifyLightMode()") 
          span &nbsp;&nbsp;표찰 상태
          img.lowast(:src="require('@/assets/img/res/img/essential.png')")
        td.item-td.input-padding(tabindex="-1")
          input.light-radio(type="radio" v-model="req.status" value="NORMAL" :id="'statusSMS'+key" :name="'status'+key" )
          label.radio-label(:for="'statusSMS'+key")
            span
              label(:class="registerType == 1 ? 'radio-status' : 'radio-status-addr'") 정상
          input.light-radio(type="radio" v-model="req.status" value="WORNOUT" :id="'statusTEL' + key" :name="'status'+key" )
          label.radio-label.radio-status-space(:for="'statusTEL' + key")
            span
              label(:class="registerType == 1 ? 'radio-status' : 'radio-status-addr'") 노후
          input.light-radio(type="radio" v-model="req.status" value="NONE" :id="'statusNONE' + key" :name="'status'+key")
          label.radio-label.radio-status-space(:for="'statusNONE' + key")
            span
              label(:class="registerType == 1 ? 'radio-status' : 'radio-status-addr'") 없음
      tr.tr-item
        th.th-item.lowast-span(:class="modifyLightMode()") 
          span &nbsp;&nbsp;고장 종류
          img.lowast(:src="require('@/assets/img/res/img/essential.png')")
        td.item-td.input-padding(tabindex="-1")
          .dropdown
            .dropdown__header(@click="toggleDropdown($event)")
              span {{code.SL_CONTENT[req.content]}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content
              ul
                li(v-if="key != 'all'" @click="clickDropDown('content', key)" v-for="value, key in code.SL_CONTENT"  :class="dropdownChoice(value, code.SL_CONTENT[req.content])") {{value}}
                  .search-division-line    
      tr.tr-item
        th.th-item.lowast-span(:class="modifyLightMode()") 
          span &nbsp;&nbsp;이설 여부
        td.item-td.input-padding(tabindex="-1")
          .dropdown
            .dropdown__header(@click="toggleDropdown($event)")
              span {{req.relocation == 'Y'? "이설":"미이설"}}
              i.fas.fa-chevron-down
              i.fas.fa-chevron-up
            .dropdown__content
              ul
                li(@click="clickDropDown('relocation', 'Y')" :class="dropdownChoice('Y', req.relocation)") 이설
                  .search-division-line
                li(@click="clickDropDown('relocation', 'N')" :class="dropdownChoice('N', req.relocation)") 미이설
                  .search-division-line
      tr.tr-item
        th.th-item.right-first-child(:class="modifyLightMode()") &nbsp;&nbsp;상태 설명
        td.complain-control.right-last-child
          textarea(row='6' v-model="req.comment" :class="registerType == 2 ? 'registerTypeAddr' : ''")
    .tab_menu
      button(type="button" class="btn btn-outline-primary" @click="getPcComplainCheckAPI" ) 민원 접수
  VM-search-addr(:id="id" :type="type" :key="key" v-on:clickAddrClose="onClickAddrClose" v-if="modalComplainAddr")
  VM-complain-history(:id="id" :type="type" :key="key" v-on:clickAddrClose="onClickAddrClose" :slcode="sl_nt" v-if="modalComplainHistory")
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
import VMSearchAddr from "@/components/modal/VMSearchAddr";
import VMComplainHistory from "@/components/modal/VMComplainHistory";
import { mkdir } from "fs";
import complainCode from "@/assets/json/complainCode.json";
import DateRangePicker from "vue2-daterange-picker";

export default {
  components: {
    VMSearchAddr,
    DateRangePicker,
    VMComplainHistory
  },
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: false
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      header: {
        icon: "",
        title: "고장 신고",
        menu: [],
        exitBtn: true
      },
      SL_SLCODE: "",
      req: {
        SL_SLNAME: "",
        user_addr: "",
        writer: "",
        repoter: "",
        phone: "",
        tel: "",
        reply: "NONE",
        content: "미점등",
        comment: "",
        cp_date: "",
        status: "NORMAL",
        relocation: "N"
      },
      SL_MAP_X: "",
      SL_MAP_Y: "",
      modalComplainAddr: false,
      modalComplainHistory: false,
      modifyLight: true,
      compainCheckContent: [],
      registerType: "1",
      code: {},
      dataRange: {
        startDate: new Date(),
        endDate: new Date()
      },
      startDate: new Date(),
      endDate: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      returnData: 0,
      snCheck: 0,
      subTitle: "작성중",
      sl_nt: ""
    };
  },
  watch: {
    req: function(val) {
      console.log("req val", val);
    },
    registerType: function(val) {
      console.log("change registerType");
      this.snCheck = 0;
      this.req.user_addr = "";
      this.req.SL_SLNAME = "";
      if (val == 1) {
        setTimeout(function() {
          $(".vm-complain-register .complain-check-sn").focus();
        }, 0);
      } else if (val == 2) {
        setTimeout(function() {
          $(".vm-complain-register .complain-check-addr").focus();
        }, 0);
      }
    },
    "dataRange.endDate": function(val) {
      console.log(val >= new Date());
      if (val >= new Date()) {
        this.$refs.alert.init(
          "black",
          null,
          "민원 일자는 최대 당일까지 선택이 가능합니다.",
          null,
          null,
          true,
          false
        );
        this.dataRange.startDate = new Date();
        this.dataRange.endDate = new Date();
      }
    }
  },
  computed: {
    nowDate() {
      return this.moment(new Date()).format("YY.MM.DD");
    }
  },
  methods: {
    searchEnter(e) {
      if (e.key == "Enter") {
        this.onClickSearchAddr();
      }
    },
    modifyLightMode() {
      if (this.modifyLight) {
        return "modify-light-mode";
      } else {
        return "";
      }
    },
    onClickAddrClose() {
      this.modalComplainHistory = false;
    },
    onClickMove() {
      // NOTE :: 신고 시설물 위치로 지도 이동
      if (this.SL_MAP_X == "") {
        this.$refs.alert.init(
          "black",
          null,
          "표찰번호를 입력 후 확인 버튼을 클릭 해주세요",
          null,
          null,
          true,
          false
        );
      } else {
        var point = window.setCoordsFromPoint(
          this.SL_MAP_X,
          this.SL_MAP_Y,
          this.$store.getters.panel_location_name
        );
        window.SetPositionLevel(point.getLng(), point.getLat(), 1);
      }
    },
    onClickAddrMove() {
      // NOTE :: 신고 주소로 지도 이동
      if (this.req.user_addr == "") {
        this.$refs.alert.init(
          "black",
          null,
          "주소를 확인해주세요",
          null,
          null,
          true,
          false
        );
      } else {
        // window.getValue(this.req.user_addr, "modal");
        var vm = this;
        var geocoder = new kakao.maps.services.Geocoder();
        geocoder.addressSearch(this.req.user_addr, function(result, status) {
          if (status === window.kakao.maps.services.Status.OK) {
            window.map.setCenter(
              window.setCoordsFromPoint(
                result[0].x,
                result[0].y,
                window.panelPosition
              )
            );
            if (window.isRvOn) {
              window.isToggleRvJustNow = true;
              window.evtRvPositionChanged();
            }
          } else {
            vm.$refs.alert.init(
              "black",
              null,
              "잘못된 주소를 입력하셨습니다",
              null,
              null,
              true,
              false
            );
          }
        });
      }
    },
    onClickClose(key) {
      this.$store.commit("modal_close", key);
    },
    GetPcaddress(data) {
      // NOTE :: 시설물에 해당하는 주소가져옴
      var addrData = {
        SL_SLNAME: data,
        PAGE: 1
      };
      var vm = this;
      this.$_API_GET("pcaddress", addrData)
        .then(function(res) {
          console.log("pcaddress", res);
          vm.returnData = res.content.length;
          if (res.content.length == 0) {
            vm.snCheck = -1;
            vm.req.user_addr = "";
          } else if (res.content.length == 1) {
            for (var value in res.notice) {
              if (value != "contains") {
                console.log(
                  "res.notice[value].SL_MAINTENANCE",
                  res.notice[value].SL_MAINTENANCE
                );
                if (res.notice[value].SL_MAINTENANCE == "INPROGRESS") {
                  console.log("접수가 있는 민원");
                  // NOTE :: 이전에 사용한 alert 인데 사용안함. 추후 사용 가능성이 있으므로 냅둠.
                  // vm.compainRegisterCheckContent = [
                  //   "해당 시설물은 {0} {1}:{2} 에 ".format(
                  //     res.notice[value].SL_NTDATE.split("T")[0],
                  //     res.notice[value].SL_NTDATE.split("T")[1].split(":")[0],
                  //     res.notice[value].SL_NTDATE.split("T")[1].split(":")[1]
                  //   ),
                  //   "이미 접수된 민원이 있습니다.",
                  //   "다시 한번 확인해 주시기 바랍니다."
                  // ];
                  vm.snCheck = 2;
                  return;
                }
              }
            }
            vm.req.SL_SLNAME = res.content[0].SL_SLNAME;
            vm.SL_SLCODE = res.content[0].SL_SLCODE;
            vm.SL_MAP_X = res.content[0].SL_MAP_X;
            vm.SL_MAP_Y = res.content[0].SL_MAP_Y;
            vm.req.user_addr = res.content[0].ADDRESS_OLD;
            if (res.notice.length == 0) {
              vm.sl_nt = "";
            } else {
              vm.sl_nt = res.notice[res.notice.length - 1].SL_NT_NO;
            }
            vm.snCheck = 1;
          } else if (res.content.length > 1) {
            // NOTE :: 환경설정으로 넘겨야 하는 부분
            // vm.modalComplainAddr = true;
            // Vue.nextTick(function() {
            //   EventBus.$emit("setAddr", vm.req.SL_SLNAME);
            // });

            // NOTE :: alert은 어떻게?

            vm.snCheck = -1;
            vm.req.user_addr = "";
          }
        })
        .catch(e => {
          console.log("주소 검색 에러", e);
        });
    },
    onClickSearchAddr() {
      if (this.req.SL_SLNAME.length >= 2) {
        this.GetPcaddress(this.req.SL_SLNAME);
      } else {
        this.$refs.alert.init(
          "black",
          null,
          "표찰번호를 2글자 이상 작성 바랍니다",
          null,
          null,
          true,
          false
        );
      }
    },
    onClickHistory() {
      if (this.snCheck != 1) {
        this.$refs.alert.init(
          "black",
          null,
          "표찰번호 중복체크해주세요",
          null,
          null,
          true,
          false
        );
      } else if (this.req.SL_SLNAME.length >= 2) {
        if (this.sl_nt == "") {
          this.$refs.alert.init(
            "black",
            null,
            "해당 시설물의 민원 이력이 없습니다",
            null,
            null,
            true,
            false
          );
        } else {
          this.modalComplainHistory = true;
        }
      } else {
        this.$refs.alert.init(
          "black",
          null,
          "표찰번호를 2글자 이상 작성 바랍니다",
          null,
          null,
          true,
          false
        );
      }
    },
    onClickShowLight() {
      if (this.SL_SLCODE == "") {
        this.$refs.alert.init(
          "black",
          null,
          "표찰번호를 입력 후 확인 버튼을 클릭 해주세요",
          null,
          null,
          true,
          false
        );
      } else {
        EventBus.$emit("modalOpen", this.SL_SLCODE, "VMLight");
      }
    },
    setComplain() {
      console.log(this.req);
      this.req.writer = this.req.repoter;
      this.req.SL_SLCODE = this.SL_SLCODE;
      this.req.cp_date = this.moment(this.dataRange.endDate).format(
        "YYYY-MM-DD"
      );
      this.PostPccomplaint(this.req);
    },
    PostPccomplaint(data) {
      // NOTE :: 민원 접수
      var vm = this;
      this.$_API_POST("pccomplaint", data).then(function(res) {
        console.log("pccomplaint", res);
        var data = {
          SL_NTDATE_START: vm.datepickerFormatter(new Date()),
          SL_NTDATE_END: vm.datepickerFormatter(new Date()),
          SL_SLNAME: "",
          SL_NTRES: "all",
          SL_REPLY: "all",
          SL_CONTENT: "all",
          PAGE: 1
        };
        EventBus.$emit("searchComplaint");
        vm.$refs.alert.init(
          "white",
          null,
          "접수가 완료되었습니다",
          null,
          null,
          "complainSuccess",
          false
        );
      });
    },
    getPcComplainCheckAPI() {
      // NOTE :: 입력 데이터 검증 및 최근 민원 확인
      var vm = this;
      console.log("snCheck", this.snCheck);
      if (this.registerType == "1") {
        if (
          (this.SL_SLCODE == "" && this.registerType == "1") ||
          this.snCheck != 1
        ) {
          this.$refs.alert.init(
            "black",
            null,
            "표찰번호를 입력 후 확인 버튼을 클릭 해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      } else if (this.registerType == "2") {
        if (this.req.user_addr == "" && this.registerType == "2") {
          this.$refs.alert.init(
            "black",
            null,
            "주소를 확인해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      }
      if (this.req.reply == "SMS" || this.req.reply == "TEL") {
        if (
          this.req.phone.length != 13 ||
          this.req.phone.split("-")[0] != "010"
        ) {
          this.$refs.alert.init(
            "black",
            null,
            "휴대전화를 확인해주세요",
            null,
            null,
            true,
            false
          );
          return;
        }
      }
      if (this.registerType == 2) {
        vm.setComplain();
      } else {
        this.$_API_GET("pc/complain/check", {
          SL_SLCODE: this.SL_SLCODE
        }).then(function(res) {
          console.log("pccomplaint", res);
          if (res.SL_NTDATE != undefined) {
            if (res.SL_MAINTENANCE == "DONE") {
              // vm.$refs.alert.init(
              //   "black",
              //   null,
              //   "가장 최근에 완료된 민원은 {0}에 접수되었습니다.".format(
              //     res.SL_NTDATE.split("T")[0]
              //   ),
              //   null,
              //   null,
              //   true,
              //   false
              // );
              vm.setComplain();
            } else {
              vm.$refs.alert.init(
                "black",
                null,
                "동일 시설물에 대해 {0}에 민원 이력이 존재합니다.".format(
                  res.SL_NTDATE.split("T")[0]
                ),
                null,
                null,
                true,
                false
              );
            }
          } else {
            vm.setComplain();
          }
        });
      }
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    closeModal() {
      this.$store.commit("modal_all_close", this.key.split(":")[0]);
    },
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      this.req[type] = data;
      $(".vm-complain-register .dropdown__header").removeClass("is-active");
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    snCheckImg() {
      if (this.snCheck == 0) {
        return "check-blank";
      } else if (this.snCheck == 1) {
        return "check-true";
      } else if (this.snCheck == -1) {
        return "check-false";
      } else if (this.snCheck == 2) {
        return "check-cation";
      }
    },
    getPhoneMask(val, key, event) {
      if (event.keyCode >= 48 && event.keyCode <= 57) {
        let res = this.getMask(val);
        this.req[key] = res;
      } else {
        // $(event.path)
        //   .eq(0)
        //   .val(val.replace(/[^0-9]/gi, ""));
      }
    },
    getMask(phoneNumber) {
      var number = phoneNumber.replace(/[^0-9]/gi, "");
      var tel = "";

      // 서울 지역번호(02)가 들어오는 경우
      if (number.substring(0, 2).indexOf("02") == 0) {
        if (number.length < 3) {
          return number;
        } else if (number.length < 6) {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2);
        } else if (number.length < 10) {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2, 3);
          tel += "-";
          tel += number.substr(5);
        } else {
          tel += number.substr(0, 2);
          tel += "-";
          tel += number.substr(2, 4);
          tel += "-";
          tel += number.substr(6);
        }

        // 서울 지역번호(02)가 아닌경우
      } else {
        if (number.length < 4) {
          return number;
        } else if (number.length < 7) {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3);
        } else if (number.length < 11) {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3, 3);
          tel += "-";
          tel += number.substr(6);
        } else {
          tel += number.substr(0, 3);
          tel += "-";
          tel += number.substr(3, 4);
          tel += "-";
          tel += number.substr(7);
        }
      }

      return tel;
    },
    alertEvent(key, inputData) {
      switch (key) {
        case "complainSuccess":
          this.onClickClose(this.key);
          break;
        case "closeModal":
          this.closeModal();
          break;
      }
    }
  },
  created() {},
  mounted() {
    // $(".modal").modal({
    //   backdrop: false
    // });
    // $(".modal-content").draggable({
    //   handle: ".modal-header, .modal-body",
    //   containment: "#modal_area"
    // });
    this.code = JSON.parse(JSON.stringify(complainCode));
    var vm = this;
    EventBus.$on("setComplainAddr" + this.id, function(
      name,
      slcode,
      MAP_X,
      MAP_Y
    ) {
      vm.req.SL_SLNAME = name;
      vm.SL_SLCODE = slcode;
      vm.SL_MAP_X = MAP_X;
      vm.SL_MAP_Y = MAP_Y;
      vm.snCheck = 1;
      vm.onClickSearchAddr();
    });

    EventBus.$on(this.id + "lightModifyStatus", function() {
      vm.$store.commit("modal_all_close", vm.key.split(":")[0]);
    });

    Vue.nextTick(function() {
      $(".vm-complain-register .item-td").focusout(function(e) {
        $(".vm-complain-register .dropdown__header").removeClass("is-active");
      });
      $(".vm-complain-register .complain-check-sn").on(
        "propertychange change keyup paste input",
        function() {
          vm.snCheck = 0;
          vm.req.user_addr = "";
          vm.SL_SLCODE = "";
          vm.SL_MAP_X = "";
          vm.SL_MAP_Y = "";
          console.log(vm.snCheck);
        }
      );
      $(".vm-complain-register .complain-check-sn").focus();
    });
  },
  updated() {
    console.log("updated base modal");
  },
  beforeDestroy() {
    EventBus.$off("setComplainAddr");
    EventBus.$off(this.id + "lightModifyStatus");
  }
};
</script>

<style>
.vm-complain-register {
  max-width: 300px; /* NOTE: dialog에 따라 width 사이즈 다르게 설정 */
}
.vm-complain-register .input-padding {
  padding: 0px;
}
.vm-complain-register .tb-textarea {
  border: 0px;
  width: 100%;
  height: 150px;
  resize: none;
}
.vm-complain-register .complain-control {
  padding: 0px;
  text-align: center;
}
.vm-complain-register .complain-control-btn {
  /* border: 1px solid rgba(25, 128, 223, 0.5); */
  background: #7d7d7d;
  color: #fff;
  padding: 1px 7px 1px 7px;
  border-radius: 15px;
  margin: 2px 0px 2px 7px;
  outline: none;
  line-height: 17px;
}
.vm-complain-register .complain-control-btn[disabled] {
  color: #979797;
  background: #e4e4e4;
}
.vm-complain-register .complain-check-sn {
  padding: 3px 55px 3px 7px;
}
.vm-complain-register .complain-check-sn-img {
  position: absolute;
  margin: 4px 4px 0px 0px;
  height: 21px;
  width: 50px;
  right: 12px;
  top: 27px;
}
.vm-complain-register .complain-check-sn-img img {
  height: 10px;
  width: 10px;
  float: right;
  margin-top: 2px;
  margin-right: 2px;
}
.vm-complain-register .complain-check-sn-img span {
  float: right;
  line-height: 13px;
}
.vm-complain-register input[type="radio"] {
  display: none;
}

.vm-complain-register input[type="radio"] + label {
  color: #000;
}

.vm-complain-register input[type="radio"] + label span {
  display: inline-block;
  width: 11px;
  height: 11px;
  /* margin: -3px 10px 0 0; */
  vertical-align: middle;
  background: url("../../assets/img/res/img/radio-btn-bg.png") top no-repeat;
  background-size: 11px;
  cursor: pointer;
}

.vm-complain-register input[type="radio"]:checked + label span {
  background: url("../../assets/img/res/img/radio-btn.png") top no-repeat;
  background-size: 11px;
}
.vm-complain-register .light-radio {
  height: 10px;
  width: 10px;
  margin-bottom: 0px;
}
.vm-complain-register .light-radio-label {
  width: 50px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 3px;
}
.vm-complain-register .radio-reply {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 230px;
}
.vm-complain-register .radio-reply-addr {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 205px;
}
.vm-complain-register .radio-status {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 255px;
}
.vm-complain-register .radio-status-addr {
  width: 25px;
  margin-bottom: 0px;
  margin-left: 15px;
  position: absolute;
  top: 230px;
}

.vm-complain-register .radio-label > span {
  margin-top: 18x;
}
.vm-complain-register .radio-label {
  margin-bottom: 0px;
  margin-left: 7px;
}
.vm-complain-register .light-radio-label-space {
  margin-left: 56px;
}
.vm-complain-register .radio-reply-space {
  margin-left: 32px;
}
.vm-complain-register .radio-status-space {
  margin-left: 32px;
}
.vm-complain-register .tab_menu button {
  font-size: 12px;
  height: 26px;
  padding: 4px 12px 6px 12px;
  background: #424242;
  border: 0px;
  color: white;
}
.vm-complain-register .tab_menu button:hover {
  background: #016aae;
}
.vm-complain-register .form-control {
  padding: 3px 12px 6px 3px;
  height: 22px;
}
.vm-complain-register .lowast-span {
  vertical-align: bottom;
}

.vm-complain-register .modal-alert {
  width: 280px;
}
</style>

<style lang="scss">
.vm-complain-register {
  & * {
    font-size: 12px;
  }
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #7d7d7d;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100%;
        }
        & input[type="text"]:disabled {
          background: lightgray;
        }
        // & input:focus {
        //   outline: #418fff auto 1px;
        //   outline-offset: -2px;
        // }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0;
      -webkit-border-radius: 10px 0 0 0;
      border-radius: 10px 0 0 0;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0 0;
      -webkit-border-radius: 0 10px 0 0;
      border-radius: 0 10px 0 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }
  }
}
</style>

<style lang="scss">
// NOTE :: DropDown CSS
.vm-complain-register {
  & .dropdown {
    width: 100%;
    &__header {
      background: #fff;
      font-size: 12px;
      cursor: pointer;
      line-height: 20px;
      position: relative;
      text-overflow: ellipsis;
      color: #000;
      width: 100%;
      height: 21px;
      i.fas {
        position: absolute;
        right: 4px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 10px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &.is-active {
        outline: -webkit-focus-ring-color auto 1px;
        outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
        }
      }
      & span {
        padding-left: 7px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #fff;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #000;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>
