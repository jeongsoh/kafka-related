<template lang="pug">
#search_list.vp-device-search
  #search_condition
    #table-all
      table.parent-table#panel-table(onmousewheel="")
        tr.group-condition
          th.item-th
            span 시설물
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_DATA_1[req.SL_DATA_1]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_DATA_1', 'all')" :class="dropdownChoice('전체', code.SL_DATA_1[req.SL_DATA_1])") 전체
                    .search-division-line
                  //- li(@click="clickDropDown('SL_DATA_1', '0')" :class="dropdownChoice('가로등', code.SL_DATA_1[req.SL_DATA_1])") 가로등
                  //-   .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_DATA_1', key)" v-for="value, key in code.SL_DATA_1" :class="dropdownChoice(value, code.SL_DATA_1[req.SL_DATA_1])") {{value}}
                    .search-division-line
        tr.group-condition
          th.item-th
            span 표찰번호
          td.item-td.td-input
            input.slname-input(v-model="req.SL_SLNAME")
        tr.group-condition
          th.item-th
            span 점멸기
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.WORK_TYPE[req.WORK_TYPE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('WORK_TYPE', 'all')" :class="dropdownChoice('전체', code.WORK_TYPE[req.WORK_TYPE])") 전체
                    .search-division-line
                  li(@click="clickDropDown('WORK_TYPE', '-1')" :class="dropdownChoice('양방향(LoRa)', code.WORK_TYPE[req.WORK_TYPE])") 양방향(LoRa)
                    .search-division-line
                  li(v-if="key != 'all' && key != '-1'" @click="clickDropDown('WORK_TYPE', key)" v-for="value, key in code.WORK_TYPE" :class="dropdownChoice(value, code.WORK_TYPE[req.WORK_TYPE])") {{value}}
                    .search-division-line
        tr.group-condition(v-show="false")
          th.item-th
            span 주소
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span(v-show="req.SL_ADDR_1 != 'all'") {{req.SL_ADDR_1}}
                span(v-show="req.SL_ADDR_1 == 'all'") 전체
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_ADDR_1', 'all')" :class="dropdownChoice('all', req.SL_ADDR_1)") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_ADDR_1', key)" v-for="value, key in res" :class="dropdownChoice(key, req.SL_ADDR_1)") {{key}}
                    .search-division-line
        tr.group-condition(v-show="false")
          th.item-th
            span 주소2
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span(v-show="req.SL_ADDR_2 != 'all'") {{req.SL_ADDR_2}}
                span(v-show="req.SL_ADDR_2 == 'all'") 전체
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_ADDR_2', 'all')"  :class="dropdownChoice('all', req.SL_ADDR_2)") 전체
                    .search-division-line
                  li(v-if="addrSub != 'all'" @click="clickDropDown('SL_ADDR_2', addrSub)" :class="dropdownChoice(addrSub, req.SL_ADDR_2)") {{addrSub}}
                    .search-division-line
        tr.group-condition(v-show="false")
          th.item-th
            span 주소3
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span(v-show="req.SL_ADDR_3 != 'all'") {{req.SL_ADDR_3}}
                span(v-show="req.SL_ADDR_3 == 'all'") 전체
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_ADDR_3', 'all')" :class="dropdownChoice('all', req.SL_ADDR_3)") 전체
                    .search-division-line
                  li(v-if="addrSub != 'all'" @click="clickDropDown('SL_ADDR_3', addrSub)" :class="dropdownChoice(addrSub, req.SL_ADDR_3)") {{addrSub}}
                    .search-division-line
        tr.group-condition
          th.item-th
            span {{$store.getters.filter['filter_1']}}
          td.item-td(tabindex="-1")
            input(v-model="req.FILTER_STREET")
            //- .dropdown
            //-   .dropdown__header(@click="toggleDropdown($event)")
            //-     span {{code.FILTER_STREET[req.FILTER_STREET]}}
            //-     i.fas.fa-chevron-down
            //-     i.fas.fa-chevron-up
            //-   .dropdown__content
            //-     ul
            //-       li(@click="clickDropDown('FILTER_STREET', 'all')" :class="dropdownChoice('전체', code.FILTER_STREET[req.FILTER_STREET])") 전체
            //-         .search-division-line
            //-       li(v-if="key != 'all'" @click="clickDropDown('FILTER_STREET', key)" v-for="value, key in code.FILTER_STREET" :class="dropdownChoice(value, code.FILTER_STREET[req.FILTER_STREET])") {{value}}
            //-         .search-division-line          
        tr.group-condition(v-show="conditionExtend")
          th.item-th
            span {{$store.getters.filter['filter_2']}}
          td.item-td(tabindex="-1")
            input(v-model="req.FILTER_VILLAGE")
            //- .dropdown
            //-   .dropdown__header(@click="toggleDropdown($event)")
            //-     span {{code.FILTER_VILLAGE[req.FILTER_VILLAGE]}}
            //-     i.fas.fa-chevron-down
            //-     i.fas.fa-chevron-up
            //-   .dropdown__content
            //-     ul
            //-       li(@click="clickDropDown('FILTER_VILLAGE', 'all')" :class="dropdownChoice('전체', code.FILTER_VILLAGE[req.FILTER_VILLAGE])") 전체
            //-         .search-division-line
            //-       li(v-if="key != 'all'" @click="clickDropDown('FILTER_VILLAGE', key)" v-for="value, key in code.FILTER_VILLAGE" :class="dropdownChoice(value, code.FILTER_VILLAGE[req.FILTER_VILLAGE])") {{value}}
            //-         .search-division-line                        
        tr.group-condition(v-show="conditionExtend")
          th.item-th
            span 빛 공해
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.POLLUTION_LIGHT[req.POLLUTION_LIGHT]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('POLLUTION_LIGHT', 'all')" :class="dropdownChoice('전체', code.POLLUTION_LIGHT[req.POLLUTION_LIGHT])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('POLLUTION_LIGHT', key)" v-for="value, key in code.POLLUTION_LIGHT" :class="dropdownChoice(value, code.POLLUTION_LIGHT[req.POLLUTION_LIGHT])") {{value}}
                    .search-division-line               
        tr.group-condition(v-show="conditionExtend")
          th.item-th
            span 전기요금
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_DATA_2[req.SL_DATA_2]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_DATA_2', 'all')"  :class="dropdownChoice('전체', code.SL_DATA_2[req.SL_DATA_2])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_DATA_2', key)" v-for="value, key in code.SL_DATA_2" :class="dropdownChoice(value, code.SL_DATA_2[req.SL_DATA_2])") {{value}}
                    .search-division-line             
        tr.group-condition(v-show="conditionExtend")
          th.item-th
            span 등주형식
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_DATA_5[req.SL_DATA_5]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_DATA_5', 'all')" :class="dropdownChoice('전체', code.SL_DATA_5[req.SL_DATA_5])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_DATA_5', key)" v-for="value, key in code.SL_DATA_5" :class="dropdownChoice(value, code.SL_DATA_5[req.SL_DATA_5])") {{value}}
                    .search-division-line   
        tr.group-condition(v-show="conditionExtend")
          th.item-th
            span 등주형태
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.POLES_DIRECTION[req.POLES_DIRECTION]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('POLES_DIRECTION', 'all')" :class="dropdownChoice('전체', code.POLES_DIRECTION[req.POLES_DIRECTION])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('POLES_DIRECTION', key)" v-for="value, key in code.POLES_DIRECTION"  :class="dropdownChoice(value, code.POLES_DIRECTION[req.POLES_DIRECTION])") {{value}}
                    .search-division-line   
        tr.group-condition(v-show="conditionExtend")
          th.item-th
            span 보행자등
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.PED_LIGHTING[req.PED_LIGHTING]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('PED_LIGHTING', 'all')" :class="dropdownChoice('전체', code.PED_LIGHTING[req.PED_LIGHTING])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('PED_LIGHTING', key)" v-for="value, key in code.PED_LIGHTING" :class="dropdownChoice(value, code.PED_LIGHTING[req.PED_LIGHTING])") {{value}}
                    .search-division-line 
        tr.group-condition(id="blank-1" v-show="this.$store.getters.panel_size >= 649")
          th.item-th.blank-th
        tr.group-condition(id="blank-2" v-show="this.$store.getters.panel_size >= 649")
          th.item-th.blank-th
        tr.group-condition(id="blank-3" v-show="this.$store.getters.panel_size >= 1000")
          th.item-th.blank-th
        tr.group-condition(id="blank-4" v-show="this.$store.getters.panel_size >= 1000")
          th.item-th.blank-th
        tr.group-condition(v-if="false")
          th.item-th.blank-th
          td.item-td.condition-extend-td
            .condition-extend-div(@click="conditionExtend = !conditionExtend")
              span 검색옵션 펼쳐보기
              i.fas.fa-chevron-down(:class="classConditionExtend('down')")
              i.fas.fa-chevron-up(:class="classConditionExtend('up')")
    .filter-footer
      button.search-btn(@click="searchLight") 검색
      button.search-btn(@click="excelDownload") 엑셀 다운로드
      span.table-total 총 검색 결과 : {{totalCount}} 개
  #search_condition.result-area(style="height:100%" v-show="resultTable")
    #search_result
      //- b-table#search-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
      .table-gradient
      table.result-table
        thead
          tr
            th.result-th-default
              .result-th 표찰번호
            th.result-th-default
              .result-th 상태
            th.result-th-default
              .result-th 에러
            th.result-th-default
              .result-th 시설물
            th.result-th-default
              .result-th 점멸기
            th.result-th-default
              .result-th 주소
            th.result-th-default
              .result-th {{$store.getters.filter['filter_1']}}
            th.result-th-default
              .result-th {{$store.getters.filter['filter_2']}}
            th.result-th-default
              .result-th 빛 공해
            //- th.result-th-default
            //-   .result-th ESCO
            th.result-th-default
              .result-th 전기요금
            th.result-th-default
              .result-th 등주형식
            th.result-th-default
              .result-th 등주형태
            th.result-th-default
              .result-th 보행자등
        tbody
          tr.result-body-tr(v-for="result in items" @click="rowSelected(result.light)")
            td {{result.light.SL_SLNAME}}
            td(style="text-align:center")
              img(:src="require('@/assets/img/res' + result.lightImage)" style="width:20px;height:20px;margin-right: 4px;")
            td {{result.errorName}}
            td {{code.SL_DATA_1[result.light.SL_DATA_1]}}
            td {{code.WORK_TYPE[result.light.WORK_TYPE]}}
            td {{result.light.ADDRESS_OLD}}
            td {{result.light.FILTER_STREET}}
            td {{result.light.FILTER_VILLAGE}}
            td {{result.light.POLLUTION_LIGHT}}
            //- td {{code.ESCO[result.light.ESCO]}}
            td {{code.SL_DATA_2[result.light.SL_DATA_2]}}
            td {{code.SL_DATA_5[result.light.SL_DATA_5]}}
            td {{code.POLES_DIRECTION[result.light.POLES_DIRECTION]}}
            td {{code.PED_LIGHTING[result.light.PED_LIGHTING]}}
          tr.non-result-table(v-show="items == ''")
            td(colspan=13 style="color:white") 검색된 시설물 결과가 없습니다.
    #search_page
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-left' @click="movePage('first')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-right:7px;" icon='angle-left' @click="movePage('down')")
      span.result-page(v-if="items != ''" v-for="page in getNumbers(paging[0],paging[1])" @click="pageSelect(page)" :class="pageChoice(page)") {{page}}
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-left:7px;" icon='angle-right' @click="movePage('up')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-right' @click="movePage('end')")
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
</template>

<script>
import Vue from "vue";
import { EventBus } from "@/main";
import deviceCode from "@/assets/json/deviceCode.json";
import Excel from 'exceljs'
import * as fs from 'file-saver';

export default {
  data() {
    return {
      fields: [],
      items: [],
      req: {
        SL_DATA_1: "all", // 시설물
        SL_SLNAME: "", // 표찰번호
        WORK_TYPE: "all", // 점멸기
        SL_ADDR_1: "all", // 주소1
        SL_ADDR_2: "all", // 주소2
        SL_ADDR_3: "all", // 주소3
        FILTER_STREET: "", // 필터1
        FILTER_VILLAGE: "", // 필터2
        POLLUTION_LIGHT: "all", // 빛 공해
        ESCO: "all", // ESCO
        SL_DATA_2: "all", // 전기요금
        SL_DATA_5: "all", // 등주형식
        POLES_DIRECTION: "all", // 등주형태
        PED_LIGHTING: "all", // 보행자등
        PAGE: 1
      },
      paging: [1, 1, false, false, 1],
      resultTable: false,
      loadData: false,
      code: "",
      res: {},
      conditionExtend: true,
      totalCount: 0
    };
  },
  updated() {
    $(".table-gradient").height($("#search_list .result-table").height());
  },
  computed: {
    addrSub() {
      // if (this.res[this.req.SL_ADDR_1] == null) {
      //   // return "";
      // } else {
      return this.res[this.req.SL_ADDR_1];
      // }
    }
  },
  methods: {
    classConditionExtend(value) {
      // NOTE :: 검색옵션 펼쳐보기 상태 class
      if (value == "down") {
        if (this.conditionExtend) {
          return "icon-hide";
        } else {
          return "";
        }
      } else if (value == "up") {
        if (this.conditionExtend) {
          return "";
        } else {
          return "icon-hide";
        }
      }
    },
    pageChoice(page) {
      if (page == this.req.PAGE) {
        return "result-page-choice";
      } else {
        return "";
      }
    },
    areaAction(slcode) {
      // NOTE :: Create Tooltip
      if (window.IscustomOverlay) {
        window.customOverlay.setMap(null);
      }
      this.$_API_GET("facility/tooltilp", {
        SL_SLCODE: slcode
      }).then(function(res) {
        window.makeToolTip(res);
      });
    },
    rowSelected(items) {
      // NOTE :: 리스트 row click
      // window.setCoordsFromPoint()
      // window.SetPositionLevel(items.SL_MAP_X, items.SL_MAP_Y, 1);
      var point = window.setCoordsFromPoint(
        items.SL_MAP_X,
        items.SL_MAP_Y,
        this.$store.getters.panel_location_name
      );
      console.log(
        items.SL_MAP_X,
        items.SL_MAP_Y,
        this.$store.getters.panel_location_name
      );
      console.log(point);
      window.SetPositionLevel(point.getLng(), point.getLat(), 1);
      var sl_slcode = items.SL_SLCODE;
      // setTimeout(function() {
      this.areaAction(sl_slcode);
      // }, 2000);
    },
    excelDownload() {

      const wb = new Excel.Workbook();

      const fname = '시설물목록';

      var vm = this;
      vm.loadData = true;
      this.$_API_GET("excel/facilities", {
      }).then(function(res) {
        console.log(res);

        var req = new XMLHttpRequest();
        
        req.open("GET", "/excel/template.xlsx", true);
        req.responseType = "blob";
        req.onload = function(e) {
          wb.xlsx.load(req.response).then(workbook => {
            
            var worksheet = workbook.getWorksheet('현황데이터');

            for (var i=0; i<res['light'].length; i++) {
              var rowIndex = [0];
              var row = [i+1];
              for(var j=0; j<res['light'][i].length; j++) {
                rowIndex.push(j);
                var val = res['light'][i][j];

                switch(j) {
                  case 2: // ADDR '거제시 거제시 거제시'
                    val = val.split(' ');
                    row.push(val[0]);
                    row.push(val[1]);
                    rowIndex.push(j);
                    continue;
                  case 10: case 13: // 10-addr_new/old 13-street/village
                    j++;
                    if(val == null || val.trim() == '') {
                      val = res['light'][i][j];
                    }
                    break;
                  case 32:
                    j++;
                    if(val != null && res['light'][i][j] != null) {
                      val = val + ', ' + res['light'][i][j];
                    }
                }
                
                if(val == null) {
                  row.push('');
                  continue;
                }

                switch(j) {
                  case 0: val = vm.code["SL_DATA_1"][val]; break;
                  case 5: val = vm.code["SL_DATA_2"][val]; break;
                  case 12: val = val.split('T')[0]; break;
                  case 15: val = vm.code["SL_DATA_5"][val]; break;
                  case 31: val = vm.code["WORK_TYPE"][val]; break;
                }

                if(val == null || val == undefined) {
                  val = '';
                }

                row.push(val);
              }
              worksheet.addRow(row, 'i');
            };
            // worksheet.addRow(rowIndex, 'i'); // for debug

            worksheet.spliceRows(4,3);

            workbook.xlsx.writeBuffer().then((data) => {
              let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
              fs.saveAs(blob, fname+'-'+new Date().valueOf()+'.xlsx');
              
              vm.loadData = false;
              
            });
          });
        }
        req.send();

      }).catch(err => {
        vm.loadData = false;
      });

    },
    searchLight() {
      this.loadData = true;
      console.log(this.req);
      this.req.PAGE = 1;
      this.getPcfacilityAPI(this.req);
    },
    firstSearchLight() {
      this.loadData = true;
      console.log(this.req);
      this.GetFacilityInfoAPI();
    },
    GetFacilityInfoAPI() {
      // NOTE :: 주소 데이터
      var vm = this;
      this.$_API_GET("postcode", {}, 24 * 7)
        .then(function(res) {
          console.log("GetFacilityInfoAPI", res);
          for (var key in res) {
            for (var value in res[key]) {
              if (key != "SIDOSGG_CD") {
                vm.res[key.split(":")[0]] = value.split(":")[0];
              }
            }
          }
          console.log("vm.res", vm.res);
        })
        .then(() => {
          vm.$forceUpdate();
          vm.getPcfacilityAPI(vm.req);
        })
        .catch(function() {
          vm.$emit(
            "onAlert",
            "black",
            null,
            "주소 가져오기 실패",
            null,
            null,
            true,
            false
          );
        });
    },
    pageSelect(page) {
      this.loadData = true;
      this.req.PAGE = page;
      this.getPcfacilityAPI(this.req);
    },
    movePage(check) {
      if (check == "down") {
        if (this.paging[2]) {
          this.req.PAGE = this.paging[0] - 5 > 0 ? this.paging[0] - 5 : 1;
        }
      } else if (check == "up") {
        if (this.paging[3]) {
          this.req.PAGE = this.paging[0] + 5;
        }
      } else if (check == "first") {
        this.req.PAGE = 1;
      } else if (check == "end") {
        this.req.PAGE = this.paging[4];
      }
      this.getPcfacilityAPI(this.req);
    },
    getPcfacilityAPI(data, path) {
      // NOTE :: 시설물 리스트
      // console.log("path", path);
      var vm = this;
      this.$_API_GET("pcfacility", data).then(function(res) {
        console.log(res);
        vm.items = [];
        window.asdasdasd = res;
        if (res.total_count == 0) {
          vm.resultTable = true;
          vm.totalCount = 0;
        } else {
          vm.items = [];
          for (var value in res.content) {
            if (value != "contains") {
              if (
                Object.keys(res.content[value].special).length &&
                Object.keys(res.content[value].status).length
              ) {
                res.content[value].status["SL_DATA_1"] =
                  res.content[value].light.SL_DATA_1;
                res.content[value].errorName = GetLightErrorName(
                  res.content[value].status,
                  res.content[value].special
                ).replace(/\(|\)/g, "");
                var lightImage1 = GetLightImagePath2(
                  res.content[value].status,
                  res.content[value].special
                ).split(".")[0];
                var lightImage2 = GetLightImagePath2(
                  res.content[value].status,
                  res.content[value].special
                ).split(".")[2];
                res.content[value].lightImage = lightImage1 + "." + lightImage2;
              } else {
                if (res.content[value].light.SL_DATA_1 == 0) {
                  res.content[value].lightImage = "/img/pin6.png";
                } else if (res.content[value].light.SL_DATA_1 == 1) {
                  res.content[value].lightImage = "/img/pin0.png";
                } else if (
                  res.content[value].light.SL_DATA_1 == 4 ||
                  res.content[value].light.SL_DATA_1 == 8 ||
                  res.content[value].light.SL_DATA_1 == 9 ||
                  res.content[value].light.SL_DATA_1 == 10
                ) {
                  res.content[value].lightImage = "/img/pin4.png";
                } else {
                  res.content[value].lightImage = "/img/pin0.png";
                }
                res.content[value].errorName = "";
              }

              vm.items.push(res.content[value]);
            }
          }
          vm.paging = res.paging;
          $("#search_page").css("display", "flex");
          console.log(vm.items);
          vm.resultTable = true;
          vm.totalCount = res["total_count"];
        }
        vm.loadData = false;
      });
    },
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      this.req[type] = data;
      $("#search_list .dropdown__header").removeClass("is-active");
      if (type == "SL_ADDR_1") {
        this.req.SL_ADDR_2 = "all";
      }
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    getDataCode() {
      // NOTE :: DataCode 가져오기
      var vm = this;
      this.$_API_GET("datacode", undefined, 1)
        .then(function(res) {
          datacode = {};
          res.forEach(function(value) {
            if (!(value.SL_GRP in datacode)) {
              datacode[value.SL_GRP] = [value];
            } else {
              datacode[value.SL_GRP].push(value);
            }
          });
          var TYPES_IDS = [0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
          // 시설물 종류
          datacode["D1"].forEach(function(val) {
            if ($.inArray(val.SL_VALUE, TYPES_IDS) >= 0) {
              if (
                $.inArray(val.SL_VALUE, [
                  TYPE_BOX_DISTRIBUTION_SUB_MODULE_A,
                  TYPE_BOX_DISTRIBUTION_SUB_MODULE_B
                ]) >= 0
              ) {
                // $('#light_type').append('<option value=' + val.SL_VALUE + ' style="display: none;">' + val.SL_DESC + '</option>');
              } else {
                // $('#light_type').append('<option value=' + val.SL_VALUE + '>' + val.SL_DESC + '</option>');
                vm.code["SL_DATA_1"][val.SL_VALUE] = val.SL_DESC;
              }
            }
          });
          // 요금형태
          datacode["D2"].forEach(function(val) {
            vm.code["SL_DATA_2"][val.SL_VALUE] = val.SL_DESC;
          });
          // 등기구 형태
          datacode["D5"].forEach(function(val) {
            vm.code["SL_DATA_5"][val.SL_VALUE] = val.SL_DESC;
          });
          // 운영방식
          datacode["D8"].sort(function(a, b) {
            return a.SL_VALUE > b.SL_VALUE;
          });
          datacode["D8"].forEach(function(val) {
            vm.code["WORK_TYPE"][val.SL_VALUE] = val.SL_DESC;
          });
          // 램프종류
          datacode["D6"].forEach(function(val) {
            vm.code["LF_LAMP"][val.SL_VALUE] = val.SL_DESC;
          });
          // 소비전력
          datacode["D7"].forEach(function(val) {
            vm.code["LF_POWER"][val.SL_VALUE] = val.SL_DESC;
          });
        })
        .then(() => {
          vm.$forceUpdate();
        })
        .catch(function() {
          vm.$refs.alert.init(
            "black",
            null,
            "데이터 코드 가져오기 실패",
            null,
            null,
            true,
            false
          );
        });
    }
  },
  created() {},

  mounted() {
    this.firstSearchLight();
    this.$store.commit("panel_size", 900);

    var vm = this;
    EventBus.$on("getPcfacilityAPI", function(data, path) {
      vm.loadData = true;
      console.log("data", data, "/ path", path);
      if (path) {
        vm.req.SL_SLNAME = data;
        vm.req.SL_ADDR_1 = "all";
      } else {
        vm.req.SL_SLNAME = "";
        vm.req.SL_ADDR_1 = data;
      }
      vm.getPcfacilityAPI(vm.req, path);
    });
    this.code = JSON.parse(JSON.stringify(deviceCode));
    this.getDataCode();

    Vue.nextTick(function() {
      $("#search_list .item-td").focusout(function(e) {
        $("#search_list .dropdown__header").removeClass("is-active");
      });
      $("#search_list .result-table").on("mousewheel DOMMouseScroll", function(
        e
      ) {
        var E = e.originalEvent;
        var delta = 0;
        if (E.detail) {
          delta = E.detail * -40;
        } else {
          delta = E.wheelDelta;
        }
        if (delta > 0) {
          $("#search_list #search_result").animate({ scrollLeft: "-=30" }, 0);
        } else {
          $("#search_list #search_result").animate({ scrollLeft: "+=30" }, 0);
        }
      });
      $(".vp-device-search .slname-input").focus();
    });
  },
  beforeDestroy() {
    EventBus.$off("getPcfacilityAPI");
  }
};
</script>

<style>
#search_list #search_condition {
  white-space: nowrap;
}
#search_list #search_condition.result-area {
  margin-left: 16px;
  width: calc(100% - 32px);
  display: flex;
  flex-direction: column;
}
#search_list {
  width: 100%;
  height: auto;
  display: flex;
  flex-direction: column;
}
#search_list tr td,
#search_list tr th {
  font-size: 12px;
}
.item-select {
  border: unset;
  height: 85%;
  width: 99%;
  padding-left: 10px;
  background: url("../../assets/img/res/img/sidebar-search-arrow.png") no-repeat
    right #fff;
  -webkit-appearance: none;
  -moz-appearance: none;
}
.td-input {
  width: 99%;
  padding: 0px;
}
#search_list .item-td,
#search_list .item-th {
  padding: 0px;
  /* border: 0.1px solid lightgray; */
  line-height: 27px;
}
#search_list .item-th {
  text-align: right;
  min-width: 70px;
  flex: 1;
  margin-right: 11px;
}
#search_list .item-td {
  display: flex;
  align-items: center;
  width: 0px;
  flex: 3;
  height: 25px;
}
#search_list .condition-input {
  padding: 0px 0px 0px 10px;
  width: 99%;
  height: 96%;
}

.parent-table {
  border: unset;
  display: flex;
  flex-wrap: wrap;
  margin-top: 14px;
}
#search_list .group-condition {
  display: flex;
  height: 25px;
  width: 100%;
  flex: 1;
}
#search_list .search-btn {
  width: calc(100% - 32px);
  background-color: #424242;
  border-radius: 5px;
  color: white;
  height: 22px;
  font-size: 12px;
  border: 1px solid rgba(188, 188, 188, 0.1);
  margin-left: 16px;
  margin-top: 11px;
  margin-bottom: 11px;
  outline: none;
  width: 124px;
  float: right;
  margin-right: 17px;
}
.blank-th {
  background-color: unset;
  border: 0px;
}

#search-table {
  white-space: nowrap;
}
#search-table tr td,
#search-table tr th {
  font-size: 12px;
}
#search_result {
  height: auto;
  width: 100%;
  overflow: auto;
}
#search_result .table-gradient {
  pointer-events: none;
  position: absolute;
  width: 100%;
}
.table-primary td {
  border-color: rgba(195, 195, 195, 0.3);
}
.table-primary {
  background-color: unset;
}
#repair_search_page,
#inspection_search_page,
#search_page {
  display: none;
  text-align: center;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  margin-top: 30px;
  margin-bottom: 27px;
}
#search_list #table-all {
  position: relative;
  margin-right: 16px;
}
.result-th {
  background-color: #2c2c2c;
  color: #fff;
  border-top: 1.4px solid #3b3b3b;
  border-bottom: 1.4px solid #3b3b3b;
  border-right: 1.4px solid #3b3b3b;
  text-align: center;
  padding: 6px 6px 6px 10px;
}
.result-body-tr:hover {
  background-color: #484848;
}
.result-body-tr {
  cursor: pointer;
}
.result-body-tr td {
  color: #fff;
}
.result-table thead tr th:first-child .result-th {
  border-left: 1.4px solid #3b3b3b;
  border-top-left-radius: 10px;
}
.result-table thead tr th:last-child .result-th {
  border-top-right-radius: 10px;
}
.result-th-default {
  padding: 0px;
}
.result-page {
  display: inline-block;
  text-align: center;
  color: white;
  font-size: 14px;
  margin: 0px 3px 0px 3px;
}
.result-page-choice {
  color: #00a0ea;
}
#search_page > * {
  vertical-align: middle;
  cursor: pointer;
}

#search_list td input {
  background-color: #2c2c2c;
  color: #fff;
  font-size: 12px;
  border-radius: 5px;
  height: 20px;
  width: 100%;
  float: right;
  padding-left: 7px;
  padding-right: 7px;
}
</style>

<style>
#search_list #search_condition #table-all th.item-th {
  color: #fff;
  line-height: 22px;
}
#search_list .condition-extend-div .icon-hide {
  display: none;
}
#search_list .condition-extend {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: flex-end;
  padding-right: 5px;
  color: #9f9f9f;
}
#search_list .condition-extend-div {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #9f9f9f;
  margin-right: 6px;
}
#search_list .condition-extend-td {
  justify-content: flex-end;
}
#search_list .condition-extend-div > * {
  font-size: 12px;
}
#search_list .condition-extend-div i {
  margin-left: 9px;
  font-size: 17px;
}

#search_list .non-result-table {
  text-align: center;
}
#search_list .table-total {
  color: white;
  font-size: 12px;
  position: absolute;
  left: 20px;
  line-height: 60px;
}
</style>
<style lang="scss">
// NOTE :: DropDown CSS
#search_list {
  & .dropdown {
    width: 100%;
    &__header {
      background: #2c2c2c;
      font-size: 12px;
      cursor: pointer;
      line-height: 20px;
      position: relative;
      text-overflow: ellipsis;
      color: #fff;
      width: 100%;
      height: 20px;
      border-radius: 5px;
      i.fas {
        position: absolute;
        right: 7px;
        top: 50%;
        transform: translateY(-50%);
        color: #484848;
        // transition: opacity 0.3s;
        font-size: 13px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &.is-active {
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #fff;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
        }
        + .dropdown__content.dropdown__longdata {
          max-height: 220px;
          overflow: scroll;
        }
      }
      & span {
        padding-left: 10px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #2c2c2c;
      border-radius: 5px;
      margin-top: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #fff;
          font-size: 12px;
          padding: 0px 0px 0px 7px;
          &.list-select {
            color: #00a0ea;
          }
          &:hover {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 0px 0px 3px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: rgba(125, 125, 125, 0.3);
          width: 95%;
          margin-top: 3px;
        }
      }
    }
  }
}
</style>
