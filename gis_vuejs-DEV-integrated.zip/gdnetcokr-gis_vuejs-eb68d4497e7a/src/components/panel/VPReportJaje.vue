<template lang="pug">
#search_list.table-content.vp-report-jaje
  #search_condition
    #table-all
      #table-border-radius
      table.parent-table#panel-table
        tr.group-condition
          th.item-th
            span 날짜
          td.item-td.date-picker-div
            date-range-picker(:singleDatePicker="true" :ranges="false" :startDate="startDate" :endDate="endDate" @update="updateDatepicker" :locale-data="locale" :opens="openPosition" autoApply v-model="dataRange" style="width:100%; height:100%; pointer-events:auto;" :show-dropdowns="true")
        tr.group-condition(id="blank-1" v-show="this.$store.getters.panel_size >= 438")
          th.item-th.blank-th
        tr.group-condition(id="blank-2" v-show="this.$store.getters.panel_size >= 860")
          th.item-th.blank-th
        tr.group-condition(id="blank-3" v-show="this.$store.getters.panel_size >= 860")
          th.item-th.blank-th
        tr.group-condition(id="blank-4" v-show="this.$store.getters.panel_size >= 1000")
          th.item-th.blank-th
    .filter-footer
      button.search-btn(@click="searchJajeList" style="margin-left:10px") 검색
      button.search-btn(@click="downloadJajeList" style="margin-right:0px") 인쇄
      span.table-total 총 검색 결과 : {{totalCount}} 개
  #search_condition.result-area(style="height:100%" v-show="resultTable")
    #search_result
      table.result-table
        thead
          tr
            th.result-th-default
              .result-th 자재명
            th.result-th-default
              .result-th 단위
            th.result-th-default
              .result-th 입고수량
            th.result-th-default
              .result-th 출고수량
            th.result-th-default
              .result-th 재고
        tbody
          tr.result-body-tr(v-for="result in items" style="cursor:auto")
            td.td-center(@click="") {{result.SL_JJ_NAME}}
            td.td-center(@click="") {{result.SL_JJ_UNIT}}
            td.td-center(@click="") {{result.SL_JJ_IN}}
            td.td-center(@click="") {{result.SL_JJ_OUT}}
            td.td-center(@click="") {{result.SL_JJ_TOTAL}}
          tr.non-result-table(v-show="items == ''")
            td(colspan=5 style="color:white") 검색된 결과가 없습니다.
    #search_page
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-left' @click="movePage('first')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-right:7px;" icon='angle-left' @click="movePage('down')")
      span.result-page(v-if="items != ''" v-for="page in getNumbers(paging[0],paging[1])" @click="pageSelect(page)" :class="pageChoice(page)") {{page}}
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-left:7px;" icon='angle-right' @click="movePage('up')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-right' @click="movePage('end')")
  vm-alert(ref="alert" @event="alertEvent")
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
  transition(name='modal' v-if="retry")
    .modal-background
      .modal-position
        | 일시적으로 데이터를 불러오지 못했습니다
        br
        | 다시 시도해주세요
        br
        button.spinner-btn(@click="searchJajeList") 다시 시도
</template>

<script>
import { EventBus } from "@/main";
import Vue from "vue";
import DateRangePicker from "vue2-daterange-picker";
import complainCode from "@/assets/json/complainCode.json";
import jajeCode from "@/assets/json/jajeCode.json";

export default {
  components: { DateRangePicker },
  data() {
    return {
      items: [],
      parentEl: "#content",
      req: {
        SL_DATE_START: new Date(),
        SL_DATE_END: new Date(),
        PAGE: 1
      },
      jajeCode: {},
      paging: [1, 1, false, false, 1],
      dataRange: {
        startDate: new Date(),
        endDate: new Date()
      },
      startDate: new Date(),
      endDate: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        All: [this.moment("1970-01-01"), this.moment()],
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      resultTable: false,
      loadData: false,
      code: {},
      modifyAuth: false,
      retry: false,
      totalCount: 0
    };
  },
  updated() {},
  watch: {},
  computed: {
    openPosition() {
      if (this.$store.getters.panel_location_name == "right") {
        return "left";
      } else {
        return "right";
      }
    }
  },
  methods: {
    dataValueCheck(data, value) {
      return data == undefined ? "" : data[value];
    },
    pageChoice(page) {
      if (page == this.req.PAGE) {
        return "result-page-choice";
      } else {
        return "";
      }
    },
    pageSelect(page) {
      this.req.PAGE = page;
      this.searchJajeList();
    },
    movePage(check) {
      if (check == "down") {
        if (this.paging[2]) {
          this.req.PAGE = this.paging[0] - 5 > 0 ? this.paging[0] - 5 : 1;
        }
      } else if (check == "up") {
        if (this.paging[3]) {
          this.req.PAGE = this.paging[0] + 5;
        }
      } else if (check == "first") {
        this.req.PAGE = 1;
      } else if (check == "end") {
        this.req.PAGE = this.paging[4];
      }
      this.searchJajeList();
    },
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    rowSelected(items) {},
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    complainDateFormatter(date) {
      return date.substring(0, 16).replace("T", " ");
    },
    jajeDateFormatter(date) {
      return date.substring(0, 10);
    },
    updateDatepicker(value) {},
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      this.req[type] = data;
      $(".vp-report-jaje .dropdown__header").removeClass("is-active");
    },
    dropdownChoice(value, choice) {
      if (value.toString().split(":")[0] == choice.toString().split(":")[0]) {
        return "list-select";
      } else {
        return "";
      }
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        if (
          res.grade.substring(0, 1) == "S" ||
          res.grade.substring(0, 1) == "A" ||
          res.grade.substring(0, 1) == "B"
        ) {
          vm.modifyAuth = true;
        } else {
          vm.modifyAuth = false;
        }
      });
    },
    checkAuth(type, position) {
      if (this.modifyAuth) {
        if (type == "INPROGRESS") {
          if (position == "right") {
            return "non-auth";
          } else {
            return "";
          }
        } else {
          return "";
        }
      } else {
        if (type == "READY") {
          if (position == "left") {
            return "non-auth";
          } else if (position == "center") {
            return "non-auth";
          }
        } else if (type == "INPROGRESS") {
          if (position == "left") {
            return "non-auth";
          } else if (position == "center") {
            return "non-auth";
          }
          return "maintenance-inprogress";
        } else if (type == "DONE") {
          if (position == "left") {
            return "non-auth";
          }
        }
      }
    },
    alertEvent() {},
    openComplain(data) {
      EventBus.$emit("modalOpen", data, "VMComplainInfo");
      Vue.nextTick(function() {
        EventBus.$emit(data + "setComplainInfo", data);
      });
    },
    searchJajeList() {
      // NOTE :: 자재 리스트
      this.req.SL_DATE_START = this.moment(this.dataRange.startDate).format(
        "YYYY-MM-DD"
      );
      // this.req.SL_DATE_START.setDate(this.req.SL_DATE_START.getDate() + 1);
      this.req.SL_DATE_END = this.moment(this.dataRange.endDate).format(
        "YYYY-MM-DD"
      );
      var vm = this;
      return this.$_API_GET("jaje/report/list", this.req)
        .then(function(res) {
          console.log("report jaje List", res);
          vm.items = [];
          if (res.data.length == 0) {
            vm.loadData = false;
            vm.resultTable = true;
            vm.totalCount = 0;
          } else {
            for (var value in res.data) {
              if (value != "contains") {
                vm.items.push(res.data[value]);
              }
            }
            // vm.paging = res.paging;
            $("#search_page").css("display", "flex");
            vm.resultTable = true;
            vm.loadData = false;
            vm.totalCount = res["total_count"];
            vm.paging = res.paging;
          }
        })
        .catch(() => {
          vm.loadData = false;
          vm.retry = true;
        });
    },
    async downloadJajeList() {
      // NOTE :: 자재 Report Download
      var vm = this;
      var AWS = require("aws-sdk");
      var Excel = require("exceljs");

      async function loadWorkbook(stream, res) {
        const wb = new Excel.Workbook();
        const reader = new FileReader();

        reader.readAsArrayBuffer(new Blob([new Uint8Array(stream.Body)]));
        reader.onload = () => {
          const buffer = reader.result;
          wb.xlsx.load(buffer).then(workbook => {
            var sheet = wb.getWorksheet("가로등 자재 수불대장");
            sheet.getCell("A7").value =
              "출력일자 : " +
              vm.moment(vm.dataRange.startDate).format("YYYY년 MM월 DD일");
            var data = 0;
            for (var val in res.data) {
              data++;
              sheet.duplicateRow(9 + Number(data), 1, true);
              ["AD", "FG", "IK", "LM", "NO"].forEach(function(col) {
                for (var i = 0; i < 3; i++) {
                  sheet.unMergeCells(
                    `${col.substring(0, 1) + (10 + Number(data) + i)}`
                  );
                  sheet.mergeCells(
                    `${col.substring(0, 1) +
                      (10 + Number(data) + i)}:${col.substring(2, 1) +
                      (10 + Number(data) + i)}`
                  );
                }
              });
              sheet.getCell(`A${9 + Number(data)}`).value =
                res.data[val].SL_JJ_NAME;
              sheet.getCell(`E${9 + Number(data)}`).value =
                res.data[val].SL_JJ_UNIT;
              var residual =
                res.data[val].SL_JJ_TOTAL -
                res.data[val].SL_JJ_IN +
                res.data[val].SL_JJ_OUT;
              sheet.getCell(`F${9 + Number(data)}`).value =
                res.data[val].SL_JJ_IN + residual;
              sheet.getCell(`H${9 + Number(data)}`).value = residual;
              sheet.getCell(`I${9 + Number(data)}`).value =
                res.data[val].SL_JJ_IN;
              sheet.getCell(`L${9 + Number(data)}`).value =
                res.data[val].SL_JJ_OUT;
              sheet.getCell(`N${9 + Number(data)}`).value =
                res.data[val].SL_JJ_TOTAL;
              sheet.getCell(`O${9 + Number(data)}`).border = {
                left: { style: "thin", color: { argb: "FF000000" } },
                right: { style: "thin", color: { argb: "FF000000" } },
                bottom: { style: "thin", color: { argb: "FF000000" } }
              };
            }
            wb.xlsx.writeBuffer().then(function(data) {
              const blob = new Blob([data], {
                type:
                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              });
              const url = window.URL.createObjectURL(blob);
              const anchor = document.createElement("a");
              anchor.href = url;
              anchor.download = "가로등 자재 수불대장.xls";
              anchor.click();
              window.URL.revokeObjectURL(url);
              vm.loadData = false;
            });
          });
        };

        return true;
      }
      async function downloadFile(res) {
        AWS.config.update({
          accessKeyId: "AKIASAFPO2VRVQE266OA",
          secretAccessKey: "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"
        });

        var params = {
          Bucket: "structureimage",
          Key: "jajeTemplate.xlsx"
        };
        window.s3 = new AWS.S3({
          apiVersion: "2006-03-01",
          region: "ap-northeast-2"
        });
        var s3Data = s3.getObject(params, async function(err, data) {
          if (err) {
            console.log("err", err);
          } else {
            console.log("data", data);
            loadWorkbook(data, res);
            return data;
          }
        });
        return s3Data;
      }
      this.req.SL_DATE_START = this.moment(this.dataRange.startDate).format(
        "YYYY-MM-DD"
      );
      this.loadData = true;
      this.$_API_GET("jaje/report", this.req)
        .then(function(res) {
          downloadFile(res);
        })
        .catch(() => {
          vm.loadData = false;
          vm.retry = true;
        });
    }
  },
  mounted() {
    var vm = this;
    this.code = JSON.parse(JSON.stringify(complainCode));
    this.jajeCode = JSON.parse(JSON.stringify(jajeCode));
    this.jajeCode["postcode"] = postcode;
    this.$store.commit("panel_size", 800);
    this.searchJajeList();
    this.getPcauthAPI();

    Vue.nextTick(function() {
      $(".vp-report-jaje .item-td").focusout(function(e) {
        $(".vp-report-jaje .dropdown__header").removeClass("is-active");
      });
      $(".vp-report-jaje .result-table").on(
        "mousewheel DOMMouseScroll",
        function(e) {
          var E = e.originalEvent;
          var delta = 0;
          if (E.detail) {
            delta = E.detail * -40;
          } else {
            delta = E.wheelDelta;
          }
          if (delta > 0) {
            $(".vp-report-jaje #search_result").animate(
              { scrollLeft: "-=30" },
              0
            );
          } else {
            $(".vp-report-jaje #search_result").animate(
              { scrollLeft: "+=30" },
              0
            );
          }
        }
      );
      $(".vp-report-jaje .slname-input").focus();
    });
  },
  beforeDestroy() {}
};
</script>

<style>
.rm-white-space {
  white-space: normal;
}
.show-calendar {
  display: block;
}

th.month {
  color: black;
}
.item-td .form-control {
  padding: 0px 0px 0px 4px;
  border: 0px;
}

.item-td .form-control * {
  font-size: 12px;
}

.non-auth {
  display: none;
}
.vp-report-jaje .jaje-button {
  border-radius: 5px;
  width: 100%;
  color: white;
  height: 100%;
  min-width: 60px;
  max-width: 60px;
  outline: none !important;
}
.jaje-search-compain {
  background-color: rgb(1, 106, 174);
  border: 1px solid rgb(1, 106, 174);
}
.jaje-search-compain:hover {
  border: 1px solid rgb(1, 106, 174);
  background-color: white;
  color: black;
}
.jaje-out {
  background-color: rgb(243, 126, 0);
  border: 1px solid rgb(243, 126, 0);
}
.jaje-out:hover {
  border: 1px solid rgb(243, 126, 0);
  background-color: white;
  color: black;
}
.jaje-del {
  background-color: #707070;
  border: 1px solid #707070;
}
.jaje-del:hover {
  border: 1px solid #707070;
  background-color: white;
  color: black;
}

.vp-report-jaje .vue-daterange-picker {
  height: 21px;
  width: 75%;
}
.vp-report-jaje .form-control {
  background-color: #2c2c2c;
  height: 20px;
  line-height: 16px;
  color: #fff;
  cursor: pointer;
}
.vp-report-jaje .vue-daterange-picker .reportrange-text {
  height: 22px;
  width: 100%;
  border: unset;
  background-color: #101010;
  padding: 0px;
  display: flex;
  align-items: center;
}
.vp-report-jaje .form-control span {
  width: 100%;
  text-align: left;
  margin-left: -4px;
}
.vp-report-jaje .date-picker-div > div {
  top: 2px;
}
.vp-report-jaje table tbody tr td.table-cmd-button {
  display: flex;
  justify-content: center;
  padding: 4px;
}
/* .vp-report-jaje table tbody tr td.table-cmd-button button:not(:last-child) {
  margin-right: 7px;
} */
.vp-report-jaje table tbody tr td.table-cmd-button button:first-child {
  margin-right: 0px;
}
.vp-report-jaje table tbody tr td.table-cmd-button button:nth-child(2) {
  margin-right: 7px;
}
.vp-report-jaje .panel-complain-list {
  position: absolute;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  color: #000 !important;
  top: 41%;
  left: 50%;
  transform: translateX(-50%);
  min-width: 322px;
}
.vp-report-jaje .alert-delete-red {
  color: red;
}
.vp-report-jaje .td-center {
  text-align: center;
  padding-left: 6px;
}
.vp-report-jaje .table-total {
  color: white;
  font-size: 12px;
  position: absolute;
  left: 20px;
  line-height: 60px;
}
.vp-report-jaje #search_result {
  /* height: calc(100vh - 110px); */
}
.vp-report-jaje .modal-icon {
  display: none;
}
.vp-report-jaje .modal-exit {
  padding-top: 10px;
}
.vp-report-jaje .transition-btn {
  padding-top: 3px;
}
</style>

<style lang="scss">
.vp-report-jaje .jaje-table {
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    & * {
      font-size: 12px;
    }
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.modify-light-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100% !important;
          background: white !important;
          color: black !important;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray !important;
        }
        & input.modify-disabled[type="Number"]:disabled {
          background: lightgray !important;
        }
        & input:focus {
          outline: #418fff auto 1px !important;
          outline-offset: -2px;
        }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0px;
      -webkit-border-radius: 10px 0 0 0px;
      border-radius: 10px 0 0 0px;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0px 0;
      -webkit-border-radius: 0 10px 0px 0;
      border-radius: 0 10px 0px 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>
