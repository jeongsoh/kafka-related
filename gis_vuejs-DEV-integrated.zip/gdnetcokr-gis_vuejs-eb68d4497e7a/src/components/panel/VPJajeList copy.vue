<template lang="pug">
#search_list.table-content.vp-jaje-list
  #search_condition
    #table-all
      #table-border-radius
      table.parent-table#panel-table
        tr.group-condition
          th.item-th
            span 민원접수일
          td.item-td.date-picker-div
            date-range-picker(:ranges="ranges" :startDate="startDate" :endDate="endDate" @update="updateDatepicker" :locale-data="locale" :opens="openPosition" autoApply v-model="dataRange" style="width:100%; height:100%; pointer-events:auto;" :show-dropdowns="true")
        tr.group-condition
          th.item-th
            span 표찰번호
          td.item-td.td-input
            input.slname-input(v-model="req.SL_SLNAME")
        tr.group-condition
          th.item-th
            span 처리상태
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_NTRES[req.SL_NTRES]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_NTRES', 'all')" :class="dropdownChoice('전체', code.SL_NTRES[req.SL_NTRES])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_NTRES', key)" v-for="value, key in code.SL_NTRES"  :class="dropdownChoice(value, code.SL_NTRES[req.SL_NTRES])") {{value}}
                    .search-division-line            
        tr.group-condition
          th.item-th
            span 표찰 상태
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_STATUS[req.SL_STATUS]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_STATUS', 'all')"  :class="dropdownChoice('전체', code.SL_STATUS[req.SL_STATUS])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_STATUS', key)" v-for="value, key in code.SL_STATUS" :class="dropdownChoice(value, code.SL_STATUS[req.SL_STATUS])") {{value}}
                    .search-division-line               
        //- tr.group-condition
        //-   th.item-th
        //-     span 회신 방법
        //-   td.item-td(tabindex="-1")
        //-     .dropdown
        //-       .dropdown__header(@click="toggleDropdown($event)")
        //-         span {{code.SL_REPLY[req.SL_REPLY]}}
        //-         i.fas.fa-chevron-down
        //-         i.fas.fa-chevron-up
        //-       .dropdown__content
        //-         ul
        //-           li(@click="clickDropDown('SL_REPLY', 'all')"  :class="dropdownChoice('전체', code.SL_REPLY[req.SL_REPLY])") 전체
        //-             .search-division-line
        //-           li(v-if="key != 'all'" @click="clickDropDown('SL_REPLY', key)" v-for="value, key in code.SL_REPLY" :class="dropdownChoice(value, code.SL_REPLY[req.SL_REPLY])") {{value}}
        //-             .search-division-line               
        tr.group-condition
          th.item-th
            span 신고 내용
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{code.SL_CONTENT[req.SL_CONTENT]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_CONTENT', 'all')" :class="dropdownChoice('전체', code.SL_CONTENT[req.SL_CONTENT])") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_CONTENT', key)" v-for="value, key in code.SL_CONTENT" :class="dropdownChoice(value, code.SL_CONTENT[req.SL_CONTENT])") {{value}}
                    .search-division-line              
        tr.group-condition(id="blank-1" v-show="this.$store.getters.panel_size >= 438")
          th.item-th.blank-th
        tr.group-condition(id="blank-2" v-show="this.$store.getters.panel_size >= 860")
          th.item-th.blank-th
        tr.group-condition(id="blank-3" v-show="this.$store.getters.panel_size >= 860")
          th.item-th.blank-th
        tr.group-condition(id="blank-4" v-show="this.$store.getters.panel_size >= 1000")
          th.item-th.blank-th
    .filter-footer
      button.search-btn(@click="searchComplaint") 검색
      span.table-total 총 검색 결과 : {{totalCount}} 개
    //- b-table#search-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
  #search_condition.result-area(style="height:100%" v-show="resultTable")
    #search_result
      //- b-table#search-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
      table.result-table
        thead
          tr
            th.result-th-default
              .result-th 접수 일자
            th.result-th-default
              .result-th 표찰번호
            th.result-th-default
              .result-th 주소
            th.result-th-default
              .result-th 처리 상태
            th.result-th-default
              .result-th 작업 명령
            th.result-th-default
              .result-th 표찰 상태
            //- th.result-th-default
            //-   .result-th 회신 방법
            th.result-th-default
              .result-th 신고 내용
        tbody
          tr.result-body-tr(v-for="result in items")
            td(@click="rowSelected(result)") {{complainDateFormatter(result.SL_NTDATE)}}
            td(@click="rowSelected(result)") {{result.SL_SLNAME}}
            td(@click="rowSelected(result)") {{result.SL_USR_ADDR}}
            td.td-center(@click="rowSelected(result)") {{code.SL_MAINTENANCE[result.SL_MAINTENANCE]}}
            td.table-cmd-button
              button.maintenance-button(@click="complainMaintenance(result, 'left')" :class="[maintenance(result.SL_MAINTENANCE), checkAuth(result.SL_MAINTENANCE, 'left')]") {{code.SL_MAINTENANCE_1[result.SL_MAINTENANCE]}}
              button.maintenance-button(@click="complainMaintenance(result, 'center')" :class="[maintenance(result.SL_MAINTENANCE), checkAuth(result.SL_MAINTENANCE, 'center')]") {{code.SL_MAINTENANCE_2[result.SL_MAINTENANCE]}}
              button.maintenance-button(@click="complainMaintenance(result, 'right')" :class="[maintenance(result.SL_MAINTENANCE), checkAuth(result.SL_MAINTENANCE, 'right')]" v-if="result.SL_MAINTENANCE == 'INPROGRESS'") 작업 처리
            td.td-center(@click="rowSelected(result)") {{code.SL_STATUS[result.SL_STATUS]}}
            //- td(@click="rowSelected(result)") {{code.SL_REPLY[result.SL_REPLY]}}
            td(@click="rowSelected(result)") {{result.SL_CONTENT}}
          tr.non-result-table(v-show="items == ''")
            td(colspan=7 style="color:white") 검색된 민원 결과가 없습니다.
    #search_page
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-left' @click="movePage('first')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-right:7px;" icon='angle-left' @click="movePage('down')")
      span.result-page(v-if="items != ''" v-for="page in getNumbers(paging[0],paging[1])" @click="pageSelect(page)" :class="pageChoice(page)") {{page}}
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-left:7px;" icon='angle-right' @click="movePage('up')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-right' @click="movePage('end')")
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
  transition(name='modal' v-if="retry")
    .modal-background
      .modal-position
        | 일시적으로 데이터를 불러오지 못했습니다
        br
        | 다시 시도해주세요
        br
        button.spinner-btn(@click="searchComplaint") 다시 시도
  transition(name='modal' v-if="directionDelete")
    .modal-background
      .modal-position.panel-complain-list
        //- span [ 
        //- span.alert-delete-red(v-if="modalData.SL_SLNAME != ''") {{modalData.SL_SLNAME}}
        //- span.alert-delete-red(v-else) 지시 취소
        //- span  ] 작업 지시를 취소하시겠습니까?
        | 작업 지시를 취소하시겠습니까?
        br
        //- | 취소하시려면 위 괄호 안의 정보를 입력해주세요
        //- br 
        | (작업지시 내역을 취소하면 미처리 상태로 변경됩니다)
        //- br
        //- input.remove-input(v-if="modalData.SL_SLNAME != ''" type="text" v-model="removeName" :placeholder="modalData.SL_SLNAME")
        //- input.remove-input(v-else type="text" v-model="removeName" :placeholder="'지시 취소'")
        br
        button.spinner-btn.spinner-left(@click="directionDelete = false") 취소
        button.spinner-btn.spinner-right(@click="onClickDirectionRemove") 확인
</template>

<script>
import { EventBus } from "@/main";
import Vue from "vue";
import DateRangePicker from "vue2-daterange-picker";
import complainCode from "@/assets/json/complainCode.json";

export default {
  components: { DateRangePicker },
  data() {
    return {
      fields: [],
      items: [],
      parentEl: "#content",
      // NOTE :: 장훈님 오면 DB 추가사항 관련 문의하여 추가작업 필요
      req: {
        SL_NTDATE_START: new Date(), // 민원 접수일
        SL_NTDATE_END: new Date(), // 민원 접수일
        SL_SLNAME: "", // 표찰번호
        SL_NTRES: "all", // 처리상태
        SL_REPLY: "all", // 회신 방법
        SL_STATUS: "all", // 표찰 상태
        SL_CONTENT: "all", // 신고 내용
        PAGE: 1
      },
      paging: [1, 1, false, false, 1],
      dataRange: {
        startDate: new Date().setMonth(new Date().getMonth() - 1),
        endDate: new Date()
      },
      startDate: new Date().setMonth(new Date().getMonth() - 1),
      endDate: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        All: [this.moment("1970-01-01"), this.moment()],
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      resultTable: false,
      loadData: false,
      code: {},
      directionDelete: false,
      removeName: "",
      modalData: {
        SL_SLNAME: "",
        SL_USERADDR: "",
        SL_DRDATA: "",
        SL_NT_NO: ""
      },
      modifyAuth: false,
      retry: false,
      totalCount: 0
    };
  },
  updated() {},
  watch: {
    directionDelete: function(val) {
      this.removeName = "";
    }
  },
  computed: {
    openPosition() {
      if (this.$store.getters.panel_location_name == "right") {
        return "left";
      } else {
        return "right";
      }
    }
  },
  methods: {
    complainMaintenance(items, division) {
      if (
        this.code.SL_MAINTENANCE_1[items.SL_MAINTENANCE] == "지시취소" &&
        division == "left"
      ) {
        this.modalData.SL_SLNAME = items.SL_SLNAME;
        this.modalData.SL_USERADDR = items.SL_USR_ADDR;
        this.modalData.SL_DRDATA = items.SL_DRDATE;
        this.modalData.SL_NT_NO = items.SL_NT_NO;
        this.directionDelete = true;
      } else {
        console.log(items);
        EventBus.$emit("modalOpen", items.SL_NT_NO, "VMComplainHandle");
        Vue.nextTick(function() {
          EventBus.$emit(items.SL_NT_NO + "complainHandle", items, division);
        });
      }
    },
    onClickDirectionRemove() {
      var data = {
        SL_NT_NO: this.modalData.SL_NT_NO
      };
      this.postPcRemoveDirectionAPI(data);
      // if (
      //   (this.modalData.SL_SLNAME != "" &&
      //     this.removeName == this.modalData.SL_SLNAME) ||
      //   (this.modalData.SL_SLNAME == "" && this.removeName == "지시 취소")
      // ) {
      //   var data = {
      //     SL_NT_NO: this.modalData.SL_NT_NO
      //   };
      //   this.postPcRemoveDirectionAPI(data);
      // } else {
      //   this.directionDelete = false;
      //   EventBus.$emit("showAlert", true, "", [
      //     "민원의 작업 지시 일자가 맞지 않습니다"
      //   ]);
      // }
    },
    postPcRemoveDirectionAPI(data) {
      var vm = this;
      this.$_API_POST("pc/remove/direction", data).then(function(res) {
        vm.directionDelete = false;
        EventBus.$emit(data.SL_NT_NO + "setComplainInfo", data.SL_NT_NO);
        EventBus.$emit(
          "searchComplaint",
          "black",
          null,
          "작업 지시가 삭제되었습니다.",
          null,
          null,
          true,
          false
        );
      });
    },
    maintenance(type) {
      if (type == "READY") {
        return "maintenance-ready";
      } else if (type == "INPROGRESS") {
        return "maintenance-inprogress";
      } else if (type == "DONE") {
        return "maintenance-done";
      }
    },
    pageChoice(page) {
      if (page == this.req.PAGE) {
        return "result-page-choice";
      } else {
        return "";
      }
    },
    pageSelect(page) {
      this.req.PAGE = page;
      this.searchComplaint();
    },
    movePage(check) {
      if (check == "down") {
        if (this.paging[2]) {
          this.req.PAGE = this.paging[0] - 5 > 0 ? this.paging[0] - 5 : 1;
        }
      } else if (check == "up") {
        if (this.paging[3]) {
          this.req.PAGE = this.paging[0] + 5;
        }
      } else if (check == "first") {
        this.req.PAGE = 1;
      } else if (check == "end") {
        this.req.PAGE = this.paging[4];
      }
      this.searchComplaint();
    },
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    rowSelected(items) {
      console.log("items", items);
      EventBus.$emit("modalOpen", items.SL_NT_NO, "VMComplainInfo");
      Vue.nextTick(function() {
        EventBus.$emit(items.SL_NT_NO + "setComplainInfo", items.SL_NT_NO);
      });
    },
    searchComplaint(cb) {
      // this.req.PAGE = 1;
      this.retry = false;
      this.loadData = true;
      this.req.SL_NTDATE_START = this.datepickerFormatter(
        this.dataRange.startDate
      );
      this.req.SL_NTDATE_END = this.datepickerFormatter(this.dataRange.endDate);
      this.getPccomplainAPI(this.req).then(function() {
        if (cb != undefined) {
          cb();
        }
      });
    },
    getPccomplainAPI(data, path) {
      var vm = this;
      return this.$_API_GET("pccomplain", data)
        .then(function(res) {
          console.log("pccomplain", res);
          vm.items = [];
          if (res.content.length == 0) {
            vm.loadData = false;
            // EventBus.$emit("showAlert", true, "", ["검색된 결과가 없습니다"]);
            vm.resultTable = true;
            vm.totalCount = 0;
          } else {
            // res.content.sort();
            for (var value in res.content) {
              if (value != "contains") {
                vm.items.push(res.content[value]);
              }
            }
            // vm.items.sort(vm.items["SL_NTDATE"]).reverse();
            vm.paging = res.paging;
            $("#search_page").css("display", "flex");
            console.log("vm,items", vm.items);
            vm.resultTable = true;
            vm.loadData = false;
            vm.totalCount = res["total_count"];
          }
        })
        .catch(() => {
          vm.loadData = false;
          vm.retry = true;
        });
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    complainDateFormatter(date) {
      return date.substring(0, 16).replace("T", " ");
    },
    updateDatepicker(value) {},
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      this.req[type] = data;
      $(".vp-jaje-list .dropdown__header").removeClass("is-active");
      if (type == "SL_ADDR_1") {
        this.req.SL_ADDR_2 = "all";
      }
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        if (
          res.grade.substring(0, 1) == "S" ||
          res.grade.substring(0, 1) == "A" ||
          res.grade.substring(0, 1) == "B"
        ) {
          vm.modifyAuth = true;
        } else {
          vm.modifyAuth = false;
        }
      });
    },
    checkAuth(type, position) {
      if (this.modifyAuth) {
        if (type == "INPROGRESS") {
          if (position == "right") {
            return "non-auth";
          } else {
            return "";
          }
        } else {
          return "";
        }
      } else {
        if (type == "READY") {
          if (position == "left") {
            return "non-auth";
          } else if (position == "center") {
            return "non-auth";
          }
        } else if (type == "INPROGRESS") {
          if (position == "left") {
            return "non-auth";
          } else if (position == "center") {
            return "non-auth";
          }
          return "maintenance-inprogress";
        } else if (type == "DONE") {
          if (position == "left") {
            return "non-auth";
          }
        }
      }
    }
  },
  mounted() {
    var vm = this;
    this.code = JSON.parse(JSON.stringify(complainCode));
    this.$store.commit("panel_size", 800);
    this.searchComplaint();
    this.getPcauthAPI();
    EventBus.$on("getPccomplainAPI", function(data) {
      vm.getPccomplainAPI(data);
    });
    EventBus.$on("searchComplaint", function(
      alertType,
      headerTitle,
      firstText,
      secondText,
      inputPlaceHolder,
      okBtn,
      cancelBtn
    ) {
      vm.searchComplaint(function() {
        if (alertType != undefined) {
          vm.$emit(
            "onAlert",
            alertType,
            headerTitle,
            firstText,
            secondText,
            inputPlaceHolder,
            okBtn,
            cancelBtn
          );
        }
      });
    });

    Vue.nextTick(function() {
      $(".vp-jaje-list .item-td").focusout(function(e) {
        $(".vp-jaje-list .dropdown__header").removeClass("is-active");
      });
      $(".vp-jaje-list .result-table").on("mousewheel DOMMouseScroll", function(
        e
      ) {
        var E = e.originalEvent;
        var delta = 0;
        if (E.detail) {
          delta = E.detail * -40;
        } else {
          delta = E.wheelDelta;
        }
        if (delta > 0) {
          $(".vp-jaje-list #search_result").animate({ scrollLeft: "-=30" }, 0);
        } else {
          $(".vp-jaje-list #search_result").animate({ scrollLeft: "+=30" }, 0);
        }
      });
      $(".vp-jaje-list .slname-input").focus();
    });
  },
  beforeDestroy() {
    EventBus.$off("getPccomplainAPI");
    EventBus.$off("searchComplaint");
  }
};
</script>

<style>
.rm-white-space {
  white-space: normal;
}
.show-calendar {
  display: block;
}

th.month {
  color: black;
}
.vp-jaje-list .item-td .form-control {
  padding: 0px 0px 0px 4px;
  border: 0px;
}

.item-td .form-control * {
  font-size: 12px;
}

.non-auth {
  display: none;
}
.maintenance-button {
  border-radius: 5px;
  width: 100%;
  color: white;
  height: 100%;
  min-width: 68px;
  max-width: 68px;
  outline: none !important;
}
.maintenance-ready {
  background-color: rgb(1, 106, 174);
  border: 1px solid rgb(1, 106, 174);
}
.maintenance-ready:hover {
  border: 1px solid rgb(1, 106, 174);
  background-color: white;
  color: black;
}
.maintenance-inprogress {
  background-color: rgb(243, 126, 0);
  border: 1px solid rgb(243, 126, 0);
}
.maintenance-inprogress:hover {
  border: 1px solid rgb(243, 126, 0);
  background-color: white;
  color: black;
}
.maintenance-done {
  background-color: rgb(24, 122, 49);
  border: 1px solid rgb(24, 122, 49);
}
.maintenance-done:hover {
  border: 1px solid rgb(24, 122, 49);
  background-color: white;
  color: black;
}

.vp-jaje-list .vue-daterange-picker {
  height: 21px;
  width: 75%;
}
.vp-jaje-list .form-control {
  background-color: #2c2c2c;
  height: 20px;
  line-height: 16px;
  color: #fff;
  cursor: pointer;
}
.vp-jaje-list .vue-daterange-picker .reportrange-text {
  height: 22px;
  width: 100%;
  border: unset;
  background-color: #101010;
  padding: 0px;
  display: flex;
  align-items: center;
}
.vp-jaje-list .form-control span {
  width: 100%;
  text-align: left;
  margin-left: -4px;
}
.vp-jaje-list .date-picker-div > div {
  top: 2px;
}
.vp-jaje-list table tbody tr td.table-cmd-button {
  display: flex;
  justify-content: center;
  padding: 6px;
}
/* .vp-jaje-list table tbody tr td.table-cmd-button button:not(:last-child) {
  margin-right: 7px;
} */
.vp-jaje-list table tbody tr td.table-cmd-button button:first-child {
  margin-right: 7px;
}
.vp-jaje-list .panel-complain-list {
  position: absolute;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  color: #000 !important;
  top: 41%;
  left: 50%;
  transform: translateX(-50%);
  min-width: 322px;
}
.vp-jaje-list .alert-delete-red {
  color: red;
}
.vp-jaje-list .td-center {
  text-align: center;
  padding-left: 6px;
}
.vp-jaje-list .table-total {
  color: white;
  font-size: 12px;
  position: absolute;
  left: 20px;
  line-height: 60px;
}
</style>
