<template lang="pug">
#trouble_list
  #trouble_area
    //- b-table#trouble-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
    #search_result
      table.result-table
        thead
          tr
            th.result-th-default
              .result-th 날짜
            th.result-th-default
              .result-th 시간
            th.result-th-default
              .result-th 시설물
            th.result-th-default
              .result-th 상태
        tbody
          tr.result-body-tr(v-for="result in items" @click="rowSelected(result)")
            td {{result.DATE}}
            td {{result.TIME}}
            td {{result.DEVICE}}
            td {{result.STATUS}}
          tr.non-result-table(v-show="items == ''")
            td(colspan=4 style="color:white") 검색된 시설물 결과가 없습니다.
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
</template>

<script>
import { EventBus } from "@/main";
export default {
  data() {
    return {
      fields: ["날짜", "시간", "시설물", "상태"],
      items: [],
      loadData: false
    };
  },
  methods: {
    rowSelected(items) {
      var point = window.setCoordsFromPoint(
        items.SL_MAP_X,
        items.SL_MAP_Y,
        this.$store.getters.panel_location_name
      );
      window.SetPositionLevel(point.getLng(), point.getLat(), 1);
    }
  },
  mounted() {
    this.loadData = true;
    this.$store.commit("panel_size", 900);
    var vm = this;
    // NOTE :: 실시간 고장내역 리스트
    this.$_API_GET("pc/header/dashboard").then(function(res) {
      if (res.errList.length == 0) {
        // EventBus.$emit("showAlert", true, "", ["검색된 결과가 없습니다"]);
        vm.loadData = false;
        return;
      } else {
        for (var key in res.errList) {
          var item = {};
          item["DATE"] = res.errList[key].SL_NTDATE.substring(5, 10);
          item["TIME"] = res.errList[key].SL_NTDATE.substring(11, 16);
          item["DEVICE"] = res.errList[key].SL_SLNAME;
          item["STATUS"] = res.errList[key].SL_CONTENT;
          item["SL_MAP_X"] = res.errList[key].SL_MAP_X;
          item["SL_MAP_Y"] = res.errList[key].SL_MAP_Y;

          vm.items.push(item);
          console.log(vm.items);
          vm.loadData = false;
        }
      }
    });
  }
};
</script>

<style>
#trouble_list #search_result {
  height: calc(100vh - 80px);
}
#trouble-table {
  white-space: nowrap;
}

#trouble_list tr td,
#trouble_list tr th {
  font-size: 12px;
}
#trouble_list {
  height: auto;
  width: 100%;
}
.table-primary td {
  border-color: rgba(195, 195, 195, 0.3);
}
.table-primary {
  background-color: unset;
}
#trouble_area {
  white-space: nowrap;
  background-color: #3b3b3b;
  border-radius: 7px;
  margin: 5px;
  padding: 8px;
  height: 99%;
}
#trouble_list > * {
  font-size: 12px;
}

#search_result .non-result-table {
  text-align: center;
}

#trouble_list ::-webkit-scrollbar {
  width: 5px; /* 세로축 스크롤바 길이 */
  height: 0px; /* 가로축 스크롤바 길이 */
}
#trouble_list ::-webkit-scrollbar-track {
  background-color: rgba(0, 0, 0, 0);
}
#trouble_list ::-webkit-scrollbar-track-piece {
  background-color: #434343;
}
#trouble_list ::-webkit-scrollbar-thumb {
  border-radius: 8px;
  background-color: #313131;
}
#trouble_list ::-webkit-scrollbar-button {
  background-color: rgba(0, 0, 0, 0);
  width: 100%;
  height: 0px;
}
#trouble_list ::-webkit-scrollbar-button:start {
  background-color: rgba(0, 0, 0, 0); /* Top, Left 방향의 이동버튼 */
}
#trouble_list ::-webkit-scrollbar-button:end {
  background-color: rgba(0, 0, 0, 0); /* Bottom, Right 방향의 이동버튼 */
}
#trouble_list ::-webkit-scrollbar-corner {
  background-color: rgba(0, 0, 0, 0); /* 우측 하단의 코너 부분 */
}
#trouble_list ::-webkit-resizer {
  background-color: rgba(0, 0, 0, 0);
}
</style>
