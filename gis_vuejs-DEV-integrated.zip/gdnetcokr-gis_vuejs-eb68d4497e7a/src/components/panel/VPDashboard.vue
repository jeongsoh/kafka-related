<template lang="pug">
#dashboard
  .table-content
    table.parent-table#panel-table
      ul
        li(v-for="(value, index ,key) in resData" :key="index")
            tr.category(@mouseover="mouseover(index)" @mouseleave="mouseleave(index)" @click = "movePanel(index)")
              td.item
                  tr
                    .head-name(v-show="hoverFlag==true || hoverTargetIndex != index")
                      span {{heardCategory[key][0]}}
                    .head-name(v-show="hoverFlag==false && hoverTargetIndex == index", :style="hoverArrowText")
                      span {{heardCategory[key][0]}}
                  tr
                    .text-image(v-show="hoverFlag==true || hoverTargetIndex != index")
                      img.down-arrow(:src="require('@/assets/img/res/img/dashboard_arrow_.png')")
                    .text-image(v-show="hoverFlag==false && hoverTargetIndex == index")
                      img.down-arrow(:src="require('@/assets/img/res/img/dashboard_arrow_hover.png')")
                  tr
                    .text-image(v-show="hoverFlag==true || hoverTargetIndex != index")
                      img.round-graph(:src="imagePath(key)")
                      .round-graph-text {{value.percent}}%
                    .text-image(v-show="hoverFlag==false && hoverTargetIndex == index")
                      img.round-graph.hover(:src="imagePathHover(key)")
                      .round-graph-text {{value.percent}}%
                  tr
                    .text-image-arrow(v-show="hoverFlag==true || hoverTargetIndex != index")
                      img.wide-arrow(:src="require('@/assets/img/res/img/dashboard_button.png')")
                      .wide-arrow-text {{value.cnt}}
                    .text-image-arrow(v-show="hoverFlag==false && hoverTargetIndex == index")
                      img.wide-arrow(:src="require('@/assets/img/res/img/dashboard_button_selected.png')")
                      .wide-arrow-text(:style="hoverArrowText") {{value.cnt}}
            //- tr
            //-   .data
            //-     tr
            //-       .item
            //-         tr
            //-           .street 가로등
            //-         tr
            //-           .tot.street 전체 {{value.total.light}}
            //-         tr
            //-           .iot.street IoT {{value.iot.light}}
            //-     tr
            //-       .item
            //-         tr
            //-           .security 보안등
            //-         tr
            //-           .tot.security 전체 {{value.total.security}}
            //-         tr
            //-           .iot.security IoT {{value.iot.security}}
            //-     tr
            //-       .item
            //-         tr
            //-           .etc 기타
            //-         tr
            //-           .tot.etc 전체 {{value.total.etc}}
            //-         tr
            //-           .iot.etc IoT {{value.iot.etc}}
  .status-area
    .light-table-area
      .light-table-title
        span(style="padding-right:6px") 도로조명 현황
        img(:src="require('@/assets/img/res/img/dashboard-arrow.png')" style="position: absolute; height: 17px; padding-top: 4px;")
      table.light-table
        tr
          th 구분
          th 계
          th 가로등
          th 보안등
          th 기타
        tr
          td(v-for="value in ['계',lightTotal, rL.total_light_general_count+rL.total_light_led_count, rL.total_security_general_count+rL.total_security_led_count, rL.total_etc_general_count+rL.total_etc_led_count]") {{ value | currency}}
        tr
          td(v-for="value in ['일반조명',lightGeneralTotal,rL.total_light_general_count,rL.total_security_general_count,rL.total_etc_general_count]") {{ value | currency}}
        tr
          td(v-for="value in ['LED',lightLedTotal,rL.total_light_led_count,rL.total_security_led_count,rL.total_etc_led_count]") {{ value | currency}}
    .iot-table-area
      .iot-table-title
        .iot-title-left
          span(style="padding-right:6px") IoT 설치 현황
          img(:src="require('@/assets/img/res/img/dashboard-arrow.png')" style="position: absolute; height: 17px; padding-top: 4px;")
        .iot-title-right
          span(style="padding-right:13px;vertical-align:bottom;font-size:10px;color:#C6C6C6") 설치율 : {{iotPer}}%
      table.iot-table
        tr
          th 구분
          th 계
          th 가로등
          th 보안등
          th 기타
        tr
          td(v-for="value in ['계',iotTotal, rI.iot_light_general_count+rI.iot_light_led_count, rI.iot_security_general_count+rI.iot_security_led_count, rI.iot_etc_general_count+rI.iot_etc_led_count]") {{ value | currency}}
        tr
          td(v-for="value in ['일반조명',iotGeneralTotal,rI.iot_light_general_count,rI.iot_security_general_count,rI.iot_etc_general_count]") {{ value | currency}}
        tr
          td(v-for="value in ['LED',iotLedTotal,rI.iot_light_led_count,rI.iot_security_led_count,rI.iot_etc_led_count]") {{ value | currency}}
    .err-table-area
      .err-table-title
        .err-title-left
          span(style="padding-right:6px") IoT 고장현황
          img(:src="require('@/assets/img/res/img/dashboard-arrow.png')" style="position: absolute; height: 17px; padding-top: 4px;")
        .err-title-right
          span(style="padding-right:13px;vertical-align:bottom;font-size:10px;color:#C6C6C6") 고장율 : {{errPer}}%
      table.err-table
        tr
          th 구분
          th 계
          th 가로등
          th 보안등
          th 기타
        tr
          td(v-for="value in ['고장',errTotal, rE.err_light, rE.err_security, rE.err_etc]") {{ value | currency}}
    .complain-table-area
      .complain-table-title 고장민원 현황
        span(style="padding-right:6px") 
        img(:src="require('@/assets/img/res/img/dashboard-arrow.png')" style="position: absolute; height: 17px; padding-top: 4px;")
      table.complain-table
        tr
          th 고장접수
          th 작업지시
          th 미처리
          th 작업완료
          th 비고
        tr
          td(v-for="value in [comTotal, comInprogress, comReady, comDone, '총량 (+오늘)']") {{ value | currency}}
  transition(name='modal' v-if="loadData")
    .modal-background(style="display:flex; justify-content: center; align-items: center; pointer-events: auto; top:0px; left:0px; height:100%")
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
</template>

<script>
import { EventBus } from "@/main";
import Vue from "vue";
import DateRangePicker from "vue2-daterange-picker";

export default {
  components: { DateRangePicker },
  filters: {
    currency: value => {
      // NOTE :: 1000단위 쉼표 filter
      var num = /^-?[\d.]+(?:e-?\d+)?$/.test(value);
      if (!num) {
        return value;
      } else {
        return value.toFixed(0).replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1,");
      }
    }
  },
  props: {
    icon: {
      type: String
    },
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    }
  },
  data() {
    return {
      loadData: false,
      heardCategory: {
        "0": [
          "전체",
          "dashboard_status_total.png",
          "dashboard_status_total_hover.png"
        ],
        "1": [
          "정상",
          "dashboard_status_normal.png",
          "dashboard_status_normal_hover.png"
        ],
        "2": [
          "고장",
          "dashboard_status_err.png",
          "dashboard_status_err_hover.png"
        ],
        "3": [
          "민원",
          "dashboard_status_complain.png",
          "dashboard_status_complain_hover.png"
        ]
      },
      hoverArrowText: {
        color: "#fff"
      },
      hoverTargetIndex: 99,
      hoverFlag: true,
      resData: {
        total: {
          percent: 100,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        normal: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        error: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        complain: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        }
      },
      res: {
        errComplain: {
          complain_done_count: 0,
          complain_inprogress_count: 0,
          complain_ready_count: 0,
          complain_today_count: 0,
          complain_today_done_count: 0,
          complain_today_inprogress_count: 0,
          complain_today_ready_count: 0,
          complain_total_count: 0
        },
        errLight: {
          err_etc: 0,
          err_light: 0,
          err_security: 0
        },
        iot: {
          iot_etc_general_count: 0,
          iot_etc_led_count: 0,
          iot_light_general_count: 0,
          iot_light_led_count: 0,
          iot_security_general_count: 0,
          iot_security_led_count: 0
        },
        light: {
          total_etc_general_count: 0,
          total_etc_led_count: 0,
          total_light_general_count: 0,
          total_light_led_count: 0,
          total_security_general_count: 0,
          total_security_led_count: 0
        }
      },
      beforeSize: 0
    };
  },
  computed: {
    rL: function() {
      return this.res.light;
    },
    rE: function() {
      return this.res.errLight;
    },
    rI: function() {
      return this.res.iot;
    },
    rC: function() {
      return this.res.errComplain;
    },

    lightTotal: function() {
      return (
        this.res.light.total_etc_general_count +
        this.res.light.total_etc_led_count +
        this.res.light.total_light_general_count +
        this.res.light.total_light_led_count +
        this.res.light.total_security_general_count +
        this.res.light.total_security_led_count
      );
    },
    lightGeneralTotal: function() {
      return (
        this.res.light.total_etc_general_count +
        this.res.light.total_light_general_count +
        this.res.light.total_security_general_count
      );
    },
    lightLedTotal: function() {
      return (
        this.res.light.total_etc_led_count +
        this.res.light.total_light_led_count +
        this.res.light.total_security_led_count
      );
    },
    iotTotal: function() {
      return (
        this.res.iot.iot_etc_general_count +
        this.res.iot.iot_etc_led_count +
        this.res.iot.iot_light_general_count +
        this.res.iot.iot_light_led_count +
        this.res.iot.iot_security_general_count +
        this.res.iot.iot_security_led_count
      );
    },
    iotGeneralTotal: function() {
      return (
        this.res.iot.iot_etc_general_count +
        this.res.iot.iot_light_general_count +
        this.res.iot.iot_security_general_count
      );
    },
    iotLedTotal: function() {
      return (
        this.res.iot.iot_etc_led_count +
        this.res.iot.iot_light_led_count +
        this.res.iot.iot_security_led_count
      );
    },
    iotPer: function() {
      return ((this.iotTotal / this.lightTotal) * 100).toFixed(1);
    },
    errPer: function() {
      var total =
        this.res.errLight.err_etc +
        this.res.errLight.err_light +
        this.res.errLight.err_security;
      return ((total / this.iotTotal) * 100).toFixed(1);
    },
    errTotal: function() {
      var total =
        this.res.errLight.err_etc +
        this.res.errLight.err_light +
        this.res.errLight.err_security;
      return total;
    },
    errTotalPer: function() {
      return (this.errTotal / this.iotTotal) * 100;
    },
    comTotal: function() {
      return (
        this.res.errComplain.complain_total_count
          .toFixed(0)
          .replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1,") +
        " (+" +
        this.res.errComplain.complain_today_count +
        ")"
      );
    },
    comReady: function() {
      return (
        this.res.errComplain.complain_ready_count
          .toFixed(0)
          .replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1,") +
        " (+" +
        this.res.errComplain.complain_today_ready_count +
        ")"
      );
    },
    comInprogress: function() {
      return (
        this.res.errComplain.complain_inprogress_count
          .toFixed(0)
          .replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1,") +
        " (+" +
        this.res.errComplain.complain_today_inprogress_count +
        ")"
      );
    },
    comDone: function() {
      return (
        this.res.errComplain.complain_done_count
          .toFixed(0)
          .replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1,") +
        " (+" +
        this.res.errComplain.complain_today_done_count +
        ")"
      );
    }
  },
  methods: {
    isNumber(n) {
      return !isNaN(parseFloat(n)) && !isNaN(n - 0);
    },
    movePanel(index) {
      if (index == "total" || index == "normal") {
        this.$store.commit("sidebar_content", "VPDeviceSearch");
        this.$store.commit("sidebar_onHeader", "상세 검색");
      } else if (index == "complain") {
        this.$store.commit("sidebar_content", "VPComplaintList");
        this.$store.commit("sidebar_onHeader", "민원 목록");
      } else if (index == "error") {
        this.$store.commit("sidebar_content", "VPDeviceTrouble");
        this.$store.commit("sidebar_onHeader", "실시간 고장내역");
      }
    },
    rowSelected(items) {
      console.log("items", items);
      EventBus.$emit("modalOpen", items.SL_NT_NO, "VMComplainInfo");
      Vue.nextTick(function() {
        EventBus.$emit(items.SL_NT_NO + "setComplainInfo", items);
      });
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    imagePath(index) {
      let each_png = this.heardCategory[index][1];
      return require("@/assets/img/res/img/" + each_png);
    },
    imagePathHover(index) {
      let each_png = this.heardCategory[index][2];
      return require("@/assets/img/res/img/" + each_png);
    },

    makePercentage() {
      let standard = this.resData["total"]["cnt"];
      let cal_value = 0;
      for (var category in this.resData) {
        if (category == "total") {
          continue;
        }
        if (this.resData[category]["cnt"] == 0) {
          cal_value = 0;
        } else {
          cal_value = (
            (this.resData[category]["cnt"] / standard) *
            100
          ).toFixed(0);
        }
        this.resData[category]["percent"] = cal_value;
      }
    },
    mouseover(index) {
      this.hoverFlag = false;
      this.hoverTargetIndex = index;
    },
    mouseleave(index) {
      this.hoverFlag = true;
      this.hoverTargetIndex = 99;
    },
    getStatusDataRoutine(spinnerFlag) {
      var vm = this;
      if (spinnerFlag) {
        // vm.getStatusCount(true);
        vm.getDeviceCount(true);
      }
      // setTimeout(function() {
      //   vm.getStatusCount();
      //   vm.getStatusDataRoutine(false);
      // }, 1000);
    },
    getStatusCount(spinnerFlag) {
      // NOTE :: 현황판 percent Data
      var vm = this;
      // if (spinnerFlag == true) {
      //   vm.loadData = true;
      // }
      this.$_API_GET("pc/dashboard/count").then(function(res) {
        if (res.length == 0) {
          this.$emit(
            "onAlert",
            "black",
            null,
            "검색된 결과가 없습니다",
            null,
            null,
            true,
            false
          );
          vm.resultTable = false;
        } else {
          vm.initDashboardData();
          vm.makeDashboard(res);
          vm.loadData = false;
        }
      });
    },
    getDeviceCount(spinnerFlag) {
      // NOTE :: 현황판 Table Data
      var vm = this;
      if (spinnerFlag == true) {
        vm.loadData = true;
      }
      this.$_API_GET("dashboard/count").then(function(res) {
        console.log("dashboard data", res);
        vm.res = vm.deepCopy(res);
      });
    },
    initDashboardData() {
      this.resData = {
        total: {
          percent: 100,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        normal: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        error: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        },
        complain: {
          percent: 0,
          cnt: 0,
          total: {
            light: 0,
            security: 0,
            etc: 0
          },
          iot: {
            light: 0,
            security: 0,
            etc: 0
          }
        }
      };
    },
    makeDashboard(res) {
      for (let key in res) {
        if (key != "time") {
          this.inputDataToDashboard(key, res[key]);
        }
      }
      this.makePercentage();
    },
    inputDataToDashboard(iot_total, item) {
      // 직접 데이터를 하나하나 넣어준다.
      // 현재 현황판이 세로로 데이터가 넣어진다 생각해야함.
      for (let key in item) {
        let value = item[key];
        key = key.split("_");
        let light_sec_etc = key[0];
        let total_noraml_complain_error = key[1];
        if (total_noraml_complain_error != "total") {
          this.resData[total_noraml_complain_error][iot_total][
            light_sec_etc
          ] = value;
        }
        if (
          total_noraml_complain_error != "total" &&
          total_noraml_complain_error != "complain"
        ) {
          this.resData["total"][iot_total][light_sec_etc] += value;
        }
        if (iot_total == "total") {
          // 퍼센트 아래 총 갯수는 cnt로 들어감
          this.resData[total_noraml_complain_error]["cnt"] += value;
          if (total_noraml_complain_error != "complain") {
            this.resData["total"]["cnt"] += value;
          }
        }
      }
    }
  },
  mounted() {
    this.getStatusDataRoutine(true);
    var vm = this;
    console.log("dashboard mounted", $(".ui-resizable").attr("width"));
    this.beforeSize = $(".ui-resizable").width();
    this.$store.commit("panel_size", 400);
    $("#panel .ui-resizable-handle").css("display", "none");

    EventBus.$on("getPccomplainAPI", function(data) {
      vm.getPccomplainAPI(data);
    });
    EventBus.$on("searchComplaint", function() {
      vm.searchComplaint();
    });
    EventBus.$on("setDashboard", function(data) {
      vm.initDashboardData();
      vm.makeDashboard(data);
      vm.loadData = false;
    });
  },
  beforeDestroy() {
    EventBus.$off("getPccomplainAPI");
    EventBus.$off("searchComplaint");
    EventBus.$off("setDashboard");
    $("#panel .ui-resizable-handle").css("display", "block");
  }
};
</script>

<style>
#dashboard {
  width: 100%;
}
#dashboard .status-area {
  background-color: #3b3b3b;
}
#dashboard .status-area {
  color: white;
}
#dashboard .status-area table {
  /* border: 1px solid red; */
  text-align: center;
  padding: 7px 10px 5px 10px;
  font-size: 12px;
}
#dashboard .status-area .light-table-area .light-table-title {
  color: white;
  padding-top: 20px;
  padding-left: 18px;
  font-size: 13px;
}
#dashboard .status-area .light-table-area .light-table tr th {
  border: 0.5px solid #3b3b3b;
  width: 20%;
  font-size: 12px;
}
#dashboard .status-area .light-table-area .light-table tr td {
  border: 0.5px solid #3b3b3b;
  font-size: 12px;
  padding-left: 0px;
  padding-right: 0px;
}
#dashboard .status-area .light-table-area .light-table tr:first-child {
  background-color: #4b4b4b;
}
#dashboard .status-area .light-table-area .light-table tr td:first-child {
  background-color: #4b4b4b;
}
#dashboard .status-area .light-table-area .light-table tr td:not(:first-child) {
  background-color: #434343;
  color: #c6c6c6;
}
#dashboard .status-area .iot-table-area .iot-table-title {
  color: white;
  padding-top: 20px;
  padding-left: 18px;
  font-size: 13px;
  display: flex;
  justify-content: space-between;
}
#dashboard .status-area .iot-table-area .iot-table tr th {
  border: 0.5px solid #3b3b3b;
  width: 20%;
  font-size: 12px;
}
#dashboard .status-area .iot-table-area .iot-table tr td {
  border: 0.5px solid #3b3b3b;
  font-size: 12px;
  padding-left: 0px;
  padding-right: 0px;
}
#dashboard .status-area .iot-table-area .iot-table tr:first-child {
  background-color: #4b4b4b;
}
#dashboard .status-area .iot-table-area .iot-table tr td:first-child {
  background-color: #4b4b4b;
}
#dashboard .status-area .iot-table-area .iot-table tr td:not(:first-child) {
  background-color: #434343;
  color: #c6c6c6;
}
#dashboard .status-area .err-table-area .err-table-title {
  color: white;
  padding-top: 20px;
  padding-left: 18px;
  font-size: 13px;
  display: flex;
  justify-content: space-between;
}
#dashboard .status-area .err-table-area .err-table tr th {
  border: 0.5px solid #3b3b3b;
  width: 20%;
  font-size: 12px;
}
#dashboard .status-area .err-table-area .err-table tr td {
  border: 0.5px solid #3b3b3b;
  font-size: 12px;
  padding-left: 0px;
  padding-right: 0px;
}
#dashboard .status-area .err-table-area .err-table tr:first-child {
  background-color: #4b4b4b;
}
#dashboard .status-area .err-table-area .err-table tr td:first-child {
  background-color: #4b4b4b;
}
#dashboard .status-area .err-table-area .err-table tr td:not(:first-child) {
  background-color: #434343;
  color: #c6c6c6;
}
#dashboard .status-area .complain-table-area .complain-table-title {
  color: white;
  padding-top: 20px;
  padding-left: 18px;
  font-size: 13px;
}
#dashboard .status-area .complain-table-area .complain-table tr th {
  border: 0.5px solid #3b3b3b;
  width: 20%;
  font-size: 12px;
}
#dashboard .status-area .complain-table-area .complain-table tr td {
  border: 0.5px solid #3b3b3b;
  font-size: 12px;
  padding-left: 0px;
  padding-right: 0px;
}
#dashboard .status-area .complain-table-area .complain-table tr:first-child {
  background-color: #4b4b4b;
}
#dashboard .status-area .complain-table-area .complain-table tr td:first-child {
  background-color: #434343;
  color: #c6c6c6;
}
#dashboard
  .status-area
  .complain-table-area
  .complain-table
  tr
  td:not(:first-child) {
  background-color: #434343;
  color: #c6c6c6;
}
#dashboard .status-area tr:first-child th:first-child {
  border-radius: 10px 0px 0px 0px;
}
#dashboard .status-area tr:first-child th:last-child {
  border-radius: 0px 10px 0px 0px;
}
#dashboard .status-area tr:last-child td:last-child {
  border-radius: 0px 0px 10px 0px;
}
#dashboard .status-area tr:last-child td:first-child {
  border-radius: 0px 0px 0px 10px;
}

#dashboard .table-content {
  background-image: url("../../assets/img/res/img/dashboard_bg_down.png");
}
#dashboard .status-area {
  height: 100%;
  background: linear-gradient(#353535, #303030);
}
#dashboard .gradient-content {
  height: 100%;
  width: 100%;
  position: absolute;
  display: flex;
  flex-direction: column;
}

#dashboard .gradient-content .gradient-bg-down {
  width: 100%;
  height: 100%;
  flex: 11;
  background-image: url("../../assets/img/res/img/dashboard_bg_down.png");
}

#dashboard .gradient-content .gradient-bg-up {
  width: 100%;
  height: 100%;
  flex: 3;
  background-image: url("../../assets/img/res/img/dashboard_bg_up.png");
}
#dashboard .category {
  cursor: pointer;
}
#dashboard .tab-content {
  display: flex;
}
#dashboard .dash-header {
  margin-top: 10px;
  margin-bottom: 10px;
}
#dashboard .tab-content .header {
  margin: 20px 20px 0px 20px;
  padding: 0px 0px 7px 0px;
  /* border-bottom:1px solid; */
  border-color: #979797;
}
#dashboard .dashboard-close {
  line-height: 37px;
  position: absolute;
  right: 0;
  margin-right: 10px;
}
#dashboard .tab-content .header-right {
  margin-left: 200px;
}
#dashboard .tab-content .header span {
  background: rgb(49, 49, 49);
  color: #00a0ea;
  /* margin: 20px 0px 15px 0px;
  padding: 5px 10px 0px 10px; */
  font-size: 14px;
  font-weight: 600;
  /* border-top-left-radius: 5px;
  border-top-right-radius: 5px; */
  /* border:1px solid #979797; */
  padding: 8px;
}
#dashboard .table-content ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
#dashboard #panel-table ul {
  z-index: 10;
}
/* #panel-table > ul > li:nth-child(1) > tr:nth-child(3) > div > tr:nth-child(2) > div */
#dashboard .item .tot {
  color: #979797;
  font-size: 12px;
  text-align: center;
}

#dashboard .item .iot {
  color: #fff;
  font-size: 12px;
}

#dashboard .table-content .category .item tr {
  text-align: center;
  padding: 20px;
}
#dashboard .table-content table tr .head-name {
  color: #979797;
}
#dashboard .table-content ul li:nth-child(1) .category .item .round-graph-text {
  color: #016aae;
}
#dashboard .table-content ul li:nth-child(2) .category .item .round-graph-text {
  color: #248de0;
}
#dashboard .table-content ul li:nth-child(3) .category .item .round-graph-text {
  color: #24a0e0;
}
#dashboard .table-content ul li:nth-child(4) .category .item .round-graph-text {
  color: #59d5ef;
}

#dashboard .table-content li {
  margin-top: 10px;
  float: left;
  color: white;
  width: 99px;
}
#dashboard table .text-image,
.text-image-arrow {
  position: relative;
  z-index: 1;
}
#dashboard .wide-arrow-text,
.round-graph-text {
  left: 0;
  position: absolute;
  text-align: center;
  font-size: 12px;
}
#dashboard .wide-arrow-text {
  top: 17px;
  width: 110%;
  color: #979797;
}

#dashboard .round-graph-text {
  top: 23px;
  width: 105%;
}

#dashboard .wide-arrow {
  height: 35px;
  width: 100%;
}

#dashboard .round-graph {
  max-width: 80%;
  max-height: 30%;
  padding: 2px 0px 2px 0px;
}

#dashboard .down-arrow {
  margin: 5px 0px 8px 0px;
}
#dashboard .text-image-arrow {
  padding: 10px 0px 10px 0px;
}
#dashboard .item {
  text-align: center;
  margin: 10px 0px 0px 0px;
  padding: 10px;
}
#dashboard .item .name {
  padding: 0px 0px 5px 5px;
}
#dashboard .device-bottom-line {
  width: calc(100% - 30px);
  height: 1px;
  background: #4e4e4e;
  margin-left: 15px;
}
#dashboard .data .item tr:first-child div {
  margin-bottom: 7px;
}
#dashboard .data tr {
  display: flex;
  justify-content: center;
}
#dashboard .table-content .parent-table {
  margin-top: 0px;
}
</style>

<style lang="scss">
#dashboard .header {
  & span {
    border: 1px solid #4e4e4e;
    padding: 14px 14px 11px 14px;
    margin: -4px;
    border-top-right-radius: 15px;
    border-top-left-radius: 15px;
  }
}
</style>
