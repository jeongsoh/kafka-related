<template lang="pug">
#search_list.table-content.vp-jaje-list
  #search_condition
    #table-all
    .filter-footer
      button.search-btn(@click="openJajeAdd('add')") 추가
      span.table-total 총 검색 결과 : {{totalCount}} 개
  #search_condition.result-area(style="height:100%" v-show="resultTable")
    #search_result
      table.result-table
        thead
          tr
            th.result-th-default
              .result-th 자재명
            th.result-th-default
              .result-th 재고
            th.result-th-default
              .result-th 단위
            th.result-th-default
              .result-th &nbsp;
        tbody
          tr.result-body-tr(v-for="result in items" v-if="result.SL_DEL_FLAG != 0")
            td(@click="openJajeAdd('modify', result)") {{result.SL_JJ_NAME}}
            td.td-center(@click="openJajeAdd('modify', result)") {{result.SL_JJ_TOTAL}}
            td.td-center(@click="openJajeAdd('modify', result)") {{result.SL_JJ_UNIT}}
            td.table-cmd-button
              button.jaje-button.jaje-in(@click="openJajeInOut('in', result)") 입고
              button.jaje-button.jaje-in(@click="openJajeInOut('out',result)") 출고
              button.jaje-button.jaje-del(@click="openDeleteJaje(result)") 삭제
          tr.non-result-table(v-show="items == ''")
            td(colspan=7 style="color:white") 검색된 자재 결과가 없습니다.
  vm-alert(ref="alert" @event="alertEvent")
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
  transition(name='modal' v-if="retry")
    .modal-background
      .modal-position
        | 일시적으로 데이터를 불러오지 못했습니다
        br
        | 다시 시도해주세요
        br
        button.spinner-btn(@click="searchComplaint") 다시 시도
  transition(name='modal' v-if="jajeInOut")
    .modal-background.jaje-table
      .modal-position.panel-complain-list(style="padding:0px 12px 12px 12px")
        .modal-header
          VMHeader(v-bind:icon="''", v-bind:title="'자재 입/출고'", v-bind:menu="[]", v-bind:exitBtn="true" v-on:clickClose="onClickClose")
        table.search-addr.table-modify
          colgroup
            col(style="width:40%")
            col(style="width:60%")
          tr.tr-item
            th.td-item.table-select-full-th.left-first-child(colspan=1) &nbsp;&nbsp;분류
            td.td-item.table-select-full-th.left-last-child(colspan=1) 
              input(v-model="jajeIOData.SL_JJ_TYPE == 'I'? '입고':'출고'" :disabled="true" style="border-top-right-radius: 8px;border-top-left-radius: 0px;border-bottom-left-radius: 0px;border-bottom-right-radius: 0px; background:lightgray !important")
          tr.tr-item
            th.td-item.table-select-full-th(colspan=1) &nbsp;&nbsp;자재명
            td.td-item.table-select-full-th(colspan=1) 
              input(v-model="jajeIOData.SL_JJ_NAME" :disabled="true" style="border-radius: 0px; background:lightgray !important")
          tr.tr-item
            th.td-item.table-select-full-th(colspan=1) &nbsp;&nbsp;현재 재고
            td.td-item.table-select-full-th(colspan=1) 
              input(v-model="jajeIOData.SL_JJ_TOTAL" :disabled="true" style="border-radius: 0px; background:lightgray !important")
          tr.tr-item
            th.td-item.table-select-full-th(colspan=1) &nbsp;&nbsp;날짜
            td.td-item.table-select-full-th(colspan=1) 
              date-range-picker.panel-date-range(:singleDatePicker="true" :ranges="false" :startDate="startDate" :endDate="endDate" @update="updateDatepicker" :locale-data="locale" :opens="'right'" autoApply v-model="dataRange" style="width:100%; height:100%;" :show-dropdowns="true")
          tr.tr-item
            th.td-item.table-select-full-th(colspan=1) &nbsp;&nbsp;수량
            td.td-item.table-select-full-th(colspan=1) 
              input(type="Number" v-model="jajeIOData.SL_JJ_COUNT")
          tr.tr-item
            th.td-item.table-select-full-th.right-first-child(colspan=1) &nbsp;&nbsp;비고
            td.td-item.table-select-full-th.right-last-child(colspan=1) 
              input(style="border-radius:10px" v-model="jajeIOData.SL_JJ_BIGO")
        button.spinner-btn.spinner-left(@click="jajeInOut = false") 취소
        button.spinner-btn.spinner-right(@click="setJajeIO()") 확인
  transition(name='modal' v-if="jajeAdd")
    .modal-background.jaje-table
      .modal-position.panel-complain-list(style="padding:0px 12px 12px 12px")
        .modal-header
          VMHeader(v-bind:icon="''", v-bind:title="jajeHeader", v-bind:menu="[]", v-bind:exitBtn="true" v-on:clickClose="onClickClose")
        table.search-addr.table-modify
          colgroup
            col(style="width:40%")
            col(style="width:60%")
          tr.tr-item
            th.td-item.table-select-full-th.left-first-child(colspan=1) &nbsp;&nbsp;자재명
            td.td-item.table-select-full-th.left-last-child(colspan=1) 
              input(style="border-radius:10px" v-model="jajeData.jajeNewName").focus-set
          tr.tr-item
            th.td-item.table-select-full-th(colspan=1) &nbsp;&nbsp;재고
            td.td-item.table-select-full-th(colspan=1) 
              input(type="Number" style="border-radius:0px" v-model="jajeData.jajeStock").jaje-stock.modify-disabled
          tr.tr-item
            th.td-item.table-select-full-th.right-first-child(colspan=1) &nbsp;&nbsp;단위
            td.td-item.table-select-full-th.right-last-child(colspan=1) 
              input(style="border-radius:10px" v-model="jajeData.jajeUnit")
        .transition-btn
          button.spinner-btn.spinner-left(@click="jajeAdd = false") 취소
          button.spinner-btn.spinner-right(@click="setJaJeCode") {{setJajeBtn}}
  transition(name='modal' v-if="jajeDel")
    .modal-background
      .modal-position.panel-complain-list
        span [ 
        span.alert-delete-red {{jajeData.jajeOldName}}
        span  ] 해당 자재 항목을 삭제하시겠습니까?
        br
        button.spinner-btn.spinner-left(@click="jajeDel = false") 취소
        button.spinner-btn.spinner-right(@click="delJajeCode()") 삭제
</template>

<script>
import { EventBus } from "@/main";
import Vue from "vue";
import DateRangePicker from "vue2-daterange-picker";
import complainCode from "@/assets/json/complainCode.json";
import VMLightQRCode from "@/components/modal/VMLightQRCode";
import jajeCode from "@/assets/json/jajeCode.json";

export default {
  components: { DateRangePicker, VMLightQRCode },
  data() {
    return {
      fields: [],
      items: [],
      parentEl: "#content",
      req: {
        SL_NTDATE_START: new Date(), // 민원 접수일
        SL_NTDATE_END: new Date(), // 민원 접수일
        SL_SLNAME: "", // 표찰번호
        SL_NTRES: "all", // 처리상태
        SL_REPLY: "all", // 회신 방법
        SL_STATUS: "all", // 표찰 상태
        SL_CONTENT: "all", // 신고 내용
        PAGE: 1
      },
      jajeIOData: {
        SL_JJ_TYPE: "",
        SL_JJ_TOTAL: 0,
        SL_JJ_NAME: "",
        SL_JJ_CODE: "",
        SL_JJ_COUNT: "",
        SL_JJ_BIGO: "",
        startDate: "",
        endDate: ""
      },
      jajeCode: {},
      resultTable: false,
      loadData: false,
      code: {},
      modifyAuth: false,
      retry: false,
      totalCount: 0,
      jajeInOut: false,
      jajeAdd: false,
      jajeDel: false,
      jajeDelName: "",
      setJajeBtn: "저장",
      jajeHeader: "자재 항목 추가",
      jajeData: {
        jajeOldName: "",
        jajeNewName: "",
        jajeStock: 0,
        jajeUnit: "",
        jajeType: "",
        SL_JJ_TYPE: "I"
      },
      header: {
        icon: "",
        title: "고장 신고",
        menu: [],
        exitBtn: true
      },
      dataRange: {
        startDate: new Date(),
        endDate: new Date()
      },
      startDate: new Date(),
      endDate: new Date(),
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      localeFinish: {},
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      }
    };
  },
  updated() {},
  watch: {},
  computed: {},
  methods: {
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    rowSelected(items) {
      console.log("items", items);
      EventBus.$emit("modalOpen", items.SL_NT_NO, "VMComplainInfo");
      Vue.nextTick(function() {
        EventBus.$emit(items.SL_NT_NO + "setComplainInfo", items.SL_NT_NO);
      });
    },
    complainDateFormatter(date) {
      return date.substring(0, 16).replace("T", " ");
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        if (
          res.grade.substring(0, 1) == "S" ||
          res.grade.substring(0, 1) == "A" ||
          res.grade.substring(0, 1) == "B"
        ) {
          vm.modifyAuth = true;
        } else {
          vm.modifyAuth = false;
        }
      });
    },
    getJajeList(data, path) {
      // NOTE :: 자재 리스트
      var vm = this;
      return this.$_API_GET("jaje", data)
        .then(function(res) {
          console.log("get jaje List", res);
          vm.items = [];
          if (res.length == 0) {
            vm.loadData = false;
            vm.resultTable = true;
            vm.totalCount = 0;
          } else {
            vm.items = res;
            vm.resultTable = true;
            vm.loadData = false;
            vm.totalCount = res.length;
          }
        })
        .catch(() => {
          vm.loadData = false;
          vm.retry = true;
        });
    },
    openJajeInOut(IO, data) {
      // NOTE :: 자재 입출고 모달 켜기
      let vm = this;
      return this.$_API_GET("one/jaje", { SL_JJ_CODE: data.SL_JJ_CODE })
        .then(function(res) {
          console.log("get one jaje", res);
          vm.jajeInOut = true;
          if (IO == "in") {
            vm.jajeIOData.SL_JJ_TYPE = "I";
          } else if (IO == "out") {
            vm.jajeIOData.SL_JJ_TYPE = "O";
          }
          vm.jajeIOData.SL_JJ_TOTAL = res.SL_JJ_TOTAL;
          vm.jajeIOData.SL_JJ_NAME = res.SL_JJ_NAME;
          vm.jajeIOData.SL_JJ_CODE = res.SL_JJ_CODE;
          vm.jajeIOData.SL_JJ_COUNT = 1;
          vm.jajeIOData.SL_JJ_BIGO = "";
          vm.dataRange.startDate = new Date();
          vm.dataRange.endDate = new Date();
          vm.startDate = new Date();
          vm.endDate = new Date();
        })
        .catch(() => {
          vm.loadData = false;
          vm.$refs.alert.init(
            "black",
            null,
            "에러 : 관리자에게 문의 바랍니다.",
            null,
            null,
            true,
            false
          );
        });
    },
    onClickClose() {
      this.jajeInOut = false;
      this.jajeAdd = false;
    },
    openJajeAdd(type, data) {
      // NOTE :: 자재 추가/수정
      this.jajeAdd = true;
      this.jajeData.jajeType = type;
      if (type == "add") {
        this.setJajeBtn = "저장";
        this.jajeHeader = "자재 항목 추가";
        this.jajeData.jajeOldName = "";
        this.jajeData.jajeNewName = "";
        this.jajeData.jajeStock = 0;
        this.jajeData.jajeUnit = "";
      } else {
        this.setJajeBtn = "수정";
        this.jajeHeader = "자재 항목 수정";
        this.jajeData.jajeOldName = data.SL_JJ_NAME;
        this.jajeData.jajeNewName = data.SL_JJ_NAME;
        this.jajeData.jajeStock = data.SL_JJ_TOTAL;
        this.jajeData.jajeUnit = data.SL_JJ_UNIT;
      }
      Vue.nextTick(function() {
        $(".vp-jaje-list .focus-set").focus();
        if (type == "modify") {
          $(".jaje-stock").attr("disabled", true);
        }
      });
    },
    setJaJeCode() {
      // NOTE :: 자재 중복 체크
      this.loadData = true;
      var vm = this;
      this.$_API_POST("jaje/code", this.jajeData)
        .then(function(res) {
          if (res.data.error == "overlap_name") {
            vm.$refs.alert.init(
              "black",
              null,
              "중복된 자재명 입니다.",
              null,
              null,
              true,
              false
            );
            vm.loadData = false;
          } else {
            vm.jajeAdd = false;
            vm.getJajeList();
          }
        })
        .catch(function() {
          // vm.jajeAdd = false;
          vm.loadData = false;
          vm.$refs.alert.init(
            "black",
            null,
            "에러 : 관리자에게 문의 바랍니다.",
            null,
            null,
            true,
            false
          );
        });
    },
    openDeleteJaje(data) {
      this.jajeDel = true;
      this.jajeData.jajeOldName = data.SL_JJ_NAME;
    },
    delJajeCode() {
      // NOTE :: 자재 삭제
      this.loadData = true;
      var vm = this;
      this.$_API_DELETE("jaje/code", this.jajeData)
        .then(function(res) {
          console.log("jaje code", res);
          vm.jajeDel = false;
          vm.getJajeList();
        })
        .catch(function() {
          // vm.jajeDel = false;
          vm.loadData = false;
          vm.$refs.alert.init(
            "black",
            null,
            "에러 : 관리자에게 문의 바랍니다.",
            null,
            null,
            true,
            false
          );
        });
    },
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      this.jajeData[type] = data;
      $(".vp-jaje-list .dropdown__header").removeClass("is-active");
      if (type == "SL_ADDR_1") {
        this.req.SL_ADDR_2 = "all";
      }
    },
    dropdownChoice(value, choice) {
      if (value == choice) {
        return "list-select";
      } else {
        return "";
      }
    },
    setJajeIO() {
      // NOTE :: 자재 입출고
      if (Number(this.jajeIOData.SL_JJ_COUNT) <= 0) {
        this.$refs.alert.init(
          "black",
          null,
          "자재 수량은 1개 이상 가능합니다.",
          null,
          null,
          true,
          false
        );
        return;
      }
      if (
        this.jajeIOData.SL_JJ_TYPE == "O" &&
        this.jajeIOData.SL_JJ_TOTAL < this.jajeIOData.SL_JJ_COUNT
      ) {
        this.$refs.alert.init(
          "black",
          null,
          "재고 수량을 초과하여 출고할 수 ",
          "없습니다.",
          null,
          true,
          false
        );
        return;
      }
      this.loadData = true;
      var vm = this;
      this.jajeIOData.endDate = this.moment(this.dataRange.endDate).format(
        "YYYY-MM-DD HH:mm:ss"
      );
      this.$_API_POST("jaje/io", this.jajeIOData)
        .then(function(res) {
          console.log("jaje io", res);
          vm.jajeInOut = false;
          vm.getJajeList();
        })
        .catch(function() {
          // vm.jajeInOut = false;
          vm.loadData = false;
          vm.$refs.alert.init(
            "black",
            null,
            "에러 : 관리자에게 문의 바랍니다.",
            null,
            null,
            true,
            false
          );
        });
    },
    alertEvent() {}
  },
  mounted() {
    var vm = this;
    this.loadData = true;
    this.code = JSON.parse(JSON.stringify(complainCode));
    this.jajeCode = JSON.parse(JSON.stringify(jajeCode));
    this.$store.commit("panel_size", 460);
    this.getPcauthAPI();
    this.getJajeList();
  },
  beforeDestroy() {}
};
</script>

<style>
.rm-white-space {
  white-space: normal;
}
.show-calendar {
  display: block;
}

th.month {
  color: black;
}
.item-td .form-control {
  padding: 0px 0px 0px 4px;
  border: 0px;
}

.item-td .form-control * {
  font-size: 12px;
}

.non-auth {
  display: none;
}
.jaje-button {
  border-radius: 5px;
  width: 100%;
  color: white;
  height: 100%;
  min-width: 50px;
  max-width: 50px;
  outline: none !important;
}
.jaje-in {
  background-color: rgb(1, 106, 174);
  border: 1px solid rgb(1, 106, 174);
}
.jaje-in:hover {
  border: 1px solid rgb(1, 106, 174);
  background-color: white;
  color: black;
}
.jaje-out {
  background-color: rgb(243, 126, 0);
  border: 1px solid rgb(243, 126, 0);
}
.jaje-out:hover {
  border: 1px solid rgb(243, 126, 0);
  background-color: white;
  color: black;
}
.jaje-del {
  background-color: #707070;
  border: 1px solid #707070;
}
.jaje-del:hover {
  border: 1px solid #707070;
  background-color: white;
  color: black;
}

.vp-jaje-list .vue-daterange-picker {
  height: 21px;
  width: 75%;
}
.vp-jaje-list .form-control {
  background-color: white;
  height: 20px;
  line-height: 16px;
  color: black;
  cursor: pointer;
}
.vp-jaje-list .vue-daterange-picker .reportrange-text {
  height: 22px;
  width: 100%;
  border: unset;
  background-color: #101010;
  padding: 0px;
  display: flex;
  align-items: center;
}
.vp-jaje-list .form-control span {
  width: 100%;
  text-align: left;
  margin-left: -4px;
}
.vp-jaje-list .date-picker-div > div {
  top: 2px;
}
.vp-jaje-list table tbody tr td.table-cmd-button {
  display: flex;
  justify-content: center;
  padding: 6px;
}
/* .vp-jaje-list table tbody tr td.table-cmd-button button:not(:last-child) {
  margin-right: 7px;
} */
.vp-jaje-list table tbody tr td.table-cmd-button button:first-child {
  margin-right: 7px;
}
.vp-jaje-list table tbody tr td.table-cmd-button button:nth-child(2) {
  margin-right: 7px;
}
.vp-jaje-list .panel-complain-list {
  position: absolute;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  color: #000 !important;
  top: 41%;
  left: 50%;
  transform: translateX(-50%);
  min-width: 322px;
}
.vp-jaje-list .alert-delete-red {
  color: red;
}
.vp-jaje-list .td-center {
  text-align: center;
  padding-left: 6px;
}
.vp-jaje-list .table-total {
  color: white;
  font-size: 12px;
  position: absolute;
  left: 20px;
  line-height: 60px;
}
.vp-jaje-list #search_result {
  height: calc(100vh - 110px);
}
.vp-jaje-list .modal-icon {
  display: none;
}
.vp-jaje-list .modal-exit {
  padding-top: 10px;
}
.vp-jaje-list .transition-btn {
  padding-top: 3px;
}
.vp-jaje-list ::-webkit-scrollbar {
  width: 5px; /* 세로축 스크롤바 길이 */
  height: 0px; /* 가로축 스크롤바 길이 */
}
.vp-jaje-list ::-webkit-scrollbar-track {
  background-color: rgba(0, 0, 0, 0);
}
.vp-jaje-list ::-webkit-scrollbar-track-piece {
  background-color: #434343;
}
.vp-jaje-list ::-webkit-scrollbar-thumb {
  border-radius: 8px;
  background-color: #313131;
}
.vp-jaje-list ::-webkit-scrollbar-button {
  background-color: rgba(0, 0, 0, 0);
  width: 100%;
  height: 0px;
}
.vp-jaje-list ::-webkit-scrollbar-button:start {
  background-color: rgba(0, 0, 0, 0); /* Top, Left 방향의 이동버튼 */
}
.vp-jaje-list ::-webkit-scrollbar-button:end {
  background-color: rgba(0, 0, 0, 0); /* Bottom, Right 방향의 이동버튼 */
}
.vp-jaje-list ::-webkit-scrollbar-corner {
  background-color: rgba(0, 0, 0, 0); /* 우측 하단의 코너 부분 */
}
.vp-jaje-list ::-webkit-resizer {
  background-color: rgba(0, 0, 0, 0);
}
.vp-jaje-list .panel-date-range,
.vp-jaje-list .panel-date-range .form-control {
  text-align: start;
  padding-left: 2px;
  padding-top: 1px;
}
</style>

<style lang="scss">
.vp-jaje-list .jaje-table {
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    & * {
      font-size: 12px;
    }
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.modify-light-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100% !important;
          background: white !important;
          color: black !important;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray !important;
        }
        & input.modify-disabled[type="Number"]:disabled {
          background: lightgray !important;
        }
        & input:focus {
          outline: #418fff auto 1px !important;
          outline-offset: -2px;
        }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0px;
      -webkit-border-radius: 10px 0 0 0px;
      border-radius: 10px 0 0 0px;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0px 0;
      -webkit-border-radius: 0 10px 0px 0;
      border-radius: 0 10px 0px 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>

<style lang="scss">
// NOTE :: DropDown CSS
#search_list.table-content.vp-jaje-list {
  & .dropdown {
    width: 100%;
    &__header {
      background: #fff;
      font-size: 12px;
      cursor: pointer;
      line-height: 20px;
      position: relative;
      text-overflow: ellipsis;
      color: #000;
      width: 100%;
      height: 22px;
      text-align: start;
      i.fas {
        position: absolute;
        right: 4px;
        top: 50%;
        transform: translateY(-50%);
        // transition: opacity 0.3s;
        font-size: 10px;
        &.fa-chevron-up {
          opacity: 0;
        }
      }
      &.is-active {
        outline: -webkit-focus-ring-color auto 1px;
        outline-offset: -2px;
        i.fas {
          &.fa-chevron-up {
            opacity: 1;
            color: #00a0ea;
          }
          &.fa-chevron-down {
            opacity: 0;
          }
        }
        + .dropdown__content {
          margin-top: 0px;
          height: auto;
          opacity: 1;
          visibility: visible;
          position: absolute;
          text-align: start;
        }
      }
      & span {
        padding-left: 7px;
      }
    }
    &__content {
      z-index: 10;
      opacity: 0;
      overflow: hidden;
      width: 100%;
      transition: opacity 0.3s;
      visibility: hidden;
      position: absolute;
      background: #fff;
      border: 1px solid #d5d5d5;
      border-radius: 5px;
      & ul {
        margin: 0px;
        & li {
          cursor: pointer;
          color: #000;
          font-size: 12px;
          padding: 4px 0px 0px 7px;
          &:hover {
            color: #00a0ea;
          }
          &.list-select {
            color: #00a0ea;
          }
          &:last-child .search-division-line {
            display: none;
          }
          &:last-child {
            padding: 4px 0px 4px 7px;
          }
        }
        & .off-search-type {
          color: #fff;
        }
        & .search-division-line {
          height: 1px;
          background: #f1f1f1;
          width: 95%;
          margin-top: 4px;
        }
      }
    }
  }
}
</style>
