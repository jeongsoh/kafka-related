<template lang="pug">
#complaint_list_header
  .device-header-content
    #header_left
      .menu-area
        span(v-for="data, index in $store.getters.sidebar_complainList" :class="isBtnClass(data.name)" @click="onClickMenu(data)") {{data.name}}
    #header_right
      .close-btn(@click="exitBtn()") &times;
  .device-bottom-line
</template>

<script>
import { EventBus } from "@/main";
export default {
  data() {
    return {};
  },
  computed: {},
  methods: {
    isBtnClass(headerName) {
      if (headerName == this.$store.getters.sidebar_onHeader) {
        return "on";
      } else {
        return "";
      }
    },
    exitBtn(data) {
      this.$store.commit("sidebar_content", "");
      this.$store.commit("sidebar_onHeader", "");
    },
    onClickMenu(data) {
      this.$store.commit("sidebar_content", data.component);
      this.$store.commit("sidebar_onHeader", data.name);
    }
  }
};
</script>

<style>
#complaint_list_header > * {
  font-size: 12px;
}
#complaint_list_header {
  display: flex;
  flex-direction: column;
}
#complaint_list_header .device-header-content {
  display: flex;
  width: 100%;
}
#complaint_list_header .device-bottom-line {
  width: calc(100% - 30px);
  height: 1px;
  background: #4e4e4e;
  margin-left: 15px;
}
#complaint_list_header #header_left {
  flex: 3;
}
#complaint_list_header #header_right {
  flex: 1;
  padding: 5px;
  display: flex;
  flex-direction: row-reverse;
}
#complaint_list_header .header-btn {
  padding: 5px 5px 5px 10px;
  margin: 5px;
  border-radius: 7px;
  width: 100px;
  box-shadow: none;
  background-color: white;
  text-align: left;
}
#complaint_list_header #header_left .menu-area {
  margin: 29px 0px 8px 15px;
}
#complaint_list_header #header_left .menu-area span:first-child {
  margin-right: 15px;
}
#complaint_list_header #header_left .menu-area span {
  font-size: 14px;
  font-weight: 600;
  color: #fff;
  padding: 8px;
  border-bottom: 0px;
  cursor: pointer;
}
#complaint_list_header #header_left .menu-area span:hover {
  background: rgb(49, 49, 49);
  color: #00a0ea;
}
#complaint_list_header #header_left .menu-area span.on {
  background: rgb(49, 49, 49);
  color: #00a0ea;
}
#complaint_list_header .header-btn.on {
  background-color: #1980e0;
  color: white;
  outline: none;
}
.panel-header-arrow {
  background: url("../../assets/img/res/img/panel-header-arrow.png") no-repeat
    right #fff;
  -webkit-appearance: none;
  -moz-appearance: none;
  padding-right: 10px !important;
}
</style>

<style lang="scss">
.device-header-content #header_left {
  & span {
    border: 1px solid #4e4e4e;
    padding: 14px;
    margin: 0px;
    border-top-right-radius: 15px;
    border-top-left-radius: 15px;
  }
}
</style>
