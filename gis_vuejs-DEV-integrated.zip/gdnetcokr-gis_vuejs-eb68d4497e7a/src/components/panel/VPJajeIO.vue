<template lang="pug">
#search_list.table-content.vp-jaje-io
  #search_condition
    #table-all
      #table-border-radius
      table.parent-table#panel-table
        tr.group-condition
          th.item-th
            span 분류
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{jajeCode.SL_JJ_TYPE[jajeData.SL_JJ_TYPE]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content
                ul
                  li(@click="clickDropDown('SL_JJ_TYPE', 'all')" :class="dropdownChoice('all', jajeData.SL_JJ_TYPE)") 전체
                    .search-division-line
                  li(v-if="key != 'all'" @click="clickDropDown('SL_JJ_TYPE', key)" v-for="value, key in jajeCode.SL_JJ_TYPE"  :class="dropdownChoice(value, jajeCode.SL_JJ_TYPE[jajeData.SL_JJ_TYPE])") {{value}}
                    .search-division-line            
        tr.group-condition
          th.item-th
            span 주소1
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{jajeData.SL_ADDR_1.split(":")[0] == 'all'?'전체':jajeData.SL_ADDR_1.split(":")[0]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(@click="clickDropDown('addr1', 'all')" :class="dropdownChoice('all', jajeData.SL_ADDR_1)") 전체
                    .search-division-line
                  li(@click="clickDropDown('addr1', key)" v-for="value, key in jajeCode.postcode"  :class="dropdownChoice(key, jajeData.SL_ADDR_1)") {{key.toString().split(":")[0]}}
                    .search-division-line            
        tr.group-condition
          th.item-th
            span 주소2
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{jajeData.SL_ADDR_2.split(":")[0] == 'all'?'전체':jajeData.SL_ADDR_2.split(":")[0]}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(@click="clickDropDown('addr2', 'all')" :class="dropdownChoice('all', jajeData.SL_ADDR_2)") 전체
                    .search-division-line
                  li(@click="clickDropDown('addr2', key)" v-for="value, key in jajeCode.postcode[jajeData.SL_ADDR_1]"  :class="dropdownChoice(key, jajeData.SL_ADDR_2)") {{key.toString().split(":")[0]}}
                    .search-division-line            
          tr.group-condition
            th.item-th
              span 주소3
            td.item-td(tabindex="-1")
              .dropdown
                .dropdown__header(@click="toggleDropdown($event)")
                  span {{jajeData.SL_ADDR_3.toString().split(":")[0] == 'all'?'전체':jajeData.SL_ADDR_3.toString().split(":")[0]}}
                  i.fas.fa-chevron-down
                  i.fas.fa-chevron-up
                .dropdown__content.dropdown__longdata
                  ul
                    li(@click="clickDropDown('addr3', 'all')" :class="dropdownChoice('all', jajeData.SL_ADDR_3)") 전체
                      .search-division-line
                    li(@click="clickDropDown('addr3', value)" v-for="value, key in (jajeCode.postcode[jajeData.SL_ADDR_1] != undefined ? jajeCode.postcode[jajeData.SL_ADDR_1][jajeData.SL_ADDR_2] : [])"  :class="dropdownChoice(key, jajeData.SL_ADDR_3)") {{value.toString().split(":")[0]}}
                      .search-division-line         
        tr.group-condition
          th.item-th
            span 날짜
          td.item-td.date-picker-div
            date-range-picker(:ranges="ranges" :startDate="startDate" :endDate="endDate" @update="updateDatepicker" :locale-data="locale" :opens="openPosition" autoApply v-model="dataRange" style="width:100%; height:100%; pointer-events:auto;" :show-dropdowns="true")
        tr.group-condition
          th.item-th
            span 자재명
          td.item-td(tabindex="-1")
            .dropdown
              .dropdown__header(@click="toggleDropdown($event)")
                span {{jajeData.SL_JJ_NAME == 'all'?'전체':jajeData.SL_JJ_NAME}}
                i.fas.fa-chevron-down
                i.fas.fa-chevron-up
              .dropdown__content.dropdown__longdata
                ul
                  li(@click="clickDropDown('SL_JJ_NAME', 'all')" :class="dropdownChoice('all', jajeData.SL_JJ_NAME)") 전체
                    .search-division-line
                  li(@click="clickDropDown('SL_JJ_NAME', value.SL_JJ_NAME)" v-for="value, key in jajeCode.jajeList"  :class="dropdownChoice(value.SL_JJ_NAME, jajeData.SL_JJ_NAME)") {{value.SL_JJ_NAME}}
                    .search-division-line            
        //- tr.group-condition(id="blank-1" v-show="this.$store.getters.panel_size >= 438")
        //-   th.item-th.blank-th
        tr.group-condition(id="blank-2" v-show="this.$store.getters.panel_size >= 860")
          th.item-th.blank-th
        tr.group-condition(id="blank-3" v-show="this.$store.getters.panel_size >= 860")
          th.item-th.blank-th
        tr.group-condition(id="blank-4" v-show="this.$store.getters.panel_size >= 1000")
          th.item-th.blank-th
    .filter-footer
      button.search-btn(@click="searchJajeIO") 검색
      span.table-total 총 검색 결과 : {{totalCount}} 개
    //- b-table#search-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
  #search_condition.result-area(style="height:100%" v-show="resultTable")
    #search_result
      //- b-table#search-table(striped hover small selectable select-mode="single" @row-selected="rowSelected" :fields="fields" :items="items")
      table.result-table
        thead
          tr
            th.result-th-default
              .result-th 날짜
            th.result-th-default
              .result-th 자재명
            th.result-th-default
              .result-th 수량
            th.result-th-default
              .result-th 구분
            th.result-th-default
              .result-th 입/출고자
            th.result-th-default
              .result-th 주소1
            th.result-th-default
              .result-th 주소2
            th.result-th-default
              .result-th 주소3
            th.result-th-default
              .result-th 입/출고 사유
        tbody
          tr.result-body-tr(v-for="result in items" style="cursor:auto")
            td.td-center(@click="") {{jajeDateFormatter(result.jaje.SL_JJ_DATE)}}
            td(@click="") {{dataValueCheck(result.code, 'SL_JJ_NAME')}}
            td.td-center(@click="") {{dataValueCheck(result.jaje, 'SL_JJ_COUNT')}}
            td.td-center(@click="") {{result.jaje.SL_JJ_TYPE == "I"?"입고":"출고"}}
            td(@click="") {{dataValueCheck(result.jaje, 'SL_JJ_ID')}}
            td.td-center(@click="") {{dataValueCheck(result.light, 'SL_ADDR').split(" ")[0]}}
            td.td-center(@click="") {{dataValueCheck(result.light, 'SL_ADDR').split(" ")[1]}}
            td.td-center(@click="") {{dataValueCheck(result.light, 'SL_ADDR').split(" ")[2]}}
            td.table-cmd-button
              span(v-if="result.jaje.SL_NT_NO == undefined || result.jaje.SL_NT_NO == ''") {{dataValueCheck(result.jaje, 'SL_JJ_BIGO')}}
              button.jaje-button.jaje-search-compain(v-else @click="openComplain(dataValueCheck(result.jaje, 'SL_NT_NO'))") 민원 조회
          tr.non-result-table(v-show="items == ''")
            td(colspan=9 style="color:white") 검색된 자재 입출고 결과가 없습니다.
    #search_page
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-left' @click="movePage('first')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-right:7px;" icon='angle-left' @click="movePage('down')")
      span.result-page(v-if="items != ''" v-for="page in getNumbers(paging[0],paging[1])" @click="pageSelect(page)" :class="pageChoice(page)") {{page}}
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px; margin-left:7px;" icon='angle-right' @click="movePage('up')")
      font-awesome-icon.result-awssome(v-if="items != ''" style="width:20px; height:20px;" icon='angle-double-right' @click="movePage('end')")
  vm-alert(ref="alert" @event="alertEvent")
  transition(name='modal' v-if="loadData")
    .modal-background
      .modal-position
        .loader
        br
        | 데이터를 불러오는 중입니다
        br
        | 잠시만 기다려주세요
  transition(name='modal' v-if="retry")
    .modal-background
      .modal-position
        | 일시적으로 데이터를 불러오지 못했습니다
        br
        | 다시 시도해주세요
        br
        button.spinner-btn(@click="searchJajeIO") 다시 시도
</template>

<script>
import { EventBus } from "@/main";
import Vue from "vue";
import DateRangePicker from "vue2-daterange-picker";
import complainCode from "@/assets/json/complainCode.json";
import jajeCode from "@/assets/json/jajeCode.json";

export default {
  components: { DateRangePicker },
  data() {
    return {
      fields: [],
      items: [],
      parentEl: "#content",
      jajeData: {
        SL_JJ_TYPE: "all",
        SL_ADDR_1: "all",
        SL_ADDR_2: "all",
        SL_ADDR_3: "all",
        SL_JJ_NAME: "all",
        SL_JJ_DATE_START: new Date(),
        SL_JJ_DATE_END: new Date(),
        SL_ADDR: "",
        SL_JJ_CODE: "",
        PAGE: 1
      },
      jajeCode: {},
      paging: [1, 1, false, false, 1],
      dataRange: {
        startDate: new Date().setMonth(new Date().getMonth() - 1),
        endDate: new Date()
      },
      startDate: new Date().setMonth(new Date().getMonth() - 1),
      endDate: new Date(),
      opens: "right", //which way the picker opens, default "center", can be "left"/"right"
      locale: {
        direction: "ltr", //direction of text
        format: "YY.MM.DD", //fomart of the dates displayed
        separator: " - ", //separator between the two ranges
        applyLabel: "Apply",
        cancelLabel: "Cancel",
        weekLabel: "W",
        customRangeLabel: "Custom Range",
        daysOfWeek: this.moment.weekdaysMin(), //array of days - see moment documenations for details
        monthNames: this.moment.monthsShort(), //array of month names - see moment documenations for details
        firstDay: 1, //ISO first day of week - see moment documenations for details
        showWeekNumbers: true //show week numbers on each row of the calendar
      },
      ranges: {
        //default value for ranges object (if you set this to false ranges will no be rendered)
        All: [this.moment("1970-01-01"), this.moment()],
        Today: [this.moment(), this.moment()],
        Yesterday: [
          this.moment().subtract(1, "days"),
          this.moment().subtract(1, "days")
        ],
        "This month": [
          this.moment().startOf("month"),
          this.moment().endOf("month")
        ],
        "This year": [
          this.moment().startOf("year"),
          this.moment().endOf("year")
        ],
        "Last week": [
          this.moment()
            .subtract(1, "week")
            .startOf("week"),
          this.moment()
            .subtract(1, "week")
            .endOf("week")
        ],
        "Last month": [
          this.moment()
            .subtract(1, "month")
            .startOf("month"),
          this.moment()
            .subtract(1, "month")
            .endOf("month")
        ]
      },
      resultTable: false,
      loadData: false,
      code: {},
      modalData: {
        SL_SLNAME: "",
        SL_USERADDR: "",
        SL_DRDATA: "",
        SL_NT_NO: ""
      },
      modifyAuth: false,
      retry: false,
      totalCount: 0,
      jajeFilter: {
        addr1: ""
      }
    };
  },
  updated() {},
  watch: {},
  computed: {
    openPosition() {
      if (this.$store.getters.panel_location_name == "right") {
        return "left";
      } else {
        return "right";
      }
    }
  },
  methods: {
    dataValueCheck(data, value) {
      return data == undefined ? "" : data[value];
    },
    pageChoice(page) {
      if (page == this.jajeData.PAGE) {
        return "result-page-choice";
      } else {
        return "";
      }
    },
    pageSelect(page) {
      this.jajeData.PAGE = page;
      this.searchJajeIO();
    },
    movePage(check) {
      if (check == "down") {
        if (this.paging[2]) {
          this.jajeData.PAGE = this.paging[0] - 5 > 0 ? this.paging[0] - 5 : 1;
        }
      } else if (check == "up") {
        if (this.paging[3]) {
          this.jajeData.PAGE = this.paging[0] + 5;
        }
      } else if (check == "first") {
        this.jajeData.PAGE = 1;
      } else if (check == "end") {
        this.jajeData.PAGE = this.paging[4];
      }
      this.searchJajeIO();
    },
    getNumbers: (start, stop) => {
      return new Array(stop + 1 - start).fill(start).map((n, i) => n + i);
    },
    rowSelected(items) {
      console.log("items", items);
    },
    datepickerFormatter(date) {
      return this.moment(date).format("YYYY-MM-DD");
    },
    complainDateFormatter(date) {
      return date.substring(0, 16).replace("T", " ");
    },
    jajeDateFormatter(date) {
      return date.substring(0, 10);
    },
    updateDatepicker(value) {},
    toggleDropdown(event) {
      event.currentTarget.classList.toggle("is-active");
    },
    clickDropDown(type, data) {
      if (type == "addr1") {
        this.jajeData.SL_ADDR_1 = data;
        this.jajeData.SL_ADDR_2 = "all";
        this.jajeData.SL_ADDR_3 = "all";
      } else if (type == "addr2") {
        this.jajeData.SL_ADDR_2 = data;
        this.jajeData.SL_ADDR_3 = "all";
      } else if (type == "addr3") {
        this.jajeData.SL_ADDR_3 = data;
      } else {
        this.jajeData[type] = data;
      }
      $(".vp-jaje-io .dropdown__header").removeClass("is-active");
    },
    dropdownChoice(value, choice) {
      if (value.toString().split(":")[0] == choice.toString().split(":")[0]) {
        return "list-select";
      } else {
        return "";
      }
    },
    getPcauthAPI() {
      var vm = this;
      this.$_API_GET("pcauth").then(function(res) {
        if (
          res.grade.substring(0, 1) == "S" ||
          res.grade.substring(0, 1) == "A" ||
          res.grade.substring(0, 1) == "B"
        ) {
          vm.modifyAuth = true;
        } else {
          vm.modifyAuth = false;
        }
      });
    },
    checkAuth(type, position) {
      if (this.modifyAuth) {
        if (type == "INPROGRESS") {
          if (position == "right") {
            return "non-auth";
          } else {
            return "";
          }
        } else {
          return "";
        }
      } else {
        if (type == "READY") {
          if (position == "left") {
            return "non-auth";
          } else if (position == "center") {
            return "non-auth";
          }
        } else if (type == "INPROGRESS") {
          if (position == "left") {
            return "non-auth";
          } else if (position == "center") {
            return "non-auth";
          }
          return "maintenance-inprogress";
        } else if (type == "DONE") {
          if (position == "left") {
            return "non-auth";
          }
        }
      }
    },
    alertEvent() {},
    getJajeList(data, path) {
      // NOTE :: Get Jaje Code
      var vm = this;
      // this.loadData = true;
      return this.$_API_GET("jaje", data)
        .then(function(res) {
          vm.jajeCode["jajeList"] = res;
          // vm.loadData = false;
          vm.$forceUpdate();
        })
        .catch(() => {
          vm.loadData = false;
          vm.retry = true;
        });
    },
    searchJajeIO() {
      // NOTE :: 자재 입출고 리스트
      var vm = this;
      this.jajeData.SL_JJ_DATE_START = this.moment(
        this.dataRange.startDate
      ).format("YYYY-MM-DD");
      this.jajeData.SL_JJ_DATE_END = this.moment(this.dataRange.endDate).format(
        "YYYY-MM-DD"
      );

      var addr = ["SL_ADDR_1", "SL_ADDR_2", "SL_ADDR_3"];
      this.jajeData.SL_ADDR = "";
      for (var key in addr) {
        if (
          this.jajeData[addr[key]] != "all" &&
          this.jajeData[addr[key]] != undefined
        ) {
          this.jajeData.SL_ADDR += this.jajeData[addr[key]].split(":")[0] + " ";
        }
      }
      if (this.jajeData.SL_ADDR != "") {
        this.jajeData.SL_ADDR = this.jajeData.SL_ADDR.substring(
          0,
          this.jajeData.SL_ADDR.length - 1
        );
      }

      if (this.jajeData.SL_JJ_NAME != "all") {
        for (var row in this.jajeCode.jajeList) {
          if (
            this.jajeCode.jajeList[row].SL_JJ_NAME == this.jajeData.SL_JJ_NAME
          ) {
            this.jajeData.SL_JJ_CODE = this.jajeCode.jajeList[row].SL_JJ_CODE;
            break;
          }
        }
      }

      return this.$_API_GET("jaje/io", this.jajeData)
        .then(function(res) {
          vm.items = [];
          if (res.data.length == 0) {
            vm.loadData = false;
            vm.resultTable = true;
            vm.totalCount = 0;
          } else {
            for (var value in res.data) {
              if (value != "contains") {
                vm.items.push(res.data[value]);
              }
            }
            vm.paging = res.paging;
            $("#search_page").css("display", "flex");
            vm.resultTable = true;
            vm.loadData = false;
            vm.totalCount = res["total_count"];
          }
        })
        .catch(() => {
          vm.loadData = false;
          vm.retry = true;
        });
    },
    openComplain(data) {
      EventBus.$emit("modalOpen", data, "VMComplainInfo");
      Vue.nextTick(function() {
        EventBus.$emit(data + "setComplainInfo", data);
      });
    }
  },
  mounted() {
    var vm = this;
    this.code = JSON.parse(JSON.stringify(complainCode));
    this.jajeCode = JSON.parse(JSON.stringify(jajeCode));
    this.jajeCode["postcode"] = postcode;
    this.getJajeList();
    this.$store.commit("panel_size", 800);
    this.searchJajeIO();
    this.getPcauthAPI();

    Vue.nextTick(function() {
      $(".vp-jaje-io .item-td").focusout(function(e) {
        $(".vp-jaje-io .dropdown__header").removeClass("is-active");
      });
      $(".vp-jaje-io .result-table").on("mousewheel DOMMouseScroll", function(
        e
      ) {
        var E = e.originalEvent;
        var delta = 0;
        if (E.detail) {
          delta = E.detail * -40;
        } else {
          delta = E.wheelDelta;
        }
        if (delta > 0) {
          $(".vp-jaje-io #search_result").animate({ scrollLeft: "-=30" }, 0);
        } else {
          $(".vp-jaje-io #search_result").animate({ scrollLeft: "+=30" }, 0);
        }
      });
      $(".vp-jaje-io .slname-input").focus();
    });
  },
  beforeDestroy() {}
};
</script>

<style>
.rm-white-space {
  white-space: normal;
}
.show-calendar {
  display: block;
}

th.month {
  color: black;
}
.item-td .form-control {
  padding: 0px 0px 0px 4px;
  border: 0px;
}

.item-td .form-control * {
  font-size: 12px;
}

.non-auth {
  display: none;
}
.vp-jaje-io .jaje-button {
  border-radius: 5px;
  width: 100%;
  color: white;
  height: 100%;
  min-width: 60px;
  max-width: 60px;
  outline: none !important;
}
.jaje-search-compain {
  background-color: rgb(1, 106, 174);
  border: 1px solid rgb(1, 106, 174);
}
.jaje-search-compain:hover {
  border: 1px solid rgb(1, 106, 174);
  background-color: white;
  color: black;
}
.jaje-out {
  background-color: rgb(243, 126, 0);
  border: 1px solid rgb(243, 126, 0);
}
.jaje-out:hover {
  border: 1px solid rgb(243, 126, 0);
  background-color: white;
  color: black;
}
.jaje-del {
  background-color: #707070;
  border: 1px solid #707070;
}
.jaje-del:hover {
  border: 1px solid #707070;
  background-color: white;
  color: black;
}

.vp-jaje-io .vue-daterange-picker {
  height: 21px;
  width: 75%;
}
.vp-jaje-io .form-control {
  background-color: #2c2c2c;
  height: 20px;
  line-height: 16px;
  color: #fff;
  cursor: pointer;
}
.vp-jaje-io .vue-daterange-picker .reportrange-text {
  height: 22px;
  width: 100%;
  border: unset;
  background-color: #101010;
  padding: 0px;
  display: flex;
  align-items: center;
}
.vp-jaje-io .form-control span {
  width: 100%;
  text-align: left;
  margin-left: -4px;
}
.vp-jaje-io .date-picker-div > div {
  top: 2px;
}
.vp-jaje-io table tbody tr td.table-cmd-button {
  display: flex;
  justify-content: center;
  padding: 4px;
}
/* .vp-jaje-io table tbody tr td.table-cmd-button button:not(:last-child) {
  margin-right: 7px;
} */
.vp-jaje-io table tbody tr td.table-cmd-button button:first-child {
  margin-right: 0px;
}
.vp-jaje-io table tbody tr td.table-cmd-button button:nth-child(2) {
  margin-right: 7px;
}
.vp-jaje-io .panel-complain-list {
  position: absolute;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  color: #000 !important;
  top: 41%;
  left: 50%;
  transform: translateX(-50%);
  min-width: 322px;
}
.vp-jaje-io .alert-delete-red {
  color: red;
}
.vp-jaje-io .td-center {
  text-align: center;
  padding-left: 6px;
}
.vp-jaje-io .table-total {
  color: white;
  font-size: 12px;
  position: absolute;
  left: 20px;
  line-height: 60px;
}
.vp-jaje-io #search_result {
  /* height: calc(100vh - 110px); */
}
.vp-jaje-io .modal-icon {
  display: none;
}
.vp-jaje-io .modal-exit {
  padding-top: 10px;
}
.vp-jaje-io .transition-btn {
  padding-top: 3px;
}
</style>

<style lang="scss">
.vp-jaje-io .jaje-table {
  & .modal-title * {
    font-size: 13px;
  }
  & table {
    & * {
      font-size: 12px;
    }
    &.table-top-margin {
      margin-top: 10px;
    }
    border: 1px solid rgba(238, 238, 238, 1);
    border-collapse: separate;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    & > tr {
      height: 25px;
      & > th {
        border-bottom: 1px solid rgba(91, 91, 91, 0.3);
        padding: 0px;
        vertical-align: middle;
        text-align: left;
        background: #424242;
        color: #fff;
        & .indispensable {
          color: #f63f3f;
          font-size: 13px;
        }
      }
      & > th.modify-light-mode {
        background: #7d7d7d;
      }

      & > td {
        border-bottom: 1px solid rgba(238, 238, 238, 1);
        text-align: unset;
        vertical-align: middle;
        padding: 0px;
        & input {
          padding: 3px 3px 3px 7px;
          height: 100% !important;
          background: white !important;
          color: black !important;
        }
        & input.modify-disabled[type="text"]:disabled {
          background: lightgray !important;
        }
        & input.modify-disabled[type="Number"]:disabled {
          background: lightgray !important;
        }
        & input:focus {
          outline: #418fff auto 1px !important;
          outline-offset: -2px;
        }
        & textarea {
          border: 0px;
          width: 100%;
          padding: 2px 2px 2px 7px;
          height: 100px;
          resize: none;
          vertical-align: bottom;
          border-radius: 10px;
          border-right: #fff 1px solid;
        }
        & textarea.registerTypeAddr {
          height: 122px;
        }
      }
      & .table-vertical-top {
        vertical-align: top;
      }
    }

    & .left-first-child {
      -moz-border-radius: 10px 0 0 0px;
      -webkit-border-radius: 10px 0 0 0px;
      border-radius: 10px 0 0 0px;
    }

    & .left-last-child {
      -moz-border-radius: 0 10px 0px 0;
      -webkit-border-radius: 0 10px 0px 0;
      border-radius: 0 10px 0px 0;
    }

    & .right-first-child {
      -moz-border-radius: 0 0 0 10px;
      -webkit-border-radius: 0 0 0 10px;
      border-radius: 0 0 0 10px;
      border-bottom: 0px;
    }

    & .right-last-child {
      -moz-border-radius: 0 0 10px 0;
      -webkit-border-radius: 0 0 10px 0;
      border-radius: 0 0 10px 0;
      border-bottom: 0px;
    }

    & .last-clear-bottom {
      border-bottom: 0px;
    }
  }
}
</style>
