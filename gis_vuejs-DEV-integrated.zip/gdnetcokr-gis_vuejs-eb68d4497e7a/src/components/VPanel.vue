<template lang="pug">
#panel_area.v-panel
  #panel_header
    component(:is="isHeaderComponents")
  #panel_content
    component(:is="$store.getters.sidebar_content" v-on:onAlert="onAlert" :key="$store.getters.sidebar_onHeader")
  vm-alert(ref="alert" @event="alertEvent")
</template>

<script>
import VPDeviceTrouble from "@/components/panel/VPDeviceTrouble";
import VPDeviceHeader from "@/components/panel/VPDeviceHeader";
import VPDeviceSearch from "@/components/panel/VPDeviceSearch";

import VPComplaintHeader from "@/components/panel/VPComplaintHeader";
import VPComplaintList from "@/components/panel/VPComplaintList";

import VPDashboardHeader from "@/components/panel/VPDashboardHeader";
import VPDashboard from "@/components/panel/VPDashboard";

import VPJajeHeader from "@/components/panel/VPJajeHeader";
import VPJajeList from "@/components/panel/VPJajeList";
import VPJajeIO from "@/components/panel/VPJajeIO";

import VPReportHeader from "@/components/panel/VPReportHeader";
import VPReportTrouble from "@/components/panel/VPReportTrouble";
import VPReportInspection from "@/components/panel/VPReportInspection";
import VPReportJaje from "@/components/panel/VPReportJaje";

import Vue from "vue";
import { EventBus } from "@/main";

export default {
  components: {
    VPDeviceHeader,
    VPDeviceTrouble,
    VPDeviceSearch,
    VPComplaintHeader,
    VPComplaintList,
    VPDashboard,
    VPDashboardHeader,
    VPJajeHeader,
    VPJajeList,
    VPJajeIO,
    VPReportHeader,
    VPReportTrouble,
    VPReportInspection,
    VPReportJaje
  },
  data() {
    return {};
  },
  computed: {
    isHeaderComponents() {
      // NOTE :: Header Component 변경
      if (
        this.$store.getters.sidebar_content == "VPDeviceTrouble" ||
        this.$store.getters.sidebar_content == "VPDeviceSearch"
      ) {
        return "VPDeviceHeader";
      } else if (this.$store.getters.sidebar_content == "VPComplaintList") {
        return "VPComplaintHeader";
      } else if (this.$store.getters.sidebar_content == "VPDashboard") {
        return "VPDashboardHeader";
      } else if (
        this.$store.getters.sidebar_content == "VPJajeList" ||
        this.$store.getters.sidebar_content == "VPJajeIO"
      ) {
        return "VPJajeHeader";
      } else if (
        this.$store.getters.sidebar_content == "VPReportTrouble" ||
        this.$store.getters.sidebar_content == "VPReportJaje" ||
        this.$store.getters.sidebar_content == "VPReportInspection"
      ) {
        return "VPReportHeader";
      } else {
        return "";
      }
    }
  },
  methods: {
    onAlert(
      alertType,
      headerTitle,
      firstText,
      secondText,
      inputPlaceHolder,
      okBtn,
      cancelBtn
    ) {
      console.log("in VPanel Alert");
      this.$refs.alert.init(
        alertType,
        headerTitle,
        firstText,
        secondText,
        inputPlaceHolder,
        okBtn,
        cancelBtn
      );
    },
    alertEvent(key, inputData) {
      console.log("alert key", key);
      console.log("alert inputData", inputData);
    }
  },
  mounted() {},
  beforeDestroy() {}
};
</script>
<style>
#panel_area {
  pointer-events: auto;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  background: #3b3b3b;
  z-index: 51;
  overflow: auto;
}
#panel_area #panel_header {
  height: auto;
}
#panel_content {
  width: auto;
  height: 100%;
  display: inherit;
}
.result-awssome {
  color: rgb(200, 200, 200);
}

#panel_area input {
  outline: none;
}

.v-panel .modal-background {
  position: absolute;
  height: 100%;
  width: 100%;
  display: table;
  background: rgba(59, 59, 59, 0.85);
  z-index: 9999;
  bottom: 0px;
  border-radius: 10px;
}
.v-panel .modal-position {
  vertical-align: middle;
  display: table-cell;
  text-align: center;
  color: white;
  font-size: 12px;
}

.v-panel .loader {
  font-size: 5px;
  margin: 1px auto;
  text-indent: -9999em;
  width: 5em;
  height: 5em;
  border-radius: 50%;
  background: #1980df;
  background: -moz-linear-gradient(
    left,
    #1980df 10%,
    rgba(25, 128, 223, 0) 42%
  );
  background: -webkit-linear-gradient(
    left,
    #1980df 10%,
    rgba(25, 128, 223, 0) 42%
  );
  background: -o-linear-gradient(left, #1980df 10%, rgba(25, 128, 223, 0) 42%);
  background: -ms-linear-gradient(left, #1980df 10%, rgba(25, 128, 223, 0) 42%);
  background: linear-gradient(to right, #1980df 10%, rgba(25, 128, 223, 0) 42%);
  position: relative;
  -webkit-animation: load3 1.4s infinite linear;
  animation: load3 1.4s infinite linear;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
}
.v-panel .loader:before {
  width: 50%;
  height: 50%;
  background: #1980df;
  border-radius: 100% 0 0 0;
  position: absolute;
  top: 0;
  left: 0;
  content: "";
}
.v-panel .loader:after {
  background: rgba(59, 59, 59, 1);
  width: 80%;
  height: 80%;
  border-radius: 50%;
  content: "";
  margin: auto;
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
</style>
