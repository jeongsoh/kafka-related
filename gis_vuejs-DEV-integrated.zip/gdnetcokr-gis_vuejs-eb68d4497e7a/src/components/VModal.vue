<template lang="pug">
.modal.v-modal(:id="key")
  .modal-dialog(:class="modalPosition()" tabindex="0")
    component(:is="type" :id="id" :type="type" )
</template>

<script>
// NOTE :: 모달 전체 Component
import VMLight from "@/components/modal/VMLight";
import VMComplainRegister from "@/components/modal/VMComplainRegister";
import VMSearchAddr from "@/components/modal/VMSearchAddr";
import VMComplainInfo from "@/components/modal/VMComplainInfo";
import VMComplainHandle from "@/components/modal/VMComplainHandle";
import VMLightAdd from "@/components/modal/VMLightAdd";
import VMLightAddr from "@/components/modal/VMLightAddr";
import VMComplaintList from "@/components/modal/VMComplaintList";

import Vue from "vue";
import VMHeader from "@/components/modal/VMHeader.vue";
Vue.component("VMHeader", VMHeader);

export default {
  components: {
    VMLight,
    VMComplainRegister,
    VMSearchAddr,
    VMComplainInfo,
    VMComplainHandle,
    VMLightAdd,
    VMLightAddr,
    VMComplaintList
  },
  name: "Info",
  props: {
    id: {
      type: String, // Number
      required: true
    },
    type: {
      type: String,
      requied: false
    },
    count: {
      type: Number,
      requied: false
    }
  },
  data() {
    return {
      key: "{0}:{1}".format(this.id, this.type),
      modalIndex: 2000, // NOTE :: 다른 곳들에서 z-index를 너무 높게 사용 중이라서 여유있게 2000으로 설정. 추후 z-index 맞출 필요가 있음.
      modalCount: 0
    };
  },
  methods: {
    onClickModal() {
      console.log("onClickModal");
    },
    modalPosition() {
      return "modal-dialog-position";
    }
  },
  created() {
    console.log("created base modal");
  },
  mounted() {
    console.log("mounted base modal");
    console.log("hi modal!", this.id, this.type);
    var vm = this;
    $(".modal").modal({
      backdrop: false
    });
    this.modalCount = this.count;
    console.log("count", this.count);

    var windowHeight = window.innerHeight;
    var windowWidth = window.innerWidth;

    var countValue = this.count * 10;

    $("#" + this.id + "\\:" + this.type)
      .children()
      .css("top", windowHeight / 10 + countValue);
    $("#" + this.id + "\\:" + this.type)
      .children()
      .css("left", windowWidth / 6 + countValue);
    // $("#" + this.id + "\\:" + this.type)
    //   .children()
    //   .css("transform", "translate(-50%, -50%)");

    // NOTE :: 모달 종류별 크기 설정
    if (
      this.type == "VMLight" ||
      this.type == "VMSearchAddr" ||
      this.type == "VMLightAdd" ||
      this.type == "VMLightAddr"
    ) {
      $("#" + this.id + "\\:" + this.type)
        .children()
        .css("max-width", 518);
    } else if (this.type == "VMComplainHandle") {
      $("#" + this.id + "\\:" + this.type)
        .children()
        .css("max-width", 598);
    } else if (this.type == "VMComplainRegister") {
      $("#" + this.id + "\\:" + this.type)
        .children()
        .css("max-width", 300);
    } else {
      $("#" + this.id + "\\:" + this.type)
        .children()
        .css("max-width", 600);
    }

    // NOTE :: 모달 drag 기능
    $("#" + this.id + "\\:" + this.type)
      .children()
      .draggable({
        handle: ".modal-header",
        stop: function() {
          // NOTE :: 화면 밖으로 일정치 넘어가면 되돌아오는 기능
          console.log("draggable stop");
          if (
            vm.type == "VMLight" ||
            vm.type == "VMSearchAddr" ||
            vm.type == "VMLightAdd" ||
            vm.type == "VMLightAddr"
          ) {
            console.log("상세창 이동임");
            var dragRange = 400; // 반응이 되었을 때 이동하는 값
            var dragRangeSub = 400; // 반응하는 범위 값
          } else if (vm.type == "VMComplainInfo") {
            var dragRange = 500; // 반응이 되었을 때 이동하는 값
            var dragRangeSub = 500; // 반응하는 범위 값
          } else if (vm.type == "VMComplainHandle") {
            var dragRange = 160; // 반응이 되었을 때 이동하는 값
            var dragRangeSub = 160; // 반응하는 범위 값
          } else {
            var dragRange = 180; // 반응이 되었을 때 이동하는 값
            var dragRangeSub = 180; // 반응하는 범위 값
          }

          var top = $(this).position().top;
          var left = $(this).position().left;
          var bottom = $(this).position().top + $(this).height();
          var right = $(this).position().left + $(this).width();
          var subWidth = $(this).width() - ($(this).width() - dragRangeSub);
          var subHeight = $(this).height() - ($(this).height() - dragRangeSub);
          if (top < 0) top = 0;
          if (left < -dragRangeSub) left = -dragRange;
          if (bottom - $(this).height() + 40 > $(window).height())
            top = $(window).height() - 40;
          if (right > $(window).width() + subWidth)
            left = $(window).width() - $(this).width() + subWidth;
          $(this).animate(
            {
              top: top,
              left: left
            },
            250,
            "easeInOutCubic"
          );
        }
      })
      .mousedown(function() {
        // NOTE :: 모달 클릭 시 모달 중에서 제일 위로 올라오는 기능
        $(this)
          .parent()
          .css("z-index", vm.$store.getters.modalIndex);
        vm.$store.commit("modalIndex", vm.$store.getters.modalIndex + 1);
        // $(this)
        //   .attr("tabindex", 0)
        //   .focus();
      });

    $("#" + this.id + "\\:" + this.type)
      .children()
      .keydown(function(evt) {
        console.log("evt", evt);
        if (evt.keyCode == 13) {
          // NOTE :: alert Enter click 연결
          // console.log("keydown: " + evt.keyCode);
          // console.log("keydown: " + "#" + vm.id + "\\:" + vm.type);
          console.log(
            "alert",
            $("#" + vm.id + "\\:" + vm.type + " .vm-alert")
              .first()
              .is(":visible")
          );
          if (
            $("#" + vm.id + "\\:" + vm.type + " .vm-alert")
              .first()
              .is(":visible")
          ) {
            $("#" + vm.id + "\\:" + vm.type)
              .children()
              .attr("tabindex", 0)
              .focus();
            vm.$forceUpdate();
            $("#" + vm.id + "\\:" + vm.type + " .vm-alert button")
              .first()
              .click();
          }
        }
      });
    var vm = this;
    $(".modal").css("z-index", this.$store.getters.modalIndex);
    this.$store.commit("modalIndex", this.$store.getters.modalIndex + 1);
  },
  updated() {
    console.log("updated base modal");
  }
};
</script>

<style>
.v-modal {
  overflow-x: unset !important;
  overflow-y: unset !important;
}
.modal-header {
  cursor: move;
  padding-bottom: 0px;
  border-bottom: 0px;
  padding: 0px;
}
.vm-header {
  /* border-bottom: 0.6px solid rgba(195, 195, 195, 0.7); */
  width: 100%;
}
.modal-title {
  float: left;
}
.modal-tabs,
.modal-exit {
  float: right;
}
.modal-title .icon {
  width: 22px;
  height: 22px;
}
.modal-title h6 {
  display: inline;
  vertical-align: sub;
  margin: 0 0 0 4px;
  line-height: 15px;
}
.modal-header .close {
  cursor: pointer;
}

table {
  border-collapse: separate;
  width: 100%;
}
tr.empty,
tr.empty > * {
  padding: 0 !important;
  height: 0 !important;
  border: none !important;
  background: transparent;
}
table,
td,
th {
  font-size: 14px;
  font-weight: unset;
  word-break: break-all;
}
.modal tr {
  border-bottom: 0.6px solid rgba(195, 195, 195, 0.3);
}
table {
  border-collapse: separate;
}
td {
  font-weight: normal !important;
}
td,
th {
  padding: 6px 6px 6px 10px;
}
.vp-device-search #panel-table th,
.vp-report-trouble #panel-table th,
.vp-report-inspection #panel-table th,
.vp-jaje-list #panel-table th,
.vp-jaje-io #panel-table th,
.vp-complain-list #panel-table th {
  width: 200px; /* NOTE 크게 잡아둬야 밸런스가 맞음 */
}
td.has_child {
  padding: 0px !important;
}
td input {
  width: 100%;
  height: 100%;
  padding: 8.5px 6px 8px 10px;
}
/* td input:focus {
  background-color: yellow;
  outline: none;
} */

.btn-outline-primary:focus,
.btn-outline-primary.focus {
  -webkit-box-shadow: 0 0 0 0rem rgba(0, 123, 255, 0.5);
  box-shadow: 0 0 0 0rem rgba(0, 123, 255, 0.5);
}

table * {
  pointer-events: auto;
}
table th {
  cursor: default;
}
.btn:focus {
  outline: none;
}

.tab_menu {
  float: right;
  margin-top: 12px;
  width: 100%;
}
.tab_menu button {
  float: right;
  outline: none !important;
  box-shadow: none !important;
}
.tab_menu > * {
  /* padding: 0.3rem 0.5rem; */
  margin: 2px 3.5px 2px 3.5px;
  font-size: 14px;
  font-weight: bold;
  border-radius: 10px;
  color: black;
}

.v-modal .modal-background {
  position: absolute;
  height: 100%;
  width: 100%;
  display: table;
  background: rgba(255, 255, 255, 0.95);
  z-index: 9999;
  bottom: 0px;
  border-radius: 10px;
}
.v-modal .modal-position {
  vertical-align: middle;
  display: table-cell;
  text-align: center;
  color: black;
}
.modal-light-info,
.modal-light-config,
.modal-complain-direction,
.modal-comaplin-maintenance,
.modal-complain-info,
.modal-light-add {
  position: relative;
  display: grid;
}

.sub-modal-position {
  position: absolute;
  top: 10px;
  left: 10px;
}
.sub-modal-position-light-info {
  position: absolute;
  top: -43px;
  left: 10px;
}
.v-modal .form-control {
  color: #000;
}
</style>

<style>
.spinner-btn {
  margin-top: 10px;
  padding: 5px 13px 5px 13px;
  background-color: #424242;
  border-radius: 10px;
  color: white;
  /* box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); */
  text-align: center;
  outline: none !important;
}
.spinner-btn:hover {
  background-color: #016aae;
}
.spinner-left {
  margin-right: 7px;
}
.spinner-right {
  margin-left: 0px;
}
/* .modal th,
.modal td {
  border: 1.2px solid rgba(195, 195, 195, 0.3);
}
.modal tr {
  border: 0px;
} */
.table-none-borer {
  border: 0px;
}

textarea[disabled="disabled"],
select[disabled="disabled"],
input[disabled="disabled"] {
  background-color: white;
  color: black;
}
select[disabled="disabled"] {
  -webkit-appearance: none;
  -moz-appearance: none;
  padding-left: 10px;
}
.modal-remove-btn {
  border-color: rgb(210, 210, 210);
}
.modal-remove-btn:hover {
  background-color: rgb(210, 210, 210);
  border-color: rgb(210, 210, 210);
}
.modal-cancel-btn {
  border-color: rgb(210, 210, 210);
}
.modal-cancel-btn:hover {
  background-color: rgb(210, 210, 210);
  border-color: rgb(210, 210, 210);
}
.modal-modify-btn {
  border-color: rgb(0, 173, 239);
}
.modal-button-color-black {
  color: black;
}
/* .modify-light-mode {
  background-color: rgb(0, 173, 239);
} */
.modal-dialog {
  outline: none;
  margin-top: 20px;
  margin-left: 370px;
  border-radius: 6px;
}
.modal-dialog-position {
  top: 0px;
  margin-left: 0px;
  margin: 0px;
}
.modal-dialog-position-1 {
  top: 10px;
  margin-left: 380px;
}
.modal-dialog-position-2 {
  top: 20px;
  margin-left: 390px;
}
.modal-dialog-position-3 {
  top: 30px;
  margin-left: 400px;
}
.modal-dialog-position-4 {
  top: 40px;
  margin-left: 410px;
}
.modal-dialog-position-5 {
  top: 50px;
  margin-left: 420px;
}
.modal-content {
  border: 1px solid #bdbdbd;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
}
.tb-select {
  border: 0px;
  width: 100%;
  height: 100%;
  text-align-last: center;
  background: url("../assets/img/res/img/panel-header-arrow.png") no-repeat
    right #fff;
  -webkit-appearance: none;
  -moz-appearance: none;
}
.light-info-select {
  border: 0px;
  width: 100%;
  padding-left: 6px;
  background: url("../assets/img/res/img/panel-header-arrow.png") no-repeat
    right #fff;
  -webkit-appearance: none;
  -moz-appearance: none;
}
.background-none {
  background: none !important;
}
.background-padding-left {
  padding-left: 10px;
}
.table-select-full-th {
  padding: 0px;
}
.table-select-full-td {
  padding: 8px 8px 8px 10px !important;
}
.config-td-span {
  display: block;
}

.v-modal .modal-body {
  padding: 0px 12px 12px 12px;
  outline: none;
}
.v-modal .loader {
  font-size: 5px;
  margin: 1px auto;
  text-indent: -9999em;
  width: 5em;
  height: 5em;
  border-radius: 50%;
  background: #1980df;
  background: -moz-linear-gradient(
    left,
    #1980df 10%,
    rgba(25, 128, 223, 0) 42%
  );
  background: -webkit-linear-gradient(
    left,
    #1980df 10%,
    rgba(25, 128, 223, 0) 42%
  );
  background: -o-linear-gradient(left, #1980df 10%, rgba(25, 128, 223, 0) 42%);
  background: -ms-linear-gradient(left, #1980df 10%, rgba(25, 128, 223, 0) 42%);
  background: linear-gradient(to right, #1980df 10%, rgba(25, 128, 223, 0) 42%);
  position: relative;
  -webkit-animation: load3 1.4s infinite linear;
  animation: load3 1.4s infinite linear;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
}
.v-modal .loader:before {
  width: 50%;
  height: 50%;
  background: #1980df;
  border-radius: 100% 0 0 0;
  position: absolute;
  top: 0;
  left: 0;
  content: "";
}
.v-modal .loader:after {
  background: rgba(255, 255, 255, 1);
  width: 80%;
  height: 80%;
  border-radius: 50%;
  content: "";
  margin: auto;
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.v-modal .alert-delete-red {
  color: red;
}
.v-modal .vm-complain-handle {
  position: relative;
  background-color: rgba(0, 0, 0, 0);
}
.v-modal .vm-complain-handle .sub-modal-position {
  top: 0px;
  left: 0px;
}
.v-modal .modal-dialog .modal-complain-info .vm-complain-handle {
  position: absolute;
  background-color: rgba(0, 0, 0, 0.4);
}
.v-modal
  .modal-dialog
  .modal-complain-info
  .vm-complain-handle
  .sub-modal-position {
  top: 10px;
  left: 10px;
}
</style>
