import Vue from "vue";
import Router from "vue-router";
import Login from "@/views/Login.vue";

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: "/",
      redirect: "Login"
    },
    {
      path: "/login",
      name: "Login",
      component: Login
    },
    {
      path: "/map",
      name: "Maps",
      component: () => import(/* webpackChunkName: "map" */ "@/vue/Layout")
    },
    {
      path: "/print/map",
      name: "PrintMap",
      component: () =>
        import(/* webpackChunkName: "map" */ "@/components/printMap")
    }
  ]
});
