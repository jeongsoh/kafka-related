import axios from "axios";

if (process.env.VUE_APP_DEBUG == "true") {
  axios.defaults.baseURL = process.env.VUE_APP_URL + "/lora/";
} else {
  axios.defaults.baseURL = "/lora/";
}

export default {
  METHOD: {
    GET: "GET",
    POST: "POST",
    PUT: "PUT",
    DELETE: "DELETE"
  },
  CACHE_VAL_ID: "__ID__",
  CACHE_TTL_KEY: "__TTL__",
  CACHE_API_KEY: "__APIKEY__",
  CACHE_VAL_JSON_PREFIX: "_JSON_:",
  CACHE_AREA_NAME: "__AREANAME__",
  spinnerCount: 0,
  async API(method, url, data, cacheTime, hasSpinner, ignoreError) {
    if (data == undefined) {
      data = {};
    }
    data["_apiKey"] = this.getCache(this.CACHE_API_KEY);
    data["ID"] = this.getCache(this.CACHE_VAL_ID);
    // data['_apiKey'] = 'cache 가져오는 부분'
    if (method != "GET") {
      data = JSON.stringify(data);
    }
    let $_res = "";
    try {
      if (method == "GET") {
        $_res = this.get(url, data);
      } else if (method == "POST") {
        $_res = this.post(url, data);
      } else if (method == "DELETE") {
        let n_data = JSON.parse(data);
        n_data["_httpMethod"] = "DELETE";
        n_data = JSON.stringify(n_data);
        $_res = this.post(url, n_data);
      } else if (method == "UPDATE") {
        let n_data = JSON.parse(data);
        n_data["_httpMethod"] = "UPDATE";
        n_data = JSON.stringify(n_data);
        $_res = this.post(url, n_data);
      }
    } catch (err) {
      console.error(err);
    }
    return $_res;
  },
  async get($_url, data) {
    return new Promise(resolve => {
      if (data) {
        $_url += "?";
        Object.keys(data).forEach($_key => {
          let $_val = data[$_key];
          $_url += `${$_key}=${$_val}&`;
        });
        $_url = $_url.substr(0, $_url.length - 1);
      }
      return axios
        .get($_url)
        .then(res => {
          if (res.status == 200) {
            resolve(res.data.data);
          } else {
            console.log("ERR");
            resolve(false);
          }
        })
        .catch(err => {
          var data = err.response;
          if (
            data != undefined &&
            data.data.data.indexOf("AssertionError: ") != -1
          ) {
            var msg = data.data.data.split("AssertionError: ")[1].trim();
            if (msg == "로그인 후 이용할 수 있습니다.") {
              delCache(CACHE_API_KEY);
              if (!DEBUG_MODE) window.location = "";
            } else if (msg == "인증시간만료, 다시 로그인 해주십시오.") {
              alert("인증시간만료, 다시 로그인 해주십시오.");
              delCache(CACHE_API_KEY);
              if (!DEBUG_MODE) window.location = "";
            } else if (msg != "") {
              // if (!ignoreError) {
              //     alert("다음의 오류가 발생하여 처리되지 않았습니다.\n- " + msg);
              // }
            }
          } else {
            // alert("오류가 발생하여 정상적으로 처리되지 않았습니다.");
          }
          let $_error = "ERROR OCCUR " + $_url;
          throw new Error(data.data.data.split("AssertionError: ")[1].trim());
        });
    });
  },
  async post($_url, body) {
    return axios
      .post($_url, body)
      .then(res => {
        console.log("SUCCESS");
        // console.log(res);
        if (res.status == 200) {
          return res.data;
        } else {
          return false;
        }
      })
      .catch(err => {
        var data = err.response;
        if (
          data != undefined &&
          data.data.data.indexOf("AssertionError: ") != -1
        ) {
          var msg = data.data.data.split("AssertionError: ")[1].trim();
          if (msg == "정보가 일치하지 않습니다.") {
            alert("정보가 일치하지 않습니다.");
          }
        } else {
          // alert("오류가 발생하여 정상적으로 처리되지 않았습니다.");
        }
        let $_error = "ERROR OCCUR " + $_url;
        throw new Error(data.data.data.split("AssertionError: ")[1].trim());
      });
  },
  async delete($_url, body) {
    return axios
      .post($_url, body)
      .then(res => {
        console.log("SUCCESS");
        // console.log(res);
        if (res.status == 200) {
          return res.data;
        } else {
          return false;
        }
      })
      .catch(err => {
        let $_error = "delete Err " + $_url;
        throw new Error($_error);
      });
  },
  getCache(key, defaultVal) {
    if (localStorage && key in localStorage) {
      var ttlKey = this.CACHE_TTL_KEY + "." + key;
      if (ttlKey in localStorage && localStorage[ttlKey] <= Date.now()) {
        if (key == this.CACHE_API_KEY) {
          // NOTE api key의 validation 체크는 서버 루틴을 통한다.
          //window.location = 'index.html';
        }
        return defaultVal;
      }
      var val = localStorage[key];
      if (
        val.substr(0, this.CACHE_VAL_JSON_PREFIX.length) ==
        this.CACHE_VAL_JSON_PREFIX
      ) {
        val = val.substr(this.CACHE_VAL_JSON_PREFIX.length);
        val = JSON.parse(val);
      }
      return val;
    }
    return defaultVal;
  },
  setCache(key, val, TTL_ms) {
    if (localStorage) {
      if (typeof val == "object") {
        val = this.CACHE_VAL_JSON_PREFIX + JSON.stringify(val);
      }
      localStorage[key] = val;
      if (typeof TTL_ms == "number") {
        localStorage[this.CACHE_TTL_KEY + "." + key] = Date.now() + TTL_ms;
      } else if (TTL_ms != undefined) {
        console.error("TTL_ms must be number..");
      }
    }
  },
  delCache(key, defaultVal) {
    if (localStorage && key in localStorage) {
      var ttlKey = this.CACHE_TTL_KEY + "." + key;
      if (ttlKey in localStorage) delete localStorage[ttlKey];

      if (key in localStorage) {
        delete localStorage[key];
        return true;
      }
    }
    return false;
  },
  install(Vue, option) {
    Vue.prototype.$_API_GET = (
      url,
      data,
      cacheTime,
      hasSpinner,
      ignoreError
    ) => {
      return this.API("GET", url, data, cacheTime, hasSpinner, ignoreError);
    };
    Vue.prototype.$_API_POST = (url, data) => {
      return this.API("POST", url, data);
    };
    Vue.prototype.$_API_UPDATE = (url, data) => {
      return this.API("UPDATE", url, data);
    };
    Vue.prototype.$_API_DELETE = (url, data) => {
      return this.API("DELETE", url, data);
    };
    Vue.prototype.$_API_SET_CACHE = (key, val, TTL_ms) => {
      return this.setCache(key, val, TTL_ms);
    };
    Vue.prototype.$_API_GET_CACHE = (key, defaultVal) => {
      return this.getCache(key, defaultVal);
    };
    Vue.prototype.$_API_DEL_CACHE = (key, defaultVal) => {
      return this.delCache(key, defaultVal);
    };
    Vue.prototype.deepCopy = key => {
      var data = JSON.stringify(key);
      return JSON.parse(data);
    };
    Vue.prototype.$_API_SHOW_SPINNER = () => {
      if (this.spinnerCount == 0) {
        //var spinner = "<div id='spinner' style='position:fixed; height:100%; width:100%; display:table; background:rgba(0,0,0,0.5); z-index:9999;'><div align='center' style='vertical-align:middle; display:table-cell;'><svg width='96px' height='96px' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' preserveAspectRatio='xMidYMid' class='uil-default'><rect x='0' y='0' width='100' height='100' fill='none' class='bk'></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(0 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-1s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(30 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.9166666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(60 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.8333333333333334s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(90 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.75s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(120 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.6666666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(150 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.5833333333333334s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(180 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.5s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(210 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.4166666666666667s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(240 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.3333333333333333s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(270 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.25s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(300 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.16666666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#00b2ff' transform='rotate(330 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='-0.08333333333333333s' repeatCount='indefinite'/></rect></svg><div id='spinnerText' style='color:white;'></div></div></div>";
        // refer: https://loading.io/css/
        var spinner =
          "<div id='spinner' style='position:fixed; height:100%; width:100%; display:table; background:rgba(0,0,0,0.5); z-index:9999;'><div align='center' style='vertical-align:middle; display:table-cell;'>";
        spinner +=
          "<div class='lds-spinner'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>";
        spinner += "<div id='spinnerText' style='color:white;'></div>";
        $("body").prepend(spinner);
      }
      this.spinnerCount++;
    };
    Vue.prototype.$_API_HIDE_SPINNER = () => {
      this.spinnerCount--;
      if (this.spinnerCount <= 0) {
        this.spinnerCount = 0;
        $("#spinner").remove();
      }
    };
  }
};
