import axios from "axios";

if (process.env.VUE_APP_DEBUG == "true") {
  axios.defaults.baseURL = process.env.VUE_APP_URL + "/lora/";
} else {
  axios.defaults.baseURL = "/lora/";
}
import { mapGetters } from "vuex";

export default {
  data() {
    return {
      METHOD: {
        GET: "GET",
        POST: "POST",
        PUT: "PUT",
        DELETE: "DELETE"
      }
    };
  },
  methods: {
    API_GET(url, data, cacheTime, hasSpinner, ignoreError) {
      return this.API("GET", url, data, cacheTime, hasSpinner, ignoreError);
    },
    API_POST(url, data) {
      return this.API("POST", url, data);
    },
    API_UPDATE(url, data) {
      // API_PUT
      if (data == undefined) data = {};
      data["_httpMethod"] = "UPDATE";
      return this.API_POST(url, data);
    },
    API_DELETE(url, data) {
      if (data == undefined) data = {};
      data["_httpMethod"] = "DELETE";
      return this.API_POST(url, data);
    },
    async API(method, url, data, cacheTime, hasSpinner, ignoreError) {
      if (data == undefined) {
        data = {};
      }
      // data['_apiKey'] = getCache(CACHE_API_KEY);
      // data['_apiKey'] = 'cache 가져오는 부분'
      if (method != "GET") {
        data = JSON.stringify(data);
      }
      let $_res = "";
      try {
        if (method == "GET") {
          $_res = this.get(url, data);
        } else if (method == "POST") {
          $_res = this.post(url, data);
        }
      } catch (err) {
        console.error(err);
      }
      console.log($_res);
      return $_res;
    },
    async get($_url, data) {
      return new Promise(resolve => {
        if (data) {
          $_url += "?";
          Object.keys(data).forEach($_key => {
            let $_val = data[$_key];
            $_url += `${$_key}=${$_val}&`;
          });
          $_url = $_url.substr(0, $_url.length - 1);
        }
        console.log($_url);
        return axios
          .get($_url)
          .then(res => {
            if (res.status == 200) {
              resolve(res.data.data);
            } else {
              console.log("ERR");
              resolve(false);
            }
          })
          .catch(err => {
            resolve(false);
            let $_error = "ERROR OCCUR " + $_url;
            throw new Error($_error);
          });
      });
    },
    async post($_url, body) {
      return axios
        .post($_url, body)
        .then(res => {
          console.log("SUCCESS");
          console.log(res);
          if (res.status == 200) {
            return res.data;
          } else {
            return false;
          }
        })
        .catch(err => {
          let $_error = "Post Err " + $_url;
          throw new Error($_error);
        });
    }
  }
};
